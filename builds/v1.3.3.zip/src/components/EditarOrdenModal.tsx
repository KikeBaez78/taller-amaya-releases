'use client';

import React, { useState, useEffect } from 'react';
import { StorageService } from '@/lib/storage';
import {
  WorkOrder,
  Vehicle,
  Client,
  Company,
  FuelLevel,
  OrderStatus,
  ServiceItem,
  HistorialModificacion,
} from '@/types';
import {
  X,
  Save,
  Car,
  User,
  Wrench,
  Fuel,
  FileText,
  Clock,
  Check,
  Plus,
  Trash2,
  ShieldCheck,
  History,
  AlertCircle,
} from 'lucide-react';

interface EditarOrdenModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: WorkOrder;
  onOrderUpdated: (updatedOrder: WorkOrder) => void;
}

export const EditarOrdenModal: React.FC<EditarOrdenModalProps> = ({
  isOpen,
  onClose,
  order,
  onOrderUpdated,
}) => {
  const mechanics = StorageService.getMechanics();
  const vehicles = StorageService.getVehicles();
  const clients = StorageService.getClients();
  const companies = StorageService.getCompanies();

  const currentVehicle = vehicles.find((v) => v.id === order.vehiculoId);
  const currentClient = clients.find((c) => c.id === order.clienteId);
  const currentCompany = companies.find((co) => co.id === order.empresaId);

  // 1. Datos del Cliente
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [clientWhatsApp, setClientWhatsApp] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [clientAddress, setClientAddress] = useState('');

  // 2. Datos del Chofer
  const [choferNombre, setChoferNombre] = useState('');
  const [choferTelefono, setChoferTelefono] = useState('');

  // 3. Datos del Vehículo
  const [placas, setPlacas] = useState('');
  const [numeroEconomico, setNumeroEconomico] = useState('');
  const [marca, setMarca] = useState('');
  const [modelo, setModelo] = useState('');
  const [ano, setAno] = useState<number>(2020);
  const [color, setColor] = useState('');
  const [motor, setMotor] = useState('');
  const [vin, setVin] = useState('');
  const [kilometraje, setKilometraje] = useState<number>(0);
  const [combustible, setCombustible] = useState<FuelLevel>('1/2');

  // 4. Datos de la Orden
  const [folio, setFolio] = useState('');
  const [fallaReportada, setFallaReportada] = useState('');
  const [estado, setEstado] = useState<OrderStatus>('recepcion');
  const [refaccionesCliente, setRefaccionesCliente] = useState<string[]>([]);
  const [nuevaRefaccion, setNuevaRefaccion] = useState('');

  // 5. Servicios / Mano de Obra
  const [servicios, setServicios] = useState<ServiceItem[]>([]);
  const [nuevoConcepto, setNuevoConcepto] = useState('');
  const [nuevoCosto, setNuevoCosto] = useState<number>(0);
  const [nuevoMecanicoId, setNuevoMecanicoId] = useState<string>(mechanics[0]?.id || 'unassigned');
  const [nuevaComision, setNuevaComision] = useState<number>(mechanics[0]?.comisionDefault || 30);

  // 6. Auditoría de Modificación
  const [usuarioModifica, setUsuarioModifica] = useState('Reyna Amaya (PIN 2036)');
  const [motivoModificacion, setMotivoModificacion] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  // Cargar datos al abrir modal
  useEffect(() => {
    if (order) {
      const v = vehicles.find((veh) => veh.id === order.vehiculoId);
      const c = clients.find((cli) => cli.id === order.clienteId);
      const comp = companies.find((co) => co.id === order.empresaId);

      setFolio(order.folio);
      setFallaReportada(order.fallaReportada);
      setEstado(order.estado);
      setKilometraje(order.kilometrajeEntrada);
      setCombustible(order.nivelCombustible || '1/2');
      setChoferNombre(order.choferNombre || v?.choferHabitual || '');
      setChoferTelefono(order.choferTelefono || v?.choferTelefono || '');
      setRefaccionesCliente(order.refaccionesCliente ? [...order.refaccionesCliente] : []);

      // Cliente
      if (comp) {
        setClientName(comp.razonSocial);
        setClientPhone(comp.telefonos?.[0] || '');
        setClientWhatsApp(comp.telefonos?.[0]?.replace(/\D/g, '') || '');
        setClientEmail(comp.correos?.[0] || '');
        setClientAddress(comp.direccion || '');
      } else if (c) {
        setClientName(c.nombre);
        setClientPhone(c.telefono);
        setClientWhatsApp(c.whatsapp || c.telefono);
        setClientEmail(c.correo || '');
        setClientAddress(c.direccion || '');
      }

      // Vehículo
      if (v) {
        setPlacas(v.placas);
        setNumeroEconomico(v.numeroEconomico || '');
        setMarca(v.marca);
        setModelo(v.modelo);
        setAno(v.ano);
        setColor(v.color);
        setMotor(v.motor || '');
        setVin(v.vin || '');
      }

      // Servicios
      setServicios(
        order.servicios?.map((s) => ({
          ...s,
        })) || []
      );

      setUsuarioModifica('Reyna Amaya (PIN 2036)');
      setMotivoModificacion('');
    }
  }, [order, isOpen]);

  if (!isOpen) return null;

  // Manejo de refacciones del cliente
  const handleAddRefaccion = () => {
    if (!nuevaRefaccion.trim()) return;
    setRefaccionesCliente([...refaccionesCliente, nuevaRefaccion.trim()]);
    setNuevaRefaccion('');
  };

  const handleRemoveRefaccion = (idx: number) => {
    setRefaccionesCliente(refaccionesCliente.filter((_, i) => i !== idx));
  };

  // Manejo de servicios
  const handleAddService = () => {
    if (!nuevoConcepto.trim() || nuevoCosto <= 0) {
      alert('Ingresa el concepto del servicio y el costo mayor a $0');
      return;
    }
    const mec = mechanics.find((m) => m.id === nuevoMecanicoId);
    const mecName = mec ? mec.nombre : 'Por Asignar Bahía';
    const comisionManoObra = Math.round(nuevoCosto * (nuevaComision / 100));

    const newSrv: ServiceItem = {
      id: `srv-${Date.now()}`,
      concepto: nuevoConcepto.trim(),
      mecanicoId: mec ? mec.id : 'unassigned',
      mecanicoNombre: mecName,
      manoObra: nuevoCosto,
      refaccionesMonto: 0,
      comisionPorcentaje: nuevaComision,
      comisionManoObra,
      estado: 'pendiente',
    };

    setServicios([...servicios, newSrv]);
    setNuevoConcepto('');
    setNuevoCosto(0);
  };

  const handleUpdateServiceField = (
    srvId: string,
    field: keyof ServiceItem,
    value: any
  ) => {
    setServicios(
      servicios.map((s) => {
        if (s.id === srvId) {
          const updated = { ...s, [field]: value };
          if (field === 'manoObra' || field === 'comisionPorcentaje') {
            const cost = field === 'manoObra' ? Number(value) || 0 : s.manoObra;
            const comm = field === 'comisionPorcentaje' ? Number(value) || 0 : s.comisionPorcentaje;
            updated.comisionManoObra = Math.round(cost * (comm / 100));
          }
          if (field === 'mecanicoId') {
            const found = mechanics.find((m) => m.id === value);
            updated.mecanicoNombre = found ? found.nombre : 'Por Asignar Bahía';
            if (found) {
              updated.comisionPorcentaje = found.comisionDefault;
              updated.comisionManoObra = Math.round(updated.manoObra * (found.comisionDefault / 100));
            }
          }
          return updated;
        }
        return s;
      })
    );
  };

  const handleRemoveService = (srvId: string) => {
    if (servicios.length <= 1) {
      if (!confirm('¿Seguro que deseas eliminar el único servicio de la orden?')) return;
    }
    setServicios(servicios.filter((s) => s.id !== srvId));
  };

  // Guardar todas las modificaciones y registrar auditoría
  const handleSaveAll = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!placas.trim()) {
      alert('Las placas del vehículo no pueden quedar vacías.');
      return;
    }

    // 1. Detectar cambios exactos para la auditoría
    const cambiosDetectados: string[] = [];

    // Cambios en vehículo
    if (currentVehicle) {
      if (currentVehicle.placas !== placas.trim().toUpperCase()) {
        cambiosDetectados.push(`Placas: "${currentVehicle.placas}" ➔ "${placas.trim().toUpperCase()}"`);
      }
      if (currentVehicle.marca !== marca.trim()) {
        cambiosDetectados.push(`Marca: "${currentVehicle.marca}" ➔ "${marca.trim()}"`);
      }
      if (currentVehicle.modelo !== modelo.trim()) {
        cambiosDetectados.push(`Modelo: "${currentVehicle.modelo}" ➔ "${modelo.trim()}"`);
      }
      if (currentVehicle.ano !== Number(ano)) {
        cambiosDetectados.push(`Año: ${currentVehicle.ano} ➔ ${ano}`);
      }
      if (currentVehicle.color !== color.trim()) {
        cambiosDetectados.push(`Color: "${currentVehicle.color}" ➔ "${color.trim()}"`);
      }
      if ((currentVehicle.numeroEconomico || '') !== numeroEconomico.trim()) {
        cambiosDetectados.push(`No. Económico: "${currentVehicle.numeroEconomico || 'N/A'}" ➔ "${numeroEconomico.trim() || 'N/A'}"`);
      }
      if ((currentVehicle.vin || '') !== vin.trim()) {
        cambiosDetectados.push(`VIN: "${currentVehicle.vin || 'N/A'}" ➔ "${vin.trim() || 'N/A'}"`);
      }
      if ((currentVehicle.motor || '') !== motor.trim()) {
        cambiosDetectados.push(`Motor: "${currentVehicle.motor || 'N/A'}" ➔ "${motor.trim() || 'N/A'}"`);
      }
    }

    // Cambios en cliente
    if (currentClient) {
      if (currentClient.nombre !== clientName.trim()) {
        cambiosDetectados.push(`Cliente: "${currentClient.nombre}" ➔ "${clientName.trim()}"`);
      }
      if (currentClient.telefono !== clientPhone.trim()) {
        cambiosDetectados.push(`Teléfono: "${currentClient.telefono}" ➔ "${clientPhone.trim()}"`);
      }
      if ((currentClient.correo || '') !== clientEmail.trim()) {
        cambiosDetectados.push(`Correo: "${currentClient.correo || 'N/A'}" ➔ "${clientEmail.trim() || 'N/A'}"`);
      }
      if ((currentClient.direccion || '') !== clientAddress.trim()) {
        cambiosDetectados.push(`Dirección: "${currentClient.direccion || 'N/A'}" ➔ "${clientAddress.trim() || 'N/A'}"`);
      }
    }

    // Cambios en orden
    if (order.folio !== folio.trim()) {
      cambiosDetectados.push(`Folio: #${order.folio} ➔ #${folio.trim()}`);
    }
    if (order.fallaReportada !== fallaReportada.trim()) {
      cambiosDetectados.push(`Falla: "${order.fallaReportada}" ➔ "${fallaReportada.trim()}"`);
    }
    if (order.estado !== estado) {
      cambiosDetectados.push(`Estatus: ${order.estado} ➔ ${estado}`);
    }
    if (order.kilometrajeEntrada !== Number(kilometraje)) {
      cambiosDetectados.push(`Odómetro: ${order.kilometrajeEntrada} km ➔ ${kilometraje} km`);
    }
    if (order.nivelCombustible !== combustible) {
      cambiosDetectados.push(`Combustible: ${order.nivelCombustible} ➔ ${combustible}`);
    }
    if ((order.choferNombre || '') !== choferNombre.trim()) {
      cambiosDetectados.push(`Chofer: "${order.choferNombre || 'N/A'}" ➔ "${choferNombre.trim() || 'N/A'}"`);
    }

    // Cambios en servicios
    const subtotalManoObra = servicios.reduce((acc, s) => acc + (s.manoObra || 0), 0);
    if (order.subtotalManoObra !== subtotalManoObra) {
      cambiosDetectados.push(`Mano de Obra Total: $${order.subtotalManoObra} ➔ $${subtotalManoObra}`);
    }

    // Si no hubo cambios, solo cerrar
    if (cambiosDetectados.length === 0) {
      alert('No se detectaron cambios en la orden.');
      onClose();
      return;
    }

    // 2. Registrar en Historial de Modificaciones
    const nuevaAuditoria: HistorialModificacion = {
      id: `audit-${Date.now()}`,
      fecha: new Date().toLocaleString(),
      usuario: usuarioModifica.trim() || 'Reyna Amaya (PIN 2036)',
      motivo: motivoModificacion.trim() || undefined,
      cambios: cambiosDetectados,
    };

    const historialActualizado = [
      ...(order.historialModificaciones || []),
      nuevaAuditoria,
    ];

    // 3. Preparar Vehículo
    let effectiveVehicleId = order.vehiculoId;
    let targetVehicle: Vehicle;

    if (currentVehicle) {
      const allOrders = StorageService.getWorkOrders();
      const otherOrdersSharingVehicle = allOrders.filter(
        (o) => o.id !== order.id && o.vehiculoId === order.vehiculoId
      );

      const hasVehicleIdentityChanges =
        currentVehicle.marca !== (marca.trim() || currentVehicle.marca) ||
        currentVehicle.modelo !== (modelo.trim() || currentVehicle.modelo) ||
        currentVehicle.placas !== placas.trim().toUpperCase() ||
        currentVehicle.ano !== Number(ano) ||
        currentVehicle.color !== (color.trim() || currentVehicle.color);

      // Si otras órdenes del cliente comparten este vehículo y se modificó algún dato del auto:
      // Desacoplarlo para que esta orden tenga su propio vehículo independiente sin afectar a las demás
      if (otherOrdersSharingVehicle.length > 0 && hasVehicleIdentityChanges) {
        effectiveVehicleId = `veh-${Date.now()}`;
        targetVehicle = {
          ...currentVehicle,
          id: effectiveVehicleId,
          placas: placas.trim().toUpperCase() || 'NO TRAE',
          numeroEconomico: numeroEconomico.trim() || undefined,
          marca: marca.trim() || currentVehicle.marca,
          modelo: modelo.trim() || currentVehicle.modelo,
          ano: Number(ano) || currentVehicle.ano,
          color: color.trim() || currentVehicle.color,
          motor: motor.trim() || undefined,
          vin: vin.trim() || undefined,
          kilometrajeActual: Number(kilometraje) || currentVehicle.kilometrajeActual,
          choferHabitual: choferNombre.trim() || undefined,
          choferTelefono: choferTelefono.trim() || undefined,
        };
      } else {
        // Es el único vehículo de esta orden: actualizar directamente
        targetVehicle = {
          ...currentVehicle,
          placas: placas.trim().toUpperCase(),
          numeroEconomico: numeroEconomico.trim() || undefined,
          marca: marca.trim() || currentVehicle.marca,
          modelo: modelo.trim() || currentVehicle.modelo,
          ano: Number(ano) || currentVehicle.ano,
          color: color.trim() || currentVehicle.color,
          motor: motor.trim() || undefined,
          vin: vin.trim() || undefined,
          kilometrajeActual: Number(kilometraje) || currentVehicle.kilometrajeActual,
          choferHabitual: choferNombre.trim() || undefined,
          choferTelefono: choferTelefono.trim() || undefined,
        };
      }
    } else {
      // Si la orden no tenía vehículo asignado
      effectiveVehicleId = `veh-${Date.now()}`;
      targetVehicle = {
        id: effectiveVehicleId,
        clienteId: currentClient?.id || `cli-${Date.now()}`,
        placas: placas.trim().toUpperCase() || 'NO TRAE',
        marca: marca.trim() || 'Genérica',
        modelo: modelo.trim() || 'Sedán',
        ano: Number(ano) || 2020,
        color: color.trim() || 'Blanco',
        motor: motor.trim() || undefined,
        vin: vin.trim() || undefined,
        kilometrajeActual: Number(kilometraje) || 0,
        choferHabitual: choferNombre.trim() || undefined,
        choferTelefono: choferTelefono.trim() || undefined,
        ultimoServicioFecha: new Date().toISOString().split('T')[0],
        ultimoServicioKm: Number(kilometraje) || 0,
      };
    }

    // 4. Preparar Cliente
    let targetClient: Client | undefined = undefined;
    if (currentClient) {
      targetClient = {
        ...currentClient,
        nombre: clientName.trim() || currentClient.nombre,
        telefono: clientPhone.trim() || currentClient.telefono,
        whatsapp: clientWhatsApp.trim() || currentClient.whatsapp,
        correo: clientEmail.trim() || undefined,
        direccion: clientAddress.trim() || undefined,
      };
    }

    // 5. Actualizar Totales y Presupuesto de la Orden
    const totalComisiones = servicios.reduce((acc, s) => acc + (s.comisionManoObra || 0), 0);
    const subtotalGeneral = subtotalManoObra + (order.subtotalRefacciones || 0);
    const saldoPendiente = Math.max(0, subtotalGeneral - (order.totalPagado || 0));

    // Sincronizar con order.presupuesto si existe
    let updatedPresupuesto = order.presupuesto ? { ...order.presupuesto } : undefined;
    if (updatedPresupuesto) {
      updatedPresupuesto.manoObra = servicios.map((s) => ({
        id: s.id,
        concepto: s.concepto,
        costo: s.manoObra,
        comisionPorcentaje: s.comisionPorcentaje,
        mecanicoId: s.mecanicoId,
        mecanicoNombre: s.mecanicoNombre,
      }));
      updatedPresupuesto.subtotalManoObra = subtotalManoObra;
      updatedPresupuesto.totalPresupuesto = subtotalManoObra + (updatedPresupuesto.subtotalPartes || 0) + (updatedPresupuesto.ivaMonto || 0);
    }

    const updatedOrder: WorkOrder = {
      ...order,
      folio: folio.trim() || order.folio,
      vehiculoId: effectiveVehicleId,
      fallaReportada: fallaReportada.trim(),
      estado,
      nivelCombustible: combustible,
      kilometrajeEntrada: Number(kilometraje) || 0,
      choferNombre: choferNombre.trim() || undefined,
      choferTelefono: choferTelefono.trim() || undefined,
      refaccionesCliente,
      servicios,
      subtotalManoObra,
      subtotalGeneral,
      totalComisionesMecanicos: totalComisiones,
      saldoPendiente,
      presupuesto: updatedPresupuesto,
      historialModificaciones: historialActualizado,
      updatedAt: new Date().toISOString(),
    };

    setIsSaving(true);
    try {
      await StorageService.saveWorkOrderCompleteAsync(updatedOrder, targetVehicle, targetClient);
      onOrderUpdated(updatedOrder);
      alert(`✓ ¡Orden #${updatedOrder.folio} actualizada con éxito!\nSe registraron ${cambiosDetectados.length} modificaciones en la auditoría.`);
      onClose();
    } catch (err) {
      console.error('Error al guardar modificaciones:', err);
      alert('Ocurrió un error al guardar las modificaciones. Por favor intenta de nuevo.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-fadeIn">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-5xl w-full max-h-[94vh] flex flex-col shadow-2xl text-slate-800 overflow-hidden">
        {/* Cabecera del Modal */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-slate-800 to-rose-950 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-600/30 text-rose-400 border border-rose-500/40 flex items-center justify-center shadow-inner">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black tracking-tight text-white">
                  Edición Total de Orden de Trabajo #{order.folio}
                </h2>
                <span className="text-[10px] font-bold bg-rose-600 text-white px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                  Acceso Autorizado PIN
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Todos los campos son 100% modificables: Cliente, Vehículo, Chofer, Falla y Servicios con registro de auditoría.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Formulario Completo Scrollable */}
        <form onSubmit={handleSaveAll} className="p-4 sm:p-6 overflow-y-auto space-y-6 flex-1 bg-slate-50">
          {/* SECCIÓN 1: DATOS DEL VEHÍCULO */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 pb-2">
              <Car className="w-4 h-4 text-rose-600" />
              <span>1. Datos del Vehículo (Modificables)</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-3">
              <div className="sm:col-span-2">
                <label className="text-xs text-rose-700 block mb-1 font-bold">Placas *:</label>
                <input
                  type="text"
                  value={placas}
                  onChange={(e) => setPlacas(e.target.value.toUpperCase())}
                  required
                  className="w-full bg-rose-50/50 border-2 border-rose-300 text-rose-800 font-mono font-bold rounded-xl px-3 py-2 text-sm focus:outline-none text-center"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs text-slate-600 block mb-1 font-bold">No. Eco / Unidad:</label>
                <input
                  type="text"
                  value={numeroEconomico}
                  onChange={(e) => setNumeroEconomico(e.target.value)}
                  placeholder="Eco-04"
                  className="w-full bg-white border border-slate-200 text-slate-800 font-mono font-bold rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none text-center"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs text-slate-500 block mb-1 font-medium">Marca:</label>
                <input
                  type="text"
                  value={marca}
                  onChange={(e) => setMarca(e.target.value)}
                  className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs text-slate-500 block mb-1 font-medium">Modelo:</label>
                <input
                  type="text"
                  value={modelo}
                  onChange={(e) => setModelo(e.target.value)}
                  className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-slate-500 block mb-1 font-medium">Año:</label>
                <input
                  type="number"
                  value={ano}
                  onChange={(e) => setAno(Number(e.target.value) || 2020)}
                  className="w-full bg-white border border-slate-200 text-slate-800 font-mono rounded-xl px-2 py-2 text-sm focus:border-rose-500 focus:outline-none text-center"
                />
              </div>

              <div>
                <label className="text-xs text-slate-500 block mb-1 font-medium">Color:</label>
                <input
                  type="text"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-2 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs text-slate-500 block mb-1 font-medium">Motor / Cilindros:</label>
                <input
                  type="text"
                  value={motor}
                  onChange={(e) => setMotor(e.target.value)}
                  placeholder="2.5L / 4 Cil"
                  className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="sm:col-span-4">
                <label className="text-xs text-slate-500 block mb-1 font-medium">No. Serie / VIN:</label>
                <input
                  type="text"
                  value={vin}
                  onChange={(e) => setVin(e.target.value.toUpperCase())}
                  placeholder="3N1AB7AP8KY..."
                  className="w-full bg-white border border-slate-200 text-slate-800 font-mono uppercase rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs text-emerald-700 block mb-1 font-bold">Odómetro / Kilometraje *:</label>
                <input
                  type="number"
                  value={kilometraje}
                  onChange={(e) => setKilometraje(Number(e.target.value) || 0)}
                  required
                  className="w-full bg-emerald-50/50 border-2 border-emerald-300 text-emerald-800 font-mono font-bold rounded-xl px-3 py-2 text-sm focus:outline-none text-right"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs text-amber-700 block mb-1 font-bold">Nivel de Combustible:</label>
                <select
                  value={combustible}
                  onChange={(e) => setCombustible(e.target.value as FuelLevel)}
                  className="w-full bg-amber-50/60 border border-amber-300 font-bold text-amber-900 rounded-xl px-3 py-2 text-sm focus:outline-none"
                >
                  <option value="Vacio">Vacio</option>
                  <option value="1/4">1/4</option>
                  <option value="1/2">1/2</option>
                  <option value="3/4">3/4</option>
                  <option value="Lleno">Lleno</option>
                </select>
              </div>
            </div>
          </div>

          {/* SECCIÓN 2: DATOS DEL CLIENTE & CHOFER */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 pb-2">
              <User className="w-4 h-4 text-rose-600" />
              <span>2. Datos del Propietario / Cliente & Chofer</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              <div>
                <label className="text-xs text-slate-600 block mb-1 font-bold">Nombre del Cliente / Empresa *:</label>
                <input
                  type="text"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  required
                  className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none font-medium"
                />
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1 font-bold">Teléfono de Contacto *:</label>
                <input
                  type="tel"
                  value={clientPhone}
                  onChange={(e) => {
                    setClientPhone(e.target.value);
                    if (!clientWhatsApp) setClientWhatsApp(e.target.value);
                  }}
                  required
                  className="w-full bg-white border border-slate-200 text-slate-800 font-mono rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1 font-medium">WhatsApp Directo:</label>
                <input
                  type="tel"
                  value={clientWhatsApp}
                  onChange={(e) => setClientWhatsApp(e.target.value)}
                  className="w-full bg-white border border-slate-200 text-slate-800 font-mono rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1 font-medium">Correo Electrónico:</label>
                <input
                  type="email"
                  value={clientEmail}
                  onChange={(e) => setClientEmail(e.target.value)}
                  placeholder="cliente@ejemplo.com"
                  className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1 font-medium">Chofer que Entregó:</label>
                <input
                  type="text"
                  value={choferNombre}
                  onChange={(e) => setChoferNombre(e.target.value)}
                  placeholder="Nombre de chofer o conductor"
                  className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1 font-medium">Teléfono del Chofer:</label>
                <input
                  type="tel"
                  value={choferTelefono}
                  onChange={(e) => setChoferTelefono(e.target.value)}
                  placeholder="664-000-0000"
                  className="w-full bg-white border border-slate-200 text-slate-800 font-mono rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="sm:col-span-2 md:col-span-3">
                <label className="text-xs text-slate-600 block mb-1 font-medium">Dirección del Cliente:</label>
                <input
                  type="text"
                  value={clientAddress}
                  onChange={(e) => setClientAddress(e.target.value)}
                  placeholder="Calle, colonia, ciudad..."
                  className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* SECCIÓN 3: DATOS DE LA ORDEN & MOTIVO DE VISITA */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 pb-2">
              <FileText className="w-4 h-4 text-rose-600" />
              <span>3. Datos de la Orden & Motivo de Ingreso</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div>
                <label className="text-xs text-slate-700 block mb-1 font-bold">Folio de la Orden:</label>
                <input
                  type="text"
                  value={folio}
                  onChange={(e) => setFolio(e.target.value)}
                  className="w-full bg-slate-100 border border-slate-300 font-mono font-bold text-slate-900 rounded-xl px-3 py-2 text-sm text-center"
                />
              </div>

              <div>
                <label className="text-xs text-slate-700 block mb-1 font-bold">Estatus de la Orden:</label>
                <select
                  value={estado}
                  onChange={(e) => setEstado(e.target.value as OrderStatus)}
                  className="w-full bg-white border border-slate-200 font-bold text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                >
                  <option value="recepcion">Recepción</option>
                  <option value="diagnostico">Diagnóstico</option>
                  <option value="en_progreso">En Progreso (Bahía)</option>
                  <option value="espera_piezas">Espera de Piezas</option>
                  <option value="lavado">Lavado / Detallado</option>
                  <option value="listo_entrega">Listo para Entrega</option>
                  <option value="entregado">Entregado al Cliente</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs text-rose-700 block mb-1 font-bold">Falla Reportada / Diagnóstico *:</label>
                <input
                  type="text"
                  value={fallaReportada}
                  onChange={(e) => setFallaReportada(e.target.value)}
                  required
                  placeholder="Síntomas que reporta el cliente..."
                  className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Refacciones del cliente */}
            <div className="pt-2 border-t border-slate-100">
              <label className="text-xs text-slate-600 block mb-1 font-semibold">
                Refacciones que trajo el cliente (Cajuela / Asiento):
              </label>
              <div className="flex gap-2 mb-2">
                <input
                  type="text"
                  value={nuevaRefaccion}
                  onChange={(e) => setNuevaRefaccion(e.target.value)}
                  placeholder="Anotar pieza dejada por cliente..."
                  className="flex-1 bg-white border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-800"
                />
                <button
                  type="button"
                  onClick={handleAddRefaccion}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold"
                >
                  + Anotar
                </button>
              </div>
              {refaccionesCliente.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {refaccionesCliente.map((ref, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center gap-1.5 text-xs bg-amber-50 text-amber-900 border border-amber-200 px-2.5 py-1 rounded-lg font-medium"
                    >
                      <span>✓ {ref}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveRefaccion(idx)}
                        className="text-rose-500 hover:text-rose-700 font-bold"
                      >
                        ✕
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* SECCIÓN 4: SERVICIOS Y MANO DE OBRA */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <Wrench className="w-4 h-4 text-rose-600" />
                <span>4. Servicios & Mano de Obra ({servicios.length})</span>
              </h3>
              <span className="font-mono font-bold text-rose-600 text-xs">
                Total M.O.: $
                {servicios.reduce((acc, s) => acc + (s.manoObra || 0), 0).toLocaleString()} MXN
              </span>
            </div>

            {/* Lista de servicios existentes */}
            <div className="space-y-2">
              {servicios.map((srv) => (
                <div
                  key={srv.id}
                  className="p-3 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-5 gap-2 items-center text-xs"
                >
                  <div className="sm:col-span-2">
                    <label className="text-[10px] text-slate-400 block font-bold uppercase mb-0.5">Concepto:</label>
                    <input
                      type="text"
                      value={srv.concepto}
                      onChange={(e) => handleUpdateServiceField(srv.id, 'concepto', e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-900 focus:border-rose-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 block font-bold uppercase mb-0.5">Mano de Obra ($):</label>
                    <input
                      type="number"
                      value={srv.manoObra || ''}
                      onChange={(e) => handleUpdateServiceField(srv.id, 'manoObra', e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-mono font-bold text-slate-900 text-right focus:border-rose-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 block font-bold uppercase mb-0.5">Mecánico Asignado:</label>
                    <select
                      value={srv.mecanicoId}
                      onChange={(e) => handleUpdateServiceField(srv.id, 'mecanicoId', e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1.5 text-xs font-bold text-slate-800"
                    >
                      <option value="unassigned">Por Asignar</option>
                      {mechanics.map((m) => (
                        <option key={m.id} value={m.id}>
                          👨‍🔧 {m.nombre}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-2 pt-1 sm:pt-0">
                    <span className="text-[11px] text-slate-500 font-mono">
                      Comisión: {srv.comisionPorcentaje}% (${srv.comisionManoObra || 0})
                    </span>
                    <button
                      type="button"
                      onClick={() => handleRemoveService(srv.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg transition-colors border border-slate-200 bg-white"
                      title="Eliminar este servicio"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Agregar nuevo servicio */}
            <div className="p-3 rounded-xl bg-rose-50/50 border border-rose-200 space-y-2">
              <span className="text-xs font-bold text-rose-900 block">+ Agregar Otro Servicio a la Orden:</span>
              <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
                <input
                  type="text"
                  placeholder="Concepto de Servicio..."
                  value={nuevoConcepto}
                  onChange={(e) => setNuevoConcepto(e.target.value)}
                  className="sm:col-span-2 bg-white border border-rose-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800"
                />
                <input
                  type="number"
                  placeholder="$ Monto"
                  value={nuevoCosto || ''}
                  onChange={(e) => setNuevoCosto(Number(e.target.value) || 0)}
                  className="bg-white border border-rose-200 rounded-lg px-2.5 py-1.5 text-xs font-mono font-bold text-right"
                />
                <select
                  value={nuevoMecanicoId}
                  onChange={(e) => {
                    setNuevoMecanicoId(e.target.value);
                    const found = mechanics.find((m) => m.id === e.target.value);
                    if (found) setNuevaComision(found.comisionDefault);
                  }}
                  className="bg-white border border-rose-200 rounded-lg px-2 py-1.5 text-xs font-bold text-slate-800"
                >
                  <option value="unassigned">Por Asignar</option>
                  {mechanics.map((m) => (
                    <option key={m.id} value={m.id}>
                      👨‍🔧 {m.nombre} ({m.comisionDefault}%)
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={handleAddService}
                  className="bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg text-xs py-1.5 shadow-sm transition-colors"
                >
                  + Agregar
                </button>
              </div>
            </div>
          </div>

          {/* SECCIÓN 5: REGISTRO DE AUDITORÍA (QUIÉN MODIFICA) */}
          <div className="bg-slate-900 text-white p-4 sm:p-5 rounded-2xl border border-slate-800 shadow-md space-y-3">
            <h3 className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>5. Registro de Seguridad & Auditoría de Quién Modifica</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-slate-300 block mb-1 font-bold">
                  Responsable de la Modificación *:
                </label>
                <input
                  type="text"
                  value={usuarioModifica}
                  onChange={(e) => setUsuarioModifica(e.target.value)}
                  required
                  placeholder="Ej. Reyna Amaya (PIN 2036)"
                  className="w-full bg-slate-800 border border-slate-700 text-white font-medium rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-rose-400"
                />
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-medium">
                  Motivo o Justificación del Cambio (Opcional):
                </label>
                <input
                  type="text"
                  value={motivoModificacion}
                  onChange={(e) => setMotivoModificacion(e.target.value)}
                  placeholder="Ej. Corrección de placas por error tipográfico / cambio de mecánico"
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-rose-400"
                />
              </div>
            </div>

            {/* Historial previo de modificaciones si existe */}
            {order.historialModificaciones && order.historialModificaciones.length > 0 && (
              <div className="mt-3 pt-3 border-t border-slate-800">
                <span className="text-[11px] font-bold text-slate-400 uppercase flex items-center gap-1.5 mb-2">
                  <History className="w-3.5 h-3.5 text-amber-400" />
                  Historial de Modificaciones Previas ({order.historialModificaciones.length}):
                </span>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {order.historialModificaciones.map((h) => (
                    <div
                      key={h.id}
                      className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-[11px] space-y-1"
                    >
                      <div className="flex items-center justify-between text-slate-300">
                        <span className="font-bold text-emerald-400">👤 {h.usuario}</span>
                        <span className="font-mono text-slate-500">{h.fecha}</span>
                      </div>
                      {h.motivo && (
                        <p className="text-amber-200/90 italic">Motivo: "{h.motivo}"</p>
                      )}
                      <div className="text-slate-300 space-y-0.5">
                        {h.cambios.map((c, i) => (
                          <div key={i} className="flex items-start gap-1 font-mono text-[10px]">
                            <span className="text-rose-400">●</span>
                            <span>{c}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Botones de Acción */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-black text-xs shadow-lg shadow-emerald-600/20 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'Guardando en disco...' : 'Guardar Modificaciones y Registrar Auditoría'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
