import { NextResponse } from 'next/server';
import os from 'os';

export const dynamic = 'force-dynamic';

function getLanIp(): string {
  const interfaces = os.networkInterfaces();
  const candidates: string[] = [];

  for (const name of Object.keys(interfaces)) {
    const lowerName = name.toLowerCase();
    // Omitir adaptadores virtuales comunes (VirtualBox, WSL, VMware, Docker)
    if (
      lowerName.includes('virtual') ||
      lowerName.includes('vethernet') ||
      lowerName.includes('vmnet') ||
      lowerName.includes('docker') ||
      lowerName.includes('loopback')
    ) {
      continue;
    }

    const ifaceList = interfaces[name];
    if (!ifaceList) continue;

    for (const iface of ifaceList) {
      if (iface.family === 'IPv4' && !iface.internal) {
        // Priorizar rango típico de routers Wi-Fi de taller (192.168.X.X o 10.X.X.X)
        if (iface.address.startsWith('192.168.') || iface.address.startsWith('10.')) {
          return iface.address;
        }
        candidates.push(iface.address);
      }
    }
  }

  return candidates[0] || '192.168.1.194';
}

export async function GET(request: Request) {
  const lanIp = getLanIp();
  const hostHeader = request.headers.get('host') || '';
  const port = hostHeader.includes(':') ? hostHeader.split(':')[1] : '3000';

  return NextResponse.json({
    lanIp,
    port,
    lanOrigin: `http://${lanIp}:${port}`,
  });
}
