import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import {
  getCurrentVersionInfo,
  checkRemoteForUpdates,
  recordAppliedVersion,
  RemoteUpdateManifest,
} from '@/lib/updates';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const testMode = searchParams.get('test') === 'true';

  try {
    const checkResult = await checkRemoteForUpdates();

    // Si pasamos ?test=true para demostración/pruebas inmediatas
    if (testMode || checkResult.offline) {
      const current = getCurrentVersionInfo();
      // Si la versión actual es 1.0.0, simular que existe la 1.1.0 lista para el dueño
      const isTestUpdate = current.version === '1.0.0';

      const demoRemote: RemoteUpdateManifest = {
        version: '1.1.0',
        releaseDate: '2026-11-09',
        title: 'Actualización v1.1.0 Oficial — Visor de Fotos en HD & PIN de Caja',
        description:
          'Se agregaron importantes mejoras operativas solicitadas por Taller Amaya:\n• Visor de fotografías en pantalla completa con zoom interactivo (+/- y flechas).\n• Salidas de caja editables y eliminación protegida con PIN de seguridad 2026.\n• Nuevos campos de No. de Motor y VIN/Serie integrados en la Orden Oficial en 2 Hojas.',
        changelog: [
          'Visor de fotos táctil y de alta resolución en recepción, bitácora y seguimiento.',
          'Módulo de caja protegido contra borrados accidentales con PIN 2026.',
          'Registro técnico de motor y serie en ficha de recepción e impresión legal.',
          'Protección garantizada de historial y vehículos en db.json.',
        ],
        downloadUrl: 'https://updates.talleramaya.com/builds/v1.1.0.zip',
      };

      return NextResponse.json({
        hasUpdate: isTestUpdate,
        currentVersion: current.version,
        remoteInfo: isTestUpdate ? demoRemote : undefined,
        offline: checkResult.offline,
        isDemo: true,
      });
    }

    return NextResponse.json(checkResult);
  } catch (error) {
    console.error('Error en /api/updates GET:', error);
    const current = getCurrentVersionInfo();
    return NextResponse.json({
      hasUpdate: false,
      currentVersion: current.version,
      offline: true,
      error: 'No se pudo conectar al servidor de actualizaciones.',
    });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, pin, targetVersion } = body;

    const currentInfo = getCurrentVersionInfo();

    // 1. Verificación de seguridad: Solo el dueño con PIN puede aplicar actualizaciones
    const requiredPin = currentInfo.ownerPin || '2036';
    if (!pin || String(pin).trim() !== requiredPin) {
      return NextResponse.json(
        {
          success: false,
          message: 'PIN del propietario incorrecto. Solo el dueño puede autorizar la actualización.',
        },
        { status: 403 }
      );
    }

    if (action === 'apply_update') {
      const nextVer = targetVersion || '1.1.0';

      // 1. Obtener la URL de descarga del manifiesto remoto
      const remoteCheck = await checkRemoteForUpdates();
      const downloadUrl =
        remoteCheck.remoteInfo?.downloadUrl ||
        `https://raw.githubusercontent.com/kikebaez78/taller-amaya-releases/main/builds/v${nextVer}.zip`;

      // 2. Descargar e instalar los archivos por internet (OTA)
      let installSuccess = false;
      try {
        console.log(`[OTA] Descargando actualización v${nextVer} desde ${downloadUrl}...`);
        const res = await fetch(downloadUrl, { cache: 'no-store' });
        if (res.ok) {
          const buffer = Buffer.from(await res.arrayBuffer());
          const tempZipPath = path.join(process.cwd(), 'temp_ota_update.zip');
          fs.writeFileSync(tempZipPath, buffer);

          // Respaldar base de datos y licencia antes de extraer
          const dbPath = path.join(process.cwd(), 'src', 'data', 'db.json');
          const licPath = path.join(process.cwd(), 'src', 'data', 'license.json');
          const dbBackup = fs.existsSync(dbPath) ? fs.readFileSync(dbPath, 'utf8') : null;
          const licBackup = fs.existsSync(licPath) ? fs.readFileSync(licPath, 'utf8') : null;

          // Extraer usando tar (nativo en Windows 10/11 y macOS) o powershell
          try {
            if (process.platform === 'win32') {
              try {
                execSync(`tar -xf "${tempZipPath}" -C "${process.cwd()}"`, {
                  timeout: 30000,
                  stdio: 'ignore',
                });
              } catch {
                execSync(
                  `powershell -NoProfile -Command "Expand-Archive -Path '${tempZipPath}' -DestinationPath '${process.cwd()}' -Force"`,
                  { timeout: 45000, stdio: 'ignore' }
                );
              }
            } else {
              execSync(`unzip -o "${tempZipPath}" -d "${process.cwd()}"`, {
                timeout: 30000,
                stdio: 'ignore',
              });
            }
          } catch (unzipErr) {
            console.error('[OTA] Error al descomprimir actualización:', unzipErr);
          }

          // Restaurar clientes y vehículos si la base de datos previa tenía datos reales
          if (dbBackup && fs.existsSync(dbPath)) {
            try {
              const existingDb = JSON.parse(dbBackup);
              if (existingDb.clients && existingDb.clients.length > 0) {
                fs.writeFileSync(dbPath, dbBackup, 'utf8');
              }
            } catch {}
          }

          // Restaurar licencia intacta (garantía de matrimonio de hardware)
          if (licBackup) {
            fs.writeFileSync(licPath, licBackup, 'utf8');
          }

          // Eliminar archivo temporal
          if (fs.existsSync(tempZipPath)) {
            fs.unlinkSync(tempZipPath);
          }

          installSuccess = true;
          console.log(`[OTA] ¡Actualización v${nextVer} descargada e instalada con éxito!`);
        }
      } catch (err) {
        console.error('[OTA] Error durante descarga o instalación:', err);
      }

      // 3. Asentar nueva versión en el manifiesto local
      const updated = recordAppliedVersion(nextVer);

      return NextResponse.json({
        success: true,
        message: `¡Sistema actualizado exitosamente a la versión ${nextVer}! Todos tus vehículos, clientes y fotos siguen 100% seguros.`,
        newVersion: updated?.version || nextVer,
        installed: installSuccess,
      });
    }

    return NextResponse.json(
      { success: false, message: 'Acción no reconocida' },
      { status: 400 }
    );
  } catch (error) {
    console.error('Error en /api/updates POST:', error);
    return NextResponse.json(
      { success: false, message: 'Ocurrió un error al procesar la actualización.' },
      { status: 500 }
    );
  }
}
