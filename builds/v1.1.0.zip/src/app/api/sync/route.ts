import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import {
  INITIAL_COMPANIES,
  INITIAL_CLIENTS,
  INITIAL_VEHICLES,
  INITIAL_WORK_ORDERS,
  INITIAL_CASH_SHIFT,
} from '@/data/mockData';
import { INITIAL_MECHANICS } from '@/data/tallerConfig';
import { WorkOrder, Vehicle, Client, Company } from '@/types';

export const dynamic = 'force-dynamic';

const DB_FILE = path.join(process.cwd(), 'src', 'data', 'db.json');

interface DatabaseSchema {
  companies: Company[];
  clients: Client[];
  vehicles: Vehicle[];
  workOrders: WorkOrder[];
  mechanics: any[];
  cashShift: any;
  updatedAt: string;
}

function getInitialDb(): DatabaseSchema {
  return {
    companies: INITIAL_COMPANIES,
    clients: INITIAL_CLIENTS,
    vehicles: INITIAL_VEHICLES,
    workOrders: INITIAL_WORK_ORDERS,
    mechanics: INITIAL_MECHANICS,
    cashShift: INITIAL_CASH_SHIFT,
    updatedAt: new Date().toISOString(),
  };
}

function readDb(): DatabaseSchema {
  try {
    if (!fs.existsSync(DB_FILE)) {
      const initial = getInitialDb();
      fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2), 'utf-8');
      return initial;
    }
    const content = fs.readFileSync(DB_FILE, 'utf-8');
    return JSON.parse(content);
  } catch (err) {
    console.error('Error reading db.json, returning initial', err);
    return getInitialDb();
  }
}

function writeDb(data: DatabaseSchema) {
  try {
    data.updatedAt = new Date().toISOString();
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing db.json', err);
  }
}

// GET: Retorna todo el estado o busca por folio específico
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const folio = searchParams.get('folio');
  const db = readDb();

  if (folio) {
    const clean = folio.replace(/^ot-/, '');
    const order = db.workOrders.find(
      (o) => o.folio === clean || o.id === `ot-${clean}` || o.id === clean
    );

    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 });
    }

    const vehicle = db.vehicles.find((v) => v.id === order.vehiculoId);
    const client = db.clients.find((c) => c.id === order.clienteId);
    const company = order.empresaId
      ? db.companies.find((co) => co.id === order.empresaId)
      : null;

    return NextResponse.json({
      order,
      vehicle,
      client,
      company,
    });
  }

  return NextResponse.json(db);
}

// POST: Guarda o actualiza una orden o datos
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const db = readDb();

    if (body.type === 'save_order' && body.order) {
      const newOrder: WorkOrder = body.order;
      const existingIdx = db.workOrders.findIndex((o) => o.id === newOrder.id);
      if (existingIdx >= 0) {
        db.workOrders[existingIdx] = newOrder;
      } else {
        db.workOrders.unshift(newOrder);
      }

      if (body.vehicle) {
        const vIdx = db.vehicles.findIndex((v) => v.id === body.vehicle.id);
        if (vIdx >= 0) db.vehicles[vIdx] = body.vehicle;
        else db.vehicles.unshift(body.vehicle);
      }

      if (body.client) {
        const cIdx = db.clients.findIndex((c) => c.id === body.client.id);
        if (cIdx >= 0) db.clients[cIdx] = body.client;
        else db.clients.unshift(body.client);
      }

      writeDb(db);
      return NextResponse.json({ success: true, order: newOrder });
    }

    if (body.type === 'save_vehicle' && body.vehicle) {
      const vIdx = db.vehicles.findIndex((v) => v.id === body.vehicle.id);
      if (vIdx >= 0) db.vehicles[vIdx] = body.vehicle;
      else db.vehicles.unshift(body.vehicle);
      writeDb(db);
      return NextResponse.json({ success: true, vehicle: body.vehicle });
    }

    if (body.type === 'save_client' && body.client) {
      const cIdx = db.clients.findIndex((c) => c.id === body.client.id);
      if (cIdx >= 0) db.clients[cIdx] = body.client;
      else db.clients.unshift(body.client);
      writeDb(db);
      return NextResponse.json({ success: true, client: body.client });
    }

    if (body.type === 'save_company' && body.company) {
      const coIdx = db.companies.findIndex((co) => co.id === body.company.id);
      if (coIdx >= 0) db.companies[coIdx] = body.company;
      else db.companies.unshift(body.company);
      writeDb(db);
      return NextResponse.json({ success: true, company: body.company });
    }

    if (body.type === 'save_cash_shift' && body.cashShift) {
      db.cashShift = body.cashShift;
      writeDb(db);
      return NextResponse.json({ success: true, cashShift: db.cashShift });
    }

    if (body.type === 'save_mechanics' && Array.isArray(body.mechanics)) {
      db.mechanics = body.mechanics;
      writeDb(db);
      return NextResponse.json({ success: true, mechanics: db.mechanics });
    }

    if (body.type === 'reset_all') {
      db.companies = [];
      db.clients = [];
      db.vehicles = [];
      db.workOrders = [];
      db.cashShift = {
        id: `caja-${Date.now()}`,
        fechaApertura: new Date().toISOString().replace('T', ' ').substring(0, 16),
        fondoInicial: 1000,
        ingresosEfectivo: 0,
        ingresosTarjeta: 0,
        ingresosTransferencia: 0,
        gastosMenores: [],
        totalGastosMenores: 0,
        efectivoEsperado: 1000,
        estado: 'abierta',
        cajero: 'Reyna Amaya (Administración)',
      };
      writeDb(db);
      return NextResponse.json({ success: true, message: 'All test client/order data cleared' });
    }

    if (body.type === 'delete_order' && body.id) {
      const target = String(body.id);
      db.workOrders = db.workOrders.filter((o) => o.id !== target && o.folio !== target);
      writeDb(db);
      return NextResponse.json({ success: true, deletedId: target });
    }

    if (body.type === 'full_sync') {
      if (Array.isArray(body.workOrders)) db.workOrders = body.workOrders;
      if (Array.isArray(body.vehicles)) db.vehicles = body.vehicles;
      if (Array.isArray(body.clients)) db.clients = body.clients;
      if (Array.isArray(body.companies)) db.companies = body.companies;
      writeDb(db);
      return NextResponse.json({ success: true });
    }

    return NextResponse.json({ error: 'Invalid payload' }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
