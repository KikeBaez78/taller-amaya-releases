import {
  Company,
  Client,
  Vehicle,
  WorkOrder,
  Mechanic,
  CashRegisterShift,
  CashExpense,
  PaymentRecord,
  MandatoryPhotos,
  DamagePoint,
  FuelLevel,
  ServiceItem,
} from '@/types';
import {
  INITIAL_COMPANIES,
  INITIAL_CLIENTS,
  INITIAL_VEHICLES,
  INITIAL_WORK_ORDERS,
  INITIAL_CASH_SHIFT,
} from '@/data/mockData';
import { INITIAL_MECHANICS, TALLER_CONFIG } from '@/data/tallerConfig';

const STORAGE_KEYS = {
  COMPANIES: 'taller_amaya_companies_v3',
  CLIENTS: 'taller_amaya_clients_v3',
  VEHICLES: 'taller_amaya_vehicles_v3',
  WORK_ORDERS: 'taller_amaya_work_orders_v3',
  MECHANICS: 'taller_amaya_mechanics_v3',
  CASH_SHIFT: 'taller_amaya_cash_shift_v3',
};

// Carga segura con fallback a mock
function load<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch (e) {
    console.error(`Error loading ${key}`, e);
    return fallback;
  }
}

function save<T>(key: string, data: T) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.error(`Error saving ${key}`, e);
  }
}

export const StorageService = {
  // CONFIG
  getConfig() {
    return TALLER_CONFIG;
  },

  // COMPANIES & CRM
  getCompanies(): Company[] {
    return load<Company[]>(STORAGE_KEYS.COMPANIES, INITIAL_COMPANIES);
  },
  saveCompany(company: Company): Company[] {
    const list = this.getCompanies();
    const idx = list.findIndex((c) => c.id === company.id);
    if (idx >= 0) {
      list[idx] = company;
    } else {
      list.push(company);
    }
    save(STORAGE_KEYS.COMPANIES, list);
    if (typeof window !== 'undefined') {
      fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'save_company', company }),
      }).catch(() => {});
    }
    return list;
  },


  // CLIENTS
  getClients(): Client[] {
    return load<Client[]>(STORAGE_KEYS.CLIENTS, INITIAL_CLIENTS);
  },
  saveClient(client: Client): Client[] {
    const list = this.getClients();
    const idx = list.findIndex((c) => c.id === client.id);
    if (idx >= 0) {
      list[idx] = client;
    } else {
      list.push(client);
    }
    save(STORAGE_KEYS.CLIENTS, list);
    if (typeof window !== 'undefined') {
      fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'save_client', client }),
      }).catch(() => {});
    }
    return list;
  },


  // VEHICLES
  getVehicles(): Vehicle[] {
    return load<Vehicle[]>(STORAGE_KEYS.VEHICLES, INITIAL_VEHICLES);
  },
  saveVehicle(vehicle: Vehicle): Vehicle[] {
    const list = this.getVehicles();
    const idx = list.findIndex((v) => v.id === vehicle.id);
    if (idx >= 0) {
      list[idx] = vehicle;
    } else {
      list.push(vehicle);
    }
    save(STORAGE_KEYS.VEHICLES, list);
    if (typeof window !== 'undefined') {
      fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'save_vehicle', vehicle }),
      }).catch(() => {});
    }
    return list;
  },


  // WORK ORDERS & FOLIOS
  getWorkOrders(): WorkOrder[] {
    return load<WorkOrder[]>(STORAGE_KEYS.WORK_ORDERS, INITIAL_WORK_ORDERS);
  },
  saveWorkOrder(order: WorkOrder): WorkOrder[] {
    const list = this.getWorkOrders();
    const idx = list.findIndex((o) => o.id === order.id);
    if (idx >= 0) {
      list[idx] = order;
    } else {
      list.unshift(order);
    }
    save(STORAGE_KEYS.WORK_ORDERS, list);

    // Sincronizar en segundo plano con la API central
    if (typeof window !== 'undefined') {
      try {
        const v = this.getVehicles().find((veh) => veh.id === order.vehiculoId);
        const c = this.getClients().find((cli) => cli.id === order.clienteId);
        fetch('/api/sync', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            type: 'save_order',
            order,
            vehicle: v,
            client: c,
          }),
        }).catch(() => {});
      } catch {}
    }

    return list;
  },

  deleteWorkOrder(idOrFolio: string): WorkOrder[] {
    const list = this.getWorkOrders().filter((o) => o.id !== idOrFolio && o.folio !== idOrFolio);
    save(STORAGE_KEYS.WORK_ORDERS, list);
    if (typeof window !== 'undefined') {
      fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'delete_order', id: idOrFolio }),
      }).catch(() => {});
    }
    return list;
  },

  // Generador del siguiente folio sugerido (iniciando en 0900)
  getNextFolio(): string {
    const orders = this.getWorkOrders();
    const numericFolios = orders
      .map((o) => parseInt(o.folio, 10))
      .filter((n) => !isNaN(n));

    if (numericFolios.length === 0) {
      return '0900';
    }
    const maxFolio = Math.max(...numericFolios, 899);
    return String(maxFolio + 1).padStart(4, '0');
  },

  // MECHANICS
  getMechanics(): Mechanic[] {
    return load<Mechanic[]>(STORAGE_KEYS.MECHANICS, INITIAL_MECHANICS);
  },
  saveMechanics(list: Mechanic[]): Mechanic[] {
    save(STORAGE_KEYS.MECHANICS, list);
    if (typeof window !== 'undefined') {
      fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'save_mechanics', mechanics: list }),
      }).catch(() => {});
    }
    return list;
  },

  saveMechanic(mechanic: Mechanic): Mechanic[] {
    const list = this.getMechanics();
    const idx = list.findIndex((m) => m.id === mechanic.id);
    if (idx >= 0) {
      list[idx] = mechanic;
    } else {
      list.push(mechanic);
    }
    return this.saveMechanics(list);
  },
  deleteMechanic(id: string): Mechanic[] {
    const list = this.getMechanics().filter((m) => m.id !== id);
    return this.saveMechanics(list);
  },

  // CAJA & CORTES
  getCashShift(): CashRegisterShift {
    return load<CashRegisterShift>(STORAGE_KEYS.CASH_SHIFT, INITIAL_CASH_SHIFT);
  },
  saveCashShift(shift: CashRegisterShift): CashRegisterShift {
    save(STORAGE_KEYS.CASH_SHIFT, shift);
    if (typeof window !== 'undefined') {
      fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'save_cash_shift', cashShift: shift }),
      }).catch(() => {});
    }
    return shift;
  },

  addExpense(expense: Omit<CashExpense, 'id'>): CashRegisterShift {
    const shift = this.getCashShift();
    const newExpense: CashExpense = {
      ...expense,
      id: `gasto-${Date.now()}`,
    };
    shift.gastosMenores.push(newExpense);
    shift.totalGastosMenores += newExpense.monto;
    shift.efectivoEsperado =
      shift.fondoInicial + shift.ingresosEfectivo - shift.totalGastosMenores;
    return this.saveCashShift(shift);
  },

  updateExpense(id: string, updatedData: Partial<CashExpense>): CashRegisterShift {
    const shift = this.getCashShift();
    const idx = shift.gastosMenores.findIndex((g) => g.id === id);
    if (idx >= 0) {
      shift.gastosMenores[idx] = {
        ...shift.gastosMenores[idx],
        ...updatedData,
      };
      shift.totalGastosMenores = shift.gastosMenores.reduce((acc, g) => acc + Number(g.monto || 0), 0);
      shift.efectivoEsperado =
        shift.fondoInicial + shift.ingresosEfectivo - shift.totalGastosMenores;
      return this.saveCashShift(shift);
    }
    return shift;
  },

  deleteExpense(id: string): CashRegisterShift {
    const shift = this.getCashShift();
    shift.gastosMenores = shift.gastosMenores.filter((g) => g.id !== id);
    shift.totalGastosMenores = shift.gastosMenores.reduce((acc, g) => acc + Number(g.monto || 0), 0);
    shift.efectivoEsperado =
      shift.fondoInicial + shift.ingresosEfectivo - shift.totalGastosMenores;
    return this.saveCashShift(shift);
  },

  recordPaymentToCash(payment: PaymentRecord): CashRegisterShift {
    const shift = this.getCashShift();
    if (payment.metodo === 'efectivo') {
      shift.ingresosEfectivo += payment.monto;
    } else if (payment.metodo === 'tarjeta') {
      shift.ingresosTarjeta += payment.montoTotalConIva;
    } else if (payment.metodo === 'transferencia') {
      shift.ingresosTransferencia += payment.montoTotalConIva;
    }
    shift.efectivoEsperado =
      shift.fondoInicial + shift.ingresosEfectivo - shift.totalGastosMenores;
    return this.saveCashShift(shift);
  },

  // ==========================================
  // BITÁCORA Y BÚSQUEDA RELACIONAL POTENTE
  // Placas, Vehículo o Nombre de Cliente -> Vehículos con historial de visitas y servicios
  // ==========================================
  searchBitacora(query: string) {
    const q = query.trim().toLowerCase();
    const vehicles = this.getVehicles();
    const clients = this.getClients();
    const companies = this.getCompanies();
    const workOrders = this.getWorkOrders();

    if (!q) {
      // Retornar todos los vehículos ordenados por último servicio
      return vehicles.map((v) => this.hydrateVehicleRecord(v, clients, companies, workOrders));
    }

    // Filtrar vehículos donde coincida placa, marca, modelo, vin, nombre del cliente o empresa
    const matched = vehicles.filter((v) => {
      const matchPlacas = v.placas.toLowerCase().includes(q);
      const matchMarca = v.marca.toLowerCase().includes(q);
      const matchModelo = v.modelo.toLowerCase().includes(q);
      const matchVin = v.vin?.toLowerCase().includes(q) || false;
      const matchChofer = v.choferHabitual?.toLowerCase().includes(q) || false;

      // Buscar cliente
      const client = clients.find((c) => c.id === v.clienteId);
      const matchClient = client?.nombre.toLowerCase().includes(q) || false;

      // Buscar empresa
      const company = companies.find((c) => c.id === v.empresaId);
      const matchCompany =
        company?.razonSocial.toLowerCase().includes(q) ||
        company?.encargadoFlotilla.toLowerCase().includes(q) ||
        false;

      return (
        matchPlacas ||
        matchMarca ||
        matchModelo ||
        matchVin ||
        matchChofer ||
        matchClient ||
        matchCompany
      );
    });

    return matched.map((v) => this.hydrateVehicleRecord(v, clients, companies, workOrders));
  },

  hydrateVehicleRecord(
    v: Vehicle,
    clients: Client[],
    companies: Company[],
    workOrders: WorkOrder[]
  ) {
    const client = clients.find((c) => c.id === v.clienteId);
    const company = companies.find((c) => c.id === v.empresaId);
    // Filtrar todas las órdenes de este auto ordenadas cronológicamente
    const history = workOrders
      .filter((o) => o.vehiculoId === v.id)
      .sort((a, b) => new Date(b.fechaIngreso).getTime() - new Date(a.fechaIngreso).getTime());

    // Alerta de mantenimiento preventivo (regla: 2 meses o 10,000 km)
    let requiereMantenimiento = false;
    let motivoAlerta = '';

    if (v.ultimoServicioFecha) {
      const fechaUltimo = new Date(v.ultimoServicioFecha);
      const mesesTranscurridos =
        (Date.now() - fechaUltimo.getTime()) / (1000 * 60 * 60 * 24 * 30.4);
      if (mesesTranscurridos >= 2) {
        requiereMantenimiento = true;
        motivoAlerta = `Han pasado ${Math.floor(mesesTranscurridos)} meses desde su última visita.`;
      }
    }
    if (v.ultimoServicioKm && v.kilometrajeActual - v.ultimoServicioKm >= 10000) {
      requiereMantenimiento = true;
      const kmDiff = v.kilometrajeActual - v.ultimoServicioKm;
      motivoAlerta += (motivoAlerta ? ' Además, ' : '') + `recorrió ${kmDiff.toLocaleString()} km desde el último servicio.`;
    }

    return {
      vehicle: v,
      client,
      company,
      history,
      requiereMantenimiento,
      motivoAlerta,
    };
  },

  // Generar mensaje de WhatsApp con formato para invitar al cliente a servicio
  generateWhatsAppReminder(vehicle: Vehicle, clientName: string, telefono: string, motivo: string) {
    const mensaje = encodeURIComponent(
      `Hola ${clientName}, te saludamos de TALLER AMAYA en Tijuana B.C. 🚗🔧\n\nLe toca mantenimiento preventivo a tu vehículo *${vehicle.marca} ${vehicle.modelo}* (Placas: *${vehicle.placas}*).\n\nMotivo: ${motivo || 'Revisión periódica de 2 meses o 10,000 km'}.\n\n¿Deseas agendar tu cita esta semana? Estamos en C. Santo Domingo #19950, Buenos Aires Sur.\nTel: 6646295614.`
    );
    const cleanPhone = telefono.replace(/\D/g, '');
    return `https://wa.me/52${cleanPhone}?text=${mensaje}`;
  },

  // Generar mensaje de WhatsApp para avisar de un detalle o hallazgo extra en bahía
  generateWhatsAppExtraAlert(
    order: WorkOrder,
    vehicle: Vehicle | undefined,
    clientName: string,
    telefono: string,
    detalleExtra: string,
    costoExtra: number
  ) {
    const vehiculoDesc = vehicle ? `${vehicle.marca} ${vehicle.modelo} (Placas: ${vehicle.placas})` : 'tu vehículo';
    const trackingUrl = `https://talleramaya.com/seguimiento/${order.folio}`;
    const texto = `Hola ${clientName || 'Estimado Cliente'}, te saludamos de *TALLER AMAYA* 🔧\n\nAl realizar la inspección / desarme de tu vehículo *${vehiculoDesc}* (Folio *#${order.folio}*), detectamos el siguiente detalle que requiere atención:\n\n⚠️ *Detalle / Hallazgo Extra:* ${detalleExtra}\n💰 *Presupuesto Adicional Estimado:* $${costoExtra.toLocaleString()} MXN\n\n¿Nos autorizas proceder con este trabajo adicional? Puedes autorizar respondiendo a este mensaje o consultando tu orden en línea:\n${trackingUrl}\n\nQuedamos a la espera de tu respuesta. ¡Gracias!`;
    const cleanPhone = (telefono || '6640000000').replace(/\D/g, '');
    return `https://wa.me/52${cleanPhone}?text=${encodeURIComponent(texto)}`;
  },

  // Generar mensaje de WhatsApp para avisar que el vehículo ya está listo para pasar a recoger
  generateWhatsAppReadyAlert(
    order: WorkOrder,
    vehicle: Vehicle | undefined,
    clientName: string,
    telefono: string
  ) {
    const vehiculoDesc = vehicle ? `${vehicle.marca} ${vehicle.modelo} (Placas: ${vehicle.placas})` : 'tu vehículo';
    const trackingUrl = `https://talleramaya.com/seguimiento/${order.folio}`;
    const texto = `¡Buenas noticias ${clientName || 'Estimado Cliente'}! 🚗✨\n\nTu vehículo *${vehiculoDesc}* (Folio *#${order.folio}*) ya se encuentra *LISTO PARA RECOGER* en *TALLER AMAYA*.\n\n📊 *Resumen de Cuenta:*\n• Total del Servicio: $${order.subtotalGeneral.toLocaleString()} MXN\n• Total Abonado: $${order.totalPagado.toLocaleString()} MXN\n• *Saldo Pendiente a Liquidar:* $${order.saldoPendiente.toLocaleString()} MXN\n\n📍 Te esperamos en: C. Santo Domingo #19950, Col. Buenos Aires Sur, Tijuana B.C.\n⏰ Horario: Lunes a Sábado de 8:00 AM a 6:00 PM\nTel: 6646295614 / WA: 6644093068\n\nVer orden digital:\n${trackingUrl}`;
    const cleanPhone = (telefono || '6640000000').replace(/\D/g, '');
    return `https://wa.me/52${cleanPhone}?text=${encodeURIComponent(texto)}`;
  },

  // Sincronización bidireccional en tiempo real entre Computadora, Celular y Tablet
  async syncFromServer(): Promise<boolean> {
    if (typeof window === 'undefined') return false;
    try {
      const res = await fetch('/api/sync?_t=' + Date.now(), { cache: 'no-store' });
      if (!res.ok) return false;
      const data = await res.json();
      if (!data) return false;

      let hasChanges = false;

      if (Array.isArray(data.workOrders)) {
        const cur = localStorage.getItem(STORAGE_KEYS.WORK_ORDERS);
        const nextStr = JSON.stringify(data.workOrders);
        if (cur !== nextStr) {
          localStorage.setItem(STORAGE_KEYS.WORK_ORDERS, nextStr);
          hasChanges = true;
        }
      }
      if (Array.isArray(data.vehicles)) {
        const cur = localStorage.getItem(STORAGE_KEYS.VEHICLES);
        const nextStr = JSON.stringify(data.vehicles);
        if (cur !== nextStr) {
          localStorage.setItem(STORAGE_KEYS.VEHICLES, nextStr);
          hasChanges = true;
        }
      }
      if (Array.isArray(data.clients)) {
        const cur = localStorage.getItem(STORAGE_KEYS.CLIENTS);
        const nextStr = JSON.stringify(data.clients);
        if (cur !== nextStr) {
          localStorage.setItem(STORAGE_KEYS.CLIENTS, nextStr);
          hasChanges = true;
        }
      }
      if (Array.isArray(data.companies)) {
        const cur = localStorage.getItem(STORAGE_KEYS.COMPANIES);
        const nextStr = JSON.stringify(data.companies);
        if (cur !== nextStr) {
          localStorage.setItem(STORAGE_KEYS.COMPANIES, nextStr);
          hasChanges = true;
        }
      }
      if (Array.isArray(data.mechanics)) {
        const cur = localStorage.getItem(STORAGE_KEYS.MECHANICS);
        const nextStr = JSON.stringify(data.mechanics);
        if (cur !== nextStr) {
          localStorage.setItem(STORAGE_KEYS.MECHANICS, nextStr);
          hasChanges = true;
        }
      }
      if (data.cashShift) {
        const cur = localStorage.getItem(STORAGE_KEYS.CASH_SHIFT);
        const nextStr = JSON.stringify(data.cashShift);
        if (cur !== nextStr) {
          localStorage.setItem(STORAGE_KEYS.CASH_SHIFT, nextStr);
          hasChanges = true;
        }
      }

      if (hasChanges) {
        window.dispatchEvent(new CustomEvent('taller_data_synced', { detail: data }));
      }
      return hasChanges;
    } catch (e) {
      return false;
    }
  },

  // Reset demo data / Dejar todo en blanco para pruebas
  async resetToInitial() {
    if (typeof window === 'undefined') return;
    try {
      await fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'reset_all' }),
      });
    } catch {}
    localStorage.removeItem(STORAGE_KEYS.COMPANIES);
    localStorage.removeItem(STORAGE_KEYS.CLIENTS);
    localStorage.removeItem(STORAGE_KEYS.VEHICLES);
    localStorage.removeItem(STORAGE_KEYS.WORK_ORDERS);
    localStorage.removeItem(STORAGE_KEYS.CASH_SHIFT);
    window.location.reload();
  },
};
