'use client';

import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { Smartphone, X, Copy, Check } from 'lucide-react';

interface MobileConnectModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MobileConnectModal: React.FC<MobileConnectModalProps> = ({ isOpen, onClose }) => {
  const [mobileUrl, setMobileUrl] = useState('http://192.168.1.194:3000');
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    fetch('/api/network-info')
      .then((res) => res.json())
      .then((data) => {
        const url = data?.lanOrigin || 'http://192.168.1.194:3000';
        setMobileUrl(url);
        QRCode.toDataURL(url, {
          width: 260,
          margin: 1,
          color: { dark: '#000000', light: '#ffffff' },
        }).then((qr) => setQrCodeUrl(qr));
      })
      .catch(() => {
        const fallback = 'http://192.168.1.194:3000';
        setMobileUrl(fallback);
        QRCode.toDataURL(fallback, { width: 260, margin: 1 }).then((qr) => setQrCodeUrl(qr));
      });
  }, [isOpen]);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(mobileUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-sm w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 text-center">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-50 text-sky-600 border border-sky-200">
              <Smartphone className="w-5 h-5" />
            </span>
            <div className="text-left">
              <h3 className="text-base font-bold text-slate-900 leading-tight">
                Conectar Celular / Tablet
              </h3>
              <span className="text-[11px] text-slate-500">Misma red Wi-Fi del taller</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3">
          <p className="text-xs text-slate-600">
            Abre la <strong>cámara de tu celular</strong> y apunta directamente a este código QR:
          </p>

          {/* Contenedor del QR */}
          <div className="bg-slate-50 p-4 rounded-2xl border-2 border-dashed border-sky-300 inline-block shadow-inner">
            {qrCodeUrl ? (
              <img
                src={qrCodeUrl}
                alt="Escanear para abrir en celular"
                className="w-52 h-52 mx-auto rounded-xl shadow-xs"
              />
            ) : (
              <div className="w-52 h-52 flex items-center justify-center text-xs text-slate-400">
                Cargando código QR...
              </div>
            )}
          </div>

          {/* Dirección IP y botón de copiar */}
          <div className="space-y-1.5 text-left bg-slate-50 p-3 rounded-xl border border-slate-200">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
              O escribe esta dirección en Safari / Chrome:
            </span>
            <div className="flex items-center justify-between gap-2">
              <span className="font-mono font-bold text-xs text-sky-800 truncate select-all">
                {mobileUrl}
              </span>
              <button
                onClick={handleCopyLink}
                className="flex items-center gap-1 px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-bold shrink-0 transition-colors cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copiado' : 'Copiar'}</span>
              </button>
            </div>
          </div>

          {/* Instrucción crucial */}
          <div className="p-2.5 bg-amber-50 rounded-xl border border-amber-200 text-left text-[11px] text-amber-950">
            <strong>⚠️ Requisito importante:</strong> Tu celular o tablet debe estar conectado al <strong>mismo Wi-Fi</strong> que esta computadora (no con datos móviles 4G/5G).
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs transition-colors cursor-pointer"
        >
          Entendido / Cerrar
        </button>
      </div>
    </div>
  );
};
