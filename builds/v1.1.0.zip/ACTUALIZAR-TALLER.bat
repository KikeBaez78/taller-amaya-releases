@echo off
title ACTUALIZAR TALLER AMAYA
color 0A

cd /d "%~dp0"

echo ========================================================
echo       APLICANDO ACTUALIZACION - TALLER AMAYA
echo ========================================================
echo.

echo [1/3] Cerrando procesos previos...
taskkill /F /IM node.exe >nul 2>&1
timeout /t 1 >nul

echo [2/3] Verificando proteccion de licencia de la maquina...
if exist "src\data\license.json" (
    echo [OK] Licencia casada con esta PC intacta.
)

echo [3/3] Iniciando Taller Amaya en segundo plano...
start wscript scripts\iniciar-taller-silencioso.vbs

echo.
echo ========================================================
echo  [EXITO] Sistema actualizado y base de datos limpia.
echo  - PIN Administrativo de Reyna Amaya: 2036
echo  - Acceso directo en escritorio listo
echo ========================================================
timeout /t 4 >nul
exit
