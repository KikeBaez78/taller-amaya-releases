' =========================================================================
' CREADOR DE ACCESO DIRECTO NATIVO DE WINDOWS - TALLER AMAYA
' =========================================================================

Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' Obtener la ruta base del proyecto
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
projectDir = fso.GetParentFolderName(scriptDir)

desktopPath = WshShell.SpecialFolders("Desktop")
shortcutPath = desktopPath & "\Taller Amaya.lnk"
vbsTarget = scriptDir & "\iniciar-taller-silencioso.vbs"
iconTarget = projectDir & "\public\logo.ico"

Set oShortcut = WshShell.CreateShortcut(shortcutPath)
oShortcut.TargetPath = "wscript.exe"
oShortcut.Arguments = """" & vbsTarget & """"
oShortcut.WorkingDirectory = projectDir
oShortcut.IconLocation = iconTarget & ",0"
oShortcut.Description = "Taller Amaya - Sistema Oficial de Control Automotriz"
oShortcut.Save

If fso.FileExists(shortcutPath) Then
    WScript.Echo "[EXITO] Acceso directo 'Taller Amaya' creado correctamente en tu Escritorio."
Else
    WScript.Echo "[ERROR] No se pudo crear el acceso directo en el Escritorio."
End If
