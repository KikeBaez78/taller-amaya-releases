' =========================================================================
' INICIADOR SILENCIOSO AUTONOMO (ZERO DEPENDENCIAS) - TALLER AMAYA
' =========================================================================

Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' Obtener la carpeta del proyecto
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)
projectDir = fso.GetParentFolderName(currentDir)

WshShell.CurrentDirectory = projectDir

' Detectar si existe el ejecutable portable de Node
portableNode = projectDir & "\runtime\node.exe"
standaloneScript = projectDir & "\.next\standalone\server.js"

If fso.FileExists(portableNode) And fso.FileExists(standaloneScript) Then
    ' Ejecucion ultra-limpia y directa sin intermediarios
    cmdToRun = """" & portableNode & """ """ & standaloneScript & """"
    WshShell.Run cmdToRun, 0, False
ElseIf fso.FileExists(standaloneScript) Then
    cmdToRun = "node """ & standaloneScript & """"
    WshShell.Run cmdToRun, 0, False
Else
    cmdToRun = "cmd /c npm start"
    WshShell.Run cmdToRun, 0, False
End If

' Esperar 2 segundos a que el servidor inicialice (arranca en ~50ms)
WScript.Sleep 2000

' Abrir en modo aplicacion nativa de Windows (sin barras de navegacion)
appUrl = "http://localhost:3000"
edgeCmd = "msedge --app=" & appUrl

On Error Resume Next
WshShell.Run edgeCmd, 1, False

If Err.Number <> 0 Then
    ' Fallback al navegador predeterminado
    WshShell.Run appUrl, 1, False
End If
