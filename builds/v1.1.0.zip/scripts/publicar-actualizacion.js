#!/usr/bin/env node

/**
 * =========================================================================
 * PUBLICADOR DE ACTUALIZACIONES OTA - TALLER AMAYA
 * USO EXCLUSIVO DEL DESARROLLADOR
 * =========================================================================
 * Uso:
 *   node scripts/publicar-actualizacion.js 1.2.0 "Título" "Notas..."
 */

const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);
const newVersion = args[0] || '1.1.0';
const title = args[1] || `Actualización Oficial v${newVersion}`;
const description = args[2] || 'Mejoras continuas y optimizaciones en Taller Amaya.';

const manifest = {
  version: newVersion,
  releaseDate: new Date().toISOString().split('T')[0],
  title: title,
  description: description,
  changelog: [
    'Mejoras en el rendimiento y estabilidad general del sistema.',
    'Optimización de base de datos e historial vehicular.',
    'Actualización de componentes del panel de control.',
  ],
  downloadUrl: `https://updates.talleramaya.com/builds/v${newVersion}.zip`,
  mandatory: false,
};

const outputPath = path.join(__dirname, '..', 'public-version.json');
fs.writeFileSync(outputPath, JSON.stringify(manifest, null, 2), 'utf8');

console.log('\n======================================================');
console.log('   MANIFIESTO DE ACTUALIZACIÓN GENERADO CON ÉXITO');
console.log('======================================================');
console.log(` Versión:      v${newVersion}`);
console.log(` Fecha:        ${manifest.releaseDate}`);
console.log(` Título:       ${title}`);
console.log(' Archivo listo en: public-version.json');
console.log(' Sube este archivo a tu servidor o repositorio de updates.');
console.log('======================================================\n');
