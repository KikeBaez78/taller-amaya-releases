'use client';

import React, { useState } from 'react';
import { StorageService } from '@/lib/storage';
import { PresupuestoItemParte, PresupuestoManoObra, Vehicle, WorkOrder } from '@/types';
import {
  Zap,
  X,
  Plus,
  Trash2,
  Wrench,
  Package,
  Calculator,
  MessageCircle,
  FileCheck,
  Printer,
  Car,
  User,
  Phone,
  Sparkles,
  Check,
  ArrowRight,
} from 'lucide-react';

interface CotizadorRapidoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConvertToOrder?: (quoteData: {
    clienteNombre: string;
    clienteTelefono: string;
    vehiculoInfo: string;
    placas: string;
    partes: PresupuestoItemParte[];
    manoObra: PresupuestoManoObra[];
    aplicaIva: boolean;
    total: number;
    falla: string;
  }) => void;
}

const PRESET_SERVICIOS = [
  {
    titulo: 'Afinación Mayor (4 Cilindros)',
    desc: 'Bujías, filtros (aire, aceite, gas), aceite sintético y lavado de inyectores',
    manoObra: [{ id: 'mo-p1', concepto: 'Afinación mayor completa y lavado de cuerpo de aceleración', costo: 1200, comisionPorcentaje: 35 }],
    partes: [
      { id: 'p-p1', descripcion: 'Aceite sintético 5W-30 (Garrafa 5L)', cantidad: 1, precioUnitario: 850, subtotal: 850, origen: 'taller' as const },
      { id: 'p-p2', descripcion: 'Juego de bujías platino NGK (4 pzas)', cantidad: 1, precioUnitario: 650, subtotal: 650, origen: 'taller' as const },
      { id: 'p-p3', descripcion: 'Filtro de aire y filtro de aceite', cantidad: 1, precioUnitario: 380, subtotal: 380, origen: 'taller' as const },
    ],
  },
  {
    titulo: 'Frenos Delanteros y Rectificado',
    desc: 'Balatas cerámicas nuevas + rectificado de 2 discos en torno',
    manoObra: [{ id: 'mo-p2', concepto: 'Cambio de balatas y rectificado de 2 rotores delanteros', costo: 850, comisionPorcentaje: 35 }],
    partes: [
      { id: 'p-p4', descripcion: 'Juego de balatas delanteras cerámicas Wagner/Duralast', cantidad: 1, precioUnitario: 750, subtotal: 750, origen: 'taller' as const },
      { id: 'p-p5', descripcion: 'Servicio de rectificado de 2 discos en torno', cantidad: 1, precioUnitario: 450, subtotal: 450, origen: 'taller' as const },
    ],
  },
  {
    titulo: 'Cambio de Aceite Sintético y Filtro',
    desc: 'Servicio express de lubricación y revisión de 25 puntos de seguridad',
    manoObra: [{ id: 'mo-p3', concepto: 'Mano de obra cambio de aceite y filtro + revisión de niveles', costo: 400, comisionPorcentaje: 30 }],
    partes: [
      { id: 'p-p6', descripcion: 'Garrafa Aceite Sintético 5W-30 / 5W-20', cantidad: 1, precioUnitario: 820, subtotal: 820, origen: 'taller' as const },
      { id: 'p-p7', descripcion: 'Filtro de aceite alto rendimiento', cantidad: 1, precioUnitario: 180, subtotal: 180, origen: 'taller' as const },
    ],
  },
  {
    titulo: 'Diagnóstico Scanner y Borrado Check Engine',
    desc: 'Escaneo electrónico OBD2 con reporte de códigos y lectura de sensores',
    manoObra: [{ id: 'mo-p4', concepto: 'Diagnóstico electrónico por scanner y prueba de sensores', costo: 500, comisionPorcentaje: 40 }],
    partes: [],
  },
  {
    titulo: 'Suspensión Delantera (Amortiguadores)',
    desc: 'Reemplazo de par de amortiguadores y bases delanteras',
    manoObra: [{ id: 'mo-p5', concepto: 'Instalación de amortiguadores delanteros y alineación', costo: 1400, comisionPorcentaje: 30 }],
    partes: [
      { id: 'p-p8', descripcion: 'Par de amortiguadores de gas delanteros', cantidad: 1, precioUnitario: 2600, subtotal: 2600, origen: 'taller' as const },
      { id: 'p-p9', descripcion: 'Par de bases de amortiguador con balero', cantidad: 1, precioUnitario: 900, subtotal: 900, origen: 'taller' as const },
    ],
  },
];

export const CotizadorRapidoModal: React.FC<CotizadorRapidoModalProps> = ({
  isOpen,
  onClose,
  onConvertToOrder,
}) => {
  const config = StorageService.getConfig();

  // Datos rápidos de cliente y auto
  const [clienteNombre, setClienteNombre] = useState('');
  const [clienteTelefono, setClienteTelefono] = useState('');
  const [vehiculoInfo, setVehiculoInfo] = useState('');
  const [placas, setPlacas] = useState('');
  const [falla, setFalla] = useState('');

  // Listas de cotización
  const [manoObra, setManoObra] = useState<PresupuestoManoObra[]>([]);
  const [partes, setPartes] = useState<PresupuestoItemParte[]>([]);
  const [aplicaIva, setAplicaIva] = useState(false);

  // Inputs para añadir items manualmente
  const [nuevoConceptoMO, setNuevoConceptoMO] = useState('');
  const [nuevoCostoMO, setNuevoCostoMO] = useState<number>(0);

  const [nuevaDescParte, setNuevaDescParte] = useState('');
  const [nuevaCantParte, setNuevaCantParte] = useState<number>(1);
  const [nuevoPrecioParte, setNuevoPrecioParte] = useState<number>(0);
  const [nuevoOrigenParte, setNuevoOrigenParte] = useState<'taller' | 'cliente'>('taller');

  // Cálculos reactivos
  const subtotalManoObra = manoObra.reduce((acc, curr) => acc + (curr.costo || 0), 0);
  const subtotalPartes = partes.reduce((acc, curr) => acc + (curr.subtotal || 0), 0);
  const subtotalSinIva = subtotalManoObra + subtotalPartes;
  const ivaMonto = aplicaIva ? Math.round(subtotalSinIva * (config.ivaFronteraPorcentaje / 100)) : 0;
  const totalCotizado = subtotalSinIva + ivaMonto;

  if (!isOpen) return null;

  // Cargar preset rápido
  const handleApplyPreset = (preset: typeof PRESET_SERVICIOS[0]) => {
    setManoObra([...preset.manoObra]);
    setPartes([...preset.partes]);
    if (!falla) setFalla(preset.titulo);
  };

  // Añadir Mano de Obra
  const handleAddManoObra = () => {
    if (!nuevoConceptoMO.trim() || nuevoCostoMO <= 0) return;
    const item: PresupuestoManoObra = {
      id: `mo-${Date.now()}`,
      concepto: nuevoConceptoMO.trim(),
      costo: nuevoCostoMO,
      comisionPorcentaje: 30,
    };
    setManoObra([...manoObra, item]);
    setNuevoConceptoMO('');
    setNuevoCostoMO(0);
  };

  // Añadir Parte
  const handleAddParte = () => {
    if (!nuevaDescParte.trim() || (nuevoOrigenParte === 'taller' && nuevoPrecioParte <= 0)) return;
    const subtotal = nuevoOrigenParte === 'cliente' ? 0 : nuevaCantParte * nuevoPrecioParte;
    const item: PresupuestoItemParte = {
      id: `p-${Date.now()}`,
      descripcion: nuevaDescParte.trim(),
      cantidad: nuevaCantParte,
      precioUnitario: nuevoOrigenParte === 'cliente' ? 0 : nuevoPrecioParte,
      subtotal,
      origen: nuevoOrigenParte,
    };
    setPartes([...partes, item]);
    setNuevaDescParte('');
    setNuevaCantParte(1);
    setNuevoPrecioParte(0);
    setNuevoOrigenParte('taller');
  };

  // Generar mensaje para WhatsApp
  const handleSendWhatsApp = () => {
    const tel = clienteTelefono.replace(/\D/g, '') || config.whatsapp;
    let mensaje = `*COTIZACIÓN TALLER AMAYA* 🚗🔧\n`;
    mensaje += `Estimado(a) *${clienteNombre || 'Cliente'}*:\n\n`;
    if (vehiculoInfo) mensaje += `Vehículo: *${vehiculoInfo}* ${placas ? `(Placas: ${placas})` : ''}\n`;
    if (falla) mensaje += `Servicio / Falla: ${falla}\n\n`;

    mensaje += `*📋 MANO DE OBRA:*\n`;
    if (manoObra.length === 0) {
      mensaje += `• Sin mano de obra especificada\n`;
    } else {
      manoObra.forEach((mo) => {
        mensaje += `• ${mo.concepto}: $${mo.costo.toLocaleString()} MXN\n`;
      });
      mensaje += `*Subtotal M.O.: $${subtotalManoObra.toLocaleString()} MXN*\n\n`;
    }

    mensaje += `*📦 REFACCIONES Y PARTES:*\n`;
    if (partes.length === 0) {
      mensaje += `• Ninguna o suministradas por cliente\n`;
    } else {
      partes.forEach((p) => {
        if (p.origen === 'cliente') {
          mensaje += `• ${p.descripcion} (Traída por cliente: $0)\n`;
        } else {
          mensaje += `• ${p.cantidad}x ${p.descripcion}: $${p.subtotal.toLocaleString()} MXN\n`;
        }
      });
      mensaje += `*Subtotal Partes: $${subtotalPartes.toLocaleString()} MXN*\n\n`;
    }

    if (aplicaIva) {
      mensaje += `Subtotal: $${subtotalSinIva.toLocaleString()} MXN\n`;
      mensaje += `IVA 8% Frontera: $${ivaMonto.toLocaleString()} MXN\n`;
    }
    mensaje += `*💵 TOTAL ESTIMADO: $${totalCotizado.toLocaleString()} MXN*\n\n`;
    mensaje += `📍 *Taller Amaya:* ${config.direccion}\n`;
    mensaje += `📞 Tel: ${config.telefonoLocal} | WhatsApp: ${config.whatsapp}\n`;
    mensaje += `_¿Gusta que le reservemos espacio o agendemos su vehículo?_`;

    const encoded = encodeURIComponent(mensaje);
    window.open(`https://wa.me/52${tel}?text=${encoded}`, '_blank');
  };

  // Imprimir o Guardar en PDF la Cotización
  const handlePrintCotizacionPDF = () => {
    const printWindow = window.open('', '_blank', 'width=950,height=1000');
    if (!printWindow) {
      alert(
        'Por favor permita las ventanas emergentes (pop-ups) en su navegador para imprimir o guardar la cotización en PDF.'
      );
      return;
    }

    const folioCotizacion = `COT-${Date.now().toString().slice(-6)}`;
    const fechaHora = new Date().toLocaleDateString('es-MX', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    const htmlContent = `
      <!DOCTYPE html>
      <html lang="es">
        <head>
          <meta charset="UTF-8" />
          <title>Cotización ${folioCotizacion} - Taller Mecánico Amaya</title>
          <style>
            @page {
              size: letter portrait;
              margin: 10mm 12mm;
            }
            * {
              box-sizing: border-box;
              margin: 0;
              padding: 0;
            }
            body {
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
              color: #0f172a;
              background-color: #f8fafc;
              font-size: 11px;
              line-height: 1.4;
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
            .no-print-bar {
              background: #0f172a;
              color: #ffffff;
              padding: 10px 20px;
              display: flex;
              align-items: center;
              justify-content: space-between;
              box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
              position: sticky;
              top: 0;
              z-index: 100;
            }
            .btn-print {
              background: #e11d48;
              color: #ffffff;
              border: none;
              padding: 8px 18px;
              font-size: 13px;
              font-weight: 700;
              border-radius: 8px;
              cursor: pointer;
              display: inline-flex;
              align-items: center;
              gap: 8px;
            }
            .btn-close {
              background: #334155;
              color: #e2e8f0;
              border: none;
              padding: 8px 14px;
              font-size: 12px;
              border-radius: 8px;
              cursor: pointer;
            }
            .sheet {
              max-width: 820px;
              margin: 20px auto;
              background: #ffffff;
              border: 1px solid #e2e8f0;
              border-radius: 12px;
              padding: 28px 32px;
              box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05);
            }
            @media print {
              body {
                background: #ffffff;
              }
              .no-print-bar {
                display: none !important;
              }
              .sheet {
                border: none;
                margin: 0;
                padding: 0;
                box-shadow: none;
                max-width: 100%;
              }
            }
            .header-grid {
              display: grid;
              grid-template-columns: 1fr 220px;
              gap: 20px;
              border-bottom: 2px solid #e11d48;
              padding-bottom: 14px;
              margin-bottom: 16px;
            }
            .brand-col h1 {
              font-size: 18px;
              font-weight: 900;
              color: #0f172a;
              text-transform: uppercase;
              letter-spacing: -0.5px;
            }
            .brand-col .sub {
              font-size: 11px;
              font-weight: 700;
              color: #e11d48;
              text-transform: uppercase;
              letter-spacing: 0.5px;
              margin-bottom: 4px;
            }
            .brand-col p {
              font-size: 9.5px;
              color: #475569;
              line-height: 1.35;
            }
            .folio-box {
              border: 1.5px solid #0f172a;
              border-radius: 8px;
              overflow: hidden;
              text-align: center;
            }
            .folio-header {
              background: #0f172a;
              color: #ffffff;
              font-size: 10px;
              font-weight: 800;
              padding: 4px 6px;
              text-transform: uppercase;
              letter-spacing: 0.5px;
            }
            .folio-body {
              padding: 6px;
              background: #fff;
            }
            .folio-num {
              font-family: monospace;
              font-size: 16px;
              font-weight: 900;
              color: #e11d48;
            }
            .folio-date {
              font-size: 8.5px;
              color: #64748b;
              margin-top: 2px;
            }
            .info-grid {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 12px;
              margin-bottom: 16px;
            }
            .info-box {
              border: 1px solid #cbd5e1;
              border-radius: 8px;
              padding: 8px 12px;
              background: #f8fafc;
            }
            .info-box-title {
              font-size: 9.5px;
              font-weight: 800;
              text-transform: uppercase;
              color: #0f172a;
              border-bottom: 1px solid #e2e8f0;
              padding-bottom: 3px;
              margin-bottom: 6px;
              display: flex;
              align-items: center;
              gap: 6px;
            }
            .info-row {
              display: flex;
              justify-content: space-between;
              margin-bottom: 3px;
              font-size: 9.5px;
            }
            .info-label {
              color: #64748b;
              font-weight: 600;
            }
            .info-value {
              font-weight: 700;
              color: #0f172a;
              text-align: right;
            }
            .falla-banner {
              background: #fff1f2;
              border-left: 4px solid #e11d48;
              border: 1px solid #fecdd3;
              border-left-width: 4px;
              border-radius: 6px;
              padding: 7px 10px;
              margin-bottom: 16px;
              font-size: 10px;
            }
            .falla-banner strong {
              color: #9f1239;
              text-transform: uppercase;
              font-size: 9px;
              display: block;
              margin-bottom: 2px;
            }
            .section-title {
              font-size: 10.5px;
              font-weight: 800;
              text-transform: uppercase;
              color: #0f172a;
              margin-bottom: 6px;
              display: flex;
              justify-content: space-between;
              align-items: center;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-bottom: 14px;
              font-size: 9.5px;
            }
            th {
              background: #0f172a;
              color: #ffffff;
              padding: 5px 8px;
              text-align: left;
              font-size: 9px;
              font-weight: 700;
              text-transform: uppercase;
              letter-spacing: 0.3px;
            }
            td {
              padding: 5px 8px;
              border-bottom: 1px solid #e2e8f0;
              color: #1e293b;
            }
            tr:nth-child(even) td {
              background-color: #f8fafc;
            }
            .text-right {
              text-align: right;
            }
            .text-center {
              text-align: center;
            }
            .tag-origen {
              font-size: 8px;
              font-weight: 700;
              padding: 1px 4px;
              border-radius: 3px;
              display: inline-block;
            }
            .tag-taller {
              background: #e0f2fe;
              color: #0369a1;
            }
            .tag-cliente {
              background: #fef3c7;
              color: #b45309;
            }
            .totals-container {
              display: flex;
              justify-content: flex-end;
              margin-top: 4px;
              margin-bottom: 18px;
            }
            .totals-table {
              width: 280px;
              border: 1px solid #cbd5e1;
              border-radius: 8px;
              overflow: hidden;
            }
            .totals-row {
              display: flex;
              justify-content: space-between;
              padding: 4px 10px;
              font-size: 10px;
              background: #f8fafc;
              border-bottom: 1px solid #e2e8f0;
            }
            .grand-total {
              background: #0f172a;
              color: #ffffff;
              display: flex;
              justify-content: space-between;
              align-items: center;
              padding: 8px 10px;
              font-weight: 900;
              font-size: 13px;
              border-bottom: none;
            }
            .grand-total span.amt {
              color: #fb7185;
              font-family: monospace;
              font-size: 15px;
            }
            .legal-box {
              background: #f8fafc;
              border: 1px solid #e2e8f0;
              border-radius: 8px;
              padding: 8px 10px;
              font-size: 8px;
              color: #475569;
              line-height: 1.35;
              margin-bottom: 22px;
            }
            .legal-title {
              font-weight: 800;
              color: #0f172a;
              text-transform: uppercase;
              font-size: 8.5px;
              margin-bottom: 4px;
            }
            .signatures-grid {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 30px;
              margin-top: 10px;
            }
            .sig-box {
              text-align: center;
            }
            .sig-line {
              border-bottom: 1.5px solid #0f172a;
              height: 44px;
              margin-bottom: 6px;
            }
            .sig-label {
              font-size: 9px;
              font-weight: 800;
              text-transform: uppercase;
              color: #0f172a;
            }
            .sig-sub {
              font-size: 8px;
              color: #64748b;
            }
            .footer-note {
              margin-top: 18px;
              text-align: center;
              font-size: 8px;
              color: #94a3b8;
              border-top: 1px dashed #e2e8f0;
              padding-top: 8px;
            }
          </style>
        </head>
        <body>
          <div class="no-print-bar">
            <div>
              <strong>Vista Previa de Cotización Rápida</strong>
              <span style="font-size: 11px; opacity: 0.8; margin-left: 8px;">Presione Imprimir para mandar a papel o Guardar como PDF</span>
            </div>
            <div style="display: flex; gap: 8px;">
              <button class="btn-print" onclick="window.print()">
                🖨️ Imprimir / Guardar en PDF
              </button>
              <button class="btn-close" onclick="window.close()">✕ Cerrar</button>
            </div>
          </div>

          <div class="sheet">
            <!-- Encabezado Taller Amaya -->
            <div class="header-grid">
              <div class="brand-col">
                <div class="sub">Servicio Mecánico Automotriz Profesional</div>
                <h1>${config.nombreComercial || 'TALLER AMAYA'}</h1>
                <p>
                  <strong>${config.razonSocial}</strong> • RFC: <strong>${config.rfc}</strong><br />
                  ${config.direccion}<br />
                  Tel: <strong>${config.telefonoLocal}</strong> • WhatsApp / Citas: <strong>${config.whatsapp}</strong> • Correo: ${config.correo}
                </p>
              </div>

              <div class="folio-box">
                <div class="folio-header">PRESUPUESTO / COTIZACIÓN</div>
                <div class="folio-body">
                  <div class="folio-num">${folioCotizacion}</div>
                  <div class="folio-date">${fechaHora}</div>
                  <div style="font-size: 8px; font-weight: 700; color: #0284c7; margin-top: 3px;">
                    VIGENCIA: 15 DÍAS NATURALES
                  </div>
                </div>
              </div>
            </div>

            <!-- Ficha Cliente y Vehículo -->
            <div class="info-grid">
              <div class="info-box">
                <div class="info-box-title">👤 Datos del Cliente</div>
                <div class="info-row">
                  <span class="info-label">Nombre del Cliente:</span>
                  <span class="info-value">${clienteNombre || 'Público en General'}</span>
                </div>
                <div class="info-row">
                  <span class="info-label">Teléfono / WhatsApp:</span>
                  <span class="info-value">${clienteTelefono || 'No especificado'}</span>
                </div>
                <div class="info-row">
                  <span class="info-label">Atendido en Recepción:</span>
                  <span class="info-value">Reyna Amaya</span>
                </div>
              </div>

              <div class="info-box">
                <div class="info-box-title">🚗 Ficha del Vehículo</div>
                <div class="info-row">
                  <span class="info-label">Vehículo (Año/Marca/Modelo):</span>
                  <span class="info-value">${vehiculoInfo || 'No especificado'}</span>
                </div>
                <div class="info-row">
                  <span class="info-label">Placas de Circulación:</span>
                  <span class="info-value" style="font-family: monospace; background: #e2e8f0; padding: 1px 4px; border-radius: 3px;">
                    ${placas || 'SIN PLACAS'}
                  </span>
                </div>
                <div class="info-row">
                  <span class="info-label">Tipo de Cotización:</span>
                  <span class="info-value" style="color: #e11d48;">Express / En Línea</span>
                </div>
              </div>
            </div>

            <!-- Falla o Trabajo Solicitado -->
            <div class="falla-banner">
              <strong>Diagnóstico Preliminar / Trabajo Solicitado por el Cliente:</strong>
              <div>${falla || 'Inspección mecánica general, diagnóstico y presupuesto preliminar.'}</div>
            </div>

            <!-- Tabla Mano de Obra -->
            <div class="section-title">
              <span>🔧 1. Mano de Obra y Servicios Especializados</span>
              <span style="font-size: 9px; color: #64748b; font-weight: normal;">Subtotal M.O.: <strong>$${subtotalManoObra.toLocaleString()} MXN</strong></span>
            </div>
            <table>
              <thead>
                <tr>
                  <th style="width: 40px;" class="text-center">#</th>
                  <th>Concepto / Descripción del Trabajo</th>
                  <th style="width: 130px;" class="text-center">Área Técnica</th>
                  <th style="width: 110px;" class="text-right">Importe MXN</th>
                </tr>
              </thead>
              <tbody>
                ${
                  manoObra.length === 0
                    ? `<tr><td colspan="4" class="text-center" style="padding: 12px; color: #94a3b8;">Sin conceptos de mano de obra añadidos</td></tr>`
                    : manoObra
                        .map(
                          (m, idx) => `
                        <tr>
                          <td class="text-center" style="font-weight: 700;">${idx + 1}</td>
                          <td><strong>${m.concepto}</strong></td>
                          <td class="text-center" style="color: #64748b; font-size: 8.5px;">Taller Amaya</td>
                          <td class="text-right" style="font-family: monospace; font-weight: 700;">$${m.costo.toLocaleString()}</td>
                        </tr>
                      `
                        )
                        .join('')
                }
              </tbody>
            </table>

            <!-- Tabla Refacciones y Partes -->
            <div class="section-title">
              <span>📦 2. Refacciones, Fluidos e Insumos</span>
              <span style="font-size: 9px; color: #64748b; font-weight: normal;">Subtotal Refacciones: <strong>$${subtotalPartes.toLocaleString()} MXN</strong></span>
            </div>
            <table>
              <thead>
                <tr>
                  <th style="width: 45px;" class="text-center">Cant.</th>
                  <th>Descripción de la Parte / Insumo</th>
                  <th style="width: 110px;" class="text-center">Origen</th>
                  <th style="width: 100px;" class="text-right">P. Unitario</th>
                  <th style="width: 110px;" class="text-right">Subtotal MXN</th>
                </tr>
              </thead>
              <tbody>
                ${
                  partes.length === 0
                    ? `<tr><td colspan="5" class="text-center" style="padding: 12px; color: #94a3b8;">No se cotizaron refacciones adicionales o son aportadas por el cliente</td></tr>`
                    : partes
                        .map(
                          (p) => `
                        <tr>
                          <td class="text-center" style="font-weight: 700;">${p.cantidad}</td>
                          <td><strong>${p.descripcion}</strong></td>
                          <td class="text-center">
                            <span class="tag-origen ${p.origen === 'cliente' ? 'tag-cliente' : 'tag-taller'}">
                              ${p.origen === 'cliente' ? 'Cliente ($0)' : 'Surtida Taller'}
                            </span>
                          </td>
                          <td class="text-right" style="font-family: monospace;">
                            ${p.origen === 'cliente' ? '$0' : `$${p.precioUnitario.toLocaleString()}`}
                          </td>
                          <td class="text-right" style="font-family: monospace; font-weight: 700;">
                            ${p.origen === 'cliente' ? '$0' : `$${p.subtotal.toLocaleString()}`}
                          </td>
                        </tr>
                      `
                        )
                        .join('')
                }
              </tbody>
            </table>

            <!-- Cuadro de Totales -->
            <div class="totals-container">
              <div class="totals-table">
                <div class="totals-row">
                  <span>Subtotal Mano de Obra:</span>
                  <strong style="font-family: monospace;">$${subtotalManoObra.toLocaleString()} MXN</strong>
                </div>
                <div class="totals-row">
                  <span>Subtotal Refacciones:</span>
                  <strong style="font-family: monospace;">$${subtotalPartes.toLocaleString()} MXN</strong>
                </div>
                <div class="totals-row">
                  <span>Subtotal Neto:</span>
                  <strong style="font-family: monospace;">$${subtotalSinIva.toLocaleString()} MXN</strong>
                </div>
                ${
                  aplicaIva
                    ? `
                  <div class="totals-row" style="color: #e11d48;">
                    <span>IVA 8% Frontera (Tijuana):</span>
                    <strong style="font-family: monospace;">$${ivaMonto.toLocaleString()} MXN</strong>
                  </div>
                `
                    : ''
                }
                <div class="grand-total">
                  <span>TOTAL ESTIMADO:</span>
                  <span class="amt">$${totalCotizado.toLocaleString()} MXN</span>
                </div>
              </div>
            </div>

            <!-- Términos y Cláusulas -->
            <div class="legal-box">
              <div class="legal-title">Términos, Garantía y Condiciones del Presupuesto:</div>
              <div>• <strong>Vigencia:</strong> Este presupuesto tiene una validez de 15 días naturales a partir de la fecha de emisión.</div>
              <div>• <strong>Anticipos:</strong> En caso de requerir refacciones bajo pedido especial o de importación, se solicitará un anticipo mínimo del 50% para ordenar los insumos.</div>
              <div>• <strong>Vicios Ocultos:</strong> El presupuesto se basa en diagnóstico preliminar. Si al desarmar se detectan daños o piezas desgastadas que no hayan sido visibles, se solicitará autorización previa al cliente antes de ejecutar el gasto extra.</div>
              <div>• <strong>Garantía:</strong> 30 días naturales en mano de obra. Las piezas nuevas cuentan con la garantía que expide el fabricante. No asumimos responsabilidad por piezas o refacciones aportadas directamente por el cliente.</div>
            </div>

            <!-- Firmas -->
            <div class="signatures-grid">
              <div class="sig-box">
                <div class="sig-line"></div>
                <div class="sig-label">Firma del Cliente de Conformidad</div>
                <div class="sig-sub">${clienteNombre || 'Nombre y Firma del Cliente'}</div>
              </div>

              <div class="sig-box">
                <div class="sig-line"></div>
                <div class="sig-label">Por Taller Mecánico Amaya</div>
                <div class="sig-sub">Reyna Guadalupe Amaya Fajardo • Administración</div>
              </div>
            </div>

            <div class="footer-note">
              ${config.razonSocial} • ${config.direccion} • Tijuana, Baja California • Tel: ${config.telefonoLocal} • WhatsApp: ${config.whatsapp}
            </div>
          </div>

          <script>
            window.addEventListener('load', () => {
              setTimeout(() => {
                window.print();
              }, 400);
            });
          </script>
        </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  // Convertir a Orden
  const handleConvert = () => {
    if (onConvertToOrder) {
      onConvertToOrder({
        clienteNombre,
        clienteTelefono,
        vehiculoInfo,
        placas,
        partes,
        manoObra,
        aplicaIva,
        total: totalCotizado,
        falla: falla || 'Cotización express aprobada',
      });
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-fadeIn">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl text-slate-800 overflow-hidden">
        {/* Cabecera */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-50 via-white to-rose-50/50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center border border-rose-200 shadow-sm">
              <Zap className="w-5 h-5 fill-rose-600" />
            </div>
            <div>
              <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                <span>Cotizador Rápido Express</span>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 border border-rose-200">
                  Para clientes con prisa
                </span>
              </h2>
              <p className="text-xs text-slate-500">
                Calcula presupuesto en 30 segundos, envía por WhatsApp o convierte en orden formal
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Cuerpo con Scroll */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6 flex-1 bg-slate-50/50">
          {/* Paquetes / Presets Rápidos con 1 Clic */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1.5 mb-2.5">
              <Sparkles className="w-4 h-4 text-rose-500" />
              <span>1. Seleccionar Paquete Rápido (Opcional):</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {PRESET_SERVICIOS.map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleApplyPreset(preset)}
                  className="text-left p-3 rounded-2xl bg-white hover:bg-rose-50/60 border border-slate-200 hover:border-rose-300 transition-all shadow-sm hover:shadow group flex flex-col justify-between"
                >
                  <div>
                    <h4 className="text-xs font-bold text-slate-800 group-hover:text-rose-700 flex items-center justify-between">
                      <span>{preset.titulo}</span>
                      <Plus className="w-3.5 h-3.5 text-slate-400 group-hover:text-rose-600" />
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">{preset.desc}</p>
                  </div>
                  <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] font-mono">
                    <span className="text-slate-400">Est. M.O. + Partes:</span>
                    <strong className="text-rose-600 font-bold">
                      ${(
                        preset.manoObra.reduce((a, b) => a + b.costo, 0) +
                        preset.partes.reduce((a, b) => a + b.subtotal, 0)
                      ).toLocaleString()}{' '}
                      MXN
                    </strong>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Datos Rápidos del Cliente y Vehículo */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
              <Car className="w-4 h-4 text-slate-500" />
              <span>2. Datos del Cliente y Vehículo:</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="text-slate-600 font-medium block mb-1">Nombre del Cliente:</label>
                <input
                  type="text"
                  placeholder="Ej. Juan Pérez"
                  value={clienteNombre}
                  onChange={(e) => setClienteNombre(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="text-slate-600 font-medium block mb-1">WhatsApp / Celular:</label>
                <input
                  type="tel"
                  placeholder="664-123-4567"
                  value={clienteTelefono}
                  onChange={(e) => setClienteTelefono(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 font-mono focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="text-slate-600 font-medium block mb-1">Vehículo (Año/Marca/Modelo):</label>
                <input
                  type="text"
                  placeholder="Ej. 2018 Nissan Versa"
                  value={vehiculoInfo}
                  onChange={(e) => setVehiculoInfo(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="text-slate-600 font-medium block mb-1">Placas (Opcional):</label>
                <input
                  type="text"
                  placeholder="BJH-44-12"
                  value={placas}
                  onChange={(e) => setPlacas(e.target.value.toUpperCase())}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 font-mono uppercase focus:outline-none focus:border-rose-500"
                />
              </div>
            </div>

            <div>
              <label className="text-slate-600 font-medium block mb-1 text-xs">Falla o Trabajo a Cotizar:</label>
              <input
                type="text"
                placeholder="Ej. Frenos delanteros, zumbido al dar vuelta, afinación..."
                value={falla}
                onChange={(e) => setFalla(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>

          {/* Desglose Mano de Obra y Partes */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Columna Mano de Obra */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <Wrench className="w-4 h-4 text-rose-600" />
                    <span>Mano de Obra ({manoObra.length})</span>
                  </h3>
                  <span className="font-mono font-bold text-rose-600 text-xs">
                    Subtotal: ${subtotalManoObra.toLocaleString()} MXN
                  </span>
                </div>

                {/* Lista de Mano de Obra */}
                <div className="space-y-1.5 min-h-[90px] max-h-[180px] overflow-y-auto mb-3">
                  {manoObra.length === 0 ? (
                    <div className="text-center py-6 text-slate-400 text-xs">
                      No hay conceptos de mano de obra añadidos
                    </div>
                  ) : (
                    manoObra.map((mo) => (
                      <div
                        key={mo.id}
                        className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                      >
                        <span className="font-medium text-slate-800 flex-1 truncate pr-2">
                          {mo.concepto}
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-slate-900">${mo.costo.toLocaleString()}</span>
                          <button
                            type="button"
                            onClick={() => setManoObra(manoObra.filter((m) => m.id !== mo.id))}
                            className="p-1 text-slate-400 hover:text-rose-600"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Agregar Concepto Mano de Obra Rápido */}
              <div className="pt-2 border-t border-slate-100 flex gap-2">
                <input
                  type="text"
                  placeholder="Concepto de mano de obra..."
                  value={nuevoConceptoMO}
                  onChange={(e) => setNuevoConceptoMO(e.target.value)}
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-rose-500"
                />
                <input
                  type="number"
                  placeholder="$ Monto"
                  value={nuevoCostoMO || ''}
                  onChange={(e) => setNuevoCostoMO(parseFloat(e.target.value) || 0)}
                  className="w-24 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-mono text-slate-800 focus:outline-none focus:border-rose-500"
                />
                <button
                  type="button"
                  onClick={handleAddManoObra}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold"
                >
                  +
                </button>
              </div>
            </div>

            {/* Columna Refacciones y Partes */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <Package className="w-4 h-4 text-emerald-600" />
                    <span>Partes y Refacciones ({partes.length})</span>
                  </h3>
                  <span className="font-mono font-bold text-emerald-600 text-xs">
                    Subtotal: ${subtotalPartes.toLocaleString()} MXN
                  </span>
                </div>

                {/* Lista de Partes */}
                <div className="space-y-1.5 min-h-[90px] max-h-[180px] overflow-y-auto mb-3">
                  {partes.length === 0 ? (
                    <div className="text-center py-6 text-slate-400 text-xs">
                      No hay piezas agregadas o son del cliente
                    </div>
                  ) : (
                    partes.map((p) => (
                      <div
                        key={p.id}
                        className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                      >
                        <div className="flex-1 truncate pr-2">
                          <span className="font-medium text-slate-800 block truncate">
                            {p.cantidad}x {p.descripcion}
                          </span>
                          <span
                            className={`text-[10px] font-semibold ${
                              p.origen === 'cliente' ? 'text-amber-600' : 'text-slate-400'
                            }`}
                          >
                            {p.origen === 'cliente' ? '✓ Traída por cliente' : 'Surtida por taller'}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-slate-900">
                            {p.origen === 'cliente' ? '$0' : `$${p.subtotal.toLocaleString()}`}
                          </span>
                          <button
                            type="button"
                            onClick={() => setPartes(partes.filter((part) => part.id !== p.id))}
                            className="p-1 text-slate-400 hover:text-rose-600"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Agregar Parte Rápida */}
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Descripción de la pieza..."
                    value={nuevaDescParte}
                    onChange={(e) => setNuevaDescParte(e.target.value)}
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-rose-500"
                  />
                  <select
                    value={nuevoOrigenParte}
                    onChange={(e) => setNuevoOrigenParte(e.target.value as any)}
                    className="bg-slate-50 border border-slate-200 rounded-xl px-2 py-1.5 text-xs text-slate-700"
                  >
                    <option value="taller">Taller</option>
                    <option value="cliente">Cliente</option>
                  </select>
                </div>
                <div className="flex gap-2">
                  <input
                    type="number"
                    min="1"
                    placeholder="Cant"
                    value={nuevaCantParte || ''}
                    onChange={(e) => setNuevaCantParte(parseInt(e.target.value) || 1)}
                    className="w-16 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-mono text-slate-800"
                  />
                  <input
                    type="number"
                    placeholder="$ P. Unitario"
                    disabled={nuevoOrigenParte === 'cliente'}
                    value={nuevoOrigenParte === 'cliente' ? 0 : nuevoPrecioParte || ''}
                    onChange={(e) => setNuevoPrecioParte(parseFloat(e.target.value) || 0)}
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-mono text-slate-800 disabled:opacity-50"
                  />
                  <button
                    type="button"
                    onClick={handleAddParte}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold"
                  >
                    + Agregar
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Resumen Final de Cotización */}
          <div className="bg-gradient-to-br from-rose-50/60 to-slate-50 border border-rose-200/80 rounded-2xl p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-1">
              <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-slate-700 font-semibold">
                <input
                  type="checkbox"
                  checked={aplicaIva}
                  onChange={(e) => setAplicaIva(e.target.checked)}
                  className="rounded border-slate-300 text-rose-600 focus:ring-rose-500 w-4 h-4"
                />
                <span>Aplicar 8% IVA Zona Fronteriza (Tijuana - si requiere factura)</span>
              </label>
              <div className="flex items-center gap-4 text-xs font-mono text-slate-600 pt-1">
                <span>M.O.: ${subtotalManoObra.toLocaleString()}</span>
                <span>•</span>
                <span>Partes: ${subtotalPartes.toLocaleString()}</span>
                {aplicaIva && (
                  <>
                    <span>•</span>
                    <span className="text-rose-600">IVA 8%: ${ivaMonto.toLocaleString()}</span>
                  </>
                )}
              </div>
            </div>

            <div className="text-right">
              <span className="text-[11px] uppercase font-bold text-slate-500 block">Total Cotizado Estimado:</span>
              <div className="text-2xl sm:text-3xl font-black font-mono text-slate-900 tracking-tight">
                ${totalCotizado.toLocaleString()} <span className="text-sm font-bold text-rose-600">MXN</span>
              </div>
            </div>
          </div>
        </div>

        {/* Barra de Acciones */}
        <div className="p-4 sm:p-5 bg-white border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold text-xs transition-colors"
          >
            Cerrar
          </button>

          <div className="flex items-center gap-2.5">
            {/* Botón Imprimir / Guardar en PDF */}
            <button
              type="button"
              onClick={handlePrintCotizacionPDF}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-md shadow-slate-900/20 transition-all cursor-pointer"
              title="Generar hoja de cotización formal e imprimir o guardar en PDF"
            >
              <Printer className="w-4 h-4 text-rose-400" />
              <span>Imprimir / Guardar en PDF</span>
            </button>

            {/* Botón Enviar WhatsApp */}
            <button
              type="button"
              onClick={handleSendWhatsApp}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-all"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Enviar Cotización por WhatsApp</span>
            </button>

            {/* Botón Convertir en Orden */}
            <button
              type="button"
              onClick={handleConvert}
              className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold text-xs shadow-lg shadow-rose-600/30 transition-all"
            >
              <span>Convertir en Orden Formal</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
