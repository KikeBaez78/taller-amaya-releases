@echo off
title ACTUALIZAR TALLER AMAYA
color 0A

cd /d "%~dp0"

echo ========================================================
echo       APLICANDO ACTUALIZACION - TALLER AMAYA
echo ========================================================
echo.

echo [1/4] Cerrando procesos previos de Taller Amaya...
taskkill /F /IM node.exe >nul 2>&1
timeout /t 1 >nul

echo [2/4] Limpiando archivos temporales y versiones anteriores obsoletas...
:: Eliminar archivos residuales o zips viejos
if exist "temp_ota_update.zip" del /f /q "temp_ota_update.zip" >nul 2>&1
if exist ".next\cache" rd /s /q ".next\cache" >nul 2>&1

:: Eliminar carpetas duplicadas viejas si existen en el escritorio
if exist "..\taller-amaya 2" rd /s /q "..\taller-amaya 2" >nul 2>&1
if exist "C:\Users\TALLER\Desktop\taller-amaya 2" rd /s /q "C:\Users\TALLER\Desktop\taller-amaya 2" >nul 2>&1
if exist "..\actualizacion-v1.1" rd /s /q "..\actualizacion-v1.1" >nul 2>&1
if exist "..\actualizacion-v1.1.zip" del /f /q "..\actualizacion-v1.1.zip" >nul 2>&1
if exist "..\actualizacion-v1.2.zip" del /f /q "..\actualizacion-v1.2.zip" >nul 2>&1

echo [OK] Limpieza de versiones viejas completada.

echo.
echo [3/4] Verificando proteccion de datos y licencia...
if exist "src\data\license.json" (
    echo [OK] Licencia oficial casada con este equipo: INTACTA.
)
if exist "src\data\db.json" (
    echo [OK] Base de datos de clientes, vehiculos y ordenes: INTACTA.
)

:: Habilitar puerto 3000 en Windows Firewall para Tablet y Celular
netsh advfirewall firewall add rule name="Taller Amaya Puerto 3000" dir=in action=allow protocol=TCP localport=3000 >nul 2>&1

echo.
echo [4/4] Iniciando Taller Amaya v1.2.1 en segundo plano...
start wscript scripts\iniciar-taller-silencioso.vbs

echo.
echo ========================================================
echo  [EXITO] Sistema actualizado y versiones viejas eliminadas.
echo  - PIN Administrativo de Reyna Amaya: 2036
echo  - Pantalla de Bahia: Accesible desde Tablet y Mostrador
echo  - Cotizador Rapido: Boton Imprimir / Guardar en PDF listo
echo  - Respaldos diarios activos
echo ========================================================
timeout /t 5 >nul
exit
