import {
  Company,
  Client,
  Vehicle,
  WorkOrder,
  Mechanic,
  CashRegisterShift,
  CashExpense,
  PaymentRecord,
  MandatoryPhotos,
  DamagePoint,
  FuelLevel,
  ServiceItem,
} from '@/types';
import {
  INITIAL_COMPANIES,
  INITIAL_CLIENTS,
  INITIAL_VEHICLES,
  INITIAL_WORK_ORDERS,
  INITIAL_CASH_SHIFT,
} from '@/data/mockData';
import { INITIAL_MECHANICS, TALLER_CONFIG } from '@/data/tallerConfig';

const STORAGE_KEYS = {
  COMPANIES: 'taller_amaya_companies_v3',
  CLIENTS: 'taller_amaya_clients_v3',
  VEHICLES: 'taller_amaya_vehicles_v3',
  WORK_ORDERS: 'taller_amaya_work_orders_v3',
  MECHANICS: 'taller_amaya_mechanics_v3',
  CASH_SHIFT: 'taller_amaya_cash_shift_v3',
};

const VAULT_PREFIX = 'taller_amaya_vault_backup_';

// Carga segura con baúl permanente que jamás permite borrado accidental
function load<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Respaldar inmediatamente en el baúl permanente
        localStorage.setItem(VAULT_PREFIX + key, raw);
        return parsed as T;
      }
      if (!Array.isArray(parsed) && parsed) {
        return parsed as T;
      }
    }
    // Si la clave principal estaba vacía o nula, revisar el baúl permanente de rescate
    const vaultRaw = localStorage.getItem(VAULT_PREFIX + key);
    if (vaultRaw) {
      const vaultParsed = JSON.parse(vaultRaw);
      if (Array.isArray(vaultParsed) && vaultParsed.length > 0) {
        console.warn(`[Vault] Restaurando automáticamente datos protegidos para ${key}`);
        localStorage.setItem(key, vaultRaw);
        return vaultParsed as T;
      }
    }
    return fallback;
  } catch (e) {
    console.error(`Error loading ${key}`, e);
    return fallback;
  }
}

function save<T>(key: string, data: T) {
  if (typeof window === 'undefined') return;
  try {
    const serialized = JSON.stringify(data);
    localStorage.setItem(key, serialized);
    if (Array.isArray(data) && data.length > 0) {
      localStorage.setItem(VAULT_PREFIX + key, serialized);
    }
  } catch (e) {
    console.error(`Error saving ${key}`, e);
  }
}

export const StorageService = {
  // CONFIG
  getConfig() {
    return TALLER_CONFIG;
  },

  // COMPANIES & CRM
  getCompanies(): Company[] {
    return load<Company[]>(STORAGE_KEYS.COMPANIES, INITIAL_COMPANIES);
  },
  saveCompany(company: Company): Company[] {
    const list = this.getCompanies();
    const idx = list.findIndex((c) => c.id === company.id);
    if (idx >= 0) {
      list[idx] = company;
    } else {
      list.push(company);
    }
    save(STORAGE_KEYS.COMPANIES, list);
    if (typeof window !== 'undefined') {
      fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'save_company', company }),
      }).catch(() => {});
    }
    return list;
  },


  // CLIENTS
  getClients(): Client[] {
    return load<Client[]>(STORAGE_KEYS.CLIENTS, INITIAL_CLIENTS);
  },
  saveClient(client: Client): Client[] {
    const list = this.getClients();
    const idx = list.findIndex((c) => c.id === client.id);
    if (idx >= 0) {
      list[idx] = client;
    } else {
      list.push(client);
    }
    save(STORAGE_KEYS.CLIENTS, list);
    if (typeof window !== 'undefined') {
      fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'save_client', client }),
      }).catch(() => {});
    }
    return list;
  },


  // VEHICLES
  getVehicles(): Vehicle[] {
    return load<Vehicle[]>(STORAGE_KEYS.VEHICLES, INITIAL_VEHICLES);
  },
  saveVehicle(vehicle: Vehicle): Vehicle[] {
    const list = this.getVehicles();
    const idx = list.findIndex((v) => v.id === vehicle.id);
    if (idx >= 0) {
      list[idx] = vehicle;
    } else {
      list.push(vehicle);
    }
    save(STORAGE_KEYS.VEHICLES, list);
    if (typeof window !== 'undefined') {
      fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'save_vehicle', vehicle }),
      }).catch(() => {});
    }
    return list;
  },


  // WORK ORDERS & FOLIOS
  getWorkOrders(): WorkOrder[] {
    return load<WorkOrder[]>(STORAGE_KEYS.WORK_ORDERS, INITIAL_WORK_ORDERS);
  },
  saveWorkOrder(order: WorkOrder): WorkOrder[] {
    order.updatedAt = new Date().toISOString();
    const list = this.getWorkOrders();
    const idx = list.findIndex((o) => o.id === order.id);
    if (idx >= 0) {
      list[idx] = order;
    } else {
      list.unshift(order);
    }
    save(STORAGE_KEYS.WORK_ORDERS, list);

    // Sincronizar en segundo plano con la API central
    if (typeof window !== 'undefined') {
      try {
        const v = this.getVehicles().find((veh) => veh.id === order.vehiculoId);
        const c = this.getClients().find((cli) => cli.id === order.clienteId);
        fetch('/api/sync', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            type: 'save_order',
            order,
            vehicle: v,
            client: c,
          }),
        }).catch(() => {});
        window.dispatchEvent(new CustomEvent('taller_data_synced'));
      } catch {}
    }

    return list;
  },

  /**
   * Guardado atómico e infalible de Orden + Vehículo + Cliente
   * Espera la confirmación del servidor antes de resolver (cero pérdida de datos)
   */
  async saveWorkOrderCompleteAsync(
    order: WorkOrder,
    vehicle?: Vehicle,
    client?: Client
  ): Promise<boolean> {
    const nowIso = new Date().toISOString();
    order.updatedAt = nowIso;

    // 1. Asentar Vehículo si se modificó
    if (vehicle) {
      vehicle.updatedAt = nowIso;
      const vList = this.getVehicles();
      const vIdx = vList.findIndex((v) => v.id === vehicle.id);
      if (vIdx >= 0) vList[vIdx] = vehicle;
      else vList.push(vehicle);
      save(STORAGE_KEYS.VEHICLES, vList);
    }

    // 2. Asentar Cliente si se modificó
    if (client) {
      client.updatedAt = nowIso;
      const cList = this.getClients();
      const cIdx = cList.findIndex((c) => c.id === client.id);
      if (cIdx >= 0) cList[cIdx] = client;
      else cList.push(client);
      save(STORAGE_KEYS.CLIENTS, cList);
    }

    // 3. Asentar Orden
    const oList = this.getWorkOrders();
    const oIdx = oList.findIndex((o) => o.id === order.id);
    if (oIdx >= 0) oList[oIdx] = order;
    else oList.unshift(order);
    save(STORAGE_KEYS.WORK_ORDERS, oList);

    // 4. Enviar transacción atómica única al servidor
    if (typeof window !== 'undefined') {
      try {
        const effVehicle = vehicle || this.getVehicles().find((veh) => veh.id === order.vehiculoId);
        const effClient = client || this.getClients().find((cli) => cli.id === order.clienteId);

        const res = await fetch('/api/sync', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            type: 'save_order',
            order,
            vehicle: effVehicle,
            client: effClient,
          }),
        });

        window.dispatchEvent(new CustomEvent('taller_data_synced'));
        return res.ok;
      } catch (err) {
        window.dispatchEvent(new CustomEvent('taller_data_synced'));
        return false;
      }
    }
    return true;
  },

  deleteWorkOrder(idOrFolio: string): WorkOrder[] {
    const list = this.getWorkOrders().filter((o) => o.id !== idOrFolio && o.folio !== idOrFolio);
    save(STORAGE_KEYS.WORK_ORDERS, list);
    if (typeof window !== 'undefined') {
      fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'delete_order', id: idOrFolio }),
      }).catch(() => {});
    }
    return list;
  },

  // Generador del siguiente folio sugerido (iniciando en 0900)
  getNextFolio(): string {
    const orders = this.getWorkOrders();
    const numericFolios = orders
      .map((o) => parseInt(o.folio, 10))
      .filter((n) => !isNaN(n));

    if (numericFolios.length === 0) {
      return '0900';
    }
    const maxFolio = Math.max(...numericFolios, 899);
    return String(maxFolio + 1).padStart(4, '0');
  },

  // MECHANICS
  getMechanics(): Mechanic[] {
    return load<Mechanic[]>(STORAGE_KEYS.MECHANICS, INITIAL_MECHANICS);
  },
  saveMechanics(list: Mechanic[]): Mechanic[] {
    const nowIso = new Date().toISOString();
    list.forEach((m) => {
      if (!m.updatedAt) m.updatedAt = nowIso;
    });
    save(STORAGE_KEYS.MECHANICS, list);
    if (typeof window !== 'undefined') {
      fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'save_mechanics', mechanics: list }),
      }).catch(() => {});
      window.dispatchEvent(new CustomEvent('taller_data_synced'));
    }
    return list;
  },

  saveMechanic(mechanic: Mechanic): Mechanic[] {
    mechanic.updatedAt = new Date().toISOString();
    const list = this.getMechanics();
    const idx = list.findIndex((m) => m.id === mechanic.id);
    if (idx >= 0) {
      list[idx] = mechanic;
    } else {
      list.push(mechanic);
    }
    this.cascadeMechanicNameUpdate(mechanic.id, mechanic.nombre);
    return this.saveMechanics(list);
  },

  async saveMechanicAsync(mechanic: Mechanic): Promise<boolean> {
    mechanic.updatedAt = new Date().toISOString();
    const list = this.getMechanics();
    const idx = list.findIndex((m) => m.id === mechanic.id);
    if (idx >= 0) {
      list[idx] = mechanic;
    } else {
      list.push(mechanic);
    }
    this.cascadeMechanicNameUpdate(mechanic.id, mechanic.nombre);
    save(STORAGE_KEYS.MECHANICS, list);

    if (typeof window !== 'undefined') {
      try {
        const res = await fetch('/api/sync', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ type: 'save_mechanics', mechanics: list }),
        });
        window.dispatchEvent(new CustomEvent('taller_data_synced'));
        return res.ok;
      } catch {
        window.dispatchEvent(new CustomEvent('taller_data_synced'));
        return false;
      }
    }
    return true;
  },

  cascadeMechanicNameUpdate(mecId: string, newName: string) {
    try {
      const orders = this.getWorkOrders();
      let changed = false;
      orders.forEach((o) => {
        (o.servicios || []).forEach((s) => {
          if (s.mecanicoId === mecId && s.mecanicoNombre !== newName) {
            s.mecanicoNombre = newName;
            changed = true;
          }
        });
      });
      if (changed) {
        save(STORAGE_KEYS.WORK_ORDERS, orders);
      }
    } catch {}
  },

  deleteMechanic(id: string): Mechanic[] {
    const list = this.getMechanics().filter((m) => m.id !== id);
    return this.saveMechanics(list);
  },

  // CAJA & CORTES
  getCashShift(): CashRegisterShift {
    return load<CashRegisterShift>(STORAGE_KEYS.CASH_SHIFT, INITIAL_CASH_SHIFT);
  },
  saveCashShift(shift: CashRegisterShift): CashRegisterShift {
    save(STORAGE_KEYS.CASH_SHIFT, shift);
    if (typeof window !== 'undefined') {
      fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'save_cash_shift', cashShift: shift }),
      }).catch(() => {});
    }
    return shift;
  },

  addExpense(expense: Omit<CashExpense, 'id'>): CashRegisterShift {
    const shift = this.getCashShift();
    const newExpense: CashExpense = {
      ...expense,
      id: `gasto-${Date.now()}`,
    };
    shift.gastosMenores.push(newExpense);
    shift.totalGastosMenores += newExpense.monto;
    shift.efectivoEsperado =
      shift.fondoInicial + shift.ingresosEfectivo - shift.totalGastosMenores;
    return this.saveCashShift(shift);
  },

  updateExpense(id: string, updatedData: Partial<CashExpense>): CashRegisterShift {
    const shift = this.getCashShift();
    const idx = shift.gastosMenores.findIndex((g) => g.id === id);
    if (idx >= 0) {
      shift.gastosMenores[idx] = {
        ...shift.gastosMenores[idx],
        ...updatedData,
      };
      shift.totalGastosMenores = shift.gastosMenores.reduce((acc, g) => acc + Number(g.monto || 0), 0);
      shift.efectivoEsperado =
        shift.fondoInicial + shift.ingresosEfectivo - shift.totalGastosMenores;
      return this.saveCashShift(shift);
    }
    return shift;
  },

  deleteExpense(id: string): CashRegisterShift {
    const shift = this.getCashShift();
    shift.gastosMenores = shift.gastosMenores.filter((g) => g.id !== id);
    shift.totalGastosMenores = shift.gastosMenores.reduce((acc, g) => acc + Number(g.monto || 0), 0);
    shift.efectivoEsperado =
      shift.fondoInicial + shift.ingresosEfectivo - shift.totalGastosMenores;
    return this.saveCashShift(shift);
  },

  recordPaymentToCash(payment: PaymentRecord): CashRegisterShift {
    const shift = this.getCashShift();
    if (payment.metodo === 'efectivo') {
      shift.ingresosEfectivo += payment.monto;
    } else if (payment.metodo === 'tarjeta') {
      shift.ingresosTarjeta += payment.montoTotalConIva;
    } else if (payment.metodo === 'transferencia') {
      shift.ingresosTransferencia += payment.montoTotalConIva;
    }
    shift.efectivoEsperado =
      shift.fondoInicial + shift.ingresosEfectivo - shift.totalGastosMenores;
    return this.saveCashShift(shift);
  },

  // ==========================================
  // BITÁCORA Y BÚSQUEDA RELACIONAL POTENTE
  // Placas, Vehículo o Nombre de Cliente -> Vehículos con historial de visitas y servicios
  // ==========================================
  searchBitacora(query: string) {
    const q = query.trim().toLowerCase();
    const vehicles = this.getVehicles();
    const clients = this.getClients();
    const companies = this.getCompanies();
    const workOrders = this.getWorkOrders();

    if (!q) {
      // Retornar todos los vehículos ordenados por último servicio
      return vehicles.map((v) => this.hydrateVehicleRecord(v, clients, companies, workOrders));
    }

    // Filtrar vehículos donde coincida placa, marca, modelo, vin, nombre del cliente o empresa
    const matched = vehicles.filter((v) => {
      const matchPlacas = v.placas.toLowerCase().includes(q);
      const matchMarca = v.marca.toLowerCase().includes(q);
      const matchModelo = v.modelo.toLowerCase().includes(q);
      const matchVin = v.vin?.toLowerCase().includes(q) || false;
      const matchChofer = v.choferHabitual?.toLowerCase().includes(q) || false;

      // Buscar cliente
      const client = clients.find((c) => c.id === v.clienteId);
      const matchClient = client?.nombre.toLowerCase().includes(q) || false;

      // Buscar empresa
      const company = companies.find((c) => c.id === v.empresaId);
      const matchCompany =
        company?.razonSocial.toLowerCase().includes(q) ||
        company?.encargadoFlotilla.toLowerCase().includes(q) ||
        false;

      return (
        matchPlacas ||
        matchMarca ||
        matchModelo ||
        matchVin ||
        matchChofer ||
        matchClient ||
        matchCompany
      );
    });

    return matched.map((v) => this.hydrateVehicleRecord(v, clients, companies, workOrders));
  },

  hydrateVehicleRecord(
    v: Vehicle,
    clients: Client[],
    companies: Company[],
    workOrders: WorkOrder[]
  ) {
    const client = clients.find((c) => c.id === v.clienteId);
    const company = companies.find((c) => c.id === v.empresaId);
    // Filtrar todas las órdenes de este auto ordenadas cronológicamente
    const history = workOrders
      .filter((o) => o.vehiculoId === v.id)
      .sort((a, b) => new Date(b.fechaIngreso).getTime() - new Date(a.fechaIngreso).getTime());

    // Alerta de mantenimiento preventivo (regla: 2 meses o 10,000 km)
    let requiereMantenimiento = false;
    let motivoAlerta = '';

    if (v.ultimoServicioFecha) {
      const fechaUltimo = new Date(v.ultimoServicioFecha);
      const mesesTranscurridos =
        (Date.now() - fechaUltimo.getTime()) / (1000 * 60 * 60 * 24 * 30.4);
      if (mesesTranscurridos >= 2) {
        requiereMantenimiento = true;
        motivoAlerta = `Han pasado ${Math.floor(mesesTranscurridos)} meses desde su última visita.`;
      }
    }
    if (v.ultimoServicioKm && v.kilometrajeActual - v.ultimoServicioKm >= 10000) {
      requiereMantenimiento = true;
      const kmDiff = v.kilometrajeActual - v.ultimoServicioKm;
      motivoAlerta += (motivoAlerta ? ' Además, ' : '') + `recorrió ${kmDiff.toLocaleString()} km desde el último servicio.`;
    }

    return {
      vehicle: v,
      client,
      company,
      history,
      requiereMantenimiento,
      motivoAlerta,
    };
  },

  // Generar mensaje de WhatsApp con formato para invitar al cliente a servicio
  generateWhatsAppReminder(vehicle: Vehicle, clientName: string, telefono: string, motivo: string) {
    const mensaje = encodeURIComponent(
      `Hola ${clientName}, te saludamos de TALLER AMAYA en Tijuana B.C. 🚗🔧\n\nLe toca mantenimiento preventivo a tu vehículo *${vehicle.marca} ${vehicle.modelo}* (Placas: *${vehicle.placas}*).\n\nMotivo: ${motivo || 'Revisión periódica de 2 meses o 10,000 km'}.\n\n¿Deseas agendar tu cita esta semana? Estamos en C. Santo Domingo #19950, Buenos Aires Sur.\nTel: 6646295614.`
    );
    const cleanPhone = telefono.replace(/\D/g, '');
    return `https://wa.me/52${cleanPhone}?text=${mensaje}`;
  },

  // Generar mensaje de WhatsApp para avisar de un detalle o hallazgo extra en bahía
  generateWhatsAppExtraAlert(
    order: WorkOrder,
    vehicle: Vehicle | undefined,
    clientName: string,
    telefono: string,
    detalleExtra: string,
    costoExtra: number
  ) {
    const vehiculoDesc = vehicle ? `${vehicle.marca} ${vehicle.modelo} (Placas: ${vehicle.placas})` : 'tu vehículo';
    const trackingUrl = `https://talleramaya.com/seguimiento/${order.folio}`;
    const texto = `Hola ${clientName || 'Estimado Cliente'}, te saludamos de *TALLER AMAYA* 🔧\n\nAl realizar la inspección / desarme de tu vehículo *${vehiculoDesc}* (Folio *#${order.folio}*), detectamos el siguiente detalle que requiere atención:\n\n⚠️ *Detalle / Hallazgo Extra:* ${detalleExtra}\n💰 *Presupuesto Adicional Estimado:* $${costoExtra.toLocaleString()} MXN\n\n¿Nos autorizas proceder con este trabajo adicional? Puedes autorizar respondiendo a este mensaje o consultando tu orden en línea:\n${trackingUrl}\n\nQuedamos a la espera de tu respuesta. ¡Gracias!`;
    const cleanPhone = (telefono || '6640000000').replace(/\D/g, '');
    return `https://wa.me/52${cleanPhone}?text=${encodeURIComponent(texto)}`;
  },

  // Generar mensaje de WhatsApp para avisar que el vehículo ya está listo para pasar a recoger
  generateWhatsAppReadyAlert(
    order: WorkOrder,
    vehicle: Vehicle | undefined,
    clientName: string,
    telefono: string
  ) {
    const vehiculoDesc = vehicle ? `${vehicle.marca} ${vehicle.modelo} (Placas: ${vehicle.placas})` : 'tu vehículo';
    const trackingUrl = `https://talleramaya.com/seguimiento/${order.folio}`;
    const texto = `¡Buenas noticias ${clientName || 'Estimado Cliente'}! 🚗✨\n\nTu vehículo *${vehiculoDesc}* (Folio *#${order.folio}*) ya se encuentra *LISTO PARA RECOGER* en *TALLER AMAYA*.\n\n📊 *Resumen de Cuenta:*\n• Total del Servicio: $${order.subtotalGeneral.toLocaleString()} MXN\n• Total Abonado: $${order.totalPagado.toLocaleString()} MXN\n• *Saldo Pendiente a Liquidar:* $${order.saldoPendiente.toLocaleString()} MXN\n\n📍 Te esperamos en: C. Santo Domingo #19950, Col. Buenos Aires Sur, Tijuana B.C.\n⏰ Horario: Lunes a Sábado de 8:00 AM a 6:00 PM\nTel: 6646295614 / WA: 6644093068\n\nVer orden digital:\n${trackingUrl}`;
    const cleanPhone = (telefono || '6640000000').replace(/\D/g, '');
    return `https://wa.me/52${cleanPhone}?text=${encodeURIComponent(texto)}`;
  },

  // Sincronización bidireccional inteligente: NUNCA destruye datos existentes con arrays vacíos
  async syncFromServer(): Promise<boolean> {
    if (typeof window === 'undefined') return false;
    try {
      const res = await fetch('/api/sync?_t=' + Date.now(), { cache: 'no-store' });
      if (!res.ok) return false;
      const data = await res.json();
      if (!data) return false;

      let hasChanges = false;
      let needPushToServer = false;

      // 1. CLIENTES (Protección Máxima de Expedientes y Ediciones)
      const curClients = this.getClients();
      const srvClients = Array.isArray(data.clients) ? data.clients : [];
      if (srvClients.length > 0) {
        const clientMap = new Map<string, Client>();
        srvClients.forEach((c: Client) => clientMap.set(c.id, c));
        curClients.forEach((cur: Client) => {
          const srv = clientMap.get(cur.id);
          if (!srv) {
            clientMap.set(cur.id, cur);
            needPushToServer = true;
          } else {
            const curTime = cur.updatedAt ? new Date(cur.updatedAt).getTime() : 0;
            const srvTime = srv.updatedAt ? new Date(srv.updatedAt).getTime() : 0;
            if (curTime > srvTime) {
              clientMap.set(cur.id, cur);
              needPushToServer = true;
            }
          }
        });
        const mergedClients = Array.from(clientMap.values());
        if (mergedClients.length !== curClients.length || JSON.stringify(mergedClients) !== JSON.stringify(curClients)) {
          save(STORAGE_KEYS.CLIENTS, mergedClients);
          hasChanges = true;
        }
      } else if (curClients.length > 0) {
        // Servidor no tiene clientes pero el navegador sí: Subirlos al servidor para que el disco duro los guarde
        needPushToServer = true;
      }

      // 2. VEHÍCULOS
      const curVehicles = this.getVehicles();
      const srvVehicles = Array.isArray(data.vehicles) ? data.vehicles : [];
      if (srvVehicles.length > 0) {
        const vehicleMap = new Map<string, Vehicle>();
        srvVehicles.forEach((v: Vehicle) => vehicleMap.set(v.id, v));
        curVehicles.forEach((cur: Vehicle) => {
          const srv = vehicleMap.get(cur.id);
          if (!srv) {
            vehicleMap.set(cur.id, cur);
            needPushToServer = true;
          } else {
            const curTime = cur.updatedAt ? new Date(cur.updatedAt).getTime() : 0;
            const srvTime = srv.updatedAt ? new Date(srv.updatedAt).getTime() : 0;
            if (curTime > srvTime) {
              vehicleMap.set(cur.id, cur);
              needPushToServer = true;
            }
          }
        });
        const mergedVehicles = Array.from(vehicleMap.values());
        if (mergedVehicles.length !== curVehicles.length || JSON.stringify(mergedVehicles) !== JSON.stringify(curVehicles)) {
          save(STORAGE_KEYS.VEHICLES, mergedVehicles);
          hasChanges = true;
        }
      } else if (curVehicles.length > 0) {
        needPushToServer = true;
      }

      // 3. ÓRDENES DE TRABAJO (Protección Inteligente de Ediciones y Auditorías)
      const curOrders = this.getWorkOrders();
      const srvOrders = Array.isArray(data.workOrders) ? data.workOrders : [];
      if (srvOrders.length > 0) {
        const orderMap = new Map<string, WorkOrder>();
        srvOrders.forEach((o: WorkOrder) => orderMap.set(o.id, o));
        curOrders.forEach((cur: WorkOrder) => {
          const srv = orderMap.get(cur.id);
          if (!srv) {
            orderMap.set(cur.id, cur);
            needPushToServer = true;
          } else {
            const curAuditCount = cur.historialModificaciones?.length || 0;
            const srvAuditCount = srv.historialModificaciones?.length || 0;
            const curTime = cur.updatedAt ? new Date(cur.updatedAt).getTime() : 0;
            const srvTime = srv.updatedAt ? new Date(srv.updatedAt).getTime() : 0;

            // Si la versión local tiene más modificaciones registradas o un sello de tiempo más nuevo:
            // PRESERVAR LA LOCAL y marcar para subirla al servidor
            if (curAuditCount > srvAuditCount || curTime > srvTime) {
              orderMap.set(cur.id, cur);
              needPushToServer = true;
            }
          }
        });
        const mergedOrders = Array.from(orderMap.values());
        if (mergedOrders.length !== curOrders.length || JSON.stringify(mergedOrders) !== JSON.stringify(curOrders)) {
          save(STORAGE_KEYS.WORK_ORDERS, mergedOrders);
          hasChanges = true;
        }
      } else if (curOrders.length > 0) {
        needPushToServer = true;
      }

      // 4. EMPRESAS (Flotillas)
      const curCompanies = this.getCompanies();
      const srvCompanies = Array.isArray(data.companies) ? data.companies : [];
      if (srvCompanies.length > 0) {
        const compMap = new Map<string, Company>();
        srvCompanies.forEach((co: Company) => compMap.set(co.id, co));
        curCompanies.forEach((co: Company) => {
          if (!compMap.has(co.id)) {
            compMap.set(co.id, co);
            needPushToServer = true;
          }
        });
        const mergedComp = Array.from(compMap.values());
        if (mergedComp.length !== curCompanies.length || JSON.stringify(mergedComp) !== JSON.stringify(curCompanies)) {
          save(STORAGE_KEYS.COMPANIES, mergedComp);
          hasChanges = true;
        }
      } else if (curCompanies.length > 0) {
        needPushToServer = true;
      }

      // 5. CAJA Y CORTES
      if (data.cashShift) {
        const cur = localStorage.getItem(STORAGE_KEYS.CASH_SHIFT);
        const nextStr = JSON.stringify(data.cashShift);
        if (cur !== nextStr) {
          localStorage.setItem(STORAGE_KEYS.CASH_SHIFT, nextStr);
          hasChanges = true;
        }
      }

      // 6. MECÁNICOS Y BAHÍAS (Protección de nombres y configuración con smart-merge por timestamp)
      const curMechanics = this.getMechanics();
      const srvMechanics = Array.isArray(data.mechanics) ? data.mechanics : [];
      if (srvMechanics.length > 0) {
        const mecMap = new Map<string, Mechanic>();
        srvMechanics.forEach((m: Mechanic) => mecMap.set(m.id, m));
        curMechanics.forEach((cur: Mechanic) => {
          const srv = mecMap.get(cur.id);
          if (!srv) {
            mecMap.set(cur.id, cur);
            needPushToServer = true;
          } else {
            const curTime = cur.updatedAt ? new Date(cur.updatedAt).getTime() : 0;
            const srvTime = srv.updatedAt ? new Date(srv.updatedAt).getTime() : 0;
            if (curTime > srvTime) {
              mecMap.set(cur.id, cur);
              needPushToServer = true;
            }
          }
        });
        const mergedMecs = Array.from(mecMap.values());
        if (mergedMecs.length !== curMechanics.length || JSON.stringify(mergedMecs) !== JSON.stringify(curMechanics)) {
          save(STORAGE_KEYS.MECHANICS, mergedMecs);
          hasChanges = true;
        }
      } else if (curMechanics.length > 0) {
        needPushToServer = true;
      }

      // Si el navegador tenía datos que el servidor no tenía en disco:
      // Subirlos de inmediato a la API central para que queden guardados en db.json
      if (needPushToServer) {
        fetch('/api/sync', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            type: 'full_sync',
            clients: this.getClients(),
            vehicles: this.getVehicles(),
            workOrders: this.getWorkOrders(),
            companies: this.getCompanies(),
            mechanics: this.getMechanics(),
          }),
        }).catch(() => {});
      }

      if (hasChanges) {
        window.dispatchEvent(new CustomEvent('taller_data_synced', { detail: data }));
      }
      return hasChanges;
    } catch (e) {
      return false;
    }
  },

  // RESPALDOS DE SEGURIDAD
  downloadBackup() {
    if (typeof window === 'undefined') return;
    const link = document.createElement('a');
    link.href = '/api/backup';
    link.download = `Respaldo_Taller_Amaya_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  },

  async getBackupList() {
    try {
      const res = await fetch('/api/backup?action=list');
      return await res.json();
    } catch (e) {
      return { success: false, backups: [] };
    }
  },

  async createManualBackup(label = 'manual') {
    try {
      const res = await fetch('/api/backup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'create_manual', label }),
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async restoreBackup(filename: string, pin: string) {
    try {
      const res = await fetch('/api/backup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'restore', filename, pin }),
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  // Reset demo data / Dejar todo en blanco para pruebas
  async resetToInitial() {
    if (typeof window === 'undefined') return;
    try {
      await fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'reset_all' }),
      });
    } catch {}
    localStorage.removeItem(STORAGE_KEYS.COMPANIES);
    localStorage.removeItem(STORAGE_KEYS.CLIENTS);
    localStorage.removeItem(STORAGE_KEYS.VEHICLES);
    localStorage.removeItem(STORAGE_KEYS.WORK_ORDERS);
    localStorage.removeItem(STORAGE_KEYS.CASH_SHIFT);
    window.location.reload();
  },
};
