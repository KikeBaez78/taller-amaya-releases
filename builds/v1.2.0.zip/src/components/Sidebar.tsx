'use client';

import React from 'react';
import Link from 'next/link';
import { TallerConfig } from '@/types';
import {
  Wrench,
  Search,
  ClipboardList,
  Users,
  DollarSign,
  BarChart3,
  PlusCircle,
  CreditCard,
  Phone,
  MessageCircle,
  ChevronLeft,
  ChevronRight,
  X,
  RotateCcw,
  Zap,
  Monitor,
  Smartphone,
  Database,
} from 'lucide-react';
import { StorageService } from '@/lib/storage';

interface SidebarProps {
  config: TallerConfig;
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onNewOrder: () => void;
  openBankModal: () => void;
  openCotizador: () => void;
  openMobileConnectModal?: () => void;
  openRespaldoModal?: () => void;
  isOpenMobile: boolean;
  setIsOpenMobile: (open: boolean) => void;
  isCollapsedDesktop: boolean;
  setIsCollapsedDesktop: (collapsed: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  config,
  currentTab,
  setCurrentTab,
  onNewOrder,
  openBankModal,
  openCotizador,
  openMobileConnectModal,
  openRespaldoModal,
  isOpenMobile,
  setIsOpenMobile,
  isCollapsedDesktop,
  setIsCollapsedDesktop,
}) => {
  const navItems = [
    { id: 'bitacora', label: 'Bitácora & Búsqueda', icon: Search, badge: 'Placas' },
    { id: 'ordenes', label: 'Órdenes de Trabajo', icon: ClipboardList, badge: '0900' },
    { id: 'crm', label: 'Flotillas & CRM', icon: Users, badge: 'Empresas' },
    { id: 'mecanicos', label: 'Taller & Comisiones', icon: Wrench, badge: '10-45%' },
    { id: 'caja', label: 'Caja & Cortes', icon: DollarSign, badge: '8% IVA' },
    { id: 'reportes', label: 'Dashboard', icon: BarChart3 },
  ];

  const handleSelectTab = (tabId: string) => {
    setCurrentTab(tabId);
    setIsOpenMobile(false);
  };

  return (
    <>
      {/* Backdrop oscuro para móvil cuando el menú está abierto */}
      {isOpenMobile && (
        <div
          onClick={() => setIsOpenMobile(false)}
          className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-sm lg:hidden transition-opacity"
        />
      )}

      {/* Menú Lateral Contenedor */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 flex flex-col bg-white border-r border-slate-200 transition-all duration-300 ease-in-out lg:static ${
          isOpenMobile ? 'translate-x-0 w-72 shadow-2xl' : '-translate-x-full lg:translate-x-0'
        } ${isCollapsedDesktop ? 'lg:w-20' : 'lg:w-64'}`}
      >
        {/* Cabecera del Sidebar con Logo Oficial Taller Amaya */}
        <div className="p-3 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2.5 overflow-hidden w-full">
            {isCollapsedDesktop ? (
              <div className="w-12 h-12 mx-auto rounded-2xl bg-white p-1 shadow-sm border border-slate-200 flex items-center justify-center shrink-0">
                <img
                  src="/logo-taller-amaya.png"
                  alt="Taller Amaya"
                  className="w-full h-full object-contain"
                />
              </div>
            ) : (
              <div className="flex items-center gap-2.5 w-full">
                <div className="w-12 h-12 rounded-2xl bg-white p-1 shadow-sm border border-slate-200 shrink-0 flex items-center justify-center">
                  <img
                    src="/logo-taller-amaya.png"
                    alt="Taller Amaya"
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="overflow-hidden leading-tight">
                  <div className="flex items-center gap-1.5">
                    <span className="font-black text-sm tracking-wide text-slate-900 uppercase truncate">
                      TALLER AMAYA
                    </span>
                  </div>
                  <span className="text-[10px] text-rose-600 font-extrabold uppercase tracking-widest block">
                    SERVICIO MECÁNICO
                  </span>
                  <span className="text-[10px] text-slate-400 font-medium">Tijuana, B.C.</span>
                </div>
              </div>
            )}
          </div>

          {/* Botón cerrar en móvil */}
          <button
            onClick={() => setIsOpenMobile(false)}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-200/60 lg:hidden ml-1"
            title="Cerrar menú"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Botón colapsar en desktop */}
          <button
            onClick={() => setIsCollapsedDesktop(!isCollapsedDesktop)}
            className="hidden lg:flex p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition-colors ml-1"
            title={isCollapsedDesktop ? 'Expandir menú' : 'Colapsar menú'}
          >
            {isCollapsedDesktop ? (
              <ChevronRight className="w-4 h-4 text-rose-600" />
            ) : (
              <ChevronLeft className="w-4 h-4 text-slate-400" />
            )}
          </button>
        </div>

        {/* Botones Principales de Acción Rápida */}
        <div className="p-3 space-y-2">
          {/* Botón 1: Registrar Entrada (Check-in con fotos) */}
          <button
            onClick={() => {
              onNewOrder();
              setIsOpenMobile(false);
            }}
            className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 via-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold text-xs shadow-md shadow-rose-600/25 ring-1 ring-rose-400/40 transition-all transform hover:-translate-y-0.5 active:translate-y-0 ${
              isCollapsedDesktop ? 'px-0' : 'px-3'
            }`}
            title="Registrar Entrada con 8 Fotos (Check-in)"
          >
            <PlusCircle className="w-4 h-4 shrink-0" />
            {!isCollapsedDesktop && <span className="truncate">Nueva Entrada (Check-in)</span>}
          </button>

          {/* Botón 2: Cotizador Rápido Express */}
          <button
            onClick={() => {
              openCotizador();
              setIsOpenMobile(false);
            }}
            className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-amber-50 to-orange-50 hover:from-amber-100 hover:to-orange-100 text-amber-900 border border-amber-300 font-bold text-xs shadow-sm transition-all transform hover:-translate-y-0.5 active:translate-y-0 ${
              isCollapsedDesktop ? 'px-0' : 'px-3'
            }`}
            title="⚡ Cotizador Rápido (Clientes con prisa)"
          >
            <Zap className="w-4 h-4 shrink-0 fill-amber-500 text-amber-600" />
            {!isCollapsedDesktop && <span className="truncate font-black">⚡ Cotizador Rápido</span>}
          </button>
        </div>

        {/* Lista de Navegación */}
        <nav className="flex-1 px-3 py-1 space-y-1 overflow-y-auto scrollbar-none">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleSelectTab(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-xs transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-rose-600 to-red-600 text-white shadow-md shadow-rose-600/20'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                } ${isCollapsedDesktop ? 'justify-center' : 'justify-between'}`}
                title={item.label}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive ? 'text-white' : 'text-slate-400 group-hover:text-rose-600'
                    }`}
                  />
                  {!isCollapsedDesktop && <span className="truncate">{item.label}</span>}
                </div>

                {!isCollapsedDesktop && item.badge && (
                  <span
                    className={`text-[9px] px-1.5 py-0.5 rounded-md font-bold uppercase font-mono ${
                      isActive
                        ? 'bg-white/20 text-white'
                        : 'bg-slate-100 text-slate-500 border border-slate-200'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Sección Inferior: Conexión QR, Cuentas Bancarias & Contacto */}
        <div className="p-3 border-t border-slate-200 space-y-2 bg-slate-50/70 text-xs">
          {/* Botón Conectar Celular / Tablet QR */}
          {openMobileConnectModal && (
            <button
              onClick={() => {
                openMobileConnectModal();
                setIsOpenMobile(false);
              }}
              className={`w-full flex items-center gap-2 py-2 px-2.5 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-900 border border-sky-300 transition-colors font-bold text-xs shadow-xs cursor-pointer ${
                isCollapsedDesktop ? 'justify-center' : ''
              }`}
              title="Conectar Celular o Tablet escaneando QR"
            >
              <Smartphone className="w-4 h-4 shrink-0 text-sky-600" />
              {!isCollapsedDesktop && <span className="truncate">📱 Conectar Celular (QR)</span>}
            </button>
          )}

          {/* Botón Respaldos del Sistema */}
          {openRespaldoModal && (
            <button
              onClick={() => {
                openRespaldoModal();
                setIsOpenMobile(false);
              }}
              className={`w-full flex items-center gap-2 py-2 px-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 transition-colors font-bold text-xs shadow-xs cursor-pointer ${
                isCollapsedDesktop ? 'justify-center' : ''
              }`}
              title="Respaldos automáticos y exportación de base de datos a USB"
            >
              <Database className="w-4 h-4 shrink-0 text-emerald-600" />
              {!isCollapsedDesktop && <span className="truncate">💾 Respaldos del Sistema</span>}
            </button>
          )}

          {/* Botón Cuentas BBVA */}
          <button
            onClick={() => {
              openBankModal();
              setIsOpenMobile(false);
            }}
            className={`w-full flex items-center gap-2 py-2 px-2.5 rounded-xl bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 shadow-sm transition-colors font-semibold ${
              isCollapsedDesktop ? 'justify-center' : ''
            }`}
            title="Datos Bancarios BBVA"
          >
            <CreditCard className="w-4 h-4 shrink-0 text-blue-600" />
            {!isCollapsedDesktop && <span className="truncate">Cuentas BBVA Bancomer</span>}
          </button>

          {/* Acceso discreto a Pantalla Bahía para Admin si se requiere */}
          <Link
            href="/bahia"
            target="_blank"
            className={`w-full flex items-center gap-2 py-1.5 px-2.5 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors text-[11px] font-medium ${
              isCollapsedDesktop ? 'justify-center' : ''
            }`}
            title="Abrir la Pantalla de Bahía en nueva pestaña"
          >
            <Monitor className="w-3.5 h-3.5 shrink-0 text-slate-400" />
            {!isCollapsedDesktop && <span className="truncate">Abrir Pantalla de Bahía</span>}
          </Link>

          {!isCollapsedDesktop && (
            <div className="space-y-1 pt-1 text-[11px] text-slate-500">
              <div className="flex items-center justify-between">
                <span className="truncate font-mono">RFC: {config.rfc}</span>
                <button
                  onClick={() => {
                    if (confirm('¿Restablecer datos demo a valores de fábrica?')) {
                      StorageService.resetToInitial();
                    }
                  }}
                  title="Restablecer datos demo"
                  className="hover:text-slate-800 p-0.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>

              <a
                href={`tel:${config.telefonoLocal}`}
                className="flex items-center gap-1.5 hover:text-rose-600 transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span className="font-mono">{config.telefonoLocal}</span>
              </a>

              <a
                href={`https://wa.me/52${config.whatsapp}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 text-emerald-600 hover:text-emerald-700 transition-colors font-semibold"
              >
                <MessageCircle className="w-3.5 h-3.5 shrink-0" />
                <span className="font-mono">WA: {config.whatsapp}</span>
              </a>
            </div>
          )}
        </div>
      </aside>
    </>
  );
};
