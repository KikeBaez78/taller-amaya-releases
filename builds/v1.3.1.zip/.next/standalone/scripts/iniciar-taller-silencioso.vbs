' =========================================================================
' INICIADOR SILENCIOSO AUTONOMO (ZERO DEPENDENCIAS) - TALLER AMAYA
' =========================================================================
On Error Resume Next

Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' Obtener la carpeta del script y del proyecto
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
projectDir = fso.GetParentFolderName(scriptDir)

WshShell.CurrentDirectory = projectDir

' Buscar el ejecutable portable de node.exe en todas las ubicaciones posibles
Dim nodePaths(7)
nodePaths(0) = projectDir & "\runtime\node.exe"
nodePaths(1) = projectDir & "\..\runtime\node.exe"
nodePaths(2) = projectDir & "\taller-amaya\runtime\node.exe"
nodePaths(3) = "C:\Users\TALLER\Desktop\taller-amaya\runtime\node.exe"
nodePaths(4) = "C:\Users\TALLER\Desktop\taller-amaya 2\runtime\node.exe"
nodePaths(5) = "C:\taller-amaya\runtime\node.exe"
nodePaths(6) = "C:\Program Files\nodejs\node.exe"
nodePaths(7) = "C:\Program Files (x86)\nodejs\node.exe"

portableNode = ""
For i = 0 To UBound(nodePaths)
    If fso.FileExists(nodePaths(i)) Then
        portableNode = nodePaths(i)
        Exit For
    End If
Next

' Buscar el script del servidor standalone
Dim serverPaths(4)
serverPaths(0) = projectDir & "\.next\standalone\server.js"
serverPaths(1) = projectDir & "\server.js"
serverPaths(2) = "C:\Users\TALLER\Desktop\taller-amaya\.next\standalone\server.js"
serverPaths(3) = "C:\Users\TALLER\Desktop\taller-amaya 2\.next\standalone\server.js"
serverPaths(4) = "C:\taller-amaya\.next\standalone\server.js"

standaloneScript = ""
For i = 0 To UBound(serverPaths)
    If fso.FileExists(serverPaths(i)) Then
        standaloneScript = serverPaths(i)
        Exit For
    End If
Next

logFile = projectDir & "\runtime\server.log"

If portableNode <> "" And standaloneScript <> "" Then
    cmdToRun = "cmd /c """"" & portableNode & """ """ & standaloneScript & """ > """ & logFile & """ 2>&1"""
    WshShell.Run cmdToRun, 0, False
ElseIf standaloneScript <> "" Then
    cmdToRun = "cmd /c node """ & standaloneScript & """ > """ & logFile & """ 2>&1"
    WshShell.Run cmdToRun, 0, False
Else
    cmdToRun = "cmd /c npm start > """ & logFile & """ 2>&1"
    WshShell.Run cmdToRun, 0, False
End If

' Esperar 2 segundos a que el servidor inicialice (arranca en ~50ms)
WScript.Sleep 2000

' Abrir en modo aplicacion nativa de Windows (sin barras de navegacion)
appUrl = "http://localhost:3000"
WshShell.Run "cmd /c start msedge --app=" & appUrl & " || start " & appUrl, 0, False
