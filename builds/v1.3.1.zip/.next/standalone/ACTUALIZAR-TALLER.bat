@echo off
title ACTUALIZAR TALLER AMAYA
color 0A

cd /d "%~dp0"

echo ========================================================
echo       APLICANDO ACTUALIZACION OFICIAL - TALLER AMAYA
echo ========================================================
echo.

echo [1/3] Cerrando procesos previos...
taskkill /F /IM node.exe >nul 2>&1
timeout /t 1 >nul

echo [2/3] Verificando proteccion de datos y licencia...
if exist "src\data\license.json" (
    echo [OK] Licencia oficial casada con esta PC intacta.
)
if exist "src\data\db.json" (
    echo [OK] Base de datos de clientes y ordenes protegida.
)

echo [3/3] Iniciando Taller Amaya en segundo plano...
start wscript scripts\iniciar-taller-silencioso.vbs

echo.
echo ========================================================
echo  [EXITO] Sistema actualizado y reiniciado.
echo  - PIN Administrativo de Reyna Amaya: 2036
echo ========================================================
timeout /t 3 >nul
exit
