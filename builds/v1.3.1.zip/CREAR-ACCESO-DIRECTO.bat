@echo off
title CREAR ACCESOS DIRECTOS - TALLER AMAYA
color 0A

cd /d "%~dp0"

echo =========================================================================
echo          CREADOR OFICIAL DE ACCESOS DIRECTOS - TALLER AMAYA
echo =========================================================================
echo.

cscript //nologo scripts\crear-acceso-directo.vbs
powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $sc = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\Taller Amaya.lnk'); $sc.TargetPath = 'wscript.exe'; $sc.Arguments = '\"' + '%~dp0scripts\iniciar-taller-silencioso.vbs' + '\"'; $sc.WorkingDirectory = '%~dp0'; if (Test-Path '%~dp0public\logo.ico') { $sc.IconLocation = '%~dp0public\logo.ico,0' }; $sc.Description = 'Taller Amaya - Sistema Oficial'; $sc.Save()" >nul 2>&1

echo.
echo =========================================================================
echo  [EXITO] Accesos directos creados correctamente en tu Escritorio:
echo  1. "Taller Amaya"
echo  2. "Pantalla Bahia - Taller Amaya"
echo =========================================================================
echo.
pause
