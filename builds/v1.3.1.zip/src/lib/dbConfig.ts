import fs from 'fs';
import path from 'path';

/**
 * Localiza de forma canónica y determinista la raíz del proyecto Taller Amaya
 * tanto en desarrollo local como en producción standalone dentro de .next/standalone
 */
export function getAppRootDir(): string {
  const cwd = process.cwd();
  // 1. Si cwd termina en .next/standalone o estamos adentro
  if (cwd.includes(path.join('.next', 'standalone'))) {
    const candidate = path.resolve(cwd, '..', '..');
    if (fs.existsSync(path.join(candidate, 'package.json')) || fs.existsSync(path.join(candidate, 'src'))) {
      return candidate;
    }
  }
  // 2. Si cwd tiene package.json o src/
  if (fs.existsSync(path.join(cwd, 'package.json')) && fs.existsSync(path.join(cwd, 'src'))) {
    return cwd;
  }
  // 3. Fallback inteligente
  const upOne = path.resolve(cwd, '..');
  if (fs.existsSync(path.join(upOne, 'package.json')) && fs.existsSync(path.join(upOne, 'src'))) {
    return upOne;
  }
  const upTwo = path.resolve(cwd, '..', '..');
  if (fs.existsSync(path.join(upTwo, 'package.json')) && fs.existsSync(path.join(upTwo, 'src'))) {
    return upTwo;
  }
  return cwd;
}

export function getDbFilePath(): string {
  const rootDir = getAppRootDir();
  const canonicalPath = path.join(rootDir, 'src', 'data', 'db.json');
  if (fs.existsSync(canonicalPath)) {
    return canonicalPath;
  }
  // Buscar si existiera en cwd
  const cwdPath = path.join(process.cwd(), 'src', 'data', 'db.json');
  if (fs.existsSync(cwdPath)) {
    return cwdPath;
  }
  return canonicalPath;
}

export function getBackupsDir(): string {
  const rootDir = getAppRootDir();
  const backupsPath = path.join(rootDir, 'src', 'data', 'backups');
  if (!fs.existsSync(backupsPath)) {
    try {
      fs.mkdirSync(backupsPath, { recursive: true });
    } catch {}
  }
  return backupsPath;
}

/**
 * Escritura atómica a prueba de fallos y de concurrencia en Windows
 */
export function atomicWriteJson(filePath: string, data: any): void {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    try {
      fs.mkdirSync(dir, { recursive: true });
    } catch {}
  }

  const content = JSON.stringify(data, null, 2);
  const tempPath = `${filePath}.tmp.${Date.now()}.${Math.random().toString(36).slice(2, 6)}`;

  try {
    fs.writeFileSync(tempPath, content, 'utf-8');
    fs.renameSync(tempPath, filePath);
  } catch (err) {
    try {
      fs.copyFileSync(tempPath, filePath);
      if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
    } catch {
      // Fallback directo
      fs.writeFileSync(filePath, content, 'utf-8');
    }
  }
}
