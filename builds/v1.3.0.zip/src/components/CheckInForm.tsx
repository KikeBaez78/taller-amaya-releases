'use client';

import React, { useState, useEffect } from 'react';
import { StorageService } from '@/lib/storage';
import {
  Vehicle,
  Client,
  Company,
  FuelLevel,
  MandatoryPhotos,
  DamagePoint,
  WorkOrder,
  PaymentMethod,
  PaymentRecord,
  Presupuesto,
  Mechanic,
} from '@/types';
import { SAMPLE_PHOTOS } from '@/data/mockData';
import {
  Car,
  Camera,
  Video,
  Fuel,
  Package,
  Plus,
  Trash2,
  Save,
  X,
  FileEdit,
  User,
  Building2,
  CheckCircle,
  AlertCircle,
  HelpCircle,
  Check,
  DollarSign,
  Wrench,
  Percent,
  Receipt,
  Sparkles,
  Eye,
  Maximize2,
} from 'lucide-react';
import { ImageLightboxModal } from './ImageLightboxModal';

interface CheckInFormProps {
  initialVehicle?: Vehicle | null;
  onSuccess: (order: WorkOrder) => void;
  onCancel: () => void;
}

const isGenericPlacas = (p?: string): boolean => {
  if (!p) return true;
  const clean = p.trim().toUpperCase().replace(/[\s\.\-_]/g, '');
  const genericTokens = [
    'NOTRAE', 'SINPLACAS', 'SP', 'SINPLACA', 'PERMISO', 'PENDIENTE', 
    'NA', 'SN', 'NOTIENE', 'NONE', 'TRAMITE', 'ENTRAMITE', 'SD'
  ];
  return clean.length <= 1 || genericTokens.includes(clean);
};

export const CheckInForm: React.FC<CheckInFormProps> = ({
  initialVehicle,
  onSuccess,
  onCancel,
}) => {
  // 1. Folio editable iniciado en 0900
  const [folio, setFolio] = useState('');
  const [isEditingFolio, setIsEditingFolio] = useState(false);

  // 2. Cliente y Flotilla
  const [clientType, setClientType] = useState<'persona' | 'empresa'>('persona');
  const [selectedCompanyId, setSelectedCompanyId] = useState('');
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [clientWhatsApp, setClientWhatsApp] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [clientAddress, setClientAddress] = useState('');
  const [choferNombre, setChoferNombre] = useState('');
  const [choferTelefono, setChoferTelefono] = useState('');

  // 3. Vehículo
  const [placas, setPlacas] = useState('');
  const [numeroEconomico, setNumeroEconomico] = useState('');
  const [marca, setMarca] = useState('');
  const [modelo, setModelo] = useState('');
  const [ano, setAno] = useState(new Date().getFullYear());
  const [color, setColor] = useState('');
  const [motor, setMotor] = useState('');
  const [vin, setVin] = useState('');
  const [kilometraje, setKilometraje] = useState(0);

  // 4. Inventario de Entrada y Falla
  const [combustible, setCombustible] = useState<FuelLevel>('1/2');
  const [fallaReportada, setFallaReportada] = useState('');

  // 5. BIFURCACIÓN ORGÁNICA: ¿El cliente trae refacciones para cambiarlas?
  const [traeRefacciones, setTraeRefacciones] = useState<'si' | 'no'>('no');
  const [refaccionesCliente, setRefaccionesCliente] = useState<string[]>([]);
  const [nuevaRefaccion, setNuevaRefaccion] = useState('');
  const [presupuestoManoObraRefacciones, setPresupuestoManoObraRefacciones] = useState<number>(850);

  // Caso B: Si no trae refacciones, presupuesto aproximado según servicio
  const [presupuestoManoObraAprox, setPresupuestoManoObraAprox] = useState<number>(1200);
  const [conceptoServicioInicial, setConceptoServicioInicial] = useState('Revisión mecánica general y diagnóstico');

  // Anticipo abierto al dejar el vehículo
  const [anticipoMonto, setAnticipoMonto] = useState<number>(0);
  const [anticipoMetodo, setAnticipoMetodo] = useState<PaymentMethod>('efectivo');

  // 6. Las 8 Fotos Obligatorias + 1 Video Opcional
  const [photos, setPhotos] = useState<MandatoryPhotos>({});
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [lightboxOpen, setLightboxOpen] = useState<boolean>(false);
  const [lightboxIndex, setLightboxIndex] = useState<number>(0);

  // 7. Diagrama de Carrocería Técnico y Profesional
  const [danos, setDanos] = useState<DamagePoint[]>([]);
  const [selectedDamageType, setSelectedDamageType] = useState<'rayon' | 'golpe' | 'abolladura' | 'quebrado'>('rayon');

  // Listas existentes de la BD
  const companies = StorageService.getCompanies();
  const clients = StorageService.getClients();
  const vehicles = StorageService.getVehicles();
  const mechanics = StorageService.getMechanics();

  // Asignación de mecánico y comisión
  const [selectedMechanicId, setSelectedMechanicId] = useState<string>(
    mechanics.length > 0 ? mechanics[0].id : ''
  );
  const [selectedMechanicCommission, setSelectedMechanicCommission] = useState<number>(
    mechanics.length > 0 ? (mechanics[0].comisionDefault || 30) : 30
  );

  const handleMechanicSelectChange = (id: string) => {
    setSelectedMechanicId(id);
    const found = mechanics.find((m) => m.id === id);
    if (found) {
      setSelectedMechanicCommission(found.comisionDefault || 30);
    }
  };

  // Inicializar folio y vehículo si viene preseleccionado
  useEffect(() => {
    const nextF = StorageService.getNextFolio();
    setFolio(nextF);

    if (mechanics.length > 0 && !selectedMechanicId) {
      setSelectedMechanicId(mechanics[0].id);
      setSelectedMechanicCommission(mechanics[0].comisionDefault || 30);
    }

    if (initialVehicle) {
      loadVehicleData(initialVehicle);
    }
  }, [initialVehicle]);

  const loadVehicleData = (veh: Vehicle) => {
    setPlacas(veh.placas);
    setNumeroEconomico(veh.numeroEconomico || '');
    setMarca(veh.marca);
    setModelo(veh.modelo);
    setAno(veh.ano);
    setColor(veh.color);
    setMotor(veh.motor || '');
    setVin(veh.vin || '');
    setKilometraje(veh.kilometrajeActual);
    if (veh.choferHabitual) setChoferNombre(veh.choferHabitual);
    if (veh.choferTelefono) setChoferTelefono(veh.choferTelefono);

    if (veh.empresaId) {
      setClientType('empresa');
      setSelectedCompanyId(veh.empresaId);
      const comp = companies.find((c) => c.id === veh.empresaId);
      if (comp) {
        setClientName(comp.razonSocial);
        setClientPhone(comp.telefonos[0] || '');
        setClientWhatsApp(comp.telefonos[0]?.replace(/\D/g, '') || '');
        setClientEmail(comp.correos?.[0] || '');
        setClientAddress(comp.direccion || '');
      }
    } else {
      setClientType('persona');
      const c = clients.find((x) => x.id === veh.clienteId);
      if (c) {
        setClientName(c.nombre);
        setClientPhone(c.telefono);
        setClientWhatsApp(c.whatsapp || c.telefono);
        setClientEmail(c.correo || '');
        setClientAddress(c.direccion || '');
      }
    }
  };

  // Autollenado instantáneo al teclear placas conocidas reales (no genéricas)
  const handlePlacasChange = (val: string) => {
    const upper = val.toUpperCase();
    setPlacas(upper);
    if (!isGenericPlacas(upper)) {
      const found = vehicles.find((v) => v.placas.toUpperCase() === upper.trim());
      if (found) {
        loadVehicleData(found);
      }
    }
  };

  // Si cambia la empresa seleccionada, autollenar datos de contacto
  const handleCompanyChange = (compKey: string) => {
    setSelectedCompanyId(compKey);
    const comp = companies.find((c) => c.id === compKey);
    if (comp) {
      setClientName(comp.razonSocial);
      setClientPhone(comp.telefonos[0] || '');
      setClientWhatsApp(comp.telefonos[0]?.replace(/\D/g, '') || '');
    }
  };

  // Agregar refacción que trae el cliente
  const handleAddRefaccion = (textToAdd?: string) => {
    const item = (textToAdd || nuevaRefaccion).trim();
    if (!item) return;
    if (!refaccionesCliente.includes(item)) {
      setRefaccionesCliente([...refaccionesCliente, item]);
    }
    setNuevaRefaccion('');
  };

  const handleRemoveRefaccion = (index: number) => {
    setRefaccionesCliente(refaccionesCliente.filter((_, i) => i !== index));
  };

  // Cargar fotos demo o de archivo
  const handleLoadSamplePhotos = () => {
    setPhotos(SAMPLE_PHOTOS);
  };

  const handleUploadPhoto = (key: keyof MandatoryPhotos, url: string) => {
    setPhotos((prev) => ({ ...prev, [key]: url }));
  };

  // Compresión en cliente y captura desde cámara del celular o archivo
  const handleFileCapture = (key: keyof MandatoryPhotos, file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new window.Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 1280;
        const scale = Math.min(1, MAX_WIDTH / img.width);
        canvas.width = img.width * scale;
        canvas.height = img.height * scale;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.8);
          handleUploadPhoto(key, compressedDataUrl);
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Click en diagrama de carrocería para marcar daño
  const handleDiagramClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.round(((e.clientX - rect.left) / rect.width) * 100);
    const y = Math.round(((e.clientY - rect.top) / rect.height) * 100);

    const detalle = prompt(
      `Observación del ${selectedDamageType.toUpperCase()} en esta zona:`,
      `${selectedDamageType.toUpperCase()} visible a simple vista`
    );
    if (detalle === null) return;

    setDanos((prev) => [
      ...prev,
      {
        id: `dp-${Date.now()}`,
        x,
        y,
        tipo: selectedDamageType,
        detalle: detalle || selectedDamageType,
      },
    ]);
  };

  const handleAddQuickDamage = (desc: string, xHint: number, yHint: number, tipo: 'rayon' | 'golpe' | 'abolladura' | 'quebrado') => {
    setDanos((prev) => [
      ...prev,
      {
        id: `dp-${Date.now()}`,
        x: xHint,
        y: yHint,
        tipo,
        detalle: desc,
      },
    ]);
  };

  const handleRemoveDamage = (id: string) => {
    setDanos(danos.filter((d) => d.id !== id));
  };

  // Cálculos consolidados en tiempo real para la orden inicial
  const presupuestoManoObraElegido =
    traeRefacciones === 'si'
      ? Number(presupuestoManoObraRefacciones) || 0
      : Number(presupuestoManoObraAprox) || 0;

  const saldoPendienteEstimado = Math.max(0, presupuestoManoObraElegido - (Number(anticipoMonto) || 0));

  // Guardar Orden de Entrada
  const handleSaveOrder = (e: React.FormEvent) => {
    e.preventDefault();

    if (!placas.trim()) {
      alert('Por favor introduce el número de placas del vehículo.');
      return;
    }
    if (!fallaReportada.trim()) {
      alert('Por favor describe la falla reportada o motivo de ingreso.');
      return;
    }

    // 1. Guardar o actualizar vehículo
    const cleanPlacas = placas.trim().toUpperCase() || 'NO TRAE';
    let vehicle: Vehicle | undefined = undefined;

    // Solo buscar vehículo existente si tiene placas reales (no genéricas)
    if (!isGenericPlacas(cleanPlacas)) {
      vehicle = vehicles.find((v) => v.placas.toUpperCase() === cleanPlacas);
    }

    // Determinar cliente (existente o nuevo)
    let clientId = vehicle?.clienteId;
    if (!clientId) {
      if (clientType === 'empresa' && selectedCompanyId) {
        const foundClient = clients.find((c) => c.empresaId === selectedCompanyId);
        clientId = foundClient ? foundClient.id : `cli-${Date.now()}`;
      } else {
        const cleanPhone = clientPhone.trim().replace(/\D/g, '');
        const foundClient = clients.find((c) => {
          if (cleanPhone && cleanPhone.length >= 7) {
            const cPhone = (c.telefono || '').replace(/\D/g, '');
            return cPhone === cleanPhone;
          }
          return clientName.trim() && c.nombre.trim().toLowerCase() === clientName.trim().toLowerCase();
        });
        clientId = foundClient ? foundClient.id : `cli-${Date.now()}`;
      }
    }

    if (!vehicle) {
      // Si el cliente no existía en la lista, crearlo
      const existingClient = clients.find((c) => c.id === clientId);
      if (!existingClient) {
        const newClient: Client = {
          id: clientId,
          tipo: clientType,
          nombre: clientName.trim() || `Cliente Placas ${cleanPlacas}`,
          telefono: clientPhone.trim() || '664-000-0000',
          whatsapp: clientWhatsApp.trim() || clientPhone.trim(),
          correo: clientEmail.trim() || undefined,
          direccion: clientAddress.trim() || undefined,
          empresaId: clientType === 'empresa' ? selectedCompanyId : undefined,
          creadoEn: new Date().toISOString().split('T')[0],
        };
        StorageService.saveClient(newClient);
      } else {
        // Actualizar datos del cliente existente si cambiaron
        if (clientName.trim()) existingClient.nombre = clientName.trim();
        if (clientPhone.trim()) existingClient.telefono = clientPhone.trim();
        if (clientWhatsApp.trim()) existingClient.whatsapp = clientWhatsApp.trim();
        existingClient.correo = clientEmail.trim() || undefined;
        existingClient.direccion = clientAddress.trim() || undefined;
        existingClient.tipo = clientType;
        if (clientType === 'empresa') {
          existingClient.empresaId = selectedCompanyId;
        }
        StorageService.saveClient(existingClient);
      }

      vehicle = {
        id: `veh-${Date.now()}`,
        clienteId: clientId,
        empresaId: clientType === 'empresa' ? selectedCompanyId : undefined,
        numeroEconomico: numeroEconomico.trim() || undefined,
        placas: cleanPlacas,
        marca: marca.trim() || 'Genérica',
        modelo: modelo.trim() || 'Sedán',
        ano: Number(ano) || 2020,
        color: color.trim() || 'Blanco',
        motor: motor.trim() || undefined,
        vin: vin.trim() || undefined,
        choferHabitual: choferNombre.trim() || undefined,
        choferTelefono: choferTelefono.trim() || undefined,
        kilometrajeActual: Number(kilometraje) || 0,
        ultimoServicioFecha: new Date().toISOString().split('T')[0],
        ultimoServicioKm: Number(kilometraje) || 0,
      };
      StorageService.saveVehicle(vehicle);
    } else if (vehicle) {
      // Actualización TOTAL y garantizada de todos los campos del vehículo con placas reales
      vehicle.marca = marca.trim() || vehicle.marca;
      vehicle.modelo = modelo.trim() || vehicle.modelo;
      vehicle.ano = Number(ano) || vehicle.ano;
      vehicle.color = color.trim() || vehicle.color;
      vehicle.motor = motor.trim() || undefined;
      vehicle.vin = vin.trim() || undefined;
      vehicle.numeroEconomico = numeroEconomico.trim() || undefined;
      vehicle.kilometrajeActual = Number(kilometraje) || vehicle.kilometrajeActual;
      vehicle.ultimoServicioFecha = new Date().toISOString().split('T')[0];
      vehicle.ultimoServicioKm = Number(kilometraje) || vehicle.kilometrajeActual;
      vehicle.choferHabitual = choferNombre.trim() || undefined;
      vehicle.choferTelefono = choferTelefono.trim() || undefined;
      if (clientType === 'empresa' && selectedCompanyId) {
        vehicle.empresaId = selectedCompanyId;
      }
      StorageService.saveVehicle(vehicle);

      // Actualización TOTAL del cliente si se modificó nombre, teléfono o datos
      const existingClient = clients.find((c) => c.id === vehicle?.clienteId);
      if (existingClient) {
        if (clientName.trim()) existingClient.nombre = clientName.trim();
        if (clientPhone.trim()) existingClient.telefono = clientPhone.trim();
        if (clientWhatsApp.trim()) existingClient.whatsapp = clientWhatsApp.trim();
        existingClient.correo = clientEmail.trim() || undefined;
        existingClient.direccion = clientAddress.trim() || undefined;
        existingClient.tipo = clientType;
        if (clientType === 'empresa') {
          existingClient.empresaId = selectedCompanyId;
        }
        StorageService.saveClient(existingClient);
      }
    }

    // 2. Estructurar el presupuesto inicial acordado en mostrador
    const assignedMechanic = mechanics.find((m) => m.id === selectedMechanicId);
    const assignedMecName = assignedMechanic ? assignedMechanic.nombre : 'Por Asignar Bahía';
    const assignedCommission = Number(selectedMechanicCommission) || assignedMechanic?.comisionDefault || 30;
    const initialComisionMonto = Math.round(presupuestoManoObraElegido * (assignedCommission / 100));

    const initialPresupuesto: Presupuesto = {
      partes:
        traeRefacciones === 'si'
          ? refaccionesCliente.map((ref, idx) => ({
              id: `parte-cli-${idx}`,
              descripcion: ref,
              cantidad: 1,
              precioUnitario: 0,
              subtotal: 0,
              origen: 'cliente' as const,
            }))
          : [],
      manoObra: [
        {
          id: `mo-init-${Date.now()}`,
          concepto:
            traeRefacciones === 'si'
              ? `Instalación de refacciones aportadas por cliente (${refaccionesCliente.join(', ') || 'piezas varias'})`
              : (conceptoServicioInicial.trim() || fallaReportada.trim() || 'Mano de obra pactada en recepción'),
          costo: presupuestoManoObraElegido,
          comisionPorcentaje: assignedCommission,
          mecanicoId: assignedMechanic?.id || 'unassigned',
          mecanicoNombre: assignedMecName,
        },
      ],
      subtotalPartes: 0,
      subtotalManoObra: presupuestoManoObraElegido,
      aplicaIva: false,
      ivaMonto: 0,
      totalPresupuesto: presupuestoManoObraElegido,
      estado: 'autorizado',
      fechaAutorizacion: new Date().toISOString().replace('T', ' ').substring(0, 16),
      medioAutorizacion: 'verbal',
      notasAutorizacion:
        traeRefacciones === 'si'
          ? 'Mano de obra pactada en mostrador por instalación de refacciones del cliente'
          : 'Presupuesto aproximado pactado en recepción al dejar el vehículo',
    };

    // 3. Registrar anticipo si el cliente dejó dinero
    const initialPagos: PaymentRecord[] = [];
    const anticipoVal = Number(anticipoMonto) || 0;

    if (anticipoVal > 0) {
      const aplicaIva8 = anticipoMetodo === 'tarjeta' || anticipoMetodo === 'transferencia';
      const montoIva = aplicaIva8 ? Math.round(anticipoVal * 0.08) : 0;
      initialPagos.push({
        id: `pay-ant-${Date.now()}`,
        fecha: new Date().toISOString().replace('T', ' ').substring(0, 16),
        metodo: anticipoMetodo,
        monto: anticipoVal,
        aplicaIva8,
        montoIva,
        montoTotalConIva: anticipoVal + montoIva,
        referencia: 'Anticipo al dejar vehículo',
      });

      // Sumar también a la caja en turno
      const shift = StorageService.getCashShift();
      if (anticipoMetodo === 'efectivo') {
        shift.ingresosEfectivo += anticipoVal;
        shift.efectivoEsperado += anticipoVal;
      } else if (anticipoMetodo === 'tarjeta') {
        shift.ingresosTarjeta += anticipoVal + montoIva;
      } else if (anticipoMetodo === 'transferencia') {
        shift.ingresosTransferencia += anticipoVal + montoIva;
      }
      StorageService.saveCashShift(shift);
    }

    // 4. Crear WorkOrder con Folio Oficial
    const newOrder: WorkOrder = {
      id: `ot-${folio || Date.now()}`,
      folio: folio.trim() || '0900',
      esModificable: true,
      vehiculoId: vehicle.id,
      clienteId: vehicle.clienteId,
      empresaId: vehicle.empresaId,
      choferNombre: choferNombre.trim() || vehicle.choferHabitual,
      choferTelefono: choferTelefono.trim() || vehicle.choferTelefono,
      fechaIngreso: new Date().toISOString().replace('T', ' ').substring(0, 16),
      estado: 'recepcion',
      fallaReportada: fallaReportada.trim(),
      nivelCombustible: combustible,
      kilometrajeEntrada: Number(kilometraje) || 0,
      refaccionesCliente: refaccionesCliente,
      fotosEntrada: photos,
      videoEntrada: videoUrl,
      danosPrevios: danos,
      servicios: [
        {
          id: `srv-init-${Date.now()}`,
          concepto: initialPresupuesto.manoObra[0].concepto,
          mecanicoId: assignedMechanic?.id || 'unassigned',
          mecanicoNombre: assignedMecName,
          manoObra: presupuestoManoObraElegido,
          refaccionesMonto: 0,
          comisionPorcentaje: assignedCommission,
          comisionManoObra: initialComisionMonto,
          estado: 'pendiente',
        },
      ],
      subtotalManoObra: presupuestoManoObraElegido,
      subtotalRefacciones: 0,
      subtotalGeneral: presupuestoManoObraElegido,
      totalComisionesMecanicos: initialComisionMonto,
      presupuesto: initialPresupuesto,
      pagos: initialPagos,
      totalPagado: anticipoVal,
      saldoPendiente: Math.max(0, presupuestoManoObraElegido - anticipoVal),
      metodoPago: anticipoVal > 0 ? anticipoMetodo : undefined,
    };

    StorageService.saveWorkOrder(newOrder);
    alert(`¡Orden de Servicio registrada con Folio #${newOrder.folio} y presupuesto pactado!`);
    onSuccess(newOrder);
  };

  const photoCategories: { key: keyof MandatoryPhotos; label: string }[] = [
    { key: 'frente', label: '1. Frente' },
    { key: 'trasera', label: '2. Trasera' },
    { key: 'lateralIzquierdo', label: '3. Lateral Izquierdo' },
    { key: 'lateralDerecho', label: '4. Lateral Derecho' },
    { key: 'motor', label: '5. Bahía de Motor' },
    { key: 'odometro', label: '6. Tablero / Odómetro' },
    { key: 'interior', label: '7. Interior / Asientos' },
    { key: 'cajuela', label: '8. Cajuela / Maletero' },
  ];

  const validPhotosList = photoCategories
    .filter(({ key }) => Boolean(photos[key]))
    .map(({ key, label }) => ({
      url: photos[key] as string,
      title: label,
    }));

  return (
    <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm max-w-5xl mx-auto text-slate-800">
      {/* Header del Formulario */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-slate-100 mb-6">
        <div>
          <div className="flex items-center gap-3">
            <div className="w-14 h-12 rounded-2xl bg-white p-1 border border-slate-200 shadow-sm flex items-center justify-center shrink-0">
              <img
                src="/logo-taller-amaya.png"
                alt="Taller Amaya"
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                Recepción & Orden de Servicio
              </h2>
              <p className="text-xs text-slate-500">
                Inspección visual inmediata, presupuesto de mano de obra y registro de piezas
              </p>
            </div>
          </div>
        </div>

        {/* Folio Editable iniciado en 0900 */}
        <div className="flex items-center gap-2 bg-rose-50/60 p-2 rounded-2xl border border-rose-200 shadow-sm">
          <div className="px-2">
            <span className="text-[10px] text-rose-600 uppercase font-black block tracking-wider">
              Folio de Servicio
            </span>
            {isEditingFolio ? (
              <input
                type="text"
                value={folio}
                onChange={(e) => setFolio(e.target.value)}
                onBlur={() => setIsEditingFolio(false)}
                autoFocus
                className="font-mono text-xl font-black text-rose-700 bg-white border border-rose-300 rounded px-2 py-0.5 w-28 focus:outline-none"
              />
            ) : (
              <span className="font-mono text-2xl font-black text-rose-700">#{folio}</span>
            )}
          </div>
          <button
            type="button"
            onClick={() => setIsEditingFolio(!isEditingFolio)}
            className="p-2 text-rose-600 hover:text-rose-800 hover:bg-rose-100 rounded-xl transition-colors"
            title="Editar número de folio si es necesario"
          >
            <FileEdit className="w-4 h-4" />
          </button>
        </div>
      </div>

      <form onSubmit={handleSaveOrder} className="space-y-6">
        {/* ============================================================== */}
        {/* SECCIÓN 1: DATOS DEL CLIENTE / FLOTILLA                       */}
        {/* ============================================================== */}
        <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
              <User className="w-4 h-4 text-slate-500" />
              <span>1. Datos del Cliente / Contacto</span>
            </h3>

            {/* Selector Persona vs Flotilla Empresa */}
            <div className="flex bg-white p-1 rounded-xl border border-slate-200 text-xs">
              <button
                type="button"
                onClick={() => setClientType('persona')}
                className={`px-3 py-1 rounded-lg font-bold transition-all ${
                  clientType === 'persona'
                    ? 'bg-rose-600 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Particular
              </button>
              <button
                type="button"
                onClick={() => setClientType('empresa')}
                className={`px-3 py-1 rounded-lg font-bold transition-all ${
                  clientType === 'empresa'
                    ? 'bg-rose-600 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Flotilla / Empresa
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {clientType === 'empresa' ? (
              <div>
                <label className="text-xs text-slate-600 block mb-1 font-medium">
                  Empresa / Flotilla Registrada:
                </label>
                <select
                  value={selectedCompanyId}
                  onChange={(e) => handleCompanyChange(e.target.value)}
                  className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                >
                  <option value="">-- Seleccionar Empresa --</option>
                  {companies.map((co) => (
                    <option key={co.id} value={co.id}>
                      {co.razonSocial} (RFC: {co.rfc})
                    </option>
                  ))}
                </select>
              </div>
            ) : (
              <div>
                <label className="text-xs text-slate-600 block mb-1 font-medium">
                  Nombre del Cliente *:
                </label>
                <input
                  type="text"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="Ej. Juan Pérez López"
                  required
                  className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>
            )}

            <div>
              <label className="text-xs text-slate-600 block mb-1 font-medium">
                Teléfono / Celular *:
              </label>
              <input
                type="tel"
                value={clientPhone}
                onChange={(e) => {
                  setClientPhone(e.target.value);
                  setClientWhatsApp(e.target.value);
                }}
                placeholder="664-123-4567"
                required
                className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none font-mono"
              />
            </div>

            <div>
              <label className="text-xs text-slate-600 block mb-1 font-medium">
                Chofer que Entrega (si aplica):
              </label>
              <input
                type="text"
                value={choferNombre}
                onChange={(e) => setChoferNombre(e.target.value)}
                placeholder="Nombre de chofer o conductor"
                className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs text-slate-600 block mb-1 font-medium">
                Correo Electrónico (Opcional):
              </label>
              <input
                type="email"
                value={clientEmail}
                onChange={(e) => setClientEmail(e.target.value)}
                placeholder="cliente@ejemplo.com"
                className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2 md:col-span-2">
              <label className="text-xs text-slate-600 block mb-1 font-medium">
                Dirección Simple (Calle, Colonia, Ciudad):
              </label>
              <input
                type="text"
                value={clientAddress}
                onChange={(e) => setClientAddress(e.target.value)}
                placeholder="Ej. Av. De las Américas #123, Col. Buenos Aires Sur, Tijuana B.C."
                className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
              />
            </div>

            {/* Selector Rápido de Unidades Registradas para Empresas */}
            {clientType === 'empresa' && selectedCompanyId && (
              <div className="sm:col-span-2 md:col-span-3 mt-2 pt-3 border-t border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <Car className="w-3.5 h-3.5 text-rose-600" />
                    Catálogo de Unidades Registradas en esta Empresa:
                  </span>
                  <span className="text-[11px] text-slate-500">
                    Clic en una unidad para autollenar todos sus datos
                  </span>
                </div>
                {(() => {
                  const companyVehicles = vehicles.filter((v) => v.empresaId === selectedCompanyId);
                  if (companyVehicles.length === 0) {
                    return (
                      <div className="text-xs text-slate-500 bg-white p-3 rounded-xl border border-dashed border-slate-200 flex items-center justify-between">
                        <span>Esta empresa aún no tiene vehículos registrados en su catálogo. Puedes ingresar los datos abajo y se guardarán automáticamente para futuras visitas.</span>
                      </div>
                    );
                  }
                  return (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                      {companyVehicles.map((v) => {
                        const isSelected = placas.trim().toUpperCase() === v.placas.trim().toUpperCase();
                        return (
                          <button
                            type="button"
                            key={v.id}
                            onClick={() => loadVehicleData(v)}
                            className={`p-2.5 rounded-xl border text-left transition-all flex flex-col justify-between ${
                              isSelected
                                ? 'bg-rose-50 border-rose-500 shadow-sm ring-1 ring-rose-500'
                                : 'bg-white hover:bg-slate-50 border-slate-200 shadow-xs'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-1 mb-1">
                              <span className="font-mono font-bold text-xs text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                                {v.placas}
                              </span>
                              {v.numeroEconomico && (
                                <span className="text-[10px] font-bold text-rose-700 bg-rose-100 px-1.5 py-0.5 rounded">
                                  {v.numeroEconomico}
                                </span>
                              )}
                            </div>
                            <div className="text-xs font-medium text-slate-700 truncate">
                              {v.marca} {v.modelo} {v.ano ? `(${v.ano})` : ''}
                            </div>
                            {v.choferHabitual && (
                              <div className="text-[11px] text-slate-500 truncate mt-0.5">
                                👤 {v.choferHabitual}
                              </div>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  );
                })()}
              </div>
            )}
          </div>
        </div>

        {/* ============================================================== */}
        {/* SECCIÓN 2: IDENTIFICACIÓN DEL VEHÍCULO & INVENTARIO            */}
        {/* ============================================================== */}
        <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
              <Car className="w-4 h-4 text-slate-500" />
              <span>2. Identificación del Vehículo</span>
            </h3>
            <span className="text-[11px] text-slate-400">
              * Escribe las placas para autollenar datos de vehículos ya registrados
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3">
            <div>
              <label className="text-xs text-rose-700 block mb-1 font-bold">
                Placas *:
              </label>
              <input
                type="text"
                value={placas}
                onChange={(e) => handlePlacasChange(e.target.value)}
                placeholder="BJE-849-A"
                required
                className="w-full bg-rose-50/50 border-2 border-rose-300 text-rose-700 font-mono font-bold rounded-xl px-3 py-2 text-sm focus:outline-none tracking-wider text-center"
              />
            </div>

            <div>
              <label className="text-xs text-slate-600 block mb-1 font-bold">
                No. Eco / Unidad:
              </label>
              <input
                type="text"
                value={numeroEconomico}
                onChange={(e) => setNumeroEconomico(e.target.value)}
                placeholder="Eco-04"
                className="w-full bg-white border border-slate-200 text-slate-800 font-mono font-bold rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none text-center"
              />
            </div>

            <div>
              <label className="text-xs text-slate-500 block mb-1 font-medium">Marca:</label>
              <input
                type="text"
                value={marca}
                onChange={(e) => setMarca(e.target.value)}
                placeholder="Nissan / Toyota"
                className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs text-slate-500 block mb-1 font-medium">Modelo:</label>
              <input
                type="text"
                value={modelo}
                onChange={(e) => setModelo(e.target.value)}
                placeholder="Urvan / Corolla"
                className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs text-slate-500 block mb-1 font-medium">Año:</label>
              <input
                type="number"
                value={ano}
                onChange={(e) => setAno(Number(e.target.value))}
                className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none font-mono"
              />
            </div>

            <div>
              <label className="text-xs text-slate-500 block mb-1 font-medium">Color:</label>
              <input
                type="text"
                value={color}
                onChange={(e) => setColor(e.target.value)}
                placeholder="Blanco"
                className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs text-emerald-700 block mb-1 font-bold">
                Kilometraje *:
              </label>
              <input
                type="number"
                value={kilometraje}
                onChange={(e) => setKilometraje(Number(e.target.value))}
                placeholder="84500"
                required
                className="w-full bg-emerald-50/40 border-2 border-emerald-300 text-emerald-800 font-mono font-bold rounded-xl px-3 py-2 text-sm focus:outline-none text-right"
              />
            </div>

            <div>
              <label className="text-xs text-slate-500 block mb-1 font-medium">Motor / Cilindros:</label>
              <input
                type="text"
                value={motor}
                onChange={(e) => setMotor(e.target.value)}
                placeholder="Ej. 2.5L / 4 Cil"
                className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2 md:col-span-2">
              <label className="text-xs text-slate-500 block mb-1 font-medium">No. de Serie / VIN:</label>
              <input
                type="text"
                value={vin}
                onChange={(e) => setVin(e.target.value.toUpperCase())}
                placeholder="Ej. 3N1AB7AP8KY123456"
                className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none font-mono uppercase"
              />
            </div>
          </div>

          {/* Nivel de Combustible con Selector Visual */}
          <div className="mt-4 pt-4 border-t border-slate-200">
            <label className="text-xs text-slate-700 font-bold block mb-2 flex items-center gap-1.5">
              <Fuel className="w-4 h-4 text-amber-600" />
              <span>Nivel de Combustible al Ingresar:</span>
            </label>
            <div className="grid grid-cols-5 gap-2">
              {(['Vacio', '1/4', '1/2', '3/4', 'Lleno'] as FuelLevel[]).map((level) => {
                const isSelected = combustible === level;
                return (
                  <button
                    key={level}
                    type="button"
                    onClick={() => setCombustible(level)}
                    className={`py-2 px-1 text-center rounded-xl border text-xs font-bold transition-all ${
                      isSelected
                        ? 'bg-amber-500 text-slate-950 border-amber-600 shadow-sm'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {level}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Falla Reportada / Motivo de Visita */}
          <div className="mt-4 pt-4 border-t border-slate-200">
            <label className="text-xs text-rose-700 font-bold block mb-1">
              Falla Reportada o Motivo de Ingreso *:
            </label>
            <textarea
              value={fallaReportada}
              onChange={(e) => setFallaReportada(e.target.value)}
              rows={2}
              required
              placeholder="Describe lo que reporta el cliente o los síntomas (ej. Se escucha rechinido en frenos, cambio de aceite y filtro, ruidos al dar vuelta a la izquierda)..."
              className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl p-3 text-sm focus:border-rose-500 focus:outline-none"
            />
          </div>
        </div>

        {/* ============================================================== */}
        {/* SECCIÓN 3: INSPECCIÓN VISUAL A SIMPLE VISTA (DIAGRAMA TÉCNICO) */}
        {/* ============================================================== */}
        <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-rose-600"></span>
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  3. Inspección Visual Inmediata a Simple Vista
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Da una vuelta alrededor del vehículo y toca el plano técnico para marcar rayones, golpes o abolladuras
              </p>
            </div>

            {/* Selector de Tipo de Daño */}
            <div className="flex gap-1.5 text-xs">
              {(
                [
                  { key: 'rayon', label: 'Rayón', color: 'bg-rose-600 text-white' },
                  { key: 'golpe', label: 'Golpe', color: 'bg-amber-600 text-white' },
                  { key: 'abolladura', label: 'Abolladura', color: 'bg-purple-600 text-white' },
                  { key: 'quebrado', label: 'Quebrado', color: 'bg-sky-600 text-white' },
                ] as const
              ).map(({ key, label, color }) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setSelectedDamageType(key)}
                  className={`px-3 py-1.5 rounded-xl font-bold uppercase text-[11px] transition-all border ${
                    selectedDamageType === key
                      ? `${color} border-transparent shadow-sm ring-2 ring-slate-400`
                      : 'bg-white text-slate-600 hover:bg-slate-100 border-slate-200'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Chips Rápidos de Daños Comunes a 1 toque */}
          <div className="flex flex-wrap items-center gap-1.5 mb-3">
            <span className="text-[10px] text-slate-400 font-bold uppercase mr-1">Rápido:</span>
            {[
              { desc: 'Rayón en defensa delantera', x: 18, y: 50, tipo: 'rayon' as const },
              { desc: 'Golpe en puerta de chofer', x: 42, y: 86, tipo: 'golpe' as const },
              { desc: 'Abolladura en salpicadera izq.', x: 26, y: 84, tipo: 'abolladura' as const },
              { desc: 'Faro / Mica delantera estrellada', x: 14, y: 32, tipo: 'quebrado' as const },
              { desc: 'Rayón en cajuela / fascia trasera', x: 84, y: 50, tipo: 'rayon' as const },
              { desc: 'Sin tapón de gasolina', x: 74, y: 16, tipo: 'golpe' as const },
            ].map((preset, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleAddQuickDamage(preset.desc, preset.x, preset.y, preset.tipo)}
                className="text-[10px] bg-white hover:bg-slate-100 text-slate-700 px-2.5 py-1 rounded-lg border border-slate-200 transition-colors shadow-2xs font-medium"
              >
                + {preset.desc}
              </button>
            ))}
          </div>

          {/* Canvas Interactivo de Silueta Automotriz Aerodinámica */}
          <div
            onClick={handleDiagramClick}
            className="relative bg-white border-2 border-slate-300 hover:border-rose-400 rounded-2xl h-64 sm:h-72 w-full cursor-crosshair overflow-hidden flex items-center justify-center select-none shadow-inner"
          >
            {/* Silueta Técnica Vectorial Profesional de Carrocería */}
            <svg
              className="w-full h-full max-w-2xl opacity-80 pointer-events-none p-2"
              viewBox="0 0 700 280"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Eje y Guías de Medición de Bahía */}
              <line x1="40" y1="140" x2="660" y2="140" stroke="#e2e8f0" strokeDasharray="4 4" strokeWidth="1" />
              <line x1="220" y1="30" x2="220" y2="250" stroke="#f1f5f9" strokeWidth="1" />
              <line x1="480" y1="30" x2="480" y2="250" stroke="#f1f5f9" strokeWidth="1" />

              {/* Ruedas y Neumáticos Deportivos */}
              {/* Delantera Izquierda (Arriba en vista superior = lado derecho del auto si mira a la izq, o copiloto) */}
              <rect x="175" y="24" width="70" height="28" rx="6" fill="#1e293b" />
              <rect x="180" y="28" width="60" height="20" rx="3" fill="#475569" stroke="#94a3b8" strokeWidth="1" />
              <circle cx="210" cy="38" r="4" fill="#cbd5e1" />

              {/* Delantera Derecha (Abajo) */}
              <rect x="175" y="228" width="70" height="28" rx="6" fill="#1e293b" />
              <rect x="180" y="232" width="60" height="20" rx="3" fill="#475569" stroke="#94a3b8" strokeWidth="1" />
              <circle cx="210" cy="242" r="4" fill="#cbd5e1" />

              {/* Trasera Izquierda (Arriba) */}
              <rect x="475" y="24" width="70" height="28" rx="6" fill="#1e293b" />
              <rect x="480" y="28" width="60" height="20" rx="3" fill="#475569" stroke="#94a3b8" strokeWidth="1" />
              <circle cx="510" cy="38" r="4" fill="#cbd5e1" />

              {/* Trasera Derecha (Abajo) */}
              <rect x="475" y="228" width="70" height="28" rx="6" fill="#1e293b" />
              <rect x="480" y="232" width="60" height="20" rx="3" fill="#475569" stroke="#94a3b8" strokeWidth="1" />
              <circle cx="510" cy="242" r="4" fill="#cbd5e1" />

              {/* Espejos Laterales Aerodinámicos */}
              <path d="M 235 52 C 228 42, 215 44, 212 50 C 210 56, 222 58, 238 56 Z" fill="#64748b" stroke="#334155" strokeWidth="1.5" />
              <path d="M 235 228 C 228 238, 215 236, 212 230 C 210 224, 222 222, 238 224 Z" fill="#64748b" stroke="#334155" strokeWidth="1.5" />

              {/* CONTORNO PRINCIPAL DE CARROCERÍA (Aerodinámica moderna) */}
              <path
                d="M 95 140 
                   C 95 105, 120 72, 165 68
                   C 195 65, 235 68, 265 66
                   C 330 64, 410 64, 465 66
                   C 500 68, 545 65, 575 70
                   C 615 76, 635 105, 635 140
                   C 635 175, 615 204, 575 210
                   C 545 215, 500 212, 465 214
                   C 410 216, 330 216, 265 214
                   C 235 212, 195 215, 165 212
                   C 120 208, 95 175, 95 140 Z"
                fill="#f8fafc"
                stroke="#334155"
                strokeWidth="2.5"
                strokeLinejoin="round"
              />

              {/* Fascia y Defensa Delantera */}
              <path d="M 98 122 Q 135 122 135 140 Q 135 158 98 158" stroke="#94a3b8" strokeWidth="1.5" fill="none" />
              <path d="M 108 86 Q 130 98 135 110" stroke="#0284c7" strokeWidth="2" strokeLinecap="round" />
              <path d="M 108 194 Q 130 182 135 170" stroke="#0284c7" strokeWidth="2" strokeLinecap="round" />

              {/* Cofre y Líneas de Estilo de Bahía de Motor */}
              <path d="M 145 88 Q 190 94 235 90" stroke="#94a3b8" strokeWidth="1.5" fill="none" />
              <path d="M 145 192 Q 190 186 235 190" stroke="#94a3b8" strokeWidth="1.5" fill="none" />
              <path d="M 130 140 L 230 140" stroke="#cbd5e1" strokeWidth="1" strokeDasharray="3 3" />

              {/* Parabrisas Delantero Curvado */}
              <path
                d="M 238 88 
                   C 255 110, 260 140, 255 170 
                   L 285 165 
                   C 290 140, 290 115, 285 93 Z"
                fill="#e0f2fe"
                stroke="#0284c7"
                strokeWidth="1.8"
              />
              {/* Plumas de Limpiaparabrisas */}
              <line x1="250" y1="110" x2="272" y2="128" stroke="#475569" strokeWidth="1.5" strokeLinecap="round" />
              <line x1="252" y1="145" x2="274" y2="162" stroke="#475569" strokeWidth="1.5" strokeLinecap="round" />

              {/* Cabina / Techo / Ventanas Laterales */}
              <path
                d="M 288 88 
                   L 460 88 
                   C 485 115, 485 165, 460 192 
                   L 288 192 
                   C 295 165, 295 115, 288 88 Z"
                fill="#ffffff"
                stroke="#475569"
                strokeWidth="1.5"
              />
              {/* Quemacocos / Techo Solar Elegante */}
              <rect x="330" y="105" width="90" height="70" rx="8" stroke="#cbd5e1" strokeWidth="1.5" fill="#f1f5f9" />

              {/* Parabrisas Trasero */}
              <path
                d="M 462 90 
                   C 480 110, 480 170, 462 190 
                   L 495 186 
                   C 505 165, 505 115, 495 94 Z"
                fill="#e0f2fe"
                stroke="#0284c7"
                strokeWidth="1.8"
              />

              {/* Cajuela / Spoiler / Calaveras Traseras */}
              <path d="M 505 92 Q 555 98 585 92" stroke="#94a3b8" strokeWidth="1.5" fill="none" />
              <path d="M 505 188 Q 555 182 585 188" stroke="#94a3b8" strokeWidth="1.5" fill="none" />
              <path d="M 610 92 Q 628 108 626 122" stroke="#e11d48" strokeWidth="2.5" strokeLinecap="round" />
              <path d="M 610 188 Q 628 172 626 158" stroke="#e11d48" strokeWidth="2.5" strokeLinecap="round" />

              {/* Rótulos Técnicos de Orientación */}
              <text x="65" y="144" fill="#e11d48" fontSize="11" fontWeight="900" textAnchor="middle">◄ FRENTE</text>
              <text x="180" y="144" fill="#94a3b8" fontSize="9" fontWeight="bold" textAnchor="middle">COFRE</text>
              <text x="375" y="144" fill="#64748b" fontSize="10" fontWeight="bold" textAnchor="middle">TECHO / CABINA</text>
              <text x="540" y="144" fill="#94a3b8" fontSize="9" fontWeight="bold" textAnchor="middle">CAJUELA</text>
              <text x="660" y="144" fill="#e11d48" fontSize="11" fontWeight="900" textAnchor="middle">TRASERA ►</text>

              <text x="375" y="44" fill="#94a3b8" fontSize="8" fontWeight="bold" textAnchor="middle">COSTADO DERECHO (COPILOTO)</text>
              <text x="375" y="244" fill="#94a3b8" fontSize="8" fontWeight="bold" textAnchor="middle">COSTADO IZQUIERDO (CHOFER)</text>
            </svg>

            {/* Pines de Daños Marcados con animación y clic para borrar */}
            {danos.map((d) => (
              <div
                key={d.id}
                style={{ left: `${d.x}%`, top: `${d.y}%` }}
                onClick={(e) => {
                  e.stopPropagation();
                  if (confirm(`¿Eliminar daño marcado: "${d.detalle}"?`)) {
                    handleRemoveDamage(d.id);
                  }
                }}
                className={`absolute -translate-x-1/2 -translate-y-1/2 w-7 h-7 rounded-full text-white border-2 border-white flex items-center justify-center font-bold text-xs shadow-xl animate-bounce hover:scale-125 transition-transform cursor-pointer ${
                  d.tipo === 'rayon'
                    ? 'bg-rose-600'
                    : d.tipo === 'golpe'
                    ? 'bg-amber-600'
                    : d.tipo === 'abolladura'
                    ? 'bg-purple-600'
                    : 'bg-sky-600'
                }`}
                title={`${d.tipo.toUpperCase()}: ${d.detalle} (Clic para eliminar)`}
              >
                ✕
              </div>
            ))}
          </div>

          {/* Lista de Daños Marcados */}
          {danos.length > 0 ? (
            <div className="mt-3 space-y-1">
              <span className="text-[11px] font-bold text-slate-500 uppercase">
                Daños Registrados ({danos.length}):
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {danos.map((d) => (
                  <div
                    key={d.id}
                    className="flex items-center justify-between text-xs bg-white px-3 py-1.5 rounded-xl border border-slate-200"
                  >
                    <span className="text-slate-800 font-medium">
                      <strong
                        className={`uppercase mr-1.5 ${
                          d.tipo === 'rayon'
                            ? 'text-rose-600'
                            : d.tipo === 'golpe'
                            ? 'text-amber-600'
                            : d.tipo === 'abolladura'
                            ? 'text-purple-600'
                            : 'text-sky-600'
                        }`}
                      >
                        ● {d.tipo}:
                      </strong>
                      {d.detalle}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleRemoveDamage(d.id)}
                      className="text-slate-400 hover:text-rose-600 ml-2"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <p className="text-[11px] text-slate-400 italic mt-2 text-center">
              Sin daños marcados a simple vista en este momento. Toca la silueta si encuentras algún detalle.
            </p>
          )}
        </div>

        {/* ============================================================== */}
        {/* SECCIÓN 4: REFACCIONES & PRESUPUESTO INICIAL DE MANO DE OBRA   */}
        {/* ============================================================== */}
        <div className="bg-slate-50 p-5 rounded-2xl border-2 border-rose-200 shadow-xs space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <Wrench className="w-4 h-4 text-rose-600" />
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  4. Refacciones & Presupuesto Pactado en Recepción
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Define si el cliente trae sus piezas o si el taller cotiza mano de obra estimada de servicio
              </p>
            </div>

            {/* Selector Central: ¿Trae refacciones nuevas en el vehículo? */}
            <div className="flex bg-white p-1 rounded-xl border border-slate-200 text-xs">
              <button
                type="button"
                onClick={() => setTraeRefacciones('si')}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg font-bold transition-all ${
                  traeRefacciones === 'si'
                    ? 'bg-amber-600 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Package className="w-3.5 h-3.5" />
                <span>Sí trae refacciones</span>
              </button>
              <button
                type="button"
                onClick={() => setTraeRefacciones('no')}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg font-bold transition-all ${
                  traeRefacciones === 'no'
                    ? 'bg-rose-600 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Wrench className="w-3.5 h-3.5" />
                <span>No trae (Taller cotiza)</span>
              </button>
            </div>
          </div>

          {/* CASO A: EL CLIENTE TRAE REFACCIONES */}
          {traeRefacciones === 'si' && (
            <div className="bg-amber-50/60 p-4 rounded-xl border border-amber-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                  <Package className="w-4 h-4 text-amber-700" />
                  <span>Inventario de Refacciones que dejó el Cliente (Cajuela / Asiento):</span>
                </span>
                <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  ✓ Costo de piezas exento para el taller
                </span>
              </div>

              {/* Botones de sugerencias rápidas de refacciones */}
              <div className="flex flex-wrap gap-1.5">
                {[
                  'Juego de Balatas Delanteras',
                  'Juego de Balatas Traseras',
                  'Garrafa de Aceite y Filtro',
                  '4 Bujías de Iridio',
                  'Amortiguadores Delanteros',
                  'Discos de Freno',
                  'Bomba de Agua',
                  'Banda de Accesorios',
                ].map((sug, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => handleAddRefaccion(sug)}
                    className="text-[10px] bg-white hover:bg-amber-100 text-amber-900 px-2.5 py-1 rounded-lg border border-amber-300 font-medium transition-colors"
                  >
                    + {sug}
                  </button>
                ))}
              </div>

              {/* Input manual de refacción */}
              <div className="flex gap-2">
                <input
                  type="text"
                  value={nuevaRefaccion}
                  onChange={(e) => setNuevaRefaccion(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddRefaccion();
                    }
                  }}
                  placeholder="Escribe otra pieza que dejó (ej. Soporte de motor derecho en caja)..."
                  className="flex-1 bg-white border border-amber-300 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-amber-600 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => handleAddRefaccion()}
                  className="flex items-center gap-1 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-sm transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  <span>Anotar Pieza</span>
                </button>
              </div>

              {/* Lista de refacciones ingresadas */}
              {refaccionesCliente.length > 0 && (
                <div className="space-y-1.5 mt-2 bg-white p-3 rounded-xl border border-amber-200">
                  {refaccionesCliente.map((ref, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between text-xs bg-amber-50/50 px-3 py-1.5 rounded-lg border border-amber-100 text-amber-900 font-medium"
                    >
                      <span>✓ {ref}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveRefaccion(idx)}
                        className="text-rose-500 hover:text-rose-700 p-0.5"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Campo de Mano de Obra por cambiar estas piezas */}
              <div className="pt-3 border-t border-amber-200 grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
                <div>
                  <label className="text-xs font-bold text-slate-800 block">
                    Presupuesto de Mano de Obra por cambiar estas piezas *:
                  </label>
                  <span className="text-[11px] text-slate-500 block">
                    Se acuerda con el cliente al recibir el coche
                  </span>
                </div>
                <div>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 font-bold text-slate-400 text-sm">$</span>
                    <input
                      type="number"
                      value={presupuestoManoObraRefacciones}
                      onChange={(e) => setPresupuestoManoObraRefacciones(Number(e.target.value))}
                      required
                      placeholder="850"
                      className="w-full bg-white border-2 border-amber-500 text-slate-900 font-mono font-black text-lg rounded-xl pl-7 pr-14 py-2 text-right focus:outline-none focus:ring-2 focus:ring-amber-400"
                    />
                    <span className="absolute right-3 top-3 text-[11px] font-bold text-slate-400 font-mono">
                      MXN
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* CASO B: EL CLIENTE NO TRAE REFACCIONES (PRESUPUESTO APROXIMADO) */}
          {traeRefacciones === 'no' && (
            <div className="bg-rose-50/40 p-4 rounded-xl border border-rose-200 space-y-3">
              <span className="text-xs font-bold text-rose-950 block">
                Presupuesto de Mano de Obra Aproximado según Servicio:
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="text-xs text-slate-600 block mb-1 font-medium">
                    Concepto de Servicio Inicial / Diagnóstico:
                  </label>
                  <input
                    type="text"
                    value={conceptoServicioInicial}
                    onChange={(e) => setConceptoServicioInicial(e.target.value)}
                    placeholder="Ej. Afinación mayor, revisión de frenos y rectificado..."
                    className="w-full bg-white border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs text-rose-700 block mb-1 font-bold">
                    Mano de Obra Estimada ($ MXN) *:
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 font-bold text-slate-400 text-sm">$</span>
                    <input
                      type="number"
                      value={presupuestoManoObraAprox}
                      onChange={(e) => setPresupuestoManoObraAprox(Number(e.target.value))}
                      required
                      placeholder="1200"
                      className="w-full bg-white border-2 border-rose-400 text-slate-900 font-mono font-black text-lg rounded-xl pl-7 pr-14 py-2 text-right focus:outline-none focus:ring-2 focus:ring-rose-400"
                    />
                    <span className="absolute right-3 top-3 text-[11px] font-bold text-slate-400 font-mono">
                      MXN
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ASIGNACIÓN DE MECÁNICO Y COMISIÓN EN BAHÍA */}
          <div className="bg-gradient-to-r from-amber-50/70 via-white to-rose-50/60 p-4 rounded-xl border-2 border-amber-300 space-y-3 shadow-xs">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-amber-200/80 pb-2">
              <div className="flex items-center gap-2">
                <span className="text-lg">👨‍🔧</span>
                <div>
                  <h4 className="text-xs font-black text-slate-900 uppercase tracking-wide">
                    Asignación de Mecánico a la Bahía
                  </h4>
                  <span className="text-[11px] text-slate-500">
                    Elige al técnico que atenderá este auto y su porcentaje de comisión
                  </span>
                </div>
              </div>
              <span className="text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 px-2 py-0.5 rounded-full">
                Comisión solo en Mano de Obra (Refacciones 0%)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-center">
              {/* Selector de Mecánico */}
              <div className="sm:col-span-2">
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Mecánico Responsable *:
                </label>
                <select
                  value={selectedMechanicId}
                  onChange={(e) => handleMechanicSelectChange(e.target.value)}
                  className="w-full bg-white border-2 border-amber-400 text-slate-900 rounded-xl px-3 py-2 text-xs sm:text-sm font-bold focus:outline-none focus:ring-2 focus:ring-amber-500 shadow-sm cursor-pointer"
                >
                  <option value="">⚠️ Por Asignar Bahía (Sin mecánico aún)</option>
                  {mechanics.map((m) => (
                    <option key={m.id} value={m.id}>
                      👨‍🔧 {m.nombre} — {m.especialidad} (Comisión base: {m.comisionDefault}%)
                    </option>
                  ))}
                </select>
              </div>

              {/* Porcentaje de Comisión */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Comisión Asignada (%):
                </label>
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <input
                      type="number"
                      min={10}
                      max={50}
                      value={selectedMechanicCommission}
                      onChange={(e) => setSelectedMechanicCommission(Number(e.target.value))}
                      className="w-full bg-white border-2 border-amber-400 text-slate-900 font-mono font-bold text-sm rounded-xl px-3 py-2 text-center focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                    <span className="absolute right-3 top-2.5 text-xs font-black text-amber-600 font-mono">
                      %
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-500 font-medium">
                    (Rango 10%-45%)
                  </div>
                </div>
              </div>
            </div>

            {/* Cálculo de Comisión en tiempo real */}
            {selectedMechanicId && (
              <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 bg-amber-100/60 rounded-xl border border-amber-200 text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-amber-950">
                    Ganancia Técnico:
                  </span>
                  <span className="font-mono font-bold text-amber-900 bg-white px-2 py-0.5 rounded border border-amber-300">
                    ${Math.round(presupuestoManoObraElegido * (selectedMechanicCommission / 100)).toLocaleString()} MXN ({selectedMechanicCommission}%)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-slate-700">
                    Retención Taller:
                  </span>
                  <span className="font-mono font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    ${Math.max(0, Math.round(presupuestoManoObraElegido * (1 - selectedMechanicCommission / 100))).toLocaleString()} MXN ({100 - selectedMechanicCommission}%)
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* ANTICIPO AL DEJAR EL VEHÍCULO (ABIERTO) */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
            <div>
              <div className="flex items-center gap-1.5">
                <Receipt className="w-4 h-4 text-emerald-600" />
                <label className="text-xs font-bold text-slate-800 block">
                  Anticipo Recibido al Dejar el Auto:
                </label>
              </div>
              <span className="text-[11px] text-slate-500 block mt-0.5">
                Abierto: escribe el monto que deje el cliente ($0 si paga al recoger)
              </span>
            </div>

            <div>
              <div className="relative">
                <span className="absolute left-3 top-2.5 font-bold text-slate-400 text-sm">$</span>
                <input
                  type="number"
                  value={anticipoMonto}
                  onChange={(e) => setAnticipoMonto(Number(e.target.value))}
                  placeholder="0"
                  className="w-full bg-slate-50 border border-slate-300 text-slate-900 font-mono font-bold text-base rounded-xl pl-7 pr-14 py-2 text-right focus:border-emerald-500 focus:outline-none"
                />
                <span className="absolute right-3 top-2.5 text-[11px] font-bold text-slate-400 font-mono">
                  MXN
                </span>
              </div>
            </div>

            <div>
              <label className="text-[11px] text-slate-500 block mb-1 font-medium">
                Método de Pago del Anticipo:
              </label>
              <select
                value={anticipoMetodo}
                onChange={(e) => setAnticipoMetodo(e.target.value as PaymentMethod)}
                className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-xl px-3 py-2 text-xs font-bold focus:outline-none"
              >
                <option value="efectivo">💵 Efectivo (En caja)</option>
                <option value="tarjeta">💳 Tarjeta (+8% IVA)</option>
                <option value="transferencia">🏦 Transferencia BBVA (+8% IVA)</option>
              </select>
            </div>
          </div>

          {/* RESUMEN DE SALDO PARA EL TICKET DE ENTRADA */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-100 rounded-xl border border-slate-200 text-xs">
            <div className="flex items-center gap-4">
              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-semibold">
                  Presupuesto Inicial:
                </span>
                <span className="font-mono text-slate-900 font-bold text-sm">
                  ${presupuestoManoObraElegido.toLocaleString()} MXN
                </span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-semibold">
                  Anticipo Abonado:
                </span>
                <span className="font-mono text-emerald-600 font-bold text-sm">
                  -${(Number(anticipoMonto) || 0).toLocaleString()} MXN
                </span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-slate-500 block text-[10px] uppercase font-bold">
                Saldo Pendiente Estimado:
              </span>
              <span className="font-mono text-base font-black text-rose-600">
                ${saldoPendienteEstimado.toLocaleString()} MXN
              </span>
            </div>
          </div>
        </div>

        {/* ============================================================== */}
        {/* SECCIÓN 5: LAS 8 FOTOGRAFÍAS + 1 VIDEO OPCIONAL                */}
        {/* ============================================================== */}
        <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
            <div>
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
                <Camera className="w-4 h-4 text-slate-500" />
                <span>5. Galería de 8 Fotografías Oficiales + 1 Video Opcional</span>
              </h3>
              <p className="text-xs text-slate-500">
                Respaldo visual para proteger al taller ante reclamos de golpes o rayones previos
              </p>
            </div>

            <button
              type="button"
              onClick={handleLoadSamplePhotos}
              className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-white text-slate-700 border border-slate-200 hover:bg-slate-100 shadow-sm transition-colors"
            >
              Cargar Fotos Demo del Taller
            </button>
          </div>

          {/* Grid de 8 Fotos */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {photoCategories.map(({ key, label }) => {
              const photoUrl = photos[key];

              return (
                <div
                  key={key}
                  className="bg-white border border-slate-200 rounded-2xl p-2 flex flex-col justify-between aspect-video relative group overflow-hidden shadow-sm"
                >
                  {photoUrl ? (
                    <div
                      className="w-full h-full relative cursor-pointer"
                      onClick={() => {
                        const idx = validPhotosList.findIndex((p) => p.url === photoUrl);
                        setLightboxIndex(idx >= 0 ? idx : 0);
                        setLightboxOpen(true);
                      }}
                      title="Clic para ver foto en tamaño grande"
                    >
                      <img
                        src={photoUrl}
                        alt={label}
                        className="w-full h-full object-cover rounded-xl group-hover:scale-105 transition-transform"
                      />
                      <div className="absolute inset-0 bg-slate-900/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                        <span className="p-1.5 bg-slate-900/80 hover:bg-slate-800 text-white rounded-lg text-xs font-bold shadow flex items-center gap-1">
                          <Eye className="w-4 h-4" />
                          <span className="text-[10px]">Ver Grande</span>
                        </span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleUploadPhoto(key, '');
                          }}
                          className="p-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold shadow"
                          title="Eliminar foto"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <span className="absolute bottom-1 left-2 text-[10px] bg-slate-900/80 text-white px-2 py-0.5 rounded-md font-semibold pointer-events-none">
                        {label}
                      </span>
                    </div>
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-center p-2">
                      <Camera className="w-6 h-6 text-slate-400 mb-1" />
                      <span className="text-[11px] font-semibold text-slate-700 block mb-1">{label}</span>
                      <input
                        type="file"
                        accept="image/*"
                        capture="environment"
                        id={`photo-input-${key}`}
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleFileCapture(key, file);
                        }}
                      />
                      <label
                        htmlFor={`photo-input-${key}`}
                        className="cursor-pointer px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg text-[10px] font-bold border border-rose-200 transition-colors block"
                      >
                        📷 Tomar Foto / Subir
                      </label>
                      <button
                        type="button"
                        onClick={() =>
                          handleUploadPhoto(key, SAMPLE_PHOTOS[key as keyof typeof SAMPLE_PHOTOS])
                        }
                        className="mt-1 text-[9px] text-slate-400 hover:text-slate-600"
                      >
                        (usar demo)
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Video Opcional */}
          <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <Video className="w-4 h-4 text-purple-600" />
              <span className="font-semibold text-slate-700">
                1 Video Corto de Diagnóstico / Sonido de Motor (Opcional):
              </span>
            </div>
            {videoUrl ? (
              <div className="flex items-center gap-2">
                <span className="text-emerald-600 font-bold">✓ Video cargado</span>
                <button
                  type="button"
                  onClick={() => setVideoUrl(null)}
                  className="text-rose-600 hover:underline text-[10px]"
                >
                  (Eliminar)
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <input
                  type="file"
                  accept="video/*"
                  capture="environment"
                  id="video-capture-input"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      setVideoUrl(URL.createObjectURL(file));
                    }
                  }}
                />
                <label
                  htmlFor="video-capture-input"
                  className="cursor-pointer text-purple-600 hover:text-purple-700 font-bold hover:underline"
                >
                  📹 Grabar / Adjuntar Video
                </label>
                <button
                  type="button"
                  onClick={() => setVideoUrl('https://example.com/video-0900.mp4')}
                  className="text-[9px] text-slate-400 hover:text-slate-600"
                >
                  (demo)
                </button>
              </div>
            )}
          </div>
        </div>

        {/* BOTONES DE ACCIÓN */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
          <button
            type="button"
            onClick={onCancel}
            className="px-5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs sm:text-sm transition-colors"
          >
            Cancelar
          </button>
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95"
          >
            <Save className="w-4 h-4" />
            <span>Guardar Orden y Generar Ticket</span>
          </button>
        </div>
      </form>

      {/* Lightbox para ver fotos en tamaño grande */}
      <ImageLightboxModal
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        photos={validPhotosList}
        initialIndex={lightboxIndex}
      />
    </div>
  );
};
