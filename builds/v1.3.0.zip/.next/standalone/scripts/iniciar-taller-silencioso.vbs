' =========================================================================
' INICIADOR SILENCIOSO AUTONOMO (ZERO DEPENDENCIAS) - TALLER AMAYA
' =========================================================================
On Error Resume Next

Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' Obtener la carpeta del script y buscar la VERDADERA raíz del proyecto
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
curr = scriptDir
projectDir = ""

' Buscar la verdadera raíz subiendo hasta 5 niveles si está dentro de .next\standalone
For k = 0 To 5
    If fso.FileExists(curr & "\INICIAR-TALLER-AMAYA.bat") Or fso.FileExists(curr & "\ACTUALIZAR-TALLER.bat") Or (fso.FileExists(curr & "\package.json") And fso.FolderExists(curr & "\src")) Then
        projectDir = curr
        Exit For
    End If
    parent = fso.GetParentFolderName(curr)
    If parent = curr Or parent = "" Then Exit For
    curr = parent
Next

If projectDir = "" Then
    projectDir = fso.GetParentFolderName(scriptDir)
End If

WshShell.CurrentDirectory = projectDir

' Buscar el ejecutable portable de node.exe en todas las ubicaciones posibles
Dim nodePaths(8)
nodePaths(0) = projectDir & "\runtime\node.exe"
nodePaths(1) = projectDir & "\..\runtime\node.exe"
nodePaths(2) = projectDir & "\taller-amaya\runtime\node.exe"
nodePaths(3) = projectDir & "\taller-amaya 2\runtime\node.exe"
nodePaths(4) = "C:\Users\TALLER\Desktop\taller-amaya\runtime\node.exe"
nodePaths(5) = "C:\Users\TALLER\Desktop\taller-amaya 2\runtime\node.exe"
nodePaths(6) = "C:\taller-amaya\runtime\node.exe"
nodePaths(7) = "C:\Program Files\nodejs\node.exe"
nodePaths(8) = "C:\Program Files (x86)\nodejs\node.exe"

portableNode = ""
For i = 0 To UBound(nodePaths)
    If fso.FileExists(nodePaths(i)) Then
        portableNode = nodePaths(i)
        Exit For
    End If
Next

' Buscar el script del servidor standalone
Dim serverPaths(6)
serverPaths(0) = projectDir & "\.next\standalone\server.js"
serverPaths(1) = projectDir & "\server.js"
serverPaths(2) = projectDir & "\taller-amaya\.next\standalone\server.js"
serverPaths(3) = "C:\Users\TALLER\Desktop\taller-amaya\.next\standalone\server.js"
serverPaths(4) = "C:\Users\TALLER\Desktop\taller-amaya 2\.next\standalone\server.js"
serverPaths(5) = "C:\taller-amaya\.next\standalone\server.js"
serverPaths(6) = scriptDir & "\..\server.js"

standaloneScript = ""
For i = 0 To UBound(serverPaths)
    If fso.FileExists(serverPaths(i)) Then
        standaloneScript = serverPaths(i)
        Exit For
    End If
Next

If portableNode <> "" And standaloneScript <> "" Then
    ' Ejecutar en el directorio del standalone para que Next.js cargue sus assets
    standaloneDir = fso.GetParentFolderName(standaloneScript)
    WshShell.CurrentDirectory = standaloneDir
    cmdToRun = """" & portableNode & """ """ & standaloneScript & """"
    WshShell.Run cmdToRun, 0, False
ElseIf standaloneScript <> "" Then
    standaloneDir = fso.GetParentFolderName(standaloneScript)
    WshShell.CurrentDirectory = standaloneDir
    cmdToRun = "cmd /c node """ & standaloneScript & """"
    WshShell.Run cmdToRun, 0, False
Else
    WshShell.CurrentDirectory = projectDir
    cmdToRun = "cmd /c npm start"
    WshShell.Run cmdToRun, 0, False
End If

' Esperar 2 segundos a que el servidor inicialice (arranca en ~50ms)
WScript.Sleep 2000

' Abrir en modo aplicacion nativa de Windows (sin barras de navegacion)
appUrl = "http://localhost:3000"
WshShell.Run "cmd /c start msedge --app=" & appUrl & " || start " & appUrl, 0, False
