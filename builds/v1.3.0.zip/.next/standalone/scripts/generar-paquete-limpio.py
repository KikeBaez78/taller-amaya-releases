import os
import shutil

base_pkg = '/Users/mac/Desktop/paquete-actualizacion/Actualizacion-Taller-Amaya-v1.3.0'
if os.path.exists('/Users/mac/Desktop/paquete-actualizacion'):
    shutil.rmtree('/Users/mac/Desktop/paquete-actualizacion')

archivos_dir = os.path.join(base_pkg, 'archivos_actualizacion')
os.makedirs(archivos_dir, exist_ok=True)

repo_dir = '/Users/mac/.gemini/antigravity/scratch/taller-amaya'

# Copiar directorios y archivos necesarios
for item in ['.next', 'src', 'scripts', 'public']:
    src_path = os.path.join(repo_dir, item)
    dst_path = os.path.join(archivos_dir, item)
    if os.path.isdir(src_path):
        shutil.copytree(src_path, dst_path)

for item in ['ACTUALIZAR-TALLER.bat', 'INICIAR-TALLER-AMAYA.bat', 'package.json']:
    src_path = os.path.join(repo_dir, item)
    dst_path = os.path.join(archivos_dir, item)
    if os.path.isfile(src_path):
        shutil.copy2(src_path, dst_path)

# Remover archivos locales que deben mantenerse en la computadora del cliente
for bad_file in [
    os.path.join(archivos_dir, 'src', 'data', 'db.json'),
    os.path.join(archivos_dir, 'src', 'data', 'license.json'),
    os.path.join(archivos_dir, '.next', 'standalone', 'src', 'data', 'db.json'),
    os.path.join(archivos_dir, '.next', 'standalone', 'src', 'data', 'license.json'),
]:
    if os.path.exists(bad_file):
        os.remove(bad_file)

backups_dir = os.path.join(archivos_dir, 'src', 'data', 'backups')
if os.path.exists(backups_dir):
    shutil.rmtree(backups_dir)

# Asegurar CRLF en todos los .bat y .vbs
for root, dirs, files in os.walk(archivos_dir):
    for f in files:
        if f.endswith('.bat') or f.endswith('.vbs'):
            fp = os.path.join(root, f)
            with open(fp, 'rb') as infile:
                content = infile.read()
            crlf_content = content.replace(b'\r\n', b'\n').replace(b'\n', b'\r\n')
            with open(fp, 'wb') as outfile:
                outfile.write(crlf_content)

# Escribir ACTUALIZAR-CON-1-CLIC.bat
lines = [
    "@echo off",
    "title ACTUALIZACION AUTOMATICA - TALLER AMAYA v1.3.0",
    "color 0A",
    "",
    "echo =========================================================================",
    "echo        INSTALADOR OFICIAL DE ACTUALIZACION v1.3.0 - TALLER AMAYA",
    "echo =========================================================================",
    "echo.",
    "echo [1/4] Cerrando el sistema para aplicar mejoras...",
    "taskkill /F /IM node.exe >nul 2>&1",
    "ping 127.0.0.1 -n 2 >nul 2>&1",
    "",
    "set \"TALLER_DIR=\"",
    "if exist \"%~dp0\\.next\\standalone\\server.js\" set \"TALLER_DIR=%~dp0\"",
    "if not defined TALLER_DIR if exist \"%~dp0\\..\\taller-amaya\\.next\\standalone\\server.js\" set \"TALLER_DIR=%~dp0\\..\\taller-amaya\"",
    "if not defined TALLER_DIR if exist \"%~dp0\\..\\taller-amaya 2\\.next\\standalone\\server.js\" set \"TALLER_DIR=%~dp0\\..\\taller-amaya 2\"",
    "if not defined TALLER_DIR if exist \"%USERPROFILE%\\Desktop\\taller-amaya\\.next\\standalone\\server.js\" set \"TALLER_DIR=%USERPROFILE%\\Desktop\\taller-amaya\"",
    "if not defined TALLER_DIR if exist \"%USERPROFILE%\\Desktop\\taller-amaya 2\\.next\\standalone\\server.js\" set \"TALLER_DIR=%USERPROFILE%\\Desktop\\taller-amaya 2\"",
    "if not defined TALLER_DIR if exist \"C:\\Users\\TALLER\\Desktop\\taller-amaya\\.next\\standalone\\server.js\" set \"TALLER_DIR=C:\\Users\\TALLER\\Desktop\\taller-amaya\"",
    "if not defined TALLER_DIR if exist \"C:\\Users\\TALLER\\Desktop\\taller-amaya 2\\.next\\standalone\\server.js\" set \"TALLER_DIR=C:\\Users\\TALLER\\Desktop\\taller-amaya 2\"",
    "if not defined TALLER_DIR if exist \"C:\\taller-amaya\\.next\\standalone\\server.js\" set \"TALLER_DIR=C:\\taller-amaya\"",
    "",
    "if not defined TALLER_DIR (",
    "    set \"TALLER_DIR=%~dp0\"",
    ")",
    "",
    "echo [INFO] Carpeta del sistema: %TALLER_DIR%",
    "echo.",
    "echo [2/4] Protegiendo base de datos de clientes, ordenes y vehiculos...",
    "if not exist \"%TALLER_DIR%\\src\\data\\backups\" mkdir \"%TALLER_DIR%\\src\\data\\backups\" >nul 2>&1",
    "if exist \"%TALLER_DIR%\\src\\data\\db.json\" (",
    "    copy /y \"%TALLER_DIR%\\src\\data\\db.json\" \"%TALLER_DIR%\\src\\data\\backups\\respaldo_pre_v130.json\" >nul 2>&1",
    "    echo [OK] Base de datos y mecanicos de Reyna: 100% RESPALDADOS E INTACTOS.",
    ")",
    "if exist \"%TALLER_DIR%\\src\\data\\license.json\" (",
    "    echo [OK] Licencia oficial del taller: INTACTA.",
    ")",
    "",
    "echo.",
    "echo [3/4] Instalando archivos renovados de la version 1.3.0...",
    "",
    "if exist \"%~dp0archivos_actualizacion\" (",
    "    xcopy /E /I /Y /Q \"%~dp0archivos_actualizacion\" \"%TALLER_DIR%\" >nul 2>&1",
    ")",
    "",
    "if exist \"%TALLER_DIR%\\.next\\static\" (",
    "    xcopy /E /I /Y /Q \"%TALLER_DIR%\\.next\\static\" \"%TALLER_DIR%\\.next\\standalone\\.next\\static\" >nul 2>&1",
    ")",
    "if exist \"%TALLER_DIR%\\public\" (",
    "    xcopy /E /I /Y /Q \"%TALLER_DIR%\\public\" \"%TALLER_DIR%\\.next\\standalone\\public\" >nul 2>&1",
    ")",
    "if exist \"%TALLER_DIR%\\scripts\" (",
    "    if not exist \"%TALLER_DIR%\\.next\\standalone\\scripts\" mkdir \"%TALLER_DIR%\\.next\\standalone\\scripts\" >nul 2>&1",
    "    copy /y \"%TALLER_DIR%\\scripts\\*\" \"%TALLER_DIR%\\.next\\standalone\\scripts\\\" >nul 2>&1",
    ")",
    "if exist \"%TALLER_DIR%\\src\\data\\version.json\" (",
    "    if not exist \"%TALLER_DIR%\\.next\\standalone\\src\\data\" mkdir \"%TALLER_DIR%\\.next\\standalone\\src\\data\" >nul 2>&1",
    "    copy /y \"%TALLER_DIR%\\src\\data\\version.json\" \"%TALLER_DIR%\\.next\\standalone\\src\\data\\version.json\" >nul 2>&1",
    ")",
    "if exist \"%TALLER_DIR%\\src\\data\\db.json\" (",
    "    if not exist \"%TALLER_DIR%\\.next\\standalone\\src\\data\" mkdir \"%TALLER_DIR%\\.next\\standalone\\src\\data\" >nul 2>&1",
    "    copy /y \"%TALLER_DIR%\\src\\data\\db.json\" \"%TALLER_DIR%\\.next\\standalone\\src\\data\\db.json\" >nul 2>&1",
    ")",
    "",
    "if exist \"%TALLER_DIR%\\.next\\cache\" rd /s /q \"%TALLER_DIR%\\.next\\cache\" >nul 2>&1",
    "",
    "echo [OK] Archivos asentados con exito.",
    "echo.",
    "echo [4/4] Iniciando Taller Amaya con la nueva version 1.3.0...",
    "cd /d \"%TALLER_DIR%\"",
    "start wscript scripts\\iniciar-taller-silencioso.vbs",
    "",
    "echo.",
    "echo =========================================================================",
    "echo  [LISTO] TALLER AMAYA v1.3.0 INSTALADO Y CORRIENDO CON EXITO!",
    "echo.",
    "echo  Mejoras activas:",
    "echo  - Modificacion del 100% de la orden y vehiculo con PIN 2036",
    "echo  - Multiples carros por cliente sin bloqueos de marca",
    "echo  - Nombres de mecanicos y reglas de bahia protegidos permanentemente",
    "echo  - Actualizador OTA blindado (las proximas se aplicaran solas sin ZIP)",
    "echo =========================================================================",
    "echo.",
    "ping 127.0.0.1 -n 4 >nul 2>&1",
    "exit",
]

bat_path = os.path.join(base_pkg, 'ACTUALIZAR-CON-1-CLIC.bat')
with open(bat_path, 'wb') as f:
    f.write(('\r\n'.join(lines) + '\r\n').encode('ascii'))

print('Paquete preparado con exito y ACTUALIZAR-CON-1-CLIC.bat escrito con CRLF estricto.')
