@echo off
title ACTUALIZAR TALLER AMAYA
color 0A

cd /d "%~dp0"

echo ========================================================
echo       APLICANDO ACTUALIZACION OFICIAL - TALLER AMAYA
echo ========================================================
echo.

echo [1/5] Cerrando procesos previos de Taller Amaya...
taskkill /F /IM node.exe >nul 2>&1
ping 127.0.0.1 -n 2 >nul 2>&1

echo [2/5] Buscando archivo de actualizacion...
set "ZIP_FOUND="
if exist "temp_ota_update.zip" set "ZIP_FOUND=temp_ota_update.zip"
if exist ".next\standalone\temp_ota_update.zip" set "ZIP_FOUND=.next\standalone\temp_ota_update.zip"
if exist "actualizacion-v1.3.0.zip" set "ZIP_FOUND=actualizacion-v1.3.0.zip"
if exist "%USERPROFILE%\Desktop\actualizacion-v1.3.0.zip" set "ZIP_FOUND=%USERPROFILE%\Desktop\actualizacion-v1.3.0.zip"
if exist "%USERPROFILE%\Downloads\actualizacion-v1.3.0.zip" set "ZIP_FOUND=%USERPROFILE%\Downloads\actualizacion-v1.3.0.zip"
if exist "Actualizacion-Taller-Amaya-v1.3.0.zip" set "ZIP_FOUND=Actualizacion-Taller-Amaya-v1.3.0.zip"
if exist "%USERPROFILE%\Desktop\Actualizacion-Taller-Amaya-v1.3.0.zip" set "ZIP_FOUND=%USERPROFILE%\Desktop\Actualizacion-Taller-Amaya-v1.3.0.zip"

if not defined ZIP_FOUND (
    for %%F in (actualizacion-*.zip) do set "ZIP_FOUND=%%F"
)
if not defined ZIP_FOUND (
    for %%F in ("%USERPROFILE%\Desktop\actualizacion-*.zip") do set "ZIP_FOUND=%%F"
)
if not defined ZIP_FOUND (
    for %%F in ("%USERPROFILE%\Downloads\actualizacion-*.zip") do set "ZIP_FOUND=%%F"
)

:: Si no se encontro ningun archivo zip local, descargarlo desde GitHub
if not defined ZIP_FOUND (
    echo [INFO] Descargando version mas reciente directamente de la nube...
    powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('https://raw.githubusercontent.com/kikebaez78/taller-amaya-releases/main/builds/v1.3.0.zip', 'temp_ota_update.zip')" >nul 2>&1
    if exist "temp_ota_update.zip" set "ZIP_FOUND=temp_ota_update.zip"
)

if defined ZIP_FOUND (
    echo [INFO] Encontrado paquete: %ZIP_FOUND%
    echo [INFO] Extrayendo actualizacion limpia sin tocar clientes ni licencias...
    tar -xf "%ZIP_FOUND%" -C "%~dp0" >nul 2>&1
    if errorlevel 1 (
        powershell -NoProfile -Command "Expand-Archive -Path '%ZIP_FOUND%' -DestinationPath '%~dp0' -Force"
    )
    echo [OK] Archivos extraidos con exito.
    if exist "temp_ota_update.zip" del /f /q "temp_ota_update.zip" >nul 2>&1
    if exist ".next\standalone\temp_ota_update.zip" del /f /q ".next\standalone\temp_ota_update.zip" >nul 2>&1
) else (
    echo [ERROR] No se pudo encontrar ni descargar el paquete de actualizacion.
)

:: Replicar assets, scripts y version.json a standalone
if exist ".next\static" (
    xcopy /E /I /Y /Q ".next\static" ".next\standalone\.next\static" >nul 2>&1
)
if exist "public" (
    xcopy /E /I /Y /Q "public" ".next\standalone\public" >nul 2>&1
)
if exist "scripts" (
    if not exist ".next\standalone\scripts" mkdir ".next\standalone\scripts" >nul 2>&1
    copy /y "scripts\*" ".next\standalone\scripts\" >nul 2>&1
)
if exist "src\data\version.json" (
    if not exist ".next\standalone\src\data" mkdir ".next\standalone\src\data" >nul 2>&1
    copy /y "src\data\version.json" ".next\standalone\src\data\version.json" >nul 2>&1
)
if exist "src\data\db.json" (
    if not exist ".next\standalone\src\data" mkdir ".next\standalone\src\data" >nul 2>&1
    copy /y "src\data\db.json" ".next\standalone\src\data\db.json" >nul 2>&1
)

echo.
echo [3/5] Limpiando cache del servidor...
if exist ".next\cache" rd /s /q ".next\cache" >nul 2>&1

echo.
echo [4/5] Verificando proteccion de base de datos...
if not exist "src\data\backups" mkdir "src\data\backups"
if exist "src\data\db.json" (
    copy /y "src\data\db.json" "src\data\backups\respaldo_previo_actualizacion.json" >nul 2>&1
    echo [OK] Base de datos de clientes, vehiculos y ordenes: RESPALDADA E INTACTA.
)
if exist "src\data\license.json" (
    echo [OK] Licencia oficial casada con este equipo: INTACTA.
)

:: Habilitar puerto 3000 en Windows Firewall para Tablet y Celular
netsh advfirewall firewall add rule name="Taller Amaya Puerto 3000" dir=in action=allow protocol=TCP localport=3000 >nul 2>&1

echo.
echo [5/5] Iniciando Taller Amaya con motor renovado...
start wscript scripts\iniciar-taller-silencioso.vbs

echo.
echo ========================================================
echo  [EXITO] Sistema actualizado y reiniciado en v1.3.0.
echo  - Modificacion de toda la tabla (Marca, Modelo, Cliente...)
echo  - Registro de auditoria con PIN 2036
echo  - Preseleccion de unidades de flotilla
echo ========================================================
ping 127.0.0.1 -n 4 >nul 2>&1
exit
