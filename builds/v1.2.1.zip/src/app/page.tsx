'use client';

import React, { useState, useEffect } from 'react';
import { StorageService } from '@/lib/storage';
import { Sidebar } from '@/components/Sidebar';
import { TopBar } from '@/components/TopBar';
import { BankModal } from '@/components/BankModal';
import { BitacoraSearch } from '@/components/BitacoraSearch';
import { CheckInForm } from '@/components/CheckInForm';
import { WorkOrdersList } from '@/components/WorkOrdersList';
import { FlotillasCRM } from '@/components/FlotillasCRM';
import { MecanicosPanel } from '@/components/MecanicosPanel';
import { CajaModal } from '@/components/CajaModal';
import { DashboardReports } from '@/components/DashboardReports';
import { Ticket80mmModal } from '@/components/Ticket80mmModal';
import { CotizadorRapidoModal } from '@/components/CotizadorRapidoModal';
import { MobileConnectModal } from '@/components/MobileConnectModal';
import { LicenseLockScreen } from '@/components/LicenseLockScreen';
import { UpdateModal } from '@/components/UpdateModal';
import { RespaldoModal } from '@/components/RespaldoModal';
import { CreativeArchitectSeal } from '@/components/CreativeArchitectSeal';
import { RemoteUpdateManifest } from '@/lib/updates';
import { Vehicle, WorkOrder } from '@/types';

export default function Home() {
  const [currentTab, setCurrentTab] = useState<string>('bitacora');
  const [isCheckInOpen, setIsCheckInOpen] = useState(false);
  const [isBankModalOpen, setIsBankModalOpen] = useState(false);
  const [isCotizadorOpen, setIsCotizadorOpen] = useState(false);
  const [isMobileConnectOpen, setIsMobileConnectOpen] = useState(false);
  const [isRespaldoModalOpen, setIsRespaldoModalOpen] = useState(false);
  const [selectedVehicleForCheckIn, setSelectedVehicleForCheckIn] = useState<Vehicle | null>(null);
  const [autoPrintOrder, setAutoPrintOrder] = useState<WorkOrder | null>(null);
  const [syncVersion, setSyncVersion] = useState<number>(0);

  // Candado de Licencia Anti-Clonación (Fase 1)
  const [licenseState, setLicenseState] = useState<{
    checked: boolean;
    isActivated: boolean;
    machineId: string;
    reason?: string;
    clientName?: string;
  }>({
    checked: false,
    isActivated: true, // Optimista mientras se consulta la API
    machineId: '',
  });

  const checkLicense = async () => {
    try {
      const res = await fetch('/api/license');
      const data = await res.json();
      setLicenseState({
        checked: true,
        isActivated: Boolean(data.isActivated),
        machineId: data.machineId || '',
        reason: data.reason,
        clientName: data.clientName,
      });
    } catch {
      setLicenseState((prev) => ({ ...prev, checked: true }));
    }
  };

  // Sistema de Notificación de Actualizaciones para el Dueño (Fase 2)
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const [updateState, setUpdateState] = useState<{
    hasUpdate: boolean;
    currentVersion: string;
    remoteInfo: RemoteUpdateManifest | null;
  }>({
    hasUpdate: false,
    currentVersion: '1.0.0',
    remoteInfo: null,
  });

  const checkUpdates = async () => {
    try {
      const res = await fetch('/api/updates?_t=' + Date.now(), { cache: 'no-store' });
      const data = await res.json();
      setUpdateState({
        hasUpdate: Boolean(data.hasUpdate),
        currentVersion: data.currentVersion || '1.0.0',
        remoteInfo: data.remoteInfo || null,
      });
    } catch {}
  };

  useEffect(() => {
    checkLicense();
    checkUpdates();
    const updateTimer = setInterval(checkUpdates, 60000);
    return () => clearInterval(updateTimer);
  }, []);

  // Sincronización en tiempo real automática entre Celular, Tablet y Computadora
  useEffect(() => {
    // Sincronizar inmediatamente al montar
    StorageService.syncFromServer();

    const onDataSynced = () => {
      setSyncVersion((v) => v + 1);
    };
    window.addEventListener('taller_data_synced', onDataSynced);

    // Polling regular cada 2.5 segundos para que si se registra un auto en el celular
    // aparezca en la computadora automáticamente sin recargar
    const interval = setInterval(() => {
      StorageService.syncFromServer();
    }, 2500);

    const onWake = () => {
      StorageService.syncFromServer();
    };
    window.addEventListener('focus', onWake);
    window.addEventListener('visibilitychange', onWake);

    return () => {
      clearInterval(interval);
      window.removeEventListener('taller_data_synced', onDataSynced);
      window.removeEventListener('focus', onWake);
      window.removeEventListener('visibilitychange', onWake);
    };
  }, []);

  // Estados responsivos para el menú lateral
  const [isOpenMobile, setIsOpenMobile] = useState(false);
  const [isCollapsedDesktop, setIsCollapsedDesktop] = useState(false);

  const config = StorageService.getConfig();

  const handleOpenCheckIn = (vehicle?: Vehicle) => {
    setSelectedVehicleForCheckIn(vehicle || null);
    setIsCheckInOpen(true);
  };

  const handleCheckInSuccess = (order: WorkOrder) => {
    setIsCheckInOpen(false);
    setSelectedVehicleForCheckIn(null);
    setCurrentTab('ordenes');
    setAutoPrintOrder(order);
  };

  const handlePayOrder = (order: WorkOrder) => {
    setCurrentTab('caja');
  };

  const handleConvertQuoteToOrder = (quoteData: any) => {
    // Si viene vehículo o placas, creamos un vehículo temporal para el checkin
    if (quoteData.placas || quoteData.vehiculoInfo) {
      const parts = (quoteData.vehiculoInfo || '').split(' ');
      const anoNum = parseInt(parts[0]) || new Date().getFullYear();
      const marca = parts[1] || 'Vehículo';
      const modelo = parts.slice(2).join(' ') || 'General';

      const tempVeh: Vehicle = {
        id: `veh-q-${Date.now()}`,
        clienteId: 'cli-per-1',
        placas: quoteData.placas || 'POR ASIGNAR',
        marca,
        modelo,
        ano: anoNum,
        color: 'Gris',
        kilometrajeActual: 50000,
        ultimoServicioFecha: new Date().toISOString().split('T')[0],
      };
      setSelectedVehicleForCheckIn(tempVeh);
    } else {
      setSelectedVehicleForCheckIn(null);
    }
    setIsCheckInOpen(true);
  };

  // Si la licencia está bloqueada o es un equipo clonado no autorizado, mostrar pantalla de bloqueo
  if (licenseState.checked && !licenseState.isActivated) {
    return (
      <LicenseLockScreen
        machineId={licenseState.machineId}
        reason={licenseState.reason}
        onActivated={() => {
          checkLicense();
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-row font-sans selection:bg-rose-600 selection:text-white">
      {/* Menú Lateral Responsivo (Sidebar en Desktop + Drawer Deslizable en Móvil) */}
      <Sidebar
        config={config}
        currentTab={currentTab}
        setCurrentTab={(tab) => {
          setCurrentTab(tab);
          setIsCheckInOpen(false);
        }}
        onNewOrder={() => handleOpenCheckIn()}
        openBankModal={() => setIsBankModalOpen(true)}
        openCotizador={() => setIsCotizadorOpen(true)}
        openMobileConnectModal={() => setIsMobileConnectOpen(true)}
        openRespaldoModal={() => setIsRespaldoModalOpen(true)}
        isOpenMobile={isOpenMobile}
        setIsOpenMobile={setIsOpenMobile}
        isCollapsedDesktop={isCollapsedDesktop}
        setIsCollapsedDesktop={setIsCollapsedDesktop}
      />

      {/* Área de Contenido Principal */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen overflow-x-hidden">
        {/* Barra Superior con Botón Hamburguesa Móvil */}
        <TopBar
          config={config}
          currentTab={currentTab}
          licenseState={licenseState}
          hasUpdate={updateState.hasUpdate}
          updateVersion={updateState.remoteInfo?.version}
          openUpdateModal={() => setIsUpdateModalOpen(true)}
          onSelectTab={(tab) => {
            setCurrentTab(tab);
            setIsCheckInOpen(false);
          }}
          onToggleMobileMenu={() => setIsOpenMobile(true)}
          openBankModal={() => setIsBankModalOpen(true)}
          openRespaldoModal={() => setIsRespaldoModalOpen(true)}
        />

        {/* Contenido Dinámico por Pestaña */}
        <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
          {isCheckInOpen ? (
            <CheckInForm
              initialVehicle={selectedVehicleForCheckIn}
              onSuccess={handleCheckInSuccess}
              onCancel={() => {
                setIsCheckInOpen(false);
                setSelectedVehicleForCheckIn(null);
              }}
            />
          ) : (
            <>
              {currentTab === 'bitacora' && (
                <BitacoraSearch
                  onNewOrderForVehicle={(veh) => handleOpenCheckIn(veh)}
                  onSelectOrder={(ord) => setCurrentTab('ordenes')}
                />
              )}

              {currentTab === 'ordenes' && (
                <WorkOrdersList
                  onOpenCheckIn={() => handleOpenCheckIn()}
                  onPayOrder={handlePayOrder}
                />
              )}

              {currentTab === 'crm' && (
                <FlotillasCRM
                  onSelectVehicle={(veh) => {
                    setCurrentTab('bitacora');
                  }}
                  onNewOrderForVehicle={(veh) => handleOpenCheckIn(veh)}
                />
              )}

              {currentTab === 'mecanicos' && <MecanicosPanel />}

              {currentTab === 'caja' && <CajaModal />}

              {currentTab === 'reportes' && <DashboardReports />}
            </>
          )}
        </main>

        {/* Footer */}
        <footer className="bg-white border-t border-slate-200 py-4 px-6 text-xs text-slate-500 shadow-sm">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
            <div>
              <span className="font-bold text-slate-800">TALLER AMAYA</span> — {config.razonSocial}
              <span className="block mt-0.5 text-[11px] text-slate-500">
                {config.direccion} | Tel: {config.telefonoLocal} | WA: {config.whatsapp}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2.5 text-slate-600 text-[11px]">
                <span className="font-mono">RFC: {config.rfc}</span>
                <span>•</span>
                <span className="text-emerald-600 font-semibold">IVA 8% Zona Fronteriza Tijuana</span>
              </div>
              <CreativeArchitectSeal />
            </div>
          </div>
        </footer>
      </div>

      {/* Modal de Cuentas Bancarias BBVA */}
      <BankModal
        isOpen={isBankModalOpen}
        onClose={() => setIsBankModalOpen(false)}
        config={config}
      />

      {/* Modal de Cotizador Rápido Express */}
      <CotizadorRapidoModal
        isOpen={isCotizadorOpen}
        onClose={() => setIsCotizadorOpen(false)}
        onConvertToOrder={handleConvertQuoteToOrder}
      />

      {/* Modal de Conexión Celular / Tablet por QR */}
      <MobileConnectModal
        isOpen={isMobileConnectOpen}
        onClose={() => setIsMobileConnectOpen(false)}
      />

      {/* Modal de Ticket Térmico 80 mm Automático al Guardar Recepción */}
      {autoPrintOrder && (
        <Ticket80mmModal
          isOpen={!!autoPrintOrder}
          onClose={() => setAutoPrintOrder(null)}
          order={autoPrintOrder}
          vehicle={StorageService.getVehicles().find((v) => v.id === autoPrintOrder.vehiculoId)}
          client={StorageService.getClients().find((c) => c.id === autoPrintOrder.clienteId)}
          company={StorageService.getCompanies().find((co) => co.id === autoPrintOrder.empresaId)}
          config={config}
        />
      )}

      {/* Modal de Respaldos de Base de Datos */}
      <RespaldoModal
        isOpen={isRespaldoModalOpen}
        onClose={() => setIsRespaldoModalOpen(false)}
      />

      {/* Modal de Actualizaciones OTA Exclusivo del Propietario (Fase 2) */}
      <UpdateModal
        isOpen={isUpdateModalOpen}
        onClose={() => setIsUpdateModalOpen(false)}
        currentVersion={updateState.currentVersion}
        remoteInfo={updateState.remoteInfo}
        onUpdateSuccess={(newVer) => {
          setUpdateState((prev) => ({
            ...prev,
            currentVersion: newVer,
            hasUpdate: false,
          }));
        }}
      />
    </div>
  );
}
