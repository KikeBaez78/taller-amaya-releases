'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { TallerConfig } from '@/types';
import { StorageService } from '@/lib/storage';
import { Menu, MessageCircle, MapPin, X, Check, Bell, ShieldCheck, Sparkles, Database, Monitor } from 'lucide-react';

interface TopBarProps {
  config: TallerConfig;
  currentTab: string;
  onSelectTab?: (tab: string) => void;
  onToggleMobileMenu: () => void;
  openBankModal: () => void;
  openRespaldoModal?: () => void;
  hasUpdate?: boolean;
  updateVersion?: string;
  openUpdateModal?: () => void;
  licenseState?: {
    isActivated: boolean;
    machineId: string;
    clientName?: string;
  };
}

export const TopBar: React.FC<TopBarProps> = ({
  config,
  currentTab,
  onSelectTab,
  onToggleMobileMenu,
  openBankModal,
  openRespaldoModal,
  hasUpdate,
  updateVersion,
  openUpdateModal,
  licenseState,
}) => {
  const tabTitles: Record<string, { title: string; subtitle: string }> = {
    bitacora: {
      title: 'Bitácora & Expedientes',
      subtitle: 'Búsqueda instantánea por placas, vehículo o cliente',
    },
    ordenes: {
      title: 'Órdenes de Servicio & Presupuestos',
      subtitle: 'Control de folios, autorización de mano de obra y refacciones',
    },
    crm: {
      title: 'Flotillas & CRM Corporativo',
      subtitle: 'Alertas preventivas cada 2 meses o 10,000 km',
    },
    mecanicos: {
      title: 'Taller & Comisiones (4 Técnicos)',
      subtitle: '10% al 45% sobre mano de obra (partes 100% exentas)',
    },
    caja: {
      title: 'Caja, Salidas & Arqueo Diario',
      subtitle: 'Cobros con 8% IVA frontera Tijuana y corte de turno',
    },
    reportes: {
      title: 'Dashboard Ejecutivo',
      subtitle: 'Métricas de rentabilidad, comisiones y servicios',
    },
  };

  const currentInfo = tabTitles[currentTab] || {
    title: 'Taller Amaya',
    subtitle: 'Servicio Mecánico Automotriz',
  };

  const [pendingBahiaCount, setPendingBahiaCount] = useState(0);
  const [showBahiaModal, setShowBahiaModal] = useState(false);

  const updateCount = () => {
    const orders = StorageService.getWorkOrders();
    const count = orders.reduce(
      (acc, o) =>
        acc + (o.solicitudesBahia?.filter((s) => s.estado === 'pendiente_admin').length || 0),
      0
    );
    setPendingBahiaCount(count);
  };

  useEffect(() => {
    updateCount();
    window.addEventListener('taller_data_synced', updateCount);
    const interval = setInterval(updateCount, 2500);
    return () => {
      window.removeEventListener('taller_data_synced', updateCount);
      clearInterval(interval);
    };
  }, []);

  const getPendingBahiaList = () => {
    const orders = StorageService.getWorkOrders();
    const vehicles = StorageService.getVehicles();
    const clients = StorageService.getClients();
    const companies = StorageService.getCompanies();

    const list: Array<{
      order: any;
      sol: any;
      vehicle?: any;
      clientName: string;
      clientPhone: string;
    }> = [];

    orders.forEach((ord) => {
      if (ord.solicitudesBahia && ord.solicitudesBahia.length > 0) {
        ord.solicitudesBahia
          .filter((s: any) => s.estado === 'pendiente_admin')
          .forEach((sol: any) => {
            const v = vehicles.find((veh) => veh.id === ord.vehiculoId);
            const c = clients.find((cli) => cli.id === ord.clienteId);
            const comp = companies.find((co) => co.id === ord.empresaId);
            const clientName = comp ? comp.encargadoFlotilla : c?.nombre || 'Cliente';
            const clientPhone = ord.choferTelefono || c?.telefono || comp?.telefonos[0] || '6640000000';
            list.push({ order: ord, sol, vehicle: v, clientName, clientPhone });
          });
      }
    });

    return list;
  };

  const handleQuickAuthorizeFromModal = async (order: any, sol: any) => {
    sol.estado = 'autorizado_cliente';
    const costoExtra = sol.costoManoObraExtra || 0;
    if (costoExtra > 0) {
      const mechanics = StorageService.getMechanics();
      const mec = mechanics.find((m) => m.id === sol.mecanicoId);
      const commPct = mec ? mec.comisionDefault : 30;
      const comisionMO = Math.round(costoExtra * (commPct / 100));

      const extraService = {
        id: `srv-extra-${Date.now()}`,
        concepto: `[Autorizado Bahía] ${sol.descripcion}`,
        mecanicoId: sol.mecanicoId,
        mecanicoNombre: sol.mecanicoNombre,
        manoObra: costoExtra,
        refaccionesMonto: 0,
        comisionPorcentaje: commPct,
        comisionManoObra: comisionMO,
        estado: 'en_progreso' as const,
      };

      order.servicios.push(extraService);
      order.subtotalManoObra += costoExtra;
      order.subtotalGeneral += costoExtra;
      order.totalComisionesMecanicos += comisionMO;
      order.saldoPendiente += costoExtra;

      if (order.presupuesto) {
        order.presupuesto.manoObra.push({
          id: `mo-extra-${Date.now()}`,
          concepto: `[Extra Bahía] ${sol.descripcion}`,
          costo: costoExtra,
          comisionPorcentaje: commPct,
          mecanicoId: sol.mecanicoId,
          mecanicoNombre: sol.mecanicoNombre,
        });
        order.presupuesto.subtotalManoObra += costoExtra;
        order.presupuesto.totalPresupuesto += costoExtra;
      }
    }

    StorageService.saveWorkOrder(order);
    await fetch('/api/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'save_order', order }),
    });

    updateCount();
    alert(`✅ ¡Autorizado! La pantalla de Bahía ya tiene indicación en verde para ${sol.mecanicoNombre}.`);
  };

  const handleRejectFromModal = async (order: any, sol: any) => {
    sol.estado = 'rechazado_cliente';
    StorageService.saveWorkOrder(order);
    await fetch('/api/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'save_order', order }),
    });
    updateCount();
  };

  const handleSendWhatsAppFromModal = (
    order: any,
    sol: any,
    vehicle: any,
    clientName: string,
    phone: string
  ) => {
    const cleanPhone = phone.replace(/\D/g, '');
    const vehiculoDesc = vehicle
      ? `${vehicle.marca} ${vehicle.modelo} (Placas: ${vehicle.placas})`
      : 'tu vehículo';
    const texto = `Hola ${clientName}, te contactamos de *Recepción de TALLER AMAYA* 🚗🔧\n\nRespecto a tu vehículo *${vehiculoDesc}* (Folio *#${order.folio}*):\nEl mecánico *${sol.mecanicoNombre}* al desarmar e inspeccionar en bahía nos solicita lo siguiente para poder continuar el trabajo:\n\n📦 *Detalle / Refacción solicitada:* ${sol.descripcion}\n${
      sol.costoManoObraExtra && sol.costoManoObraExtra > 0
        ? `💰 *Mano de Obra extra estimada:* $${sol.costoManoObraExtra.toLocaleString()} MXN\n`
        : ''
    }\n¿Nos autorizas proceder con esta refacción / trabajo extra para que el mecánico continúe?\n\nPuedes autorizarnos por este mismo medio. ¡Muchas gracias!`;

    const url = `https://wa.me/52${cleanPhone}?text=${encodeURIComponent(texto)}`;
    window.open(url, '_blank');
  };

  const handleGoToOrderView = (order: any) => {
    setShowBahiaModal(false);
    if (onSelectTab) {
      onSelectTab('ordenes');
    }
    window.dispatchEvent(new CustomEvent('filter_solicitudes_bahia'));
  };

  return (
    <header className="bg-white border-b border-slate-200 text-slate-800 sticky top-0 z-30 shadow-sm">
      {/* Top micro banner */}
      <div className="hidden md:flex bg-slate-50 px-6 py-1 text-[11px] justify-between items-center text-slate-500 border-b border-slate-200">
        <div className="flex items-center gap-2">
          <span className="text-rose-600 font-bold uppercase tracking-wider">{config.razonSocial}</span>
          <span>•</span>
          <span className="flex items-center gap-1 text-slate-600">
            <MapPin className="w-3 h-3 text-rose-500" />
            {config.direccion}
          </span>
        </div>
        <div className="flex items-center gap-4 text-slate-600">
          <span className="font-mono text-emerald-600 font-bold">IVA Frontera 8%</span>
          <span>•</span>
          <button
            onClick={openBankModal}
            className="hover:text-blue-700 text-blue-600 font-semibold"
          >
            BBVA CLABE: {config.clabe}
          </button>
        </div>
      </div>

      {/* Main bar */}
      <div className="px-4 py-2.5 sm:px-6 flex items-center justify-between gap-4">
        {/* Lado izquierdo */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleMobileMenu}
            className="p-2 -ml-1 text-slate-500 hover:text-slate-800 rounded-xl hover:bg-slate-100 lg:hidden focus:outline-none"
            title="Abrir menú lateral"
          >
            <Menu className="w-6 h-6 text-rose-600" />
          </button>

          <div className="lg:hidden flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-white p-0.5 shadow-sm border border-slate-200 flex items-center justify-center shrink-0">
              <img
                src="/logo-taller-amaya.png"
                alt="Taller Amaya"
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <h2 className="font-black text-sm text-slate-900 leading-tight">TALLER AMAYA</h2>
              <span className="text-[10px] text-rose-600 font-extrabold uppercase tracking-widest block">
                SERVICIO MECÁNICO
              </span>
            </div>
          </div>

          <div className="hidden lg:flex items-center gap-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Panel Activo:</span>
            <span className="text-xs font-black uppercase text-slate-900 bg-slate-100 px-3 py-1 rounded-xl border border-slate-200 shadow-2xs">
              {currentInfo.title}
            </span>
          </div>
        </div>

        {/* Lado derecho: Notificaciones críticas y WhatsApp */}
        <div className="flex items-center gap-2">
          {/* Alerta de Solicitudes pendientes de Bahía (Solo aparece cuando hay algo urgente por autorizar) */}
          {pendingBahiaCount > 0 && (
            <button
              onClick={() => setShowBahiaModal(true)}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-md shadow-amber-500/30 animate-pulse transition-all cursor-pointer border border-amber-600"
              title={`${pendingBahiaCount} solicitud(es) de refacción o insumo pendiente(s) desde Bahía`}
            >
              <Bell className="w-4 h-4 fill-slate-950" />
              <span>🔔 {pendingBahiaCount} Solicitud de Bahía</span>
            </button>
          )}

          {/* Notificación de Actualización Disponible Exclusiva para el Dueño */}
          {hasUpdate && openUpdateModal && (
            <button
              type="button"
              onClick={openUpdateModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-rose-600 to-amber-500 hover:from-rose-500 hover:to-amber-400 text-white font-black text-xs shadow-md shadow-rose-600/30 animate-pulse transition-all cursor-pointer"
              title="¡Hay una nueva versión disponible! Haz clic para revisar las mejoras y actualizar"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>🔔 Nueva v{updateVersion || '1.1.0'}</span>
            </button>
          )}

          <a
            href={`https://wa.me/52${config.whatsapp}`}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl transition-colors font-bold text-xs"
            title="Abrir WhatsApp oficial del taller"
          >
            <MessageCircle className="w-4 h-4 text-emerald-600" />
            <span className="hidden sm:inline">WhatsApp Taller</span>
          </a>

          {/* Botón directo a Pantalla de Bahía */}
          <Link
            href="/bahia"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-sm transition-all"
            title="Abrir la Pantalla de Bahía en vivo para mecánicos"
          >
            <Monitor className="w-3.5 h-3.5 text-rose-400" />
            <span className="hidden sm:inline">Pantalla Bahía</span>
          </Link>

          {/* Botón de Respaldos de Seguridad */}
          {openRespaldoModal && (
            <button
              type="button"
              onClick={openRespaldoModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs border border-slate-200 transition-colors cursor-pointer"
              title="Respaldos automáticos y exportación de base de datos a USB"
            >
              <Database className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">Respaldos</span>
            </button>
          )}

          {/* Badge de Licencia Casada con este Equipo */}
          {licenseState?.isActivated && (
            <button
              type="button"
              onClick={openUpdateModal}
              className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-xl text-[11px] font-mono font-bold transition-colors cursor-pointer"
              title={`Software Oficial Casado con esta Máquina: ${licenseState.machineId}. Haz clic para ver actualizaciones.`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Oficial ({licenseState.machineId.substring(0, 10)}...)</span>
            </button>
          )}
        </div>
      </div>

      {/* Modal Rápido de Solicitudes Pendientes de Bahía (VISTA DIRECTA DE SOLICITUD) */}
      {showBahiaModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border-2 border-amber-400 rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 text-slate-800">
            {/* Cabecera del Modal */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-2xl bg-amber-500 text-slate-950 font-black text-lg">
                  🔔
                </span>
                <div>
                  <h3 className="text-base font-black text-slate-900 leading-tight">
                    Solicitud de Bahía Pendiente ({getPendingBahiaList().length})
                  </h3>
                  <span className="text-xs text-amber-800 font-semibold">
                    El mecánico está esperando cotización o autorización para continuar
                  </span>
                </div>
              </div>

              <button
                onClick={() => setShowBahiaModal(false)}
                className="text-slate-400 hover:text-slate-700 p-1 cursor-pointer"
                title="Cerrar / Regresar"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Lista de Solicitudes */}
            <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-1">
              {getPendingBahiaList().length === 0 ? (
                <div className="text-center py-8 text-slate-400">
                  <Check className="w-10 h-10 mx-auto text-emerald-500 mb-2" />
                  <p className="font-bold text-slate-700">No hay solicitudes pendientes</p>
                  <span className="text-xs text-slate-500">
                    Todas las solicitudes de bahía han sido atendidas.
                  </span>
                </div>
              ) : (
                getPendingBahiaList().map(({ order, sol, vehicle, clientName, clientPhone }) => (
                  <div
                    key={sol.id}
                    className="p-4 rounded-2xl bg-amber-50/80 border-2 border-amber-300 shadow-sm space-y-3"
                  >
                    {/* Auto y Mecánico */}
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-amber-200 pb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-black text-sm bg-rose-50 text-rose-700 border border-rose-200 px-2 py-0.5 rounded-lg">
                          #{order.folio}
                        </span>
                        <span className="font-mono font-black text-xs bg-slate-900 text-white px-2 py-0.5 rounded-md">
                          {vehicle?.placas || 'SIN PLACAS'}
                        </span>
                        <strong className="text-xs text-slate-900">
                          {vehicle?.marca} {vehicle?.modelo} ({vehicle?.ano})
                        </strong>
                      </div>

                      <span className="text-[11px] font-bold text-slate-700 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
                        👨‍🔧 {sol.mecanicoNombre} • {sol.fecha}
                      </span>
                    </div>

                    {/* Cliente */}
                    <div className="text-xs text-slate-600 flex items-center justify-between">
                      <span>
                        Cliente: <strong>{clientName}</strong>
                      </span>
                      <span className="font-mono text-[11px] text-slate-500">
                        Tel: {clientPhone}
                      </span>
                    </div>

                    {/* Qué solicita el mecánico */}
                    <div className="bg-white p-3 rounded-xl border border-amber-300 space-y-1">
                      <span className="text-[10px] uppercase font-bold text-amber-800 tracking-wider block">
                        📦 Lo que solicita el mecánico para continuar el trabajo:
                      </span>
                      <p className="font-black text-slate-900 text-sm leading-snug">
                        "{sol.descripcion}"
                      </p>
                      {sol.costoManoObraExtra && sol.costoManoObraExtra > 0 ? (
                        <span className="text-[11px] font-mono text-amber-900 font-bold block pt-1">
                          Mano de obra extra estimada: ${sol.costoManoObraExtra.toLocaleString()} MXN
                        </span>
                      ) : null}
                    </div>

                    {/* Botones de Acción Directa */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                      {/* 1. WhatsApp al cliente */}
                      <button
                        onClick={() =>
                          handleSendWhatsAppFromModal(order, sol, vehicle, clientName, clientPhone)
                        }
                        className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-transform active:scale-95 cursor-pointer"
                        title="Abrir WhatsApp para pedir autorización al cliente"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>📲 Cotizar (WhatsApp)</span>
                      </button>

                      {/* 2. Marcar Autorizado y Proceder */}
                      <button
                        onClick={() => handleQuickAuthorizeFromModal(order, sol)}
                        className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-sm transition-transform active:scale-95 cursor-pointer"
                        title="Autorizar y notificar en vivo a la pantalla de bahía"
                      >
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                        <span>✓ Marcar Autorizado</span>
                      </button>

                      {/* 3. Ver exclusivamente esta orden */}
                      <button
                        onClick={() => handleGoToOrderView(order)}
                        className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
                        title="Ver la orden de servicio completa"
                      >
                        <span>📋 Ver en Orden</span>
                      </button>
                    </div>

                    {/* Rechazar */}
                    <div className="text-right pt-0.5">
                      <button
                        onClick={() => handleRejectFromModal(order, sol)}
                        className="text-[11px] text-slate-400 hover:text-rose-600 underline font-semibold cursor-pointer"
                      >
                        ✕ No autorizar este extra
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Pie con opción de Regresar */}
            <div className="flex items-center justify-between border-t border-slate-100 pt-3">
              <span className="text-[11px] text-slate-500">
                Al autorizar, el monitor de bahía cambia a color verde automáticamente.
              </span>
              <button
                onClick={() => setShowBahiaModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition-colors cursor-pointer"
              >
                ← Regresar / Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
