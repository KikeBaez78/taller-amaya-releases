'use client';

import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { Smartphone, Monitor, X, Copy, Check, ExternalLink, Wifi } from 'lucide-react';

interface MobileConnectModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MobileConnectModal: React.FC<MobileConnectModalProps> = ({ isOpen, onClose }) => {
  const [targetMode, setTargetMode] = useState<'bahia' | 'recepcion'>('bahia');
  const [lanBaseUrl, setLanBaseUrl] = useState('http://192.168.1.194:3000');
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);

  // Obtener la IP local de la computadora en la red Wi-Fi
  useEffect(() => {
    if (!isOpen) return;
    setLoading(true);
    fetch('/api/network-info')
      .then((res) => res.json())
      .then((data) => {
        const base = data?.lanOrigin || 'http://192.168.1.194:3000';
        setLanBaseUrl(base);
      })
      .catch(() => {
        setLanBaseUrl('http://192.168.1.194:3000');
      })
      .finally(() => {
        setLoading(false);
      });
  }, [isOpen]);

  // Generar el código QR según el modo seleccionado (Bahía o Recepción)
  const currentTargetUrl =
    targetMode === 'bahia' ? `${lanBaseUrl}/bahia` : lanBaseUrl;

  useEffect(() => {
    if (!isOpen || !currentTargetUrl) return;
    QRCode.toDataURL(currentTargetUrl, {
      width: 280,
      margin: 1,
      color: { dark: '#0f172a', light: '#ffffff' },
    })
      .then((url) => setQrCodeUrl(url))
      .catch((err) => console.error('Error generating QR', err));
  }, [isOpen, currentTargetUrl]);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(currentTargetUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenDirectly = () => {
    window.open(currentTargetUrl, '_blank');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl space-y-4 text-center text-slate-800 overflow-hidden">
        {/* Cabecera */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2.5 text-left">
            <span className="p-2 rounded-2xl bg-rose-50 text-rose-600 border border-rose-200">
              <Wifi className="w-5 h-5" />
            </span>
            <div>
              <h3 className="text-base font-black text-slate-900 leading-tight">
                Conectar Tablet / Celular
              </h3>
              <span className="text-[11px] text-slate-500 font-medium">
                Sincronización en vivo en la red Wi-Fi del taller
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Selector de Pantalla a Conectar */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-2xl text-xs font-bold">
          {/* Opción 1: Pantalla de Bahía */}
          <button
            type="button"
            onClick={() => setTargetMode('bahia')}
            className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl transition-all cursor-pointer ${
              targetMode === 'bahia'
                ? 'bg-slate-900 text-white shadow-md'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Monitor className="w-4 h-4 text-rose-400" />
            <span>🖥️ Tablet de Bahía</span>
          </button>

          {/* Opción 2: Recepción / Patio */}
          <button
            type="button"
            onClick={() => setTargetMode('recepcion')}
            className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl transition-all cursor-pointer ${
              targetMode === 'recepcion'
                ? 'bg-slate-900 text-white shadow-md'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Smartphone className="w-4 h-4 text-emerald-400" />
            <span>📱 Recepción Móvil</span>
          </button>
        </div>

        {/* Instrucción según la pestaña */}
        <div className="text-xs text-slate-600 leading-snug">
          {targetMode === 'bahia' ? (
            <p>
              Apunta la <strong>cámara de la Tablet</strong> a este código para abrir la{' '}
              <strong className="text-rose-600">Pantalla de Bahía</strong> en vivo:
            </p>
          ) : (
            <p>
              Apunta la <strong>cámara de tu celular</strong> para recibir autos y levantar órdenes caminando en el patio:
            </p>
          )}
        </div>

        {/* Contenedor del Código QR */}
        <div className="bg-slate-50 p-4 rounded-3xl border-2 border-dashed border-slate-300 inline-block shadow-inner">
          {loading || !qrCodeUrl ? (
            <div className="w-56 h-56 flex flex-col items-center justify-center text-xs text-slate-400 gap-2">
              <div className="w-6 h-6 border-2 border-rose-600 border-t-transparent rounded-full animate-spin" />
              <span>Generando código QR...</span>
            </div>
          ) : (
            <img
              src={qrCodeUrl}
              alt="Escanear con tablet o celular"
              className="w-56 h-56 mx-auto rounded-2xl shadow-xs"
            />
          )}
        </div>

        {/* Dirección URL exacta y botones */}
        <div className="space-y-2 text-left bg-slate-50 p-3 rounded-2xl border border-slate-200">
          <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-slate-500">
            <span>Dirección en el navegador:</span>
            <span className="font-mono text-rose-600">
              {targetMode === 'bahia' ? '/bahia' : '/mostrador'}
            </span>
          </div>

          <div className="flex items-center justify-between gap-2">
            <span className="font-mono font-black text-xs text-slate-900 truncate select-all">
              {currentTargetUrl}
            </span>
            <button
              onClick={handleCopyLink}
              className="flex items-center gap-1 px-2.5 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold shrink-0 transition-colors cursor-pointer shadow-xs"
              title="Copiar enlace"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copiado' : 'Copiar'}</span>
            </button>
          </div>

          <button
            type="button"
            onClick={handleOpenDirectly}
            className="w-full flex items-center justify-center gap-1.5 py-1.5 text-xs text-slate-600 hover:text-slate-900 hover:bg-white rounded-xl transition-colors font-semibold border border-transparent hover:border-slate-200"
          >
            <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
            <span>Abrir directamente en esta computadora</span>
          </button>
        </div>

        {/* Requisito de Red */}
        <div className="p-2.5 bg-amber-50 rounded-2xl border border-amber-200 text-left text-[11px] text-amber-950 flex items-start gap-2">
          <span className="text-base leading-none">⚠️</span>
          <span>
            <strong>Requisito:</strong> La tablet o celular debe estar conectado a la red{' '}
            <strong>Wi-Fi del taller</strong> (la misma que esta laptop).
          </span>
        </div>

        {/* Botón Cerrar */}
        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors cursor-pointer"
        >
          Cerrar
        </button>
      </div>
    </div>
  );
};
