@echo off
title CREAR ACCESO DIRECTO - TALLER AMAYA
color 0A

cd /d "%~dp0"

echo ========================================================
echo     INSTALANDO ACCESO DIRECTO EN TU ESCRITORIO...
echo ========================================================
echo.

cscript //nologo scripts\crear-acceso-directo.vbs

echo.
echo ========================================================
echo A partir de ahora solo dale doble clic al icono
echo "Taller Amaya" en tu escritorio para abrir el sistema.
echo ========================================================
echo.
pause
