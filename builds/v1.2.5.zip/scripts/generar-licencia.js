#!/usr/bin/env node

/**
 * =========================================================================
 * GENERADOR OFICIAL DE LICENCIAS - TALLER AMAYA
 * USO EXCLUSIVO DEL DESARROLLADOR / ADMINISTRADOR MAESTRO
 * =========================================================================
 * Uso:
 *   node scripts/generar-licencia.js AMAYA-87A8-018F-5E68-830F "Taller Amaya Sucursal 1"
 * O sin argumentos para que genere la clave de la máquina actual.
 */

const crypto = require('crypto');
const readline = require('readline');

const MASTER_SECRET = 'AMAYA_SECURE_HMAC_MASTER_LICENSE_KEY_2026_TIJUANA_BC';

function generateKeyForMachine(machineId) {
  const cleanId = machineId.trim().toUpperCase();
  const signature = crypto
    .createHmac('sha256', MASTER_SECRET)
    .update(cleanId)
    .digest('hex')
    .toUpperCase();

  return `KEY-AMAYA-${signature.substring(0, 4)}-${signature.substring(4, 8)}-${signature.substring(8, 12)}-${signature.substring(12, 16)}`;
}

const args = process.argv.slice(2);

if (args.length > 0) {
  const machineId = args[0].trim().toUpperCase();
  const clientName = args[1] || 'Cliente Oficial';

  const activationKey = generateKeyForMachine(machineId);

  console.log('\n======================================================');
  console.log('   GENERADOR OFICIAL DE LICENCIAS - TALLER AMAYA');
  console.log('======================================================');
  console.log(` Cliente:         ${clientName}`);
  console.log(` Código Máquina:  ${machineId}`);
  console.log('------------------------------------------------------');
  console.log(` CLAVE DE ACTIVACIÓN:`);
  console.log(` >>> \x1b[32m\x1b[1m${activationKey}\x1b[0m <<<`);
  console.log('======================================================\n');
  process.exit(0);
}

// Si no pasaron argumentos, pedir el código por consola
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

console.log('\n======================================================');
console.log('   GENERADOR OFICIAL DE LICENCIAS - TALLER AMAYA');
console.log('======================================================');
rl.question('Pega el Código de Máquina del cliente (ej. AMAYA-XXXX-...): ', (machineId) => {
  if (!machineId || !machineId.trim()) {
    console.log('Error: Debe ingresar un código de máquina.');
    rl.close();
    process.exit(1);
  }

  rl.question('Nombre del cliente o sucursal (opcional): ', (clientName) => {
    const key = generateKeyForMachine(machineId);
    console.log('\n------------------------------------------------------');
    console.log(` Cliente:         ${clientName || 'Taller Amaya'}`);
    console.log(` Código Máquina:  ${machineId.trim().toUpperCase()}`);
    console.log('------------------------------------------------------');
    console.log(` CLAVE DE ACTIVACIÓN GENERADA:`);
    console.log(` >>> \x1b[32m\x1b[1m${key}\x1b[0m <<<`);
    console.log('======================================================\n');
    rl.close();
  });
});
