#!/usr/bin/env node

/**
 * =========================================================================
 * PUBLICADOR AUTOMATIZADO DE ACTUALIZACIONES OTA - TALLER AMAYA
 * USO EXCLUSIVO DEL DESARROLLADOR (kikebaez78)
 * =========================================================================
 * Uso:
 *   node scripts/publicar-actualizacion.js 1.2.0 "Título de la mejora" "Descripción..."
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const args = process.argv.slice(2);
const newVersion = args[0] || '1.1.0';
const title = args[1] || `Actualización Oficial v${newVersion}`;
const description = args[2] || 'Mejoras continuas y optimizaciones en Taller Amaya.';

const projectDir = path.resolve(__dirname, '..');
const releasesRepoDir = path.resolve(projectDir, '..', 'taller-amaya-releases');
const buildsDir = path.join(releasesRepoDir, 'builds');

console.log('\n======================================================');
console.log(`   PUBLICANDO ACTUALIZACIÓN OTA v${newVersion} - TALLER AMAYA`);
console.log('======================================================');

// 1. Asegurar directorios
if (!fs.existsSync(buildsDir)) {
  fs.mkdirSync(buildsDir, { recursive: true });
}

// 2. Compilar versión standalone si es necesario
console.log('\n[1/4] Compilando motor de alta velocidad...');
try {
  execSync('npm run build', { cwd: projectDir, stdio: 'inherit' });
  execSync('cp -r public .next/standalone/ && cp -r .next/static .next/standalone/.next/', {
    cwd: projectDir,
    stdio: 'inherit',
  });
  console.log('   ✓ Compilación completada con éxito.');
} catch (e) {
  console.error('Error al compilar:', e.message);
}

// 3. Empaquetar actualización (sin license.json)
const zipTarget = path.join(buildsDir, `v${newVersion}.zip`);
console.log(`\n[2/4] Empaquetando archivo de distribución: v${newVersion}.zip...`);
try {
  if (fs.existsSync(zipTarget)) fs.unlinkSync(zipTarget);
  execSync(`zip -r "${zipTarget}" .next src scripts public ACTUALIZAR-TALLER.bat -x "src/data/license.json" "src/data/db.json" "src/data/backups/*" "*.DS_Store"`, {
    cwd: projectDir,
    stdio: 'pipe',
  });
  const stats = fs.statSync(zipTarget);
  console.log(`   ✓ Paquete generado (${(stats.size / 1024 / 1024).toFixed(1)} MB).`);
} catch (e) {
  console.error('Error al empaquetar zip:', e.message);
}

// 4. Actualizar manifiesto version.json
console.log('\n[3/4] Generando manifiesto público version.json...');
const manifest = {
  version: newVersion,
  releaseDate: new Date().toISOString().split('T')[0],
  title: title,
  description: description,
  changelog: [
    title,
    description,
    'Protección permanente de vehículos, clientes y base de datos (db.json).',
    'Seguro de activación de hardware intacto.',
  ],
  downloadUrl: `https://raw.githubusercontent.com/kikebaez78/taller-amaya-releases/main/builds/v${newVersion}.zip`,
  mandatory: false,
};

fs.writeFileSync(
  path.join(releasesRepoDir, 'version.json'),
  JSON.stringify(manifest, null, 2),
  'utf8'
);
console.log('   ✓ Manifiesto version.json actualizado.');

// 5. Commit y Push a GitHub
console.log('\n[4/4] Subiendo a GitHub (kikebaez78/taller-amaya-releases)...');
try {
  execSync('git add .', { cwd: releasesRepoDir, stdio: 'inherit' });
  try {
    execSync(`git commit -m "Release v${newVersion} - ${title}"`, { cwd: releasesRepoDir, stdio: 'inherit' });
  } catch {}
  execSync('git push origin main', { cwd: releasesRepoDir, stdio: 'inherit' });
  console.log('   ✓ ¡Subido con éxito a GitHub!');
} catch (e) {
  console.log('   Nota: Para completar la subida, ejecuta:');
  console.log(`   cd ${releasesRepoDir} && git push origin main`);
}

console.log('\n======================================================');
console.log(` [LISTO] Versión v${newVersion} publicada en el canal OTA.`);
console.log(` En cuanto la PC o tablet del taller se abra con internet,`);
console.log(` le aparecerá la notificación a Reyna con el PIN 2036.`);
console.log('======================================================\n');
