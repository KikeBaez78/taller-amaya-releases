' =========================================================================
' ABRIR PANTALLA DE BAHIA - TALLER AMAYA
' =========================================================================
On Error Resume Next
Set WshShell = CreateObject("WScript.Shell")
appUrl = "http://localhost:3000/bahia"
WshShell.Run "cmd /c start msedge --app=" & appUrl & " || start " & appUrl, 0, False
