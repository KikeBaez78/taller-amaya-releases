import { TallerConfig, Mechanic } from '@/types';

export const TALLER_CONFIG: TallerConfig = {
  razonSocial: 'REYNA GUADALUPE AMAYA FAJARDO',
  nombreComercial: 'TALLER AMAYA',
  rfc: 'AAFR9312155V1',
  direccion: 'C. Santo Domingo #19950, Buenos Aires Sur, CP 22207, Tijuana B.C.',
  telefonoLocal: '6646295614',
  whatsapp: '6644093068',
  correo: 'reynatacorp@gmail.com',
  banco: 'BBVA BANCOMER',
  cuenta: '0477881630',
  clabe: '012028004778816301',
  ivaFronteraPorcentaje: 8,
  folioInicial: 900,
  adminPin: '2036',
};

export const INITIAL_MECHANICS: Mechanic[] = [
  {
    id: 'mec-1',
    nombre: 'Carlos Mendoza',
    especialidad: 'Afinaciones y Motor',
    telefono: '664-123-4501',
    comisionDefault: 35,
    activo: true,
  },
  {
    id: 'mec-2',
    nombre: 'Javier Ruiz',
    especialidad: 'Frenos y Suspensión',
    telefono: '664-123-4502',
    comisionDefault: 30,
    activo: true,
  },
  {
    id: 'mec-3',
    nombre: 'Roberto Amaya',
    especialidad: 'Diagnóstico por Computadora y Eléctrico',
    telefono: '664-123-4503',
    comisionDefault: 40,
    activo: true,
  },
  {
    id: 'mec-4',
    nombre: 'Miguel Ángel Torres',
    especialidad: 'Transmisiones y Mecánica Rápida',
    telefono: '664-123-4504',
    comisionDefault: 25,
    activo: true,
  },
];
