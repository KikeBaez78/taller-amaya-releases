import { Company, Client, Vehicle, WorkOrder, CashRegisterShift } from '@/types';

// DATOS LIMPIOS PARA PRUEBAS REALES EN TABLET Y TALLER
export const INITIAL_COMPANIES: Company[] = [];

export const INITIAL_CLIENTS: Client[] = [];

export const INITIAL_VEHICLES: Vehicle[] = [];

export const INITIAL_WORK_ORDERS: WorkOrder[] = [];

export const INITIAL_CASH_SHIFT: CashRegisterShift = {
  id: 'caja-turno-inicial',
  fechaApertura: new Date().toISOString().replace('T', ' ').substring(0, 16),
  fondoInicial: 1000, // $1,000 MXN fondo inicial en caja
  ingresosEfectivo: 0,
  ingresosTarjeta: 0,
  ingresosTransferencia: 0,
  gastosMenores: [],
  totalGastosMenores: 0,
  efectivoEsperado: 1000,
  estado: 'abierta',
  cajero: 'Reyna Amaya (Administración)',
};

export const SAMPLE_PHOTOS = {
  frente: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=800&q=80',
  trasera: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=800&q=80',
  lateralIzquierdo: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=800&q=80',
  lateralDerecho: 'https://images.unsplash.com/photo-1542362567-b07e5359b964?auto=format&fit=crop&w=800&q=80',
  motor: 'https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=800&q=80',
  odometro: 'https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80',
  interior: 'https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&w=800&q=80',
  cajuela: 'https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=800&q=80',
};
