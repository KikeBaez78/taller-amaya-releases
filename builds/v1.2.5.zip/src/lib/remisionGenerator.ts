import { TALLER_CONFIG } from '@/data/tallerConfig';

export interface RemisionItem {
  cantidad: number | string;
  descripcion: string;
  costo: number;
}

export interface RemisionData {
  folio: string;
  fecha?: string;
  cliente: string;
  telefono?: string;
  vehiculo: {
    marca?: string;
    modelo?: string;
    motor?: string;
    cilindros?: string;
    tipo?: string;
    color?: string;
    placas?: string;
    ano?: number | string;
  };
  partes: RemisionItem[];
  manoDeObraItems?: RemisionItem[];
  subtotalPartes: number;
  subtotalManoObra: number;
  aplicaIva: boolean;
  ivaMonto: number;
  total: number;
  trackingUrl?: string;
  nota?: string;
}

export function generateRemisionHTML(data: RemisionData): string {
  const fechaStr =
    data.fecha ||
    new Date().toLocaleDateString('es-MX', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });

  // Combinar partes y mano de obra para la tabla de Partes a Remplazar y Reparación
  const allItems: { cantidad: string | number; descripcion: string; costo: string }[] = [];

  (data.partes || []).forEach((p) => {
    if (p.descripcion && p.descripcion.trim()) {
      allItems.push({
        cantidad: p.cantidad || 1,
        descripcion: p.descripcion,
        costo: p.costo > 0 ? `$${p.costo.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '',
      });
    }
  });

  (data.manoDeObraItems || []).forEach((m) => {
    if (m.descripcion && m.descripcion.trim()) {
      allItems.push({
        cantidad: m.cantidad || 1,
        descripcion: `M.O. ${m.descripcion}`,
        costo: m.costo > 0 ? `$${m.costo.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '',
      });
    }
  });

  // Si hay pocas filas, rellenar hasta un mínimo de 14 renglones para que dé el formato de remisión formal
  const minRows = 14;
  const rowsNeeded = Math.max(0, minRows - allItems.length);

  const qrUrl = data.trackingUrl || `https://wa.me/52${TALLER_CONFIG.whatsapp}`;
  const qrImgSrc = `https://api.qrserver.com/v1/create-qr-code/?size=100x100&margin=0&data=${encodeURIComponent(qrUrl)}`;

  const v = data.vehiculo || {};

  return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Remisión ${data.folio} - Taller Amaya</title>
  <style>
    @page {
      size: letter portrait;
      margin: 12mm 15mm;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
      color: #000000;
      background: #ffffff;
      font-size: 11px;
      line-height: 1.25;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    .no-print-bar {
      background: #0f172a;
      color: #ffffff;
      padding: 10px 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: 0 4px 6px -1px rgba(0,0,0,0.15);
      position: sticky;
      top: 0;
      z-index: 999;
      font-family: sans-serif;
    }
    .btn-print {
      background: #e11d48;
      color: #ffffff;
      border: none;
      padding: 8px 20px;
      font-size: 13px;
      font-weight: 700;
      border-radius: 8px;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
    }
    .btn-close {
      background: #334155;
      color: #e2e8f0;
      border: none;
      padding: 8px 14px;
      font-size: 12px;
      border-radius: 8px;
      cursor: pointer;
    }
    .sheet {
      max-width: 800px;
      margin: 20px auto;
      padding: 24px 30px;
      background: #ffffff;
      border: 1px solid #d1d5db;
      box-shadow: 0 4px 15px rgba(0,0,0,0.06);
    }
    @media print {
      body {
        background: #ffffff;
      }
      .no-print-bar {
        display: none !important;
      }
      .sheet {
        border: none;
        margin: 0;
        padding: 0;
        box-shadow: none;
        max-width: 100%;
      }
    }

    /* CABECERA EXACTA AL FORMATO */
    .header-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 6px;
    }
    .logo-td {
      width: 160px;
      vertical-align: middle;
    }
    .logo-img {
      max-width: 155px;
      max-height: 70px;
      object-fit: contain;
    }
    .title-td {
      text-align: center;
      vertical-align: middle;
    }
    .main-title {
      font-size: 26px;
      font-weight: 900;
      color: #001f54;
      letter-spacing: 1px;
      font-family: 'Arial Black', Arial, sans-serif;
    }
    .remision-box-td {
      width: 130px;
      text-align: right;
      vertical-align: top;
    }
    .remision-box {
      border: 2px solid #000000;
      padding: 4px 8px;
      text-align: center;
      display: inline-block;
      min-width: 110px;
    }
    .remision-box .title {
      font-weight: 900;
      font-size: 12px;
      letter-spacing: 1px;
    }
    .remision-box .folio {
      font-size: 12px;
      font-weight: 800;
      font-family: monospace;
      color: #b91c1c;
      margin-top: 1px;
    }

    /* DATOS FISCALES DEL TALLER */
    .company-info {
      text-align: center;
      margin-bottom: 12px;
      font-size: 10.5px;
      line-height: 1.35;
    }
    .company-info .field-bold {
      font-weight: 800;
    }

    /* FECHA */
    .date-row {
      text-align: right;
      font-weight: 800;
      font-size: 11px;
      margin-bottom: 4px;
      padding-right: 4px;
    }

    /* TABLA CLIENTE Y VEHICULO */
    .client-vehicle-table {
      width: 100%;
      border-collapse: collapse;
      border: 2px solid #000000;
      margin-bottom: 8px;
    }
    .client-vehicle-table td, .client-vehicle-table th {
      border: 1px solid #000000;
      padding: 4px 6px;
      font-size: 10px;
    }
    .client-row-header {
      font-weight: 900;
      text-transform: uppercase;
      font-size: 10.5px;
      background: #ffffff;
    }
    .client-row-value {
      font-weight: 800;
      font-size: 11px;
    }
    .vehicle-col-header {
      font-weight: 800;
      text-align: center;
      text-transform: uppercase;
      font-size: 9.5px;
      background: #ffffff;
      padding: 3px 2px;
    }
    .vehicle-col-value {
      text-align: center;
      font-weight: 700;
      font-size: 10.5px;
      height: 20px;
    }

    /* TABLA DE PARTES Y REPARACIÓN */
    .parts-table {
      width: 100%;
      border-collapse: collapse;
      border: 2px solid #000000;
      margin-bottom: 10px;
    }
    .parts-table th, .parts-table td {
      border: 1px solid #000000;
      padding: 4px 6px;
      font-size: 10px;
    }
    .parts-main-header {
      text-align: center;
      font-weight: 900;
      font-size: 11px;
      letter-spacing: 0.5px;
      background: #ffffff;
      border-bottom: 2px solid #000000 !important;
      padding: 5px !important;
    }
    .col-cant-hdr {
      width: 80px;
      text-align: center;
      font-weight: 800;
    }
    .col-desc-hdr {
      text-align: center;
      font-weight: 800;
    }
    .col-cost-hdr {
      width: 110px;
      text-align: center;
      font-weight: 800;
    }

    .col-cant-val {
      text-align: center;
      font-weight: 700;
      font-size: 10.5px;
      height: 22px;
    }
    .col-desc-val {
      text-align: left;
      font-weight: 600;
      font-size: 10.5px;
    }
    .col-cost-val {
      text-align: right;
      font-family: monospace;
      font-weight: 700;
      font-size: 11px;
      padding-right: 8px;
    }

    /* FOOTER Y TOTALES */
    .footer-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 4px;
    }
    .footer-left {
      width: 58%;
      vertical-align: top;
      padding-right: 15px;
    }
    .footer-right {
      width: 42%;
      vertical-align: top;
    }

    .note-container {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .qr-img {
      width: 65px;
      height: 65px;
      border: 1px solid #000000;
      padding: 2px;
    }
    .note-text {
      font-size: 10px;
      font-weight: 800;
      line-height: 1.35;
    }
    .note-text .label {
      font-weight: 900;
    }

    /* TABLA DE TOTALES DERECHA */
    .totals-table {
      width: 100%;
      border-collapse: collapse;
      border: 2px solid #000000;
    }
    .totals-table td {
      border: 1px solid #000000;
      padding: 4px 8px;
      font-size: 10.5px;
    }
    .totals-lbl {
      font-weight: 800;
      text-align: left;
      text-transform: uppercase;
    }
    .totals-val {
      font-weight: 900;
      text-align: right;
      font-family: monospace;
      font-size: 11.5px;
      min-width: 90px;
    }
    .total-final-row td {
      background: #f1f5f9;
      font-size: 12px;
      border-top: 2px solid #000000 !important;
    }
  </style>
</head>
<body>

  <!-- Barra superior en pantalla (no sale en la impresión) -->
  <div class="no-print-bar">
    <div style="display: flex; align-items: center; gap: 10px;">
      <span style="font-size: 16px;">📄</span>
      <div>
        <strong style="font-size: 13px;">Remisión Formal - Taller Amaya</strong>
        <span style="display: block; font-size: 11px; opacity: 0.8;">Folio: ${data.folio} • Cliente: ${data.cliente || 'Público General'}</span>
      </div>
    </div>
    <div style="display: flex; align-items: center; gap: 8px;">
      <button class="btn-print" onclick="window.print()">
        🖨️ Imprimir / Guardar en PDF
      </button>
      <button class="btn-close" onclick="window.close()">
        ✕ Cerrar
      </button>
    </div>
  </div>

  <div class="sheet">
    <!-- 1. ENCABEZADO -->
    <table class="header-table">
      <tr>
        <td class="logo-td">
          <img src="/logo-taller-amaya.png" alt="Taller Amaya" class="logo-img" onerror="this.src='/logo.png'" />
        </td>
        <td class="title-td">
          <div class="main-title">TALLER AMAYA</div>
        </td>
        <td class="remision-box-td">
          <div class="remision-box">
            <div class="title">REMISIÓN</div>
            <div class="folio">${data.folio}</div>
          </div>
        </td>
      </tr>
    </table>

    <!-- 2. DATOS FISCALES -->
    <div class="company-info">
      <div><span class="field-bold">RAZON SOCIAL:</span> ${TALLER_CONFIG.razonSocial}</div>
      <div><span class="field-bold">RFC:</span> ${TALLER_CONFIG.rfc}</div>
      <div><span class="field-bold">DOMICILIO:</span> ${TALLER_CONFIG.direccion.toUpperCase()}</div>
      <div>
        <span class="field-bold">TEL.</span> (${TALLER_CONFIG.telefonoLocal.slice(0,3)}) ${TALLER_CONFIG.telefonoLocal.slice(3,4)}-${TALLER_CONFIG.telefonoLocal.slice(4,6)}-${TALLER_CONFIG.telefonoLocal.slice(6,8)}-${TALLER_CONFIG.telefonoLocal.slice(8)}.
        &nbsp;&nbsp;•&nbsp;&nbsp;
        <span class="field-bold">CORREO:</span> ${TALLER_CONFIG.correo}
      </div>
    </div>

    <!-- 3. FECHA -->
    <div class="date-row">
      ${fechaStr}
    </div>

    <!-- 4. CLIENTE Y VEHICULO -->
    <table class="client-vehicle-table">
      <tr>
        <td colspan="7" class="client-row-header">
          NOMBRE DEL CLIENTE O´ COMPAÑÍA: <span class="client-row-value">${data.cliente ? data.cliente.toUpperCase() : 'MOSTRADOR / PÚBLICO GENERAL'}</span>
        </td>
      </tr>
      <tr>
        <th class="vehicle-col-header" style="width: 14%;">MARCA</th>
        <th class="vehicle-col-header" style="width: 18%;">MODELO</th>
        <th class="vehicle-col-header" style="width: 13%;">MOTOR</th>
        <th class="vehicle-col-header" style="width: 13%;">CILINDROS</th>
        <th class="vehicle-col-header" style="width: 14%;">TIPO</th>
        <th class="vehicle-col-header" style="width: 14%;">COLOR</th>
        <th class="vehicle-col-header" style="width: 14%;">PLACAS</th>
      </tr>
      <tr>
        <td class="vehicle-col-value">${(v.marca || '-').toUpperCase()}</td>
        <td class="vehicle-col-value">${(v.modelo || '-').toUpperCase()}${v.ano ? ` (${v.ano})` : ''}</td>
        <td class="vehicle-col-value">${(v.motor || '-').toUpperCase()}</td>
        <td class="vehicle-col-value">${(v.cilindros || '-').toUpperCase()}</td>
        <td class="vehicle-col-value">${(v.tipo || '-').toUpperCase()}</td>
        <td class="vehicle-col-value">${(v.color || '-').toUpperCase()}</td>
        <td class="vehicle-col-value font-mono font-bold" style="font-weight: 800;">${(v.placas || 'SIN PLACAS').toUpperCase()}</td>
      </tr>
    </table>

    <!-- 5. TABLA DE PARTES A REMPLAZAR Y REPARACIÓN -->
    <table class="parts-table">
      <thead>
        <tr>
          <th colspan="3" class="parts-main-header">
            PARTES A REMPLAZAR Y REPARACION
          </th>
        </tr>
        <tr>
          <th class="col-cant-hdr">CANTIDAD</th>
          <th class="col-desc-hdr">PARTES A REMPLAZAR</th>
          <th class="col-cost-hdr">COSTO</th>
        </tr>
      </thead>
      <tbody>
        ${allItems
          .map(
            (it) => `
        <tr>
          <td class="col-cant-val">${it.cantidad}</td>
          <td class="col-desc-val">${it.descripcion}</td>
          <td class="col-cost-val">${it.costo}</td>
        </tr>`
          )
          .join('')}

        <!-- Renglones vacíos para completar formato de remisión impresa -->
        ${Array.from({ length: rowsNeeded })
          .map(
            () => `
        <tr>
          <td class="col-cant-val">&nbsp;</td>
          <td class="col-desc-val">&nbsp;</td>
          <td class="col-cost-val">&nbsp;</td>
        </tr>`
          )
          .join('')}
      </tbody>
    </table>

    <!-- 6. NOTAS Y TOTALES -->
    <table class="footer-table">
      <tr>
        <!-- Lado izquierdo: Nota y QR -->
        <td class="footer-left">
          <div class="note-container">
            <img src="${qrImgSrc}" alt="QR" class="qr-img" />
            <div class="note-text">
              <div class="label">NOTA:</div>
              <div>${data.nota || 'ESTA REMISION ESTA SUJETA A CAMBIO SIN PREVIO AVISO'}</div>
            </div>
          </div>
        </td>

        <!-- Lado derecho: Desglose de totales -->
        <td class="footer-right">
          <table class="totals-table">
            <tr>
              <td class="totals-lbl">TOTAL PARTES</td>
              <td class="totals-val">$${data.subtotalPartes.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
            </tr>
            <tr>
              <td class="totals-lbl">MANO D´OBRA</td>
              <td class="totals-val">$${data.subtotalManoObra.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
            </tr>
            <tr>
              <td class="totals-lbl">SUB-TOTAL</td>
              <td class="totals-val">$${(data.subtotalPartes + data.subtotalManoObra).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
            </tr>
            ${
              data.aplicaIva
                ? `
            <tr>
              <td class="totals-lbl">I.V.A. 8%</td>
              <td class="totals-val">$${data.ivaMonto.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
            </tr>`
                : ''
            }
            <tr class="total-final-row">
              <td class="totals-lbl" style="font-weight: 900;">TOTAL</td>
              <td class="totals-val" style="font-size: 13px; font-weight: 900; color: #000000;">
                $${data.total.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </div>

  <script>
    // Foco automático para facilitar impresión inmediata con Ctrl+P
    window.onload = function() {
      // Dejar lista la página para impresión
    };
  </script>
</body>
</html>`;
}

export function openRemisionPrintWindow(data: RemisionData): void {
  const printWindow = window.open('', '_blank', 'width=950,height=1000');
  if (!printWindow) {
    alert('Por favor permita las ventanas emergentes (pop-ups) en su navegador para imprimir o guardar la remisión en PDF.');
    return;
  }
  const html = generateRemisionHTML(data);
  printWindow.document.open();
  printWindow.document.write(html);
  printWindow.document.close();
}
