-- ========================================================
-- ESQUEMA SQL OFICIAL PARA SUPABASE - TALLER AMAYA
-- REYNA GUADALUPE AMAYA FAJARDO (Tijuana, B.C.)
-- ========================================================

-- 1. TABLA DE EMPRESAS / FLOTILLAS
CREATE TABLE IF NOT EXISTS public.companies (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  razon_social TEXT NOT NULL,
  rfc TEXT NOT NULL,
  encargado_flotilla TEXT NOT NULL,
  direccion TEXT NOT NULL,
  telefonos TEXT[] DEFAULT '{}',
  correos TEXT[] DEFAULT '{}',
  dias_credito INT DEFAULT 15,
  notas TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 2. TABLA DE CLIENTES (Persona Física o Enlace a Flotilla)
CREATE TABLE IF NOT EXISTS public.clients (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  tipo TEXT NOT NULL CHECK (tipo IN ('persona', 'empresa')),
  nombre TEXT NOT NULL,
  telefono TEXT NOT NULL,
  whatsapp TEXT,
  correo TEXT,
  empresa_id UUID REFERENCES public.companies(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 3. TABLA DE VEHÍCULOS
CREATE TABLE IF NOT EXISTS public.vehicles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  cliente_id UUID REFERENCES public.clients(id) ON DELETE CASCADE,
  empresa_id UUID REFERENCES public.companies(id) ON DELETE SET NULL,
  placas TEXT NOT NULL UNIQUE,
  marca TEXT NOT NULL,
  modelo TEXT NOT NULL,
  ano INT NOT NULL,
  color TEXT NOT NULL,
  vin TEXT,
  chofer_habitual TEXT,
  chofer_telefono TEXT,
  kilometraje_actual INT DEFAULT 0,
  ultimo_servicio_fecha DATE,
  ultimo_servicio_km INT,
  proximo_servicio_fecha DATE,
  proximo_servicio_km INT,
  notas TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 4. TABLA DE MECÁNICOS (Plantilla de 4 mecánicos)
CREATE TABLE IF NOT EXISTS public.mechanics (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  nombre TEXT NOT NULL,
  especialidad TEXT,
  telefono TEXT,
  comision_default NUMERIC(5,2) DEFAULT 30.00 CHECK (comision_default BETWEEN 10 AND 45),
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 5. TABLA DE ÓRDENES DE TRABAJO (Check-in, fotos, combustible e inventario)
-- Folio editable con inicio sugerido en 0900
CREATE TABLE IF NOT EXISTS public.work_orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  folio TEXT NOT NULL UNIQUE,
  vehiculo_id UUID REFERENCES public.vehicles(id) ON DELETE RESTRICT,
  cliente_id UUID REFERENCES public.clients(id) ON DELETE RESTRICT,
  empresa_id UUID REFERENCES public.companies(id) ON DELETE SET NULL,
  chofer_nombre TEXT,
  chofer_telefono TEXT,
  fecha_ingreso TIMESTAMPTZ DEFAULT now(),
  fecha_promesa TIMESTAMPTZ,
  fecha_salida TIMESTAMPTZ,
  estado TEXT DEFAULT 'recepcion' CHECK (estado IN ('recepcion', 'diagnostico', 'aprobada', 'en_proceso', 'listo', 'entregado', 'cancelado')),
  falla_reportada TEXT NOT NULL,
  nivel_combustible TEXT DEFAULT '1/2' CHECK (nivel_combustible IN ('Vacio', '1/4', '1/2', '3/4', 'Lleno')),
  kilometraje_entrada INT NOT NULL,
  refacciones_cliente TEXT[] DEFAULT '{}',
  fotos_entrada JSONB DEFAULT '{}', -- 8 fotos obligatorias
  video_entrada TEXT,
  danos_previos JSONB DEFAULT '[]', -- Diagrama de carrocería con coordenadas x,y
  subtotal_mano_obra NUMERIC(12,2) DEFAULT 0,
  subtotal_refacciones NUMERIC(12,2) DEFAULT 0,
  subtotal_general NUMERIC(12,2) DEFAULT 0,
  total_comisiones NUMERIC(12,2) DEFAULT 0,
  total_pagado NUMERIC(12,2) DEFAULT 0,
  saldo_pendiente NUMERIC(12,2) DEFAULT 0,
  fotos_salida TEXT[] DEFAULT '{}',
  firma_cliente TEXT,
  notas_salida TEXT,
  entregado_por TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 6. TABLA DE SERVICIOS POR ORDEN (Con cálculo de comisión individual)
CREATE TABLE IF NOT EXISTS public.order_services (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  work_order_id UUID REFERENCES public.work_orders(id) ON DELETE CASCADE,
  concepto TEXT NOT NULL,
  mecanico_id UUID REFERENCES public.mechanics(id),
  mano_obra NUMERIC(12,2) DEFAULT 0,
  refacciones_monto NUMERIC(12,2) DEFAULT 0,
  comision_porcentaje NUMERIC(5,2) DEFAULT 30.00 CHECK (comision_porcentaje BETWEEN 10 AND 45),
  comision_mano_obra NUMERIC(12,2) GENERATED ALWAYS AS (mano_obra * (comision_porcentaje / 100.0)) STORED,
  estado TEXT DEFAULT 'pendiente' CHECK (estado IN ('pendiente', 'en_progreso', 'terminado'))
);

-- 7. TABLA DE PAGOS (Con 8% de IVA en tarjeta y transferencia)
CREATE TABLE IF NOT EXISTS public.order_payments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  work_order_id UUID REFERENCES public.work_orders(id) ON DELETE CASCADE,
  fecha TIMESTAMPTZ DEFAULT now(),
  metodo TEXT NOT NULL CHECK (metodo IN ('efectivo', 'tarjeta', 'transferencia')),
  monto NUMERIC(12,2) NOT NULL,
  aplica_iva_8 BOOLEAN DEFAULT false,
  monto_iva NUMERIC(12,2) DEFAULT 0,
  monto_total_con_iva NUMERIC(12,2) NOT NULL,
  referencia TEXT
);

-- 8. TABLA DE TURNOS DE CAJA Y ARQUEOS
CREATE TABLE IF NOT EXISTS public.cash_shifts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  fecha_apertura TIMESTAMPTZ DEFAULT now(),
  fecha_cierre TIMESTAMPTZ,
  fondo_inicial NUMERIC(12,2) DEFAULT 1000.00,
  ingresos_efectivo NUMERIC(12,2) DEFAULT 0,
  ingresos_tarjeta NUMERIC(12,2) DEFAULT 0,
  ingresos_transferencia NUMERIC(12,2) DEFAULT 0,
  total_gastos_menores NUMERIC(12,2) DEFAULT 0,
  efectivo_esperado NUMERIC(12,2) DEFAULT 0,
  efectivo_real_contado NUMERIC(12,2),
  diferencia NUMERIC(12,2),
  estado TEXT DEFAULT 'abierta' CHECK (estado IN ('abierta', 'cerrada')),
  cajero TEXT NOT NULL,
  observaciones TEXT
);

-- 9. TABLA DE GASTOS MENORES DEL TALLER (Salidas de caja diaria)
CREATE TABLE IF NOT EXISTS public.cash_expenses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  cash_shift_id UUID REFERENCES public.cash_shifts(id) ON DELETE CASCADE,
  fecha TIMESTAMPTZ DEFAULT now(),
  descripcion TEXT NOT NULL,
  monto NUMERIC(12,2) NOT NULL,
  categoria TEXT NOT NULL CHECK (categoria IN ('solventes', 'tornilleria', 'alimentos', 'herramienta', 'otro')),
  autorizado_por TEXT NOT NULL
);

-- Índices de búsqueda ultra-rápida por placas, modelo, VIN y cliente
CREATE INDEX IF NOT EXISTS idx_vehicles_placas ON public.vehicles(placas);
CREATE INDEX IF NOT EXISTS idx_work_orders_folio ON public.work_orders(folio);
CREATE INDEX IF NOT EXISTS idx_work_orders_vehiculo ON public.work_orders(vehiculo_id);
