'use client';

import React, { useState } from 'react';
import { ShieldAlert, ShieldCheck, KeyRound, Copy, Check, Lock, Cpu, Sparkles, AlertTriangle } from 'lucide-react';

interface LicenseLockScreenProps {
  machineId: string;
  reason?: string;
  onActivated: () => void;
}

export const LicenseLockScreen: React.FC<LicenseLockScreenProps> = ({
  machineId,
  reason,
  onActivated,
}) => {
  const [activationKey, setActivationKey] = useState('');
  const [clientName, setClientName] = useState('Taller Amaya');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const handleCopyMachineId = () => {
    navigator.clipboard.writeText(machineId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleActivate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activationKey.trim()) {
      setErrorMessage('Por favor ingresa la clave de activación provista por soporte.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/license', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          activationKey: activationKey.trim(),
          clientName: clientName.trim(),
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        setErrorMessage(data.message || 'La clave ingresada no es válida para este equipo.');
        setIsLoading(false);
        return;
      }

      // Éxito
      onActivated();
    } catch (err) {
      setErrorMessage('No se pudo verificar la clave. Intenta de nuevo.');
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[9999] bg-slate-950 flex items-center justify-center p-4 text-slate-100 select-none overflow-y-auto">
      {/* Fondo con detalles sutiles de seguridad */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-rose-950/30 via-slate-950 to-slate-950 pointer-events-none" />

      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        {/* Cabecera con Logotipo */}
        <div className="text-center space-y-2">
          <div className="inline-flex p-3 rounded-2xl bg-rose-600/10 border border-rose-500/20 text-rose-500 mb-2">
            <Lock className="w-8 h-8" />
          </div>
          <div className="flex items-center justify-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-wider uppercase">
              TALLER AMAYA
            </h1>
            <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-rose-600 text-white tracking-widest">
              OFFICIAL SYSTEM
            </span>
          </div>
          <h2 className="text-sm font-bold text-rose-400">
            Bloqueo de Seguridad — Licencia de Software Requerida
          </h2>
          <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
            {reason ||
              'Este software cuenta con protección anti-clonación y requiere una licencia autorizada para operar en este equipo físico.'}
          </p>
        </div>

        {/* Tarjeta de Identificación de Hardware */}
        <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-slate-400">
            <span className="flex items-center gap-1.5 text-slate-300">
              <Cpu className="w-4 h-4 text-rose-500" />
              <span>Código de Máquina Físico (Hardware ID):</span>
            </span>
            <span className="text-[10px] text-emerald-400 uppercase tracking-widest font-mono">
              Único
            </span>
          </div>

          <div className="flex items-center justify-between bg-slate-900 p-3 rounded-xl border border-slate-700 font-mono text-sm sm:text-base font-black text-amber-400 tracking-wider">
            <span>{machineId}</span>
            <button
              type="button"
              onClick={handleCopyMachineId}
              className="ml-2 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-sans font-bold flex items-center gap-1.5 transition-colors border border-slate-600 active:scale-95 shrink-0"
              title="Copiar código al portapapeles"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">¡Copiado!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copiar</span>
                </>
              )}
            </button>
          </div>

          <p className="text-[11px] text-slate-500 leading-normal">
            💡 <strong>Instrucciones:</strong> Copia este código y envíaselo al administrador o soporte técnico para recibir tu <strong>Clave de Activación Oficial</strong>.
          </p>
        </div>

        {/* Formulario de Activación */}
        <form onSubmit={handleActivate} className="space-y-4">
          <div>
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1.5 flex items-center gap-1.5">
              <KeyRound className="w-3.5 h-3.5 text-rose-500" />
              <span>Ingresa tu Clave de Activación Oficial:</span>
            </label>
            <input
              type="text"
              required
              value={activationKey}
              onChange={(e) => setActivationKey(e.target.value)}
              placeholder="KEY-AMAYA-XXXX-XXXX-XXXX-XXXX"
              className="w-full bg-slate-950 border border-slate-700 text-white placeholder-slate-600 rounded-xl px-3 py-3 text-sm font-mono tracking-wider focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500 text-center uppercase"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Nombre de Sucursal o Propietario:
            </label>
            <input
              type="text"
              value={clientName}
              onChange={(e) => setClientName(e.target.value)}
              placeholder="Taller Amaya Principal"
              className="w-full bg-slate-950 border border-slate-700 text-white placeholder-slate-600 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-rose-500"
            />
          </div>

          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-sm tracking-wider uppercase transition-all shadow-lg shadow-rose-600/30 active:scale-95 flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isLoading ? (
              <span>Verificando Licencia Criptográfica...</span>
            ) : (
              <>
                <ShieldCheck className="w-5 h-5" />
                <span>Activar y Casar Software con este Equipo</span>
              </>
            )}
          </button>
        </form>

        <div className="pt-2 border-t border-slate-800/80 text-center text-[10px] text-slate-500">
          Protección Criptográfica HMAC-SHA256 • Funciona 100% Offline • No transferible
        </div>
      </div>
    </div>
  );
};
