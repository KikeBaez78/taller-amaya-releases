'use client';

import React, { useState } from 'react';
import { StorageService } from '@/lib/storage';
import { openRemisionPrintWindow, RemisionItem } from '@/lib/remisionGenerator';
import { WorkOrder, OrderStatus, Vehicle, Client, Company, Mechanic } from '@/types';
import { PublicClientModal } from './PublicClientModal';
import { Ticket80mmModal } from './Ticket80mmModal';
import { PresupuestoModal } from './PresupuestoModal';
import { OrdenDosHojasModal } from './OrdenDosHojasModal';
import { ReinaSecurityModal } from './ReinaSecurityModal';
import {
  ClipboardList,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  Car,
  DollarSign,
  Share2,
  FileEdit,
  KeyRound,
  FileCheck,
  AlertCircle,
  MessageCircle,
  Camera,
  PenTool,
  Printer,
  FileSpreadsheet,
  FileText,
  Check,
  Wrench,
  Package,
  Trash2,
  X,
} from 'lucide-react';

interface WorkOrdersListProps {
  onOpenCheckIn: () => void;
  onPayOrder: (order: WorkOrder) => void;
}

export const WorkOrdersList: React.FC<WorkOrdersListProps> = ({
  onOpenCheckIn,
  onPayOrder,
}) => {
  const [orders, setOrders] = useState<WorkOrder[]>(StorageService.getWorkOrders());
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const [vehicles, setVehicles] = useState<Vehicle[]>(StorageService.getVehicles());
  const [clients, setClients] = useState<Client[]>(StorageService.getClients());
  const [companies, setCompanies] = useState<Company[]>(StorageService.getCompanies());
  const config = StorageService.getConfig();
  const [mechanics, setMechanics] = useState<Mechanic[]>(StorageService.getMechanics());

  // Escuchar sincronización en tiempo real del servidor
  React.useEffect(() => {
    const handleSync = () => {
      setOrders(StorageService.getWorkOrders());
      setMechanics(StorageService.getMechanics());
      setVehicles(StorageService.getVehicles());
      setClients(StorageService.getClients());
      setCompanies(StorageService.getCompanies());
    };
    const handleFilterBahia = () => {
      setFilterStatus('solicitudes_bahia');
    };
    window.addEventListener('taller_data_synced', handleSync);
    window.addEventListener('filter_solicitudes_bahia', handleFilterBahia);
    StorageService.syncFromServer();
    return () => {
      window.removeEventListener('taller_data_synced', handleSync);
      window.removeEventListener('filter_solicitudes_bahia', handleFilterBahia);
    };
  }, []);

  // Estados para modal de asignación rápida de mecánico
  const [assignModalOrder, setAssignModalOrder] = useState<WorkOrder | null>(null);
  const [assignMecId, setAssignMecId] = useState<string>('');
  const [assignCommission, setAssignCommission] = useState<number>(30);
  const [assignConcepto, setAssignConcepto] = useState<string>('Servicio general de mano de obra');
  const [assignManoObraMonto, setAssignManoObraMonto] = useState<number>(1000);

  // Estados para modal de ticket térmico 80 mm con QR
  const [selectedTicketOrder, setSelectedTicketOrder] = useState<WorkOrder | null>(null);

  // Estados para modal de orden de servicio en 2 hojas (PDF / Carta)
  const [selectedDosHojasOrder, setSelectedDosHojasOrder] = useState<WorkOrder | null>(null);

  // Estados para modal de presupuesto y cotización detallada
  const [selectedPresupuestoOrder, setSelectedPresupuestoOrder] = useState<WorkOrder | null>(null);

  // Estados para protección con PIN de Reyna (2036) para Eliminar y Editar
  const [orderToDelete, setOrderToDelete] = useState<WorkOrder | null>(null);
  const [orderToEdit, setOrderToEdit] = useState<WorkOrder | null>(null);

  const handleConfirmDeleteOrder = () => {
    if (!orderToDelete) return;
    const updated = StorageService.deleteWorkOrder(orderToDelete.id);
    setOrders([...updated]);
    setOrderToDelete(null);
  };

  const handleConfirmEditBudget = () => {
    if (!orderToEdit) return;
    setSelectedPresupuestoOrder(orderToEdit);
    setOrderToEdit(null);
  };

  // Estados para modal de link público de cliente
  const [publicModalOrder, setPublicModalOrder] = useState<WorkOrder | null>(null);

  // Estados para modal de Entrega / Check-out con firma
  const [checkoutOrder, setCheckoutOrder] = useState<WorkOrder | null>(null);
  const [signatureText, setSignatureText] = useState('');
  const [checkoutNotes, setCheckoutNotes] = useState('');
  const [exitPhotosLoaded, setExitPhotosLoaded] = useState(false);

  // Estados para modal de Aviso de Detalle Extra por WhatsApp
  const [extraAlertOrder, setExtraAlertOrder] = useState<WorkOrder | null>(null);
  const [extraAlertDetalle, setExtraAlertDetalle] = useState('');
  const [extraAlertCosto, setExtraAlertCosto] = useState<number>(450);
  const [extraAlertSumarPresupuesto, setExtraAlertSumarPresupuesto] = useState(true);

  // Filtrado reactivo
  const pendingBahiaCount = orders.filter((o) =>
    o.solicitudesBahia?.some((s) => s.estado === 'pendiente_admin')
  ).length;

  const filteredOrders = orders.filter((o) => {
    const matchStatus =
      filterStatus === 'all'
        ? true
        : filterStatus === 'solicitudes_bahia'
        ? o.solicitudesBahia && o.solicitudesBahia.some((s) => s.estado === 'pendiente_admin')
        : o.estado === filterStatus;
    const v = vehicles.find((veh) => veh.id === o.vehiculoId);
    const c = clients.find((cli) => cli.id === o.clienteId);
    const comp = companies.find((co) => co.id === o.empresaId);

    const q = searchQuery.toLowerCase().trim();
    const matchSearch =
      !q ||
      o.folio.toLowerCase().includes(q) ||
      o.fallaReportada.toLowerCase().includes(q) ||
      v?.placas.toLowerCase().includes(q) ||
      v?.marca.toLowerCase().includes(q) ||
      v?.modelo.toLowerCase().includes(q) ||
      c?.nombre.toLowerCase().includes(q) ||
      comp?.razonSocial.toLowerCase().includes(q) ||
      o.choferNombre?.toLowerCase().includes(q);

    return matchStatus && matchSearch;
  });

  // Cambiar estatus de una orden
  const handleUpdateStatus = (orderId: string, newStatus: OrderStatus) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;

    order.estado = newStatus;
    if (newStatus === 'entregado' && !order.fechaSalida) {
      order.fechaSalida = new Date().toISOString().replace('T', ' ').substring(0, 16);
    }
    const updated = StorageService.saveWorkOrder(order);
    setOrders([...updated]);
  };

  // Guardar entrega / Check-out con firma digital
  const handleConfirmCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    if (!checkoutOrder) return;

    if (checkoutOrder.saldoPendiente > 0) {
      if (!confirm(`La orden aún tiene saldo pendiente de $${checkoutOrder.saldoPendiente.toLocaleString()} MXN. ¿Deseas autorizar la salida a crédito?`)) {
        return;
      }
    }

    checkoutOrder.estado = 'entregado';
    checkoutOrder.fechaSalida = new Date().toISOString().replace('T', ' ').substring(0, 16);
    checkoutOrder.firmaCliente = signatureText || 'Firma de recibido digitalizada';
    checkoutOrder.notasSalida = checkoutNotes;
    checkoutOrder.entregadoPor = 'Reyna Amaya (Administración)';
    if (exitPhotosLoaded) {
      checkoutOrder.fotosSalida = [
        'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=600&q=80',
        'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=600&q=80',
      ];
    }

    const updated = StorageService.saveWorkOrder(checkoutOrder);
    setOrders([...updated]);
    setCheckoutOrder(null);
    alert(`¡Vehículo entregado con éxito bajo Folio #${checkoutOrder.folio}! Firma registrada.`);
  };

  // Enviar aviso de detalle extra / hallazgo en bahía por WhatsApp
  const handleSendExtraAlert = (e: React.FormEvent) => {
    e.preventDefault();
    if (!extraAlertOrder || !extraAlertDetalle.trim()) return;

    const v = vehicles.find((veh) => veh.id === extraAlertOrder.vehiculoId);
    const c = clients.find((cli) => cli.id === extraAlertOrder.clienteId);
    const comp = companies.find((co) => co.id === extraAlertOrder.empresaId);
    const clientName = comp ? comp.encargadoFlotilla : c?.nombre || 'Cliente';
    const phone = extraAlertOrder.choferTelefono || c?.telefono || comp?.telefonos[0] || '6640000000';

    if (extraAlertSumarPresupuesto && extraAlertCosto > 0) {
      const orderToUpdate = { ...extraAlertOrder };
      if (!orderToUpdate.presupuesto) {
        orderToUpdate.presupuesto = {
          partes: [],
          manoObra: [],
          subtotalPartes: 0,
          subtotalManoObra: orderToUpdate.subtotalManoObra,
          aplicaIva: false,
          ivaMonto: 0,
          totalPresupuesto: orderToUpdate.subtotalGeneral,
          estado: 'pendiente',
        };
      }
      orderToUpdate.presupuesto.manoObra.push({
        id: `mo-extra-${Date.now()}`,
        concepto: `[EXTRA] ${extraAlertDetalle.trim()}`,
        costo: Number(extraAlertCosto),
        comisionPorcentaje: 30,
      });
      orderToUpdate.presupuesto.subtotalManoObra += Number(extraAlertCosto);
      orderToUpdate.presupuesto.totalPresupuesto += Number(extraAlertCosto);
      orderToUpdate.presupuesto.estado = 'pendiente'; // Requiere autorización

      orderToUpdate.subtotalManoObra += Number(extraAlertCosto);
      orderToUpdate.subtotalGeneral += Number(extraAlertCosto);
      orderToUpdate.saldoPendiente += Number(extraAlertCosto);

      StorageService.saveWorkOrder(orderToUpdate);
      setOrders(StorageService.getWorkOrders());
    }

    const url = StorageService.generateWhatsAppExtraAlert(
      extraAlertOrder,
      v,
      clientName,
      phone,
      extraAlertDetalle,
      extraAlertCosto
    );
    window.open(url, '_blank');
    setExtraAlertOrder(null);
    setExtraAlertDetalle('');
  };

  // Enviar aviso de listo para recoger por WhatsApp
  const handleSendReadyAlert = (order: WorkOrder) => {
    const v = vehicles.find((veh) => veh.id === order.vehiculoId);
    const c = clients.find((cli) => cli.id === order.clienteId);
    const comp = companies.find((co) => co.id === order.empresaId);
    const clientName = comp ? comp.encargadoFlotilla : c?.nombre || 'Cliente';
    const phone = order.choferTelefono || c?.telefono || comp?.telefonos[0] || '6640000000';

    // Si aún no está marcado como listo, actualizar a 'listo'
    if (order.estado !== 'listo' && order.estado !== 'entregado') {
      handleUpdateStatus(order.id, 'listo');
    }

    const url = StorageService.generateWhatsAppReadyAlert(order, v, clientName, phone);
    window.open(url, '_blank');
  };

  // Imprimir Remisión Formal (Formato Carta) desde una Orden existente
  const handlePrintRemision = (order: WorkOrder) => {
    const v = vehicles.find((veh) => veh.id === order.vehiculoId);
    const c = clients.find((cli) => cli.id === order.clienteId);
    const comp = companies.find((co) => co.id === order.empresaId);
    const clientName = comp ? comp.razonSocial : c?.nombre || 'Público General';

    const partesList: RemisionItem[] = (order.presupuesto?.partes || []).map((p) => ({
      cantidad: p.cantidad || 1,
      descripcion: p.descripcion,
      costo: p.subtotal || p.precioUnitario * p.cantidad,
    }));

    const moList: RemisionItem[] = (order.presupuesto?.manoObra || []).map((m) => ({
      cantidad: 1,
      descripcion: m.concepto,
      costo: m.costo,
    }));

    if (partesList.length === 0 && moList.length === 0 && order.servicios && order.servicios.length > 0) {
      order.servicios.forEach((s) => {
        moList.push({
          cantidad: 1,
          descripcion: s.concepto,
          costo: s.manoObra,
        });
        if (s.refaccionesMonto > 0) {
          partesList.push({
            cantidad: 1,
            descripcion: `Refacciones para ${s.concepto}`,
            costo: s.refaccionesMonto,
          });
        }
      });
    }

    const subtotalPartes = partesList.reduce((acc, it) => acc + (it.costo || 0), 0);
    const subtotalMO = moList.reduce((acc, it) => acc + (it.costo || 0), 0);
    const subtotalSinIva = subtotalPartes + subtotalMO;
    const aplicaIva = Boolean(order.presupuesto?.aplicaIva);
    const ivaMonto = aplicaIva ? Math.round(subtotalSinIva * 0.08) : 0;
    const total = subtotalSinIva + ivaMonto;

    openRemisionPrintWindow({
      folio: `REM-${order.folio}`,
      fecha: order.fechaIngreso ? order.fechaIngreso.split(' ')[0] : undefined,
      cliente: clientName,
      telefono: order.choferTelefono || c?.telefono || comp?.telefonos?.[0],
      vehiculo: {
        marca: v?.marca,
        modelo: v?.modelo,
        motor: v?.motor,
        color: v?.color,
        placas: v?.placas,
        ano: v?.ano,
      },
      partes: partesList,
      manoDeObraItems: moList,
      subtotalPartes,
      subtotalManoObra: subtotalMO,
      aplicaIva,
      ivaMonto,
      total,
      trackingUrl: `https://talleramaya.com/seguimiento/${order.folio}`,
    });
  };

  // Admin contacta al cliente vía WhatsApp respecto a lo que el mecánico solicitó en Bahía
  const handleWhatsAppClientSolicitud = (order: WorkOrder, sol: any) => {
    const v = vehicles.find((veh) => veh.id === order.vehiculoId);
    const c = clients.find((cli) => cli.id === order.clienteId);
    const comp = companies.find((co) => co.id === order.empresaId);
    const clientName = comp ? comp.encargadoFlotilla : c?.nombre || 'Cliente';
    const phone = (order.choferTelefono || c?.telefono || comp?.telefonos[0] || '6640000000').replace(/\D/g, '');
    const vehiculoDesc = v ? `${v.marca} ${v.modelo} (Placas: ${v.placas})` : 'tu vehículo';

    const texto = `Hola ${clientName}, te contactamos de *Recepción de TALLER AMAYA* 🚗🔧\n\nRespecto a tu vehículo *${vehiculoDesc}* (Folio *#${order.folio}*):\nEl mecánico *${sol.mecanicoNombre}* al desarmar e inspeccionar en bahía nos solicita lo siguiente para poder continuar el trabajo:\n\n📦 *Detalle / Refacción solicitada:* ${sol.descripcion}\n${sol.costoManoObraExtra && sol.costoManoObraExtra > 0 ? `💰 *Mano de Obra extra estimada:* $${sol.costoManoObraExtra.toLocaleString()} MXN\n` : ''}\n¿Nos autorizas proceder con esta refacción / trabajo extra para que el mecánico continúe?\n\nPuedes autorizarnos por este mismo medio. ¡Muchas gracias!`;

    const url = `https://wa.me/52${phone}?text=${encodeURIComponent(texto)}`;
    window.open(url, '_blank');
  };

  // Admin autoriza la solicitud de bahía y notifica en vivo a la pantalla del mecánico
  const handleAuthorizeSolicitud = async (orderId: string, solId: string) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order || !order.solicitudesBahia) return;

    const sol = order.solicitudesBahia.find((s) => s.id === solId);
    if (!sol) return;

    sol.estado = 'autorizado_cliente';

    // Si tiene costo de mano de obra extra y no ha sido sumado, integrarlo a servicios y presupuesto
    const costoExtra = sol.costoManoObraExtra || 0;
    if (costoExtra > 0) {
      const mec = mechanics.find((m) => m.id === sol.mecanicoId);
      const commPct = mec ? mec.comisionDefault : 30;
      const comisionMO = Math.round(costoExtra * (commPct / 100));

      const extraService = {
        id: `srv-extra-${Date.now()}`,
        concepto: `[Autorizado Bahía] ${sol.descripcion}`,
        mecanicoId: sol.mecanicoId,
        mecanicoNombre: sol.mecanicoNombre,
        manoObra: costoExtra,
        refaccionesMonto: 0,
        comisionPorcentaje: commPct,
        comisionManoObra: comisionMO,
        estado: 'en_progreso' as const,
      };

      order.servicios.push(extraService);
      order.subtotalManoObra += costoExtra;
      order.subtotalGeneral += costoExtra;
      order.totalComisionesMecanicos += comisionMO;
      order.saldoPendiente += costoExtra;

      if (order.presupuesto) {
        order.presupuesto.manoObra.push({
          id: `mo-extra-${Date.now()}`,
          concepto: `[Extra Bahía] ${sol.descripcion}`,
          costo: costoExtra,
          comisionPorcentaje: commPct,
          mecanicoId: sol.mecanicoId,
          mecanicoNombre: sol.mecanicoNombre,
        });
        order.presupuesto.subtotalManoObra += costoExtra;
        order.presupuesto.totalPresupuesto += costoExtra;
      }
    }

    const updated = StorageService.saveWorkOrder(order);
    setOrders([...updated]);

    // Enviar al servidor para que la pantalla de bahía se actualice en tiempo real
    await fetch('/api/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'save_order', order }),
    });

    alert(`✅ ¡Solicitud autorizada! La pantalla de Bahía fue actualizada en tiempo real con luz verde para ${sol.mecanicoNombre}.`);
  };

  // Admin marca la solicitud como rechazada por el cliente
  const handleRejectSolicitud = async (orderId: string, solId: string) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order || !order.solicitudesBahia) return;

    const sol = order.solicitudesBahia.find((s) => s.id === solId);
    if (!sol) return;

    sol.estado = 'rechazado_cliente';

    const updated = StorageService.saveWorkOrder(order);
    setOrders([...updated]);

    await fetch('/api/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'save_order', order }),
    });
  };

  const handleOrderUpdatedFromPresupuesto = (updatedOrder: WorkOrder) => {
    const updated = orders.map((o) => (o.id === updatedOrder.id ? updatedOrder : o));
    setOrders(updated);
  };

  // Asignar o cambiar mecánico directamente desde la tarjeta
  const handleQuickAssignMechanic = (orderId: string, serviceId: string, mechanicId: string) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;

    const mec = mechanics.find((m) => m.id === mechanicId);
    const mecName = mec ? mec.nombre : 'Por Asignar Bahía';
    const commPct = mec ? mec.comisionDefault : 30;

    order.servicios = order.servicios.map((srv) => {
      if (srv.id === serviceId) {
        const comisionManoObra = Math.round(srv.manoObra * (commPct / 100));
        return {
          ...srv,
          mecanicoId: mec ? mec.id : 'unassigned',
          mecanicoNombre: mecName,
          comisionPorcentaje: commPct,
          comisionManoObra,
        };
      }
      return srv;
    });

    if (order.presupuesto && order.presupuesto.manoObra) {
      order.presupuesto.manoObra = order.presupuesto.manoObra.map((mo) => {
        if (mo.id === serviceId || order.servicios.length === 1) {
          return {
            ...mo,
            mecanicoId: mec ? mec.id : 'unassigned',
            mecanicoNombre: mecName,
            comisionPorcentaje: commPct,
          };
        }
        return mo;
      });
    }

    order.totalComisionesMecanicos = order.servicios.reduce((acc, s) => acc + (s.comisionManoObra || 0), 0);
    const updated = StorageService.saveWorkOrder(order);
    setOrders([...updated]);
  };

  // Cambiar porcentaje de comisión de un servicio
  const handleQuickChangeCommission = (orderId: string, serviceId: string, newComm: number) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;

    order.servicios = order.servicios.map((srv) => {
      if (srv.id === serviceId) {
        const comisionManoObra = Math.round(srv.manoObra * (newComm / 100));
        return {
          ...srv,
          comisionPorcentaje: newComm,
          comisionManoObra,
        };
      }
      return srv;
    });

    if (order.presupuesto && order.presupuesto.manoObra) {
      order.presupuesto.manoObra = order.presupuesto.manoObra.map((mo) => {
        if (mo.id === serviceId || order.servicios.length === 1) {
          return {
            ...mo,
            comisionPorcentaje: newComm,
          };
        }
        return mo;
      });
    }

    order.totalComisionesMecanicos = order.servicios.reduce((acc, s) => acc + (s.comisionManoObra || 0), 0);
    const updated = StorageService.saveWorkOrder(order);
    setOrders([...updated]);
  };

  // Abrir modal de asignación de mecánico para una orden
  const handleOpenAssignModal = (order: WorkOrder) => {
    setAssignModalOrder(order);
    const firstSrv = order.servicios[0];
    const defaultMec = mechanics.find((m) => m.id === firstSrv?.mecanicoId) || mechanics[0];
    setAssignMecId(defaultMec ? defaultMec.id : '');
    setAssignCommission(firstSrv?.comisionPorcentaje || defaultMec?.comisionDefault || 30);
    setAssignConcepto(firstSrv?.concepto || order.fallaReportada || 'Mano de obra en bahía');
    setAssignManoObraMonto(firstSrv?.manoObra || order.subtotalManoObra || 1000);
  };

  // Guardar asignación desde modal
  const handleSaveModalAssignment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!assignModalOrder) return;

    const mec = mechanics.find((m) => m.id === assignMecId);
    const mecName = mec ? mec.nombre : 'Por Asignar Bahía';
    const commPct = Number(assignCommission) || 30;
    const moMonto = Number(assignManoObraMonto) || 0;
    const comisionMO = Math.round(moMonto * (commPct / 100));

    if (assignModalOrder.servicios.length > 0) {
      assignModalOrder.servicios[0] = {
        ...assignModalOrder.servicios[0],
        concepto: assignConcepto.trim() || assignModalOrder.servicios[0].concepto,
        mecanicoId: mec ? mec.id : 'unassigned',
        mecanicoNombre: mecName,
        manoObra: moMonto,
        comisionPorcentaje: commPct,
        comisionManoObra: comisionMO,
      };
    } else {
      assignModalOrder.servicios = [
        {
          id: `srv-${Date.now()}`,
          concepto: assignConcepto.trim() || 'Servicio de bahía',
          mecanicoId: mec ? mec.id : 'unassigned',
          mecanicoNombre: mecName,
          manoObra: moMonto,
          refaccionesMonto: 0,
          comisionPorcentaje: commPct,
          comisionManoObra: comisionMO,
          estado: 'pendiente',
        },
      ];
    }

    if (assignModalOrder.presupuesto) {
      if (assignModalOrder.presupuesto.manoObra.length > 0) {
        assignModalOrder.presupuesto.manoObra[0].mecanicoId = mec ? mec.id : 'unassigned';
        assignModalOrder.presupuesto.manoObra[0].mecanicoNombre = mecName;
        assignModalOrder.presupuesto.manoObra[0].comisionPorcentaje = commPct;
        assignModalOrder.presupuesto.manoObra[0].costo = moMonto;
      }
      assignModalOrder.presupuesto.subtotalManoObra = moMonto;
      assignModalOrder.presupuesto.totalPresupuesto = moMonto + assignModalOrder.presupuesto.subtotalPartes;
    }

    assignModalOrder.subtotalManoObra = moMonto;
    assignModalOrder.subtotalGeneral = moMonto + assignModalOrder.subtotalRefacciones;
    assignModalOrder.totalComisionesMecanicos = comisionMO;
    assignModalOrder.saldoPendiente = Math.max(0, assignModalOrder.subtotalGeneral - assignModalOrder.totalPagado);

    const updated = StorageService.saveWorkOrder(assignModalOrder);
    setOrders([...updated]);
    setAssignModalOrder(null);
    alert(`¡Mecánico "${mecName}" asignado con éxito a la Orden #${assignModalOrder.folio}!`);
  };

  return (
    <div className="space-y-4">
      {/* Barra de Filtros y Búsqueda Limpia (Sin botones ni títulos repetidos) */}
      <div className="bg-white border border-slate-200 rounded-2xl p-3 sm:p-4 shadow-sm flex flex-wrap items-center justify-between gap-3">
        {/* Input de filtro directo */}
        <div className="relative flex-1 min-w-[260px]">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar por folio (#0900), placas, cliente o chofer..."
            className="w-full bg-slate-50 border border-slate-200 focus:border-rose-500 rounded-xl px-4 py-2 pl-10 text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-none transition-colors"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        {/* Filtros por Estatus */}
        <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs">
          {[
            { id: 'all', label: 'Todas las Órdenes' },
            ...(pendingBahiaCount > 0
              ? [{ id: 'solicitudes_bahia', label: `🔔 Solicitudes Bahía (${pendingBahiaCount})` }]
              : []),
            { id: 'recepcion', label: 'Recepción' },
            { id: 'en_proceso', label: 'En Bahía' },
            { id: 'listo', label: 'Listas para Salida' },
            { id: 'entregado', label: 'Entregadas' },
          ].map((st) => (
            <button
              key={st.id}
              onClick={() => setFilterStatus(st.id)}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                filterStatus === st.id
                  ? st.id === 'solicitudes_bahia'
                    ? 'bg-amber-500 text-slate-950 shadow-sm border border-amber-600'
                    : 'bg-white text-rose-600 shadow-sm border border-slate-200'
                  : st.id === 'solicitudes_bahia'
                  ? 'text-amber-800 bg-amber-200/80 hover:bg-amber-200 font-black animate-pulse'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {st.label}
            </button>
          ))}
        </div>
      </div>

      {/* Banner de Modo Enfoque / Regresar si se filtró por Solicitud de Bahía */}
      {filterStatus === 'solicitudes_bahia' && (
        <div className="bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 text-slate-950 p-4 sm:p-5 rounded-3xl flex flex-wrap items-center justify-between gap-3 shadow-lg border-2 border-amber-600 animate-in fade-in">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-slate-950 text-amber-400 flex items-center justify-center font-black text-xl shrink-0 shadow-sm">
              🔔
            </div>
            <div>
              <h3 className="font-black text-base text-slate-950 uppercase tracking-tight">
                Viendo Exclusivamente Solicitud de Bahía
              </h3>
              <p className="text-xs text-slate-900 font-bold mt-0.5">
                Aquí tienes lo que el mecánico necesita para continuar. Puedes autorizarlo directamente o cotizar por WhatsApp.
              </p>
            </div>
          </div>

          <button
            onClick={() => setFilterStatus('all')}
            className="px-5 py-2.5 rounded-2xl bg-slate-950 hover:bg-slate-800 text-white font-black text-xs transition-colors shadow-md cursor-pointer flex items-center gap-2 active:scale-95"
          >
            <span>← Regresar a todas las órdenes</span>
          </button>
        </div>
      )}

      {/* Lista de Órdenes */}
      <div className="space-y-4">
        {filteredOrders.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-3xl p-10 text-center text-slate-400 shadow-sm">
            <ClipboardList className="w-12 h-12 mx-auto text-slate-300 mb-2" />
            <p className="font-bold text-slate-700">No hay órdenes que coincidan con el filtro</p>
          </div>
        ) : (
          filteredOrders.map((order) => {
            const v = vehicles.find((veh) => veh.id === order.vehiculoId);
            const c = clients.find((cli) => cli.id === order.clienteId);
            const comp = companies.find((co) => co.id === order.empresaId);

            const pEstado = order.presupuesto?.estado || 'pendiente';

            return (
              <div
                key={order.id}
                className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-sm hover:shadow-md transition-all space-y-4"
              >
                {/* Cabecera de la Orden */}
                <div className="flex flex-wrap items-start justify-between gap-3 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xl font-black bg-rose-50 text-rose-700 border border-rose-200 px-3 py-1 rounded-2xl shadow-sm">
                      #{order.folio}
                    </span>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-sm bg-slate-100 text-slate-800 px-2 py-0.5 rounded-lg border border-slate-200">
                          {v?.placas || 'SIN PLACAS'}
                        </span>
                        <h3 className="font-bold text-slate-900 text-base">
                          {v?.marca} {v?.modelo} ({v?.ano})
                        </h3>
                      </div>
                      <span className="text-xs text-slate-500 mt-0.5 block">
                        Ingreso: {order.fechaIngreso} | Nivel Gasolina: {order.nivelCombustible} | Odómetro: {order.kilometrajeEntrada.toLocaleString()} km
                      </span>
                    </div>
                  </div>

                  {/* Selector rápido de estatus del vehículo */}
                  <div className="flex items-center gap-2">
                    <select
                      value={order.estado}
                      onChange={(e) => handleUpdateStatus(order.id, e.target.value as OrderStatus)}
                      className={`text-xs font-bold uppercase px-3 py-1.5 rounded-xl border focus:outline-none cursor-pointer shadow-sm ${
                        order.estado === 'entregado'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                          : order.estado === 'listo'
                          ? 'bg-purple-50 text-purple-700 border-purple-300'
                          : order.estado === 'en_proceso'
                          ? 'bg-amber-50 text-amber-700 border-amber-300'
                          : 'bg-sky-50 text-sky-700 border-sky-300'
                      }`}
                    >
                      <option value="recepcion">1. Recepción</option>
                      <option value="diagnostico">2. Diagnóstico</option>
                      <option value="en_proceso">3. En Bahía</option>
                      <option value="listo">4. Listo para Entrega</option>
                      <option value="entregado">5. Entregado</option>
                    </select>
                  </div>
                </div>

                {/* SOLICITUDES DESDE BAHÍA (PIEZAS / INSUMOS REPORTADOS POR EL MECÁNICO - PRIORIDAD MÁXIMA) */}
                {order.solicitudesBahia && order.solicitudesBahia.length > 0 && (
                  <div className="space-y-3 p-4 sm:p-5 rounded-2xl bg-amber-50/90 border-2 border-amber-400 shadow-sm animate-in fade-in">
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-amber-200 pb-2.5">
                      <div className="flex items-center gap-2">
                        <span className="p-1.5 rounded-xl bg-amber-500 text-slate-950 font-black text-sm">
                          🔔
                        </span>
                        <div>
                          <span className="text-xs font-black text-amber-950 uppercase tracking-wide block">
                            Solicitud de Bahía de la Orden #{order.folio}
                          </span>
                          <span className="text-[11px] text-amber-800 font-semibold">
                            El mecánico necesita autorización para continuar este trabajo
                          </span>
                        </div>
                      </div>
                      <span className="text-[10px] text-amber-950 font-black bg-amber-200 border border-amber-300 px-3 py-1 rounded-full uppercase tracking-wider">
                        Recepción Contacta y Autoriza
                      </span>
                    </div>

                    <div className="space-y-3">
                      {order.solicitudesBahia.map((sol) => (
                        <div
                          key={sol.id}
                          className={`p-4 rounded-xl border-2 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs transition-all ${
                            sol.estado === 'pendiente_admin'
                              ? 'bg-white border-amber-400 shadow-md ring-2 ring-amber-300/60'
                              : sol.estado === 'autorizado_cliente'
                              ? 'bg-emerald-50 border-emerald-400'
                              : 'bg-rose-50 border-rose-200 opacity-75'
                          }`}
                        >
                          <div className="space-y-1.5 flex-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="font-black text-slate-900 text-sm flex items-center gap-1">
                                👨‍🔧 {sol.mecanicoNombre}
                              </span>
                              <span className="text-[10px] text-slate-500 font-mono bg-slate-100 px-2 py-0.5 rounded">
                                {sol.fecha}
                              </span>
                              <span
                                className={`text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full border ${
                                  sol.estado === 'pendiente_admin'
                                    ? 'bg-amber-100 text-amber-900 border-amber-400 animate-pulse'
                                    : sol.estado === 'autorizado_cliente'
                                    ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                                    : 'bg-rose-100 text-rose-800 border-rose-300'
                                }`}
                              >
                                {sol.estado === 'pendiente_admin' && '⏳ En espera de autorización del cliente'}
                                {sol.estado === 'autorizado_cliente' && '✅ Autorizado por Cliente (Procediendo en Bahía)'}
                                {sol.estado === 'rechazado_cliente' && '❌ Rechazado por Cliente'}
                              </span>
                            </div>

                            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                              <span className="text-[10px] text-slate-400 font-bold uppercase block">
                                Requerimiento / Falla detectada al desarmar:
                              </span>
                              <p className="font-black text-slate-900 text-base leading-snug mt-0.5">
                                "{sol.descripcion}"
                              </p>
                            </div>

                            <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-600 pt-0.5">
                              <span>
                                Tipo:{' '}
                                <strong className="text-slate-800">
                                  {sol.tipo === 'refaccion'
                                    ? '📦 Refacción / Insumo'
                                    : sol.tipo === 'mano_obra_extra'
                                    ? '🔧 Mano de Obra Extra'
                                    : '📦 Refacción + Mano de Obra'}
                                </strong>
                              </span>
                              {sol.costoManoObraExtra && sol.costoManoObraExtra > 0 ? (
                                <span className="font-mono text-amber-900 font-bold bg-amber-100 px-2 py-0.5 rounded border border-amber-300">
                                  Labor extra estimada: ${sol.costoManoObraExtra.toLocaleString()} MXN
                                </span>
                              ) : null}
                            </div>
                          </div>

                          {/* Acciones exclusivas de Administración */}
                          <div className="flex flex-wrap items-center gap-2 shrink-0">
                            {sol.estado === 'pendiente_admin' && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => handleWhatsAppClientSolicitud(order, sol)}
                                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm transition-all active:scale-95 cursor-pointer"
                                  title="Enviar mensaje por WhatsApp al cliente para cotizar y pedir autorización"
                                >
                                  <MessageCircle className="w-4 h-4" />
                                  <span>📲 Cotizar a Cliente (WhatsApp)</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleAuthorizeSolicitud(order.id, sol.id)}
                                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-md transition-all active:scale-95 cursor-pointer"
                                  title="Marcar autorizado por el cliente y notificar en vivo a la pantalla del mecánico"
                                >
                                  <Check className="w-4 h-4 stroke-[3]" />
                                  <span>✓ Marcar Autorizado</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleRejectSolicitud(order.id, sol.id)}
                                  className="flex items-center gap-1 px-3 py-2 rounded-xl bg-slate-100 hover:bg-rose-100 text-rose-700 font-bold text-xs border border-slate-200 transition-all cursor-pointer"
                                  title="Marcar como no autorizado por el cliente"
                                >
                                  <X className="w-3.5 h-3.5" />
                                  <span>No Autorizar</span>
                                </button>
                              </>
                            )}

                            {sol.estado === 'autorizado_cliente' && (
                              <span className="text-xs text-emerald-800 font-black bg-emerald-100 border border-emerald-300 px-3.5 py-1.5 rounded-xl flex items-center gap-1.5 shadow-xs">
                                <Check className="w-4 h-4 stroke-[3]" />
                                Notificado a Bahía: Proceder
                              </span>
                            )}

                            {sol.estado === 'rechazado_cliente' && (
                              <span className="text-xs text-rose-700 font-bold bg-rose-100 border border-rose-300 px-3 py-1.5 rounded-xl">
                                ❌ Rechazado
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Cliente / Chofer / Falla */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs bg-slate-50/70 p-3.5 rounded-2xl border border-slate-200">
                  <div>
                    <span className="text-slate-400 block font-medium">Propietario / Flotilla:</span>
                    <strong className="text-slate-900 text-sm">
                      {comp ? comp.razonSocial : c?.nombre || 'Cliente Particular'}
                    </strong>
                    {comp && (
                      <span className="text-[11px] text-emerald-600 font-semibold block mt-0.5">
                        Encargado: {comp.encargadoFlotilla}
                      </span>
                    )}
                  </div>

                  <div>
                    <span className="text-slate-400 block font-medium">Chofer que Entregó:</span>
                    <strong className="text-slate-800 text-sm">
                      {order.choferNombre || 'Mismo cliente'}
                    </strong>
                    {order.choferTelefono && (
                      <span className="text-[11px] text-slate-500 block font-mono">
                        Tel: {order.choferTelefono}
                      </span>
                    )}
                  </div>

                  <div>
                    <span className="text-slate-400 block font-medium">Falla Reportada:</span>
                    <p className="text-slate-700 font-medium line-clamp-2">
                      {order.fallaReportada}
                    </p>
                  </div>
                </div>

                {/* Banner de Presupuesto y Autorización */}
                <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 bg-gradient-to-r from-slate-50 via-white to-rose-50/40 rounded-2xl border border-slate-200">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                      <FileSpreadsheet className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-800">Presupuesto del Servicio:</span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase border ${
                            pEstado === 'autorizado'
                              ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                              : pEstado === 'rechazado'
                              ? 'bg-rose-100 text-rose-800 border-rose-300'
                              : 'bg-amber-100 text-amber-800 border-amber-300'
                          }`}
                        >
                          {pEstado === 'autorizado'
                            ? '✓ Autorizado por Cliente'
                            : pEstado === 'rechazado'
                            ? '✕ Rechazado'
                            : '⏳ Pendiente de Autorización'}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                        Mano de Obra: ${order.subtotalManoObra.toLocaleString()} MXN | Partes: ${order.subtotalRefacciones.toLocaleString()} MXN
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => setOrderToEdit(order)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-slate-50 text-slate-800 border border-slate-200 shadow-sm font-bold text-xs hover:border-rose-300 transition-colors"
                  >
                    <FileEdit className="w-3.5 h-3.5 text-rose-600" />
                    <span>Modificar Presupuesto / Partes</span>
                  </button>
                </div>

                {/* Refacciones del Cliente si hay */}
                {order.refaccionesCliente && order.refaccionesCliente.length > 0 && (
                  <div className="text-xs p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-900">
                    <strong className="block text-[11px] uppercase text-amber-800 font-bold">
                      ✓ Refacciones traídas por el cliente (Cajuela/Asiento):
                    </strong>
                    <span>{order.refaccionesCliente.join(' • ')}</span>
                  </div>
                )}

                {/* Servicios y Operaciones Asignadas con Selector de Mecánico */}
                <div className="space-y-2 bg-slate-50/80 p-3.5 rounded-2xl border border-slate-200">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-2">
                    <div className="flex items-center gap-2">
                      <Wrench className="w-4 h-4 text-rose-600" />
                      <span className="text-xs font-black text-slate-800 uppercase tracking-wider">
                        Mano de Obra & Mecánico Asignado ({order.servicios.length}):
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleOpenAssignModal(order)}
                      className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-bold text-[11px] shadow-xs transition-colors"
                      title="Abrir panel para asignar mecánico y comisión a esta orden"
                    >
                      <span>👨‍🔧 Asignar / Cambiar Mecánico</span>
                    </button>
                  </div>

                  {order.servicios.length === 0 ? (
                    <div className="flex items-center justify-between p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900">
                      <span>⚠️ Esta orden aún no tiene mecánico asignado en bahía.</span>
                      <button
                        onClick={() => handleOpenAssignModal(order)}
                        className="font-bold underline hover:text-amber-950"
                      >
                        Asignar ahora
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {order.servicios.map((srv) => (
                        <div
                          key={srv.id}
                          className="bg-white p-3 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                        >
                          <div className="space-y-1">
                            <span className="font-bold text-slate-900 block text-sm">
                              {srv.concepto}
                            </span>
                            <div className="flex flex-wrap items-center gap-2 text-slate-600">
                              <span className="text-[11px] font-semibold text-slate-500">Mecánico:</span>
                              <select
                                value={srv.mecanicoId || 'unassigned'}
                                onChange={(e) =>
                                  handleQuickAssignMechanic(order.id, srv.id, e.target.value)
                                }
                                className="font-bold bg-amber-50/60 border border-amber-300 rounded-lg px-2 py-1 text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500 cursor-pointer text-xs"
                              >
                                <option value="unassigned">⚠️ Por Asignar Bahía</option>
                                {mechanics.map((m) => (
                                  <option key={m.id} value={m.id}>
                                    👨‍🔧 {m.nombre} ({m.especialidad})
                                  </option>
                                ))}
                              </select>

                              {/* Porcentaje de comisión directo */}
                              <div className="flex items-center gap-1 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded-lg text-[11px] font-mono">
                                <span className="text-slate-500">Comisión:</span>
                                <input
                                  type="number"
                                  min={10}
                                  max={50}
                                  value={srv.comisionPorcentaje}
                                  onChange={(e) =>
                                    handleQuickChangeCommission(
                                      order.id,
                                      srv.id,
                                      Number(e.target.value)
                                    )
                                  }
                                  className="w-12 bg-white border border-slate-300 rounded px-1 py-0.5 text-center font-bold text-xs"
                                />
                                <span className="font-bold text-amber-700">
                                  % = ${srv.comisionManoObra.toLocaleString()} MXN
                                </span>
                              </div>
                            </div>
                          </div>

                          <div className="text-right shrink-0">
                            <span className="text-[10px] text-slate-400 block font-semibold uppercase">
                              Mano de Obra
                            </span>
                            <span className="font-mono font-black text-slate-900 text-sm">
                              ${srv.manoObra.toLocaleString()} MXN
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Avisos Rápidos por WhatsApp en Bahía */}
                <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-gradient-to-r from-slate-50 via-white to-emerald-50/40 rounded-2xl border border-slate-200 text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-slate-700">
                    <MessageCircle className="w-4 h-4 text-emerald-600" />
                    <span>Avisos Rápidos por WhatsApp:</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Botón 1: Avisar Detalle Extra al Desarmar */}
                    <button
                      type="button"
                      onClick={() => {
                        setExtraAlertOrder(order);
                        setExtraAlertDetalle('');
                        setExtraAlertCosto(450);
                      }}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 rounded-xl font-bold transition-all shadow-xs"
                      title="Enviar aviso por WhatsApp de una falla o pieza extra encontrada al desarmar"
                    >
                      <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                      <span>⚠️ Avisar Detalle Extra</span>
                    </button>

                    {/* Botón 2: Avisar que Pase a Recoger */}
                    <button
                      type="button"
                      onClick={() => handleSendReadyAlert(order)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition-all shadow-xs active:scale-95"
                      title="Avisar por WhatsApp que el auto ya está terminado y listo para entrega"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>🚗 Avisar Listo para Recoger</span>
                    </button>
                  </div>
                </div>

                {/* Pie con Totales y Botones de Acción */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 text-xs">
                  <div className="flex items-center gap-4 font-mono">
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-bold">Total Orden:</span>
                      <strong className="text-slate-900 text-base">${order.subtotalGeneral.toLocaleString()}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-bold">Pagado:</span>
                      <strong className="text-emerald-600 text-base">${order.totalPagado.toLocaleString()}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-bold">Saldo Pendiente:</span>
                      <strong
                        className={`text-base font-black ${
                          order.saldoPendiente > 0 ? 'text-rose-600' : 'text-emerald-600'
                        }`}
                      >
                        ${order.saldoPendiente.toLocaleString()}
                      </strong>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Botón Asignar Mecánico */}
                    <button
                      onClick={() => handleOpenAssignModal(order)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-bold transition-colors shadow-xs"
                      title="Asignar o cambiar mecánico a esta orden"
                    >
                      <Wrench className="w-3.5 h-3.5 text-amber-700" />
                      <span>Mecánico</span>
                    </button>

                    {/* Botón Presupuesto / Cotización */}
                    <button
                      onClick={() => setOrderToEdit(order)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 font-bold transition-colors shadow-sm"
                      title="Editar Presupuesto de Mano de Obra y Partes (Requiere PIN de Reyna)"
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5 text-rose-600" />
                      <span>Presupuesto</span>
                    </button>

                    {/* Botón Remisión Carta (PDF / Impresión) */}
                    <button
                      onClick={() => handlePrintRemision(order)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold transition-colors shadow-sm cursor-pointer"
                      title="Imprimir Remisión Formal Tamaño Carta de Taller Amaya"
                    >
                      <Printer className="w-3.5 h-3.5 text-rose-400" />
                      <span>Remisión (Carta)</span>
                    </button>

                    {/* Botón Ticket 80 mm con Código QR */}
                    <button
                      onClick={() => setSelectedTicketOrder(order)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 font-bold transition-colors shadow-sm"
                      title="Imprimir Ticket Térmico de 80 mm con Código QR de Seguimiento"
                    >
                      <Printer className="w-3.5 h-3.5 text-slate-700" />
                      <span>Ticket 80 mm</span>
                    </button>

                    {/* Botón Orden de Servicio en 2 Hojas (PDF / Impresión) */}
                    <button
                      onClick={() => setSelectedDosHojasOrder(order)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 font-bold transition-colors shadow-sm"
                      title="Generar Orden de Servicio en 2 Hojas con Fotos, Presupuesto y Disclaimers (Imprimir / PDF)"
                    >
                      <FileText className="w-3.5 h-3.5 text-rose-600" />
                      <span>Orden 2 Hojas (PDF)</span>
                    </button>

                    {/* Botón WhatsApp de Cliente */}
                    <button
                      onClick={() => setPublicModalOrder(order)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 font-bold transition-colors shadow-sm"
                      title="Generar link público para WhatsApp"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>Link WhatsApp</span>
                    </button>

                    {/* Botón Cobrar en Caja */}
                    {order.saldoPendiente > 0 && (
                      <button
                        onClick={() => onPayOrder(order)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-colors shadow-md shadow-emerald-600/20"
                      >
                        <DollarSign className="w-3.5 h-3.5" />
                        <span>Cobrar Saldo</span>
                      </button>
                    )}

                    {/* Botón Check-out / Entrega */}
                    {order.estado !== 'entregado' && (
                      <button
                        onClick={() => {
                          setCheckoutOrder(order);
                          setSignatureText(c?.nombre || order.choferNombre || '');
                        }}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold transition-colors shadow-md shadow-rose-600/20"
                      >
                        <KeyRound className="w-3.5 h-3.5" />
                        <span>Check-out / Entrega</span>
                      </button>
                    )}

                    {/* Botón Eliminar Orden (Exclusivo Reyna Amaya con PIN 2036) */}
                    <button
                      onClick={() => setOrderToDelete(order)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-50 hover:bg-rose-50 text-slate-500 hover:text-rose-700 border border-slate-200 hover:border-rose-300 font-bold transition-colors shadow-xs"
                      title="Eliminar orden de trabajo (Exclusivo Reyna Amaya con PIN)"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                      <span>Eliminar</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* MODAL DE VISTA PÚBLICA DEL CLIENTE */}
      {publicModalOrder && (
        <PublicClientModal
          isOpen={true}
          onClose={() => setPublicModalOrder(null)}
          order={publicModalOrder}
          vehicle={vehicles.find((veh) => veh.id === publicModalOrder.vehiculoId)}
          client={clients.find((cli) => cli.id === publicModalOrder.clienteId)}
          company={companies.find((co) => co.id === publicModalOrder.empresaId)}
          config={config}
        />
      )}

      {/* MODAL DE PRESUPUESTO & AUTORIZACIÓN */}
      {selectedPresupuestoOrder && (
        <PresupuestoModal
          isOpen={!!selectedPresupuestoOrder}
          onClose={() => setSelectedPresupuestoOrder(null)}
          order={selectedPresupuestoOrder}
          vehicle={vehicles.find((veh) => veh.id === selectedPresupuestoOrder.vehiculoId)}
          client={clients.find((cli) => cli.id === selectedPresupuestoOrder.clienteId)}
          company={companies.find((co) => co.id === selectedPresupuestoOrder.empresaId)}
          onOrderUpdated={handleOrderUpdatedFromPresupuesto}
        />
      )}

      {/* MODAL DE ENTREGA Y CHECK-OUT CON FIRMA DIGITAL */}
      {checkoutOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white border border-slate-200 rounded-3xl max-w-lg w-full p-6 shadow-2xl text-slate-800">
            <h3 className="text-xl font-black text-slate-900 mb-1">
              Check-out & Entrega del Vehículo
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Folio #{checkoutOrder.folio} | Validación de saldo, fotos de salida y firma de conformidad
            </p>

            <form onSubmit={handleConfirmCheckout} className="space-y-4">
              {/* Saldo Warning */}
              <div
                className={`p-3.5 rounded-2xl border text-xs flex items-center justify-between ${
                  checkoutOrder.saldoPendiente === 0
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : 'bg-rose-50 border-rose-200 text-rose-800'
                }`}
              >
                <span className="font-semibold">
                  {checkoutOrder.saldoPendiente === 0
                    ? '✓ Saldo completamente liquidado en $0'
                    : `⚠️ Saldo pendiente: $${checkoutOrder.saldoPendiente.toLocaleString()} MXN`}
                </span>
                <span className="font-mono font-bold text-sm">
                  ${checkoutOrder.saldoPendiente.toLocaleString()} MXN
                </span>
              </div>

              {/* Fotos de Salida */}
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="font-bold text-slate-700 flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-slate-500" />
                    <span>Fotos de Salida para Cotejo:</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => setExitPhotosLoaded(true)}
                    className="text-xs text-rose-600 hover:underline font-semibold"
                  >
                    + Capturar / Cargar Fotos
                  </button>
                </div>

                {exitPhotosLoaded ? (
                  <div className="grid grid-cols-2 gap-2 text-[10px] text-emerald-700 bg-emerald-50 p-2 rounded-xl border border-emerald-200">
                    <span>✓ Foto frente salida cargada</span>
                    <span>✓ Foto trasera salida cargada</span>
                  </div>
                ) : (
                  <span className="text-[11px] text-slate-400 block italic">
                    Sin fotos de salida (opcional para cotejo de no daños)
                  </span>
                )}
              </div>

              {/* Firma de Recepción Digital */}
              <div>
                <label className="text-xs text-slate-600 block mb-1 font-semibold">
                  Firma Digital o Nombre de quien recibe la unidad:
                </label>
                <input
                  type="text"
                  value={signatureText}
                  onChange={(e) => setSignatureText(e.target.value)}
                  placeholder="Nombre y firma digital de quien recibe el auto..."
                  required
                  className="w-full bg-slate-50 border border-slate-200 text-slate-900 rounded-xl p-2.5 text-xs font-serif italic text-center focus:border-rose-500 focus:outline-none"
                />
                <span className="text-[10px] text-slate-400 block text-center mt-1">
                  Certifica recepción satisfactoria del vehículo y refacciones reemplazadas
                </span>
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1 font-semibold">
                  Notas de Entrega / Garantía:
                </label>
                <textarea
                  value={checkoutNotes}
                  onChange={(e) => setCheckoutNotes(e.target.value)}
                  placeholder="Ej. Se entregaron balatas usadas al cliente. Garantía de 30 días o 1,000 km en mano de obra..."
                  rows={2}
                  className="w-full bg-slate-50 border border-slate-200 text-slate-900 rounded-xl p-2.5 text-xs focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setCheckoutOrder(null)}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold text-xs shadow-md shadow-rose-600/20 transition-all"
                >
                  Finalizar Entrega (Check-out)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal para Avisar Detalle Extra / Hallazgo al Desarmar */}
      {extraAlertOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white border border-slate-200 rounded-3xl max-w-lg w-full p-6 shadow-2xl text-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                  ⚠️
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">
                    Avisar Detalle Extra / Hallazgo en Bahía
                  </h3>
                  <p className="text-xs text-slate-500">
                    Folio #{extraAlertOrder.folio} • Solicitar autorización por WhatsApp
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setExtraAlertOrder(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSendExtraAlert} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Detalle / Falla Extra Encontrada *:
                </label>
                <textarea
                  value={extraAlertDetalle}
                  onChange={(e) => setExtraAlertDetalle(e.target.value)}
                  required
                  rows={3}
                  placeholder="Ej. Al desmontar las llantas detectamos que los baleros de masa tienen juego excesivo y el retén está tirando grasa. Se requiere cambio para evitar que se amarre la rueda..."
                  className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-xl p-3 text-xs focus:border-amber-500 focus:outline-none"
                />
              </div>

              {/* Botones de sugerencias rápidas */}
              <div className="flex flex-wrap gap-1.5">
                {[
                  'Discos de freno agrietados / requieren rectificado',
                  'Fuga en manguera de radiador / bomba de agua',
                  'Amortiguadores tirando aceite',
                  'Bieletas y terminales con juego excesivo',
                  'Banda de accesorios cuarteada',
                ].map((sug, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setExtraAlertDetalle(sug)}
                    className="text-[10px] bg-amber-50/80 hover:bg-amber-100 text-amber-900 px-2 py-0.5 rounded-lg border border-amber-200"
                  >
                    + {sug}
                  </button>
                ))}
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Presupuesto Adicional Estimado ($ MXN) *:
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 font-bold text-slate-400 text-sm">$</span>
                  <input
                    type="number"
                    value={extraAlertCosto}
                    onChange={(e) => setExtraAlertCosto(Number(e.target.value))}
                    required
                    placeholder="450"
                    className="w-full bg-slate-50 border border-slate-200 text-slate-900 font-mono font-bold rounded-xl pl-7 pr-12 py-2 text-sm focus:border-amber-500 focus:outline-none"
                  />
                  <span className="absolute right-3 top-2.5 text-xs text-slate-400 font-mono font-bold">
                    MXN
                  </span>
                </div>
              </div>

              <div className="p-3 bg-amber-50/70 rounded-xl border border-amber-200 text-xs flex items-start gap-2">
                <input
                  type="checkbox"
                  id="chk-sumar-presupuesto"
                  checked={extraAlertSumarPresupuesto}
                  onChange={(e) => setExtraAlertSumarPresupuesto(e.target.checked)}
                  className="mt-0.5 accent-amber-600 rounded"
                />
                <label htmlFor="chk-sumar-presupuesto" className="text-amber-950 cursor-pointer">
                  <strong>Sumar automáticamente a la cotización de la orden</strong> como concepto pendiente de autorización (se actualiza el total de la orden).
                </label>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setExtraAlertOrder(null)}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all active:scale-95"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Enviar por WhatsApp</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal de Asignación / Cambio de Mecánico */}
      {assignModalOrder && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-xl">👨‍🔧</span>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Asignar Mecánico & Comisión
                  </h3>
                  <span className="text-xs text-rose-600 font-mono font-bold">
                    Orden #{assignModalOrder.folio}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setAssignModalOrder(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveModalAssignment} className="space-y-4 text-xs">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Mecánico en Bahía *:
                </label>
                <select
                  value={assignMecId}
                  onChange={(e) => {
                    setAssignMecId(e.target.value);
                    const found = mechanics.find((m) => m.id === e.target.value);
                    if (found) setAssignCommission(found.comisionDefault);
                  }}
                  required
                  className="w-full bg-slate-50 border-2 border-amber-400 rounded-xl px-3 py-2 text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                >
                  <option value="">-- Seleccionar Mecánico --</option>
                  {mechanics.map((m) => (
                    <option key={m.id} value={m.id}>
                      👨‍🔧 {m.nombre} ({m.especialidad}) - {m.comisionDefault}% base
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Concepto del Trabajo / Mano de Obra:
                </label>
                <input
                  type="text"
                  value={assignConcepto}
                  onChange={(e) => setAssignConcepto(e.target.value)}
                  placeholder="Ej. Cambio de balatas, afinación..."
                  className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Costo Mano de Obra:
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2 font-bold text-slate-400 text-xs">$</span>
                    <input
                      type="number"
                      value={assignManoObraMonto}
                      onChange={(e) => setAssignManoObraMonto(Number(e.target.value))}
                      className="w-full bg-slate-50 border border-slate-200 text-slate-900 font-mono font-bold rounded-xl pl-6 pr-2 py-1.5 text-xs text-right focus:border-rose-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Comisión (%):
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min={10}
                      max={50}
                      value={assignCommission}
                      onChange={(e) => setAssignCommission(Number(e.target.value))}
                      className="w-full bg-slate-50 border-2 border-amber-400 text-slate-900 font-mono font-bold rounded-xl px-3 py-1.5 text-center text-xs focus:outline-none"
                    />
                    <span className="absolute right-3 top-1.5 text-xs font-black text-amber-600 font-mono">
                      %
                    </span>
                  </div>
                </div>
              </div>

              {/* Cálculo en vivo */}
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 space-y-1">
                <div className="flex justify-between items-center text-amber-950 font-semibold">
                  <span>Pago al Mecánico:</span>
                  <span className="font-mono font-bold text-amber-900 bg-white px-2 py-0.5 rounded border border-amber-300">
                    ${Math.round(assignManoObraMonto * (assignCommission / 100)).toLocaleString()} MXN ({assignCommission}%)
                  </span>
                </div>
                <div className="flex justify-between items-center text-slate-600 text-[11px]">
                  <span>Margen Taller:</span>
                  <span className="font-mono font-bold text-emerald-800">
                    ${Math.max(0, Math.round(assignManoObraMonto * (1 - assignCommission / 100))).toLocaleString()} MXN
                  </span>
                </div>
                <span className="text-[10px] text-amber-800/80 block mt-1">
                  *Las refacciones no pagan comisión (0% refacción).
                </span>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setAssignModalOrder(null)}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-bold text-xs shadow-md transition-all active:scale-95"
                >
                  <span>✓ Guardar Asignación</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal de Ticket Térmico 80 mm con Código QR */}
      {selectedTicketOrder && (
        <Ticket80mmModal
          isOpen={!!selectedTicketOrder}
          onClose={() => setSelectedTicketOrder(null)}
          order={selectedTicketOrder}
          vehicle={vehicles.find((v) => v.id === selectedTicketOrder.vehiculoId)}
          client={clients.find((c) => c.id === selectedTicketOrder.clienteId)}
          company={companies.find((co) => co.id === selectedTicketOrder.empresaId)}
          config={config}
        />
      )}

      {/* Modal de Orden de Servicio en 2 Hojas (Fotos, Presupuesto y Disclaimers) */}
      {selectedDosHojasOrder && (
        <OrdenDosHojasModal
          isOpen={!!selectedDosHojasOrder}
          onClose={() => setSelectedDosHojasOrder(null)}
          order={selectedDosHojasOrder}
          vehicle={vehicles.find((v) => v.id === selectedDosHojasOrder.vehiculoId)}
          client={clients.find((c) => c.id === selectedDosHojasOrder.clienteId)}
          company={companies.find((co) => co.id === selectedDosHojasOrder.empresaId)}
          config={config}
          onOrderUpdated={(updated) => {
            setOrders(StorageService.getWorkOrders());
            setSelectedDosHojasOrder(updated);
          }}
        />
      )}

      {/* Modal de Seguridad de Reyna para Eliminar Orden */}
      <ReinaSecurityModal
        isOpen={!!orderToDelete}
        onClose={() => setOrderToDelete(null)}
        onSuccess={handleConfirmDeleteOrder}
        title="Eliminar Orden de Trabajo"
        description={`¿Estás seguro de eliminar permanentemente la orden #${orderToDelete?.folio}? Esta acción requiere el PIN de Reyna Amaya.`}
        actionLabel="Eliminar Orden"
        actionType="delete"
      />

      {/* Modal de Seguridad de Reyna para Editar Presupuesto */}
      <ReinaSecurityModal
        isOpen={!!orderToEdit}
        onClose={() => setOrderToEdit(null)}
        onSuccess={handleConfirmEditBudget}
        title="Modificar Presupuesto & Costos"
        description={`Para modificar o editar los costos y servicios de la orden #${orderToEdit?.folio}, ingresa el PIN de Reyna Amaya.`}
        actionLabel="Desbloquear Edición"
        actionType="edit"
      />
    </div>
  );
};
