'use client';

import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { WorkOrder, Vehicle, Client, Company, TallerConfig } from '@/types';
import {
  Printer,
  X,
  Sliders,
  Check,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  Sparkles,
  Info,
} from 'lucide-react';

interface Ticket80mmModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: WorkOrder;
  vehicle?: Vehicle;
  client?: Client;
  company?: Company;
  config: TallerConfig;
}

interface TicketSettings {
  anchoMm: number; // 68, 72 (estándar 80mm), 76 (completo), 54 (58mm)
  fontSizePx: number; // 9.5, 10.5, 11.5, 12.5
  escala: number; // 85, 90, 95, 100, 105
  mostrarLogo: boolean;
  mostrarQr: boolean;
  mostrarClausulas: boolean;
  mostrarCuentasBanco: boolean;
  mostrarFirmas: boolean;
  margenLateralMm: number; // 0, 1, 2
}

const DEFAULT_SETTINGS: TicketSettings = {
  anchoMm: 72, // 72 mm es el estándar físico imprimible de los rollos térmicos de 80 mm (Epson, Xprinter, POS-80)
  fontSizePx: 10.5,
  escala: 100,
  mostrarLogo: true,
  mostrarQr: true,
  mostrarClausulas: true,
  mostrarCuentasBanco: true,
  mostrarFirmas: true,
  margenLateralMm: 1,
};

export const Ticket80mmModal: React.FC<Ticket80mmModalProps> = ({
  isOpen,
  onClose,
  order,
  vehicle,
  client,
  company,
  config,
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [trackingUrl, setTrackingUrl] = useState<string>('');
  const [showConfig, setShowConfig] = useState<boolean>(false);
  const [settings, setSettings] = useState<TicketSettings>(DEFAULT_SETTINGS);

  // Cargar configuración guardada en localStorage
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const saved = localStorage.getItem('taller_ticket_settings');
      if (saved) {
        setSettings({ ...DEFAULT_SETTINGS, ...JSON.parse(saved) });
      }
    } catch {}
  }, [isOpen]);

  // Guardar configuración en localStorage
  const updateSettings = (partial: Partial<TicketSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...partial };
      try {
        localStorage.setItem('taller_ticket_settings', JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  const handleResetSettings = () => {
    setSettings(DEFAULT_SETTINGS);
    try {
      localStorage.setItem('taller_ticket_settings', JSON.stringify(DEFAULT_SETTINGS));
    } catch {}
  };

  useEffect(() => {
    if (!isOpen) return;

    const generateQr = (originUrl: string) => {
      const url = `${originUrl}/seguimiento/${order.folio}`;
      setTrackingUrl(url);

      QRCode.toDataURL(url, {
        width: 240,
        margin: 1,
        color: {
          dark: '#000000',
          light: '#ffffff',
        },
        errorCorrectionLevel: 'M',
      })
        .then((dataUrl) => setQrDataUrl(dataUrl))
        .catch((err) => console.error('Error generando QR', err));
    };

    if (typeof window !== 'undefined') {
      const hostname = window.location.hostname;
      if (hostname === 'localhost' || hostname === '127.0.0.1') {
        fetch('/api/network-info')
          .then((res) => res.json())
          .then((data) => {
            if (data?.lanOrigin) {
              generateQr(data.lanOrigin);
            } else {
              generateQr(window.location.origin);
            }
          })
          .catch(() => {
            generateQr(window.location.origin);
          });
      } else {
        generateQr(window.location.origin);
      }
    } else {
      generateQr('');
    }
  }, [isOpen, order.folio]);

  if (!isOpen) return null;

  // =========================================================================
  // MÉTODO 1: IMPRESIÓN DIRECTA POS (VENTANA LIMPIA CON AUTO-PRINT)
  // Este método es el estándar POS porque aísla el ticket en un 100%,
  // no depende de iframes que colapsan a 0px en macOS/Chrome, y aplica
  // el ancho exacto del rollo térmico.
  // =========================================================================
  const handlePrintPopup = () => {
    const ticketElem = document.getElementById('ticket-80mm-printable');
    if (!ticketElem) {
      window.print();
      return;
    }

    const printWindow = window.open(
      '',
      '_blank',
      'width=480,height=720,menubar=no,toolbar=no,location=no,status=no'
    );
    if (!printWindow) {
      window.print();
      return;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html lang="es">
        <head>
          <meta charset="utf-8" />
          <title>Ticket #${order.folio} - Taller Amaya</title>
          <style>
            @page {
              size: ${settings.anchoMm}mm auto;
              margin: 0mm;
            }
            * {
              box-sizing: border-box !important;
              margin: 0;
              padding: 0;
            }
            body {
              width: ${settings.anchoMm}mm;
              max-width: ${settings.anchoMm}mm;
              margin: 0 auto;
              padding: 2mm ${settings.margenLateralMm}mm;
              font-family: 'Courier New', Courier, monospace, Arial, sans-serif;
              font-size: ${settings.fontSizePx}px;
              line-height: 1.25;
              color: #000000;
              background: #ffffff;
              zoom: ${settings.escala}%;
              -webkit-print-color-adjust: exact !important;
              print-color-adjust: exact !important;
            }
            img {
              max-width: 100%;
              height: auto;
              display: block;
            }
            .text-center { text-align: center; }
            .text-right { text-align: right; }
            .text-left { text-align: left; }
            .font-bold { font-weight: bold; }
            .font-black { font-weight: 900; }
            .uppercase { text-transform: uppercase; }
            .truncate { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            .flex { display: flex; }
            .justify-between { justify-content: space-between; }
            .items-center { align-items: center; }
            .border-b { border-bottom: 1px solid #000; }
            .border-b-2 { border-bottom: 2px solid #000; }
            .border-t { border-top: 1px solid #000; }
            .border-y { border-top: 1px solid #000; border-bottom: 1px solid #000; }
            .border-2 { border: 2px solid #000; }
            .border-dotted { border-style: dotted !important; }
            .border-dashed { border-style: dashed !important; }
            .rounded { border-radius: 4px; }
            .rounded-lg { border-radius: 8px; }
            .p-1 { padding: 4px; }
            .p-1\\.5 { padding: 6px; }
            .p-2 { padding: 8px; }
            .px-1 { padding-left: 4px; padding-right: 4px; }
            .py-1 { padding-top: 4px; padding-bottom: 4px; }
            .my-1 { margin-top: 4px; margin-bottom: 4px; }
            .my-1\\.5 { margin-top: 6px; margin-bottom: 6px; }
            .my-2 { margin-top: 8px; margin-bottom: 8px; }
            .my-3 { margin-top: 12px; margin-bottom: 12px; }
            .mt-0\\.5 { margin-top: 2px; }
            .mt-1 { margin-top: 4px; }
            .mb-1 { margin-bottom: 4px; }
            .mb-1\\.5 { margin-bottom: 6px; }
            .mx-auto { margin-left: auto; margin-right: auto; }
            .mx-2 { margin-left: 8px; margin-right: 8px; }
            .w-full { width: 100%; }
            .grid { display: grid; }
            .grid-cols-2 { grid-template-columns: 1fr 1fr; }
            .gap-2 { gap: 8px; }
            .bg-black { background-color: #000 !important; color: #fff !important; }
            .text-white { color: #fff !important; }
            .bg-zinc-100, .bg-zinc-50, .bg-slate-100 { background-color: #f4f4f5 !important; }
            @media print {
              .no-print { display: none !important; }
            }
          </style>
        </head>
        <body>
          <div class="no-print" style="padding: 10px; background: #fef3c7; border: 1px solid #f59e0b; margin-bottom: 12px; font-family: sans-serif; font-size: 11px; text-align: center; border-radius: 8px;">
            <strong>Configuración Recomendada en tu Impresora:</strong><br />
            1. En <strong>Márgenes</strong> selecciona <strong>"Ninguno"</strong> (None).<br />
            2. En <strong>Tamaño de papel</strong> selecciona <strong>80 mm / Receipt</strong>.<br />
            <button onclick="window.print()" style="margin-top: 6px; padding: 6px 14px; background: #e11d48; color: white; border: none; font-weight: bold; border-radius: 6px; cursor: pointer;">
              🖨️ Presiona aquí si no abrió la ventana de impresión
            </button>
          </div>

          <div style="width: 100%;">
            ${ticketElem.innerHTML}
          </div>

          <script>
            window.addEventListener('load', function() {
              setTimeout(function() {
                window.focus();
                window.print();
              }, 250);
            });
          </script>
        </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto print:p-0 print:bg-white print:static animate-in fade-in">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-lg w-full max-h-[96vh] overflow-y-auto shadow-2xl relative text-slate-800 print:border-none print:shadow-none print:max-w-none print:w-full">
        {/* ============================================================== */}
        {/* BARRA SUPERIOR CON ACCIONES E INICIADOR DE CONFIGURACIÓN        */}
        {/* ============================================================== */}
        <div className="sticky top-0 bg-white/95 backdrop-blur-md p-3.5 sm:p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 z-20 print:hidden">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-rose-50 text-rose-600 border border-rose-200">
              <Printer className="w-5 h-5" />
            </span>
            <div>
              <h3 className="font-black text-sm text-slate-900 leading-tight">
                Impresión Térmica 80 mm
              </h3>
              <p className="text-[11px] text-slate-500 font-mono">
                Orden #{order.folio} • {settings.anchoMm} mm ({settings.escala}%)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Botón para desplegar configuración de impresora */}
            <button
              onClick={() => setShowConfig(!showConfig)}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-xl border font-bold text-xs transition-colors cursor-pointer ${
                showConfig
                  ? 'bg-amber-100 text-amber-900 border-amber-300'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
              }`}
              title="Ajustar ancho, tamaño de letra y contenido del ticket"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>Configurar</span>
              {showConfig ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>

            {/* Botón Principal de Impresión */}
            <button
              onClick={handlePrintPopup}
              className="flex items-center gap-1.5 px-4 py-1.5 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black text-xs rounded-xl shadow-md shadow-rose-600/25 transition-all active:scale-95 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Imprimir</span>
            </button>

            {/* Cerrar modal */}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* ============================================================== */}
        {/* PANEL DESPLEGABLE DE CONFIGURACIÓN DEL TICKET                    */}
        {/* ============================================================== */}
        {showConfig && (
          <div className="bg-amber-50/70 border-b border-amber-200 p-4 space-y-3.5 text-xs animate-in slide-in-from-top-2">
            <div className="flex items-center justify-between border-b border-amber-200/80 pb-2">
              <span className="font-black text-amber-950 uppercase tracking-wide flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-amber-700" />
                Ajustes de Impresora Térmica
              </span>
              <button
                onClick={handleResetSettings}
                className="text-[11px] text-amber-900 hover:underline flex items-center gap-1 font-semibold cursor-pointer"
                title="Restablecer valores predeterminados"
              >
                <RotateCcw className="w-3 h-3" />
                Restablecer
              </button>
            </div>

            {/* 1. Selector de Ancho de Papel */}
            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Ancho del Rollo de Impresora:
              </label>
              <div className="grid grid-cols-4 gap-1.5">
                {[
                  { mm: 72, label: '80mm Estándar', desc: '72mm útil (Recomendado)' },
                  { mm: 76, label: '80mm Amplio', desc: '76mm útil' },
                  { mm: 68, label: '80mm Estrecho', desc: '68mm (Margen seguro)' },
                  { mm: 54, label: '58mm Chico', desc: 'Mini impresora' },
                ].map((opt) => (
                  <button
                    key={opt.mm}
                    onClick={() => updateSettings({ anchoMm: opt.mm })}
                    className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                      settings.anchoMm === opt.mm
                        ? 'bg-amber-500 text-slate-950 font-black border-amber-600 shadow-xs'
                        : 'bg-white text-slate-700 border-amber-200 hover:bg-amber-100/60'
                    }`}
                  >
                    <span className="block font-bold text-xs leading-tight">{opt.label}</span>
                    <span className="block text-[9px] opacity-75 mt-0.5">{opt.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Tamaño de Letra y Zoom */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Tamaño de Letra:
                </label>
                <div className="flex rounded-xl border border-amber-200 bg-white p-0.5">
                  {[
                    { px: 9.5, label: 'Chica (9.5px)' },
                    { px: 10.5, label: 'Normal (10.5px)' },
                    { px: 12, label: 'Grande (12px)' },
                  ].map((f) => (
                    <button
                      key={f.px}
                      onClick={() => updateSettings({ fontSizePx: f.px })}
                      className={`flex-1 py-1 px-1.5 text-center rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                        settings.fontSizePx === f.px
                          ? 'bg-amber-500 text-slate-950 shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Escala de Impresión:
                </label>
                <div className="flex rounded-xl border border-amber-200 bg-white p-0.5">
                  {[85, 90, 95, 100, 105].map((sc) => (
                    <button
                      key={sc}
                      onClick={() => updateSettings({ escala: sc })}
                      className={`flex-1 py-1 text-center rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                        settings.escala === sc
                          ? 'bg-amber-500 text-slate-950 shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {sc}%
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* 3. Elementos a Incluir en el Ticket */}
            <div>
              <label className="font-bold text-slate-700 block mb-1.5">
                Contenido a Imprimir en el Ticket:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { key: 'mostrarLogo', label: 'Logotipo Taller' },
                  { key: 'mostrarQr', label: 'Código QR Rastreo' },
                  { key: 'mostrarClausulas', label: 'Tarifas y Cláusulas' },
                  { key: 'mostrarCuentasBanco', label: 'Cuentas BBVA' },
                  { key: 'mostrarFirmas', label: 'Líneas de Firma' },
                ].map((item) => {
                  const isChecked = (settings as any)[item.key];
                  return (
                    <label
                      key={item.key}
                      className="flex items-center gap-2 p-2 rounded-xl bg-white border border-amber-200 cursor-pointer hover:bg-amber-50"
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={(e) => updateSettings({ [item.key]: e.target.checked } as any)}
                        className="rounded border-amber-400 text-rose-600 focus:ring-rose-500"
                      />
                      <span className="font-semibold text-[11px] text-slate-800">{item.label}</span>
                    </label>
                  );
                })}
              </div>
            </div>

            {/* 4. Guía Crucial para la Impresora de la Computadora */}
            <div className="p-3 bg-white rounded-xl border border-amber-300 text-[11px] text-amber-950 space-y-1 shadow-2xs">
              <strong className="block text-amber-900 font-black uppercase flex items-center gap-1">
                <Info className="w-3.5 h-3.5 text-amber-700" />
                Regla para que no se recorte ni se achique al imprimir:
              </strong>
              <p>
                Al abrirse la ventana de la impresora en tu computadora o navegador:
              </p>
              <ul className="list-disc list-inside space-y-0.5 font-medium pl-1">
                <li>
                  <strong>Márgenes:</strong> Cambia a <strong>"Ninguno"</strong> (None).
                </li>
                <li>
                  <strong>Gráficos en segundo plano:</strong> Deja marcada la casilla.
                </li>
                <li>
                  <strong>Tamaño de papel:</strong> Elige <strong>80 x 297 mm</strong> o <strong>Roll Paper / Receipt</strong>.
                </li>
              </ul>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* VISTA PREVIA Y FORMATO DE IMPRESIÓN DEL TICKET                  */}
        {/* ============================================================== */}
        <div className="p-3 sm:p-5 flex justify-center bg-slate-100 print:bg-white print:p-0">
          <div
            id="ticket-80mm-printable"
            style={{
              width: `${settings.anchoMm}mm`,
              maxWidth: `${settings.anchoMm}mm`,
              fontSize: `${settings.fontSizePx}px`,
              zoom: `${settings.escala}%`,
            }}
            className="bg-white text-black font-mono p-2 leading-tight border border-slate-300 shadow-lg print:border-none print:shadow-none print:p-0"
          >
            {/* Encabezado del Taller con Logotipo Oficial */}
            <div className="text-center pb-2 border-b-2 border-black">
              {settings.mostrarLogo && (
                <div className="flex justify-center mb-1">
                  <img
                    src="/logo-taller-amaya.png"
                    alt="Taller Amaya Servicio Mecánico"
                    className="h-14 max-w-[180px] w-auto object-contain mx-auto"
                  />
                </div>
              )}
              <div className="text-[11px] font-black uppercase tracking-wider text-black">
                {config.nombreComercial}
              </div>
              <div className="text-[9px] text-zinc-700 uppercase font-bold">
                Mecánica General • Diagnóstico por Computadora
              </div>
              <div className="text-[9px] text-zinc-800 mt-0.5 font-medium">
                {config.direccion}
              </div>
              <div className="text-[9px] font-bold mt-0.5">
                Tel: {config.telefonoLocal} | WA: {config.whatsapp}
              </div>
              <div className="text-[9px] text-zinc-700">
                RFC: {config.rfc} | Tijuana, B.C.
              </div>
            </div>

            {/* Número de Folio y Fecha */}
            <div className="flex justify-between items-center my-1.5 py-1 border-b border-black">
              <div>
                <span className="font-mono text-base font-black tracking-wider">
                  FOLIO: #{order.folio}
                </span>
              </div>
              <div className="text-right text-[9px] font-mono font-semibold">
                <div>Fecha: {order.fechaIngreso.split(' ')[0]}</div>
                <div>Hora: {order.fechaIngreso.split(' ')[1] || '08:30'}</div>
              </div>
            </div>

            <div className="text-center font-black text-[10.5px] uppercase tracking-wider py-0.5 border-y border-black bg-zinc-100">
              * CONTRATO DE SERVICIO & RECEPCIÓN *
            </div>

            {/* Datos del Vehículo */}
            <div className="my-1.5 text-[10px] space-y-0.5">
              <div className="flex justify-between border-b border-dotted border-zinc-400 pb-0.5">
                <span className="font-bold">PLACAS:</span>
                <span className="font-mono font-black text-xs px-1 bg-black text-white rounded">
                  {vehicle?.placas || 'SIN PLACAS'}
                </span>
              </div>
              <div className="flex justify-between">
                <span>VEHÍCULO:</span>
                <span className="font-bold text-right truncate">
                  {vehicle?.marca} {vehicle?.modelo} ({vehicle?.ano})
                </span>
              </div>
              <div className="flex justify-between">
                <span>COLOR:</span>
                <span className="font-semibold">{vehicle?.color || 'N/A'}</span>
              </div>
              {vehicle?.vin && (
                <div className="flex justify-between">
                  <span>SERIE / VIN:</span>
                  <span className="font-mono text-[9px] font-semibold">{vehicle.vin}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>KILOMETRAJE:</span>
                <span className="font-mono font-bold">
                  {order.kilometrajeEntrada.toLocaleString()} KM
                </span>
              </div>
              <div className="flex justify-between">
                <span>NIVEL GASOLINA:</span>
                <span className="font-bold">{order.nivelCombustible}</span>
              </div>
            </div>

            {/* Datos del Cliente & Chofer */}
            <div className="my-1.5 pt-1 border-t border-black text-[10px] space-y-0.5">
              <div>
                <span className="font-bold">CLIENTE / FLOTILLA:</span>
                <div className="font-bold text-xs truncate">
                  {company ? company.razonSocial : client?.nombre || 'PARTICULAR'}
                </div>
              </div>
              {order.choferNombre && (
                <div className="flex justify-between text-[9px]">
                  <span>CHOFER QUE ENTREGA:</span>
                  <span className="font-bold">{order.choferNombre}</span>
                </div>
              )}
              <div className="flex justify-between text-[9px]">
                <span>TELÉFONO:</span>
                <span className="font-mono font-bold">
                  {order.choferTelefono || client?.telefono || config.whatsapp}
                </span>
              </div>
            </div>

            {/* Falla / Comentario del Cliente */}
            <div className="my-1.5 p-1 border border-zinc-400 bg-zinc-50 text-[9px] rounded">
              <span className="font-bold block uppercase text-zinc-700">Falla / Motivo de Ingreso:</span>
              <p className="font-medium text-black mt-0.5 whitespace-pre-wrap">
                {order.fallaReportada}
              </p>
            </div>

            {/* Refacciones que trae el Cliente (como viene en la hoja física) */}
            {order.refaccionesCliente && order.refaccionesCliente.length > 0 && (
              <div className="my-1 p-1 border border-black bg-zinc-100 text-[9px]">
                <strong className="block uppercase font-bold text-[8.5px]">
                  ✓ Refacciones que trajo el cliente (Cajuela/Asiento):
                </strong>
                <ul className="list-disc list-inside space-y-0.5 pl-1 font-semibold">
                  {order.refaccionesCliente.map((ref, idx) => (
                    <li key={idx} className="truncate">{ref}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Cláusulas Oficiales de la Hoja Física de Taller Amaya */}
            {settings.mostrarClausulas && (
              <div className="my-1.5 text-[8px] leading-tight space-y-0.5 text-zinc-800 border-t border-b border-zinc-300 py-1">
                <div className="font-bold text-center">
                  * CONDICIONES Y TARIFAS DE SERVICIO *
                </div>
                <div>
                  • <strong>REVISIÓN:</strong> Toda revisión genera un costo de <strong>$450.00 pesos</strong> por mínima que sea.
                </div>
                <div>
                  • <strong>ANTICIPO:</strong> Se solicita anticipo de <strong>$500.00 pesos</strong> como mínimo al dejar su vehículo.
                </div>
                <div>
                  • <strong>ALMACENAMIENTO:</strong> Cuota de <strong>$50.00 pesos por día</strong> acumulado a partir de la fecha y hora de aviso de terminación.
                </div>
                <div>
                  • <strong>FACTURACIÓN:</strong> Favor de avisar al ingresar si requiere factura fiscal (aplica 8% IVA Zona Fronteriza Tijuana).
                </div>
                <div>
                  • <strong>OBJETOS PERSONALES:</strong> El taller NO se hace responsable de dinero, herramienta u objetos de valor dejados dentro de la unidad.
                </div>
              </div>
            )}

            {/* Desglose de Presupuesto (Partes y Mano de Obra) */}
            {order.presupuesto ? (
              <div className="my-1.5 p-1 bg-zinc-50 border border-black text-[9px] space-y-0.5">
                <div className="flex justify-between font-bold border-b border-zinc-300 pb-0.5">
                  <span className="uppercase">COTIZACIÓN / PRESUPUESTO:</span>
                  <span className="font-mono text-[8px] px-1 bg-zinc-200 rounded uppercase font-bold">
                    {order.presupuesto.estado}
                  </span>
                </div>
                {order.presupuesto.partes.length > 0 && (
                  <div>
                    <span className="font-bold text-[8px] block">Partes / Refacciones:</span>
                    {order.presupuesto.partes.map((p) => (
                      <div key={p.id} className="flex justify-between pl-1 text-[8px] text-zinc-700">
                        <span>{p.cantidad}x {p.descripcion}</span>
                        <span className="font-mono">${p.subtotal.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                )}
                {order.presupuesto.manoObra.length > 0 && (
                  <div>
                    <span className="font-bold text-[8px] block">Mano de Obra:</span>
                    {order.presupuesto.manoObra.map((m) => (
                      <div key={m.id} className="flex justify-between pl-1 text-[8px] text-zinc-700">
                        <span>{m.concepto}</span>
                        <span className="font-mono">${m.costo.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                )}
                <div className="border-t border-zinc-300 pt-0.5 space-y-0.5 font-bold">
                  <div className="flex justify-between">
                    <span>TOTAL PRESUPUESTO:</span>
                    <span className="font-mono text-xs">${order.presupuesto.totalPresupuesto.toLocaleString()} MXN</span>
                  </div>
                  <div className="flex justify-between font-normal text-zinc-600">
                    <span>ANTICIPO RECIBIDO:</span>
                    <span className="font-mono">${order.totalPagado.toLocaleString()} MXN</span>
                  </div>
                  <div className="flex justify-between font-black text-xs text-black">
                    <span>SALDO PENDIENTE:</span>
                    <span className="font-mono">${order.saldoPendiente.toLocaleString()} MXN</span>
                  </div>
                </div>
              </div>
            ) : (
              /* Desglose Estándar & Saldos */
              <div className="my-1.5 p-1 bg-zinc-100 border border-black text-[9.5px] space-y-0.5">
                <div className="flex justify-between font-bold">
                  <span>PRESUPUESTO ESTIMADO:</span>
                  <span className="font-mono text-xs">${order.subtotalGeneral.toLocaleString()} MXN</span>
                </div>
                <div className="flex justify-between text-zinc-700">
                  <span>ANTICIPO RECIBIDO:</span>
                  <span className="font-mono">${order.totalPagado.toLocaleString()} MXN</span>
                </div>
                <div className="flex justify-between font-black border-t border-zinc-300 pt-0.5 text-[10.5px]">
                  <span>SALDO PENDIENTE:</span>
                  <span className="font-mono">${order.saldoPendiente.toLocaleString()} MXN</span>
                </div>
              </div>
            )}

            {/* Cuentas Bancarias BBVA para Transferencia */}
            {settings.mostrarCuentasBanco && (
              <div className="my-1.5 p-1 border border-dotted border-zinc-500 text-[8px] leading-tight">
                <div className="font-bold uppercase text-center mb-0.5">Transferencias BBVA Bancomer:</div>
                <div className="font-mono text-center">CLABE: <strong>{config.clabe}</strong></div>
                <div className="text-center truncate">Beneficiario: {config.razonSocial}</div>
              </div>
            )}

            {/* ============================================================== */}
            {/* SECCIÓN DEL CÓDIGO QR PARA RASTREO Y ESTATUS EN CELULAR        */}
            {/* ============================================================== */}
            {settings.mostrarQr && (
              <div className="my-2 py-1.5 border-2 border-black text-center bg-white rounded-lg">
                <span className="font-black text-[9.5px] uppercase block tracking-wider">
                  📱 ESCANEA CON TU CELULAR
                </span>
                <span className="text-[7.5px] text-zinc-600 block mb-0.5">
                  Para ver fotos, avances, cotización y estatus en vivo
                </span>

                {qrDataUrl ? (
                  <div className="flex justify-center my-0.5">
                    <img
                      src={qrDataUrl}
                      alt="Código QR de Rastreo"
                      className="w-28 h-28 border border-black p-0.5 bg-white"
                    />
                  </div>
                ) : (
                  <div className="w-24 h-24 mx-auto bg-zinc-100 flex items-center justify-center font-mono text-[8.5px]">
                    Generando QR...
                  </div>
                )}

                <span className="font-mono text-[7.5px] font-semibold text-zinc-600 block truncate px-1">
                  {trackingUrl}
                </span>
              </div>
            )}

            {/* Firmas de Conformidad */}
            {settings.mostrarFirmas && (
              <div className="my-2.5 pt-3 grid grid-cols-2 gap-2 text-center text-[8px]">
                <div>
                  <div className="border-b border-black mb-1 mx-2 h-5" />
                  <span className="font-bold block">FIRMA DE CONFORMIDAD</span>
                  <span className="text-zinc-600 text-[7px]">Cliente / Chofer</span>
                </div>
                <div>
                  <div className="border-b border-black mb-1 mx-2 h-5" />
                  <span className="font-bold block">RECIBIÓ POR TALLER</span>
                  <span className="text-zinc-600 text-[7px]">{order.entregadoPor || 'Recepción Amaya'}</span>
                </div>
              </div>
            )}

            {/* Leyenda Final */}
            <div className="text-center text-[7px] text-zinc-500 pt-1 border-t border-dashed border-zinc-400">
              ESTE DOCUMENTO ES PARA CONTROL INTERNO Y SEGUIMIENTO INFORMATIVO. GRACIAS POR SU PREFERENCIA EN TALLER AMAYA.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
