'use client';

import React, { useState, useEffect } from 'react';
import { Lock, ShieldAlert, X, CheckCircle2 } from 'lucide-react';
import { TALLER_CONFIG } from '@/data/tallerConfig';

interface ReinaSecurityModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  title?: string;
  description?: string;
  actionLabel?: string;
  actionType?: 'delete' | 'edit' | 'admin';
}

export const ReinaSecurityModal: React.FC<ReinaSecurityModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  title = 'Autorización de Reyna Amaya',
  description = 'Acción protegida: Ingrese el PIN de seguridad de 4 dígitos para autorizar.',
  actionLabel = 'Autorizar',
  actionType = 'delete',
}) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  const correctPin = TALLER_CONFIG.adminPin || '2036';

  useEffect(() => {
    if (isOpen) {
      setPin('');
      setError(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin.trim() === correctPin) {
      setError(false);
      onSuccess();
      onClose();
    } else {
      setError(true);
      setPin('');
    }
  };

  const isDelete = actionType === 'delete';

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-sm w-full p-6 sm:p-7 shadow-2xl text-slate-800 relative overflow-hidden">
        {/* Botón cerrar */}
        <button
          onClick={onClose}
          type="button"
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Icono de seguridad */}
        <div
          className={`w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-sm border ${
            isDelete
              ? 'bg-rose-50 text-rose-600 border-rose-200'
              : 'bg-amber-50 text-amber-600 border-amber-200'
          }`}
        >
          {isDelete ? <ShieldAlert className="w-7 h-7" /> : <Lock className="w-7 h-7" />}
        </div>

        {/* Título y descripción */}
        <h3 className="text-base font-black text-slate-900 text-center mb-1 tracking-tight">
          {title}
        </h3>
        <p className="text-xs text-slate-500 text-center mb-5 leading-relaxed">
          {description}
        </p>

        {/* Formulario de PIN */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-[11px] uppercase tracking-wider text-slate-600 block mb-1.5 font-bold text-center">
              PIN de 4 dígitos de Reyna:
            </label>
            <input
              type="password"
              maxLength={4}
              autoFocus
              required
              value={pin}
              onChange={(e) => {
                setPin(e.target.value.replace(/\D/g, ''));
                setError(false);
              }}
              placeholder="••••"
              className="w-full bg-slate-50 border-2 border-slate-300 text-slate-900 font-mono font-black rounded-2xl px-4 py-3 text-center text-2xl tracking-[0.6em] focus:border-rose-500 focus:bg-white focus:outline-none transition-all shadow-inner"
            />
            {error && (
              <p className="text-xs text-rose-600 font-bold text-center mt-2 animate-bounce">
                ⚠️ PIN incorrecto. Exclusivo para Reyna Amaya.
              </p>
            )}
          </div>

          <div className="flex gap-2 pt-1">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className={`flex-1 py-2.5 px-4 rounded-xl text-white font-black text-xs shadow-md transition-all active:scale-95 flex items-center justify-center gap-1.5 ${
                isDelete
                  ? 'bg-rose-600 hover:bg-rose-500 shadow-rose-600/30'
                  : 'bg-slate-900 hover:bg-slate-800 shadow-slate-900/30'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{actionLabel}</span>
            </button>
          </div>
        </form>

        {/* Nota al pie */}
        <div className="mt-4 pt-3 border-t border-slate-100 text-center">
          <span className="text-[10px] text-slate-400 font-medium">
            Taller Amaya • Control Administrativo de Seguridad
          </span>
        </div>
      </div>
    </div>
  );
};
