'use client';

import React from 'react';
import { WorkOrder, Vehicle, Client, Company, TallerConfig } from '@/types';
import {
  X,
  Car,
  CheckCircle2,
  Clock,
  Wrench,
  Camera,
  DollarSign,
  Phone,
  MessageCircle,
  ShieldCheck,
  Building2,
  Copy,
  Check,
  Eye,
} from 'lucide-react';
import { ImageLightboxModal } from './ImageLightboxModal';

interface PublicClientModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: WorkOrder;
  vehicle?: Vehicle;
  client?: Client;
  company?: Company;
  config: TallerConfig;
}

export const PublicClientModal: React.FC<PublicClientModalProps> = ({
  isOpen,
  onClose,
  order,
  vehicle,
  client,
  company,
  config,
}) => {
  const [copied, setCopied] = React.useState(false);
  const [lightboxOpen, setLightboxOpen] = React.useState(false);
  const [lightboxIndex, setLightboxIndex] = React.useState(0);

  const fotosEntradaList = React.useMemo(() => {
    if (!order?.fotosEntrada) return [];
    const labels: Record<string, string> = {
      frente: '1. Frente',
      trasera: '2. Trasera',
      lateralIzquierdo: '3. Lateral Izquierdo',
      lateralDerecho: '4. Lateral Derecho',
      motor: '5. Bahía Motor',
      odometro: '6. Tablero / Odómetro',
      interior: '7. Interior / Asientos',
      cajuela: '8. Cajuela / Maletero',
    };
    return Object.entries(order.fotosEntrada)
      .filter(([, url]) => Boolean(url))
      .map(([key, url]) => ({
        url: url as string,
        title: labels[key] || key.charAt(0).toUpperCase() + key.slice(1),
      }));
  }, [order?.fotosEntrada]);

  if (!isOpen) return null;

  const publicUrl = `https://talleramaya.com/seguimiento/${order.folio}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(publicUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const whatsAppShareText = encodeURIComponent(
    `Hola ${client?.nombre || 'Estimado Cliente'}, aquí puedes consultar el estatus en vivo, fotos de inspección y presupuesto de tu vehículo en *TALLER AMAYA*:\n\n🚗 *${vehicle?.marca} ${vehicle?.modelo}* (Placas: *${vehicle?.placas}*)\n📋 Folio de Servicio: *#${order.folio}*\n📊 Estatus Actual: *${order.estado.toUpperCase()}*\n\nConsulta el avance aquí:\n${publicUrl}\n\nEstamos a tus órdenes en C. Santo Domingo #19950, Tijuana B.C.`
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl relative text-slate-800">
        {/* Barra superior de control */}
        <div className="sticky top-0 bg-white/95 backdrop-blur-sm p-4 border-b border-slate-200 flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Simulación Vista Móvil del Cliente</span>
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Header con Branding de Taller Amaya */}
          <div className="text-center pb-4 border-b border-slate-200">
            <div className="w-28 h-20 rounded-2xl bg-white p-2 mx-auto flex items-center justify-center shadow-md border border-slate-200 mb-3">
              <img
                src="/logo-taller-amaya.png"
                alt="Taller Amaya"
                className="w-full h-full object-contain"
              />
            </div>
            <h2 className="text-2xl font-black tracking-wider text-slate-900">TALLER AMAYA</h2>
            <span className="text-xs font-extrabold text-rose-600 uppercase tracking-widest block">
              SERVICIO MECÁNICO
            </span>
            <p className="text-xs text-slate-500 mt-1">{config.direccion}</p>
            <p className="text-xs text-rose-600 font-semibold mt-0.5">
              Tel: {config.telefonoLocal} | WhatsApp: {config.whatsapp}
            </p>
          </div>

          {/* Tarjeta del Vehículo y Folio */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <span className="text-xs text-slate-500 block font-medium">Orden de Trabajo:</span>
                <span className="font-mono text-xl font-black text-rose-600">
                  Folio #{order.folio}
                </span>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-500 block font-medium">Placas:</span>
                <span className="font-mono text-lg font-black bg-white text-rose-700 px-2.5 py-0.5 rounded border border-rose-200">
                  {vehicle?.placas}
                </span>
              </div>
            </div>

            <div className="mt-3 pt-3 border-t border-slate-200 grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-slate-500 block">Vehículo:</span>
                <strong className="text-slate-800 text-sm">
                  {vehicle?.marca} {vehicle?.modelo} ({vehicle?.ano})
                </strong>
              </div>
              <div>
                <span className="text-slate-500 block">Cliente:</span>
                <strong className="text-slate-800 text-sm">
                  {company ? company.razonSocial : client?.nombre}
                </strong>
              </div>
            </div>
          </div>

          {/* Línea de Tiempo del Estatus */}
          <div>
            <span className="text-xs font-bold text-slate-600 uppercase tracking-wider block mb-3">
              Estatus del Servicio en Taller:
            </span>
            <div className="grid grid-cols-4 gap-2 text-center text-xs">
              {[
                { key: 'recepcion', label: '1. Recepción', done: true },
                {
                  key: 'en_proceso',
                  label: '2. En Bahía',
                  done: order.estado !== 'recepcion',
                },
                {
                  key: 'listo',
                  label: '3. Terminado',
                  done: order.estado === 'listo' || order.estado === 'entregado',
                },
                {
                  key: 'entregado',
                  label: '4. Entregado',
                  done: order.estado === 'entregado',
                },
              ].map((step) => (
                <div
                  key={step.key}
                  className={`p-2.5 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                    step.done
                      ? 'bg-rose-50 border-rose-300 text-rose-700 font-bold shadow-sm'
                      : 'bg-slate-50 border-slate-200 text-slate-400'
                  }`}
                >
                  <span className="text-xs">{step.label}</span>
                  {step.done ? (
                    <CheckCircle2 className="w-4 h-4 text-rose-600" />
                  ) : (
                    <Clock className="w-4 h-4 text-slate-400" />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Fotos de Entrada de Cotejo */}
          {fotosEntradaList.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1.5">
                  <Camera className="w-4 h-4 text-rose-600" />
                  <span>Fotos de Inspección al Recibir ({fotosEntradaList.length} Registradas):</span>
                </span>
                <span className="text-[10px] text-rose-600 font-bold bg-rose-50 px-2 py-0.5 rounded-full border border-rose-100">
                  Clic para ampliar
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {fotosEntradaList.map((photo, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      setLightboxIndex(idx);
                      setLightboxOpen(true);
                    }}
                    className="rounded-xl overflow-hidden border border-slate-200 bg-slate-100 aspect-video relative group shadow-sm cursor-pointer hover:border-rose-400 transition-all"
                    title="Clic para ver foto en tamaño grande"
                  >
                    <img src={photo.url} alt={photo.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <span className="p-1 bg-white/95 text-slate-900 rounded text-[9px] font-bold flex items-center gap-1 shadow">
                        <Eye className="w-3 h-3 text-rose-600" />
                        <span>Ver Grande</span>
                      </span>
                    </div>
                    <span className="absolute bottom-0 inset-x-0 bg-white/90 text-[10px] text-center text-slate-800 font-semibold py-0.5 capitalize border-t border-slate-200 truncate px-1">
                      {photo.title}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Desglose Transparente de Servicios y Refacciones */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
              Desglose de Trabajos Realizados:
            </span>

            <div className="space-y-2">
              {order.servicios.map((srv) => (
                <div
                  key={srv.id}
                  className="flex items-center justify-between text-xs bg-white p-2.5 rounded-lg border border-slate-200 shadow-sm"
                >
                  <div>
                    <span className="font-semibold text-slate-800 block">{srv.concepto}</span>
                    <span className="text-[11px] text-slate-500">
                      Técnico responsable: {srv.mecanicoNombre}
                    </span>
                  </div>
                  <span className="font-mono font-bold text-slate-900 text-sm">
                    ${(srv.manoObra + srv.refaccionesMonto).toLocaleString()} MXN
                  </span>
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-slate-200 space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-500">
                <span>Subtotal General:</span>
                <span className="font-mono text-slate-800">
                  ${order.subtotalGeneral.toLocaleString()} MXN
                </span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Total Abonado / Pagado:</span>
                <span className="font-mono text-emerald-600 font-semibold">
                  ${order.totalPagado.toLocaleString()} MXN
                </span>
              </div>
              <div className="flex justify-between text-base font-bold text-slate-800 pt-2 border-t border-slate-200">
                <span>Saldo por Liquidar:</span>
                <span
                  className={`font-mono text-lg font-black ${
                    order.saldoPendiente > 0 ? 'text-rose-600' : 'text-emerald-600'
                  }`}
                >
                  ${order.saldoPendiente.toLocaleString()} MXN
                </span>
              </div>
            </div>
          </div>

          {/* Datos para Pagar por Transferencia BBVA */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs space-y-1.5">
            <span className="font-bold text-slate-800 block mb-1">
              ¿Deseas pagar por Transferencia Bancaria?
            </span>
            <div className="text-slate-700 space-y-0.5 font-mono text-[11px]">
              <div>Banco: <strong>{config.banco}</strong></div>
              <div>Beneficiario: <strong>{config.razonSocial}</strong></div>
              <div>Cuenta: <strong>{config.cuenta}</strong></div>
              <div>CLABE: <strong className="text-emerald-600">{config.clabe}</strong></div>
            </div>
            <p className="text-[10px] text-slate-500 pt-1">
              * Nota: Pagos por transferencia causan 8% de IVA (Zona Fronteriza).
            </p>
          </div>

          {/* Botones para Enviar por WhatsApp al Cliente */}
          <div className="flex flex-wrap gap-3 pt-2 border-t border-slate-200">
            <button
              onClick={handleCopyLink}
              className="flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs border border-slate-200 transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>¡Enlace Copiado!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copiar Enlace de Seguimiento</span>
                </>
              )}
            </button>

            <a
              href={`https://wa.me/?text=${whatsAppShareText}`}
              target="_blank"
              rel="noreferrer"
              className="flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all active:scale-95"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Enviar al Cliente por WhatsApp</span>
            </a>
          </div>
        </div>
      </div>

      {/* Lightbox para ver fotos de cliente en tamaño grande */}
      <ImageLightboxModal
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        photos={fotosEntradaList}
        initialIndex={lightboxIndex}
      />
    </div>
  );
};
