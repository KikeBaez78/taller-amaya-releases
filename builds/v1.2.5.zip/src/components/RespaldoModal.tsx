'use client';

import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Download,
  Database,
  RefreshCw,
  HardDrive,
  Calendar,
  Clock,
  FileCheck,
  AlertTriangle,
  X,
  Lock,
  RotateCcw,
} from 'lucide-react';
import { StorageService } from '@/lib/storage';
import { ReinaSecurityModal } from '@/components/ReinaSecurityModal';

interface BackupItem {
  filename: string;
  sizeBytes: number;
  sizeFormatted: string;
  createdAt: string;
  isToday: boolean;
  type: 'diario' | 'manual' | 'seguridad';
}

interface RespaldoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RespaldoModal: React.FC<RespaldoModalProps> = ({ isOpen, onClose }) => {
  const [backups, setBackups] = useState<BackupItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [creating, setCreating] = useState(false);
  const [msg, setMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Modal de PIN para restauración
  const [showPinModal, setShowPinModal] = useState(false);
  const [backupToRestore, setBackupToRestore] = useState<string | null>(null);

  const fetchBackups = async () => {
    setLoading(true);
    try {
      const data = await StorageService.getBackupList();
      if (data && data.backups) {
        setBackups(data.backups);
      }
    } catch {
      // Ignorar
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchBackups();
      setMsg(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleDownloadDirect = () => {
    StorageService.downloadBackup();
    setMsg({
      text: '¡Respaldo descargado con éxito! Guárdalo en una memoria USB o carpeta segura.',
      type: 'success',
    });
  };

  const handleCreateManual = async () => {
    setCreating(true);
    setMsg(null);
    try {
      const res = await StorageService.createManualBackup('manual_usuario');
      if (res.success) {
        setMsg({ text: '✅ Respaldo manual generado correctamente.', type: 'success' });
        await fetchBackups();
      } else {
        setMsg({ text: res.error || 'Error al generar respaldo.', type: 'error' });
      }
    } catch (e: any) {
      setMsg({ text: e.message, type: 'error' });
    } finally {
      setCreating(false);
    }
  };

  const handleDownloadSpecificFile = (filename: string) => {
    const link = document.createElement('a');
    link.href = `/api/backup?action=download_file&file=${encodeURIComponent(filename)}`;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleRequestRestore = (filename: string) => {
    setBackupToRestore(filename);
    setShowPinModal(true);
  };

  const handlePinSuccess = async () => {
    if (!backupToRestore) return;
    setShowPinModal(false);
    setLoading(true);
    setMsg(null);
    try {
      const res = await StorageService.restoreBackup(backupToRestore, '2036');
      if (res.success) {
        alert(`✅ Base de datos restaurada con éxito desde ${backupToRestore}. El sistema se recargará.`);
        window.location.reload();
      } else {
        setMsg({ text: res.error || 'Error al restaurar.', type: 'error' });
      }
    } catch (e: any) {
      setMsg({ text: e.message, type: 'error' });
    } finally {
      setLoading(false);
      setBackupToRestore(null);
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
        <div className="bg-white border border-slate-200 rounded-3xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-slate-800">
          {/* Cabecera */}
          <div className="p-5 bg-gradient-to-r from-slate-900 to-slate-800 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-black flex items-center gap-2">
                  <span>Respaldos Automáticos del Sistema</span>
                  <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Activo 24/7
                  </span>
                </h2>
                <p className="text-xs text-slate-300">
                  Protección garantizada de órdenes, clientes, vehículos y cortes de caja
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-700/50 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cuerpo */}
          <div className="p-5 overflow-y-auto space-y-4 flex-1 bg-slate-50/50">
            {/* Mensajes de alerta */}
            {msg && (
              <div
                className={`p-3 rounded-2xl text-xs font-semibold flex items-center gap-2 border ${
                  msg.type === 'success'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : 'bg-rose-50 text-rose-800 border-rose-200'
                }`}
              >
                {msg.type === 'success' ? (
                  <FileCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                )}
                <span>{msg.text}</span>
              </div>
            )}

            {/* Tarjeta de Estado del Respaldo Automático */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Protección Automática en Segundo Plano</span>
                </div>
                <span className="text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800 px-2.5 py-0.5 rounded-full">
                  Rotación 30 días
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Cada vez que se guarda una orden, pago o corte, el sistema verifica y actualiza
                el respaldo diario en disco. Los últimos 30 días se mantienen protegidos localmente en
                la laptop sin ocupar espacio excesivo.
              </p>
            </div>

            {/* Acciones Rápidas de Descarga y Respaldo Manual */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Botón Descargar Copia a USB */}
              <button
                type="button"
                onClick={handleDownloadDirect}
                className="p-4 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white shadow-md shadow-emerald-700/20 text-left transition-all group cursor-pointer flex flex-col justify-between"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-black uppercase tracking-wider text-emerald-100">
                    Copia Inmediata
                  </span>
                  <Download className="w-5 h-5 text-white group-hover:scale-110 transition-transform" />
                </div>
                <div>
                  <strong className="text-sm font-bold block">Descargar a USB / PC</strong>
                  <span className="text-[11px] text-emerald-100/90 leading-tight block mt-0.5">
                    Exporta la base de datos completa a un archivo .json listo para guardar en USB.
                  </span>
                </div>
              </button>

              {/* Botón Respaldo Manual en Disco */}
              <button
                type="button"
                onClick={handleCreateManual}
                disabled={creating}
                className="p-4 rounded-2xl bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 shadow-sm text-left transition-all group cursor-pointer flex flex-col justify-between disabled:opacity-50"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-black uppercase tracking-wider text-slate-500">
                    Punto de Control
                  </span>
                  <HardDrive className="w-5 h-5 text-slate-700 group-hover:scale-110 transition-transform" />
                </div>
                <div>
                  <strong className="text-sm font-bold block text-slate-900">
                    {creating ? 'Guardando Respaldo...' : 'Crear Snapshot Manual'}
                  </strong>
                  <span className="text-[11px] text-slate-500 leading-tight block mt-0.5">
                    Guarda una copia extra con la hora y fecha exacta en la memoria interna de la laptop.
                  </span>
                </div>
              </button>
            </div>

            {/* Lista de Respaldos Históricos en la Laptop */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-slate-500" />
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                    Respaldos Disponibles en Disco ({backups.length})
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={fetchBackups}
                  className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
                  title="Refrescar lista"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                </button>
              </div>

              {backups.length === 0 ? (
                <div className="text-center py-6 text-slate-400 text-xs">
                  {loading ? 'Cargando respaldos...' : 'No se han generado respaldos aún'}
                </div>
              ) : (
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {backups.map((b) => (
                    <div
                      key={b.filename}
                      className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3 text-xs"
                    >
                      <div className="flex-1 truncate">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-slate-900 truncate">
                            {b.filename}
                          </span>
                          {b.isToday && (
                            <span className="text-[9px] font-bold uppercase px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800">
                              Hoy
                            </span>
                          )}
                          <span
                            className={`text-[9px] font-bold uppercase px-1.5 py-0.2 rounded ${
                              b.type === 'manual'
                                ? 'bg-blue-100 text-blue-700'
                                : b.type === 'seguridad'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-slate-200 text-slate-700'
                            }`}
                          >
                            {b.type}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-3">
                          <span>
                            {new Date(b.createdAt).toLocaleString('es-MX', {
                              dateStyle: 'short',
                              timeStyle: 'short',
                            })}
                          </span>
                          <span>•</span>
                          <span className="font-mono">{b.sizeFormatted}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {/* Descargar este archivo */}
                        <button
                          type="button"
                          onClick={() => handleDownloadSpecificFile(b.filename)}
                          className="p-1.5 text-slate-600 hover:text-emerald-700 rounded-lg hover:bg-emerald-50 border border-transparent hover:border-emerald-200 transition-colors"
                          title="Descargar este archivo de respaldo"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </button>

                        {/* Restaurar este archivo (con PIN) */}
                        <button
                          type="button"
                          onClick={() => handleRequestRestore(b.filename)}
                          className="px-2 py-1 text-[11px] font-bold text-slate-700 hover:text-rose-700 rounded-lg hover:bg-rose-50 border border-slate-200 hover:border-rose-200 transition-colors flex items-center gap-1"
                          title="Restaurar base de datos a este punto (requiere PIN)"
                        >
                          <RotateCcw className="w-3 h-3 text-rose-500" />
                          <span>Restaurar</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Pie */}
          <div className="p-4 bg-white border-t border-slate-200 flex items-center justify-between">
            <span className="text-[11px] text-slate-500">
              Ubicación en laptop: <code className="font-mono bg-slate-100 px-1 py-0.5 rounded">src/data/backups/</code>
            </span>
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors"
            >
              Cerrar
            </button>
          </div>
        </div>
      </div>

      {/* Modal de PIN para autorizar restauración de respaldo */}
      <ReinaSecurityModal
        isOpen={showPinModal}
        onClose={() => {
          setShowPinModal(false);
          setBackupToRestore(null);
        }}
        onSuccess={handlePinSuccess}
        title="Restaurar Respaldo de Base de Datos"
        description={`Está a punto de sobreescribir la base de datos actual con el respaldo "${backupToRestore}". Ingrese el PIN de administración (Reyna Amaya) para confirmar.`}
        actionLabel="Restaurar Respaldo"
        actionType="admin"
      />
    </>
  );
};
