'use client';

import React, { useState } from 'react';
import { StorageService } from '@/lib/storage';
import { CashRegisterShift, CashExpense, PaymentMethod, WorkOrder } from '@/types';
import { ReinaSecurityModal } from './ReinaSecurityModal';
import {
  DollarSign,
  CreditCard,
  Building2,
  TrendingDown,
  TrendingUp,
  Receipt,
  Plus,
  Lock,
  Unlock,
  AlertCircle,
  CheckCircle,
  FileText,
  Calendar,
  Edit2,
  Trash2,
  Save,
  X,
} from 'lucide-react';

interface CajaModalProps {
  onOrderPaid?: () => void;
}

export const CajaModal: React.FC<CajaModalProps> = ({ onOrderPaid }) => {
  const [shift, setShift] = useState<CashRegisterShift>(StorageService.getCashShift());
  const config = StorageService.getConfig();
  const workOrders = StorageService.getWorkOrders();

  // Estados para nuevo gasto menor
  const [isAddingExpense, setIsAddingExpense] = useState(false);
  const [expenseDesc, setExpenseDesc] = useState('');
  const [expenseAmount, setExpenseAmount] = useState<number>(150);
  const [expenseCategory, setExpenseCategory] = useState<
    'solventes' | 'tornilleria' | 'alimentos' | 'herramienta' | 'otro'
  >('solventes');
  const [expenseAuthorized, setExpenseAuthorized] = useState('Carlos Amaya');

  // Estados para edición de gasto menor existente
  const [editingExpenseId, setEditingExpenseId] = useState<string | null>(null);
  const [editExpenseDesc, setEditExpenseDesc] = useState('');
  const [editExpenseAmount, setEditExpenseAmount] = useState<number>(0);
  const [editExpenseCategory, setEditExpenseCategory] = useState<
    'solventes' | 'tornilleria' | 'alimentos' | 'herramienta' | 'otro'
  >('solventes');
  const [editExpenseAuthorized, setEditExpenseAuthorized] = useState('');

  // Estados para eliminación y edición con PIN de seguridad de Reyna Amaya (2036)
  const [expenseToAuthorizeDelete, setExpenseToAuthorizeDelete] = useState<CashExpense | null>(null);
  const [expenseToAuthorizeEdit, setExpenseToAuthorizeEdit] = useState<CashExpense | null>(null);

  // Estados para cobro de orden
  const [isPayingOrder, setIsPayingOrder] = useState(false);
  const [selectedOrderId, setSelectedOrderId] = useState<string>(
    workOrders.find((o) => o.saldoPendiente > 0)?.id || workOrders[0]?.id || ''
  );
  const [payMethod, setPayMethod] = useState<PaymentMethod>('efectivo');
  const [payAmount, setPayAmount] = useState<number>(0);
  const [payRef, setPayRef] = useState('');

  // Estados para Arqueo de caja
  const [isDoingArqueo, setIsDoingArqueo] = useState(false);
  const [countedCash, setCountedCash] = useState<number>(shift.efectivoEsperado);
  const [arqueoNotes, setArqueoNotes] = useState('');

  // Calcular orden seleccionada para cobro
  const selectedOrder = workOrders.find((o) => o.id === selectedOrderId);

  // Al cambiar la orden seleccionada, precargar su saldo pendiente
  const handleSelectOrderForPay = (orderId: string) => {
    setSelectedOrderId(orderId);
    const ord = workOrders.find((o) => o.id === orderId);
    if (ord) {
      setPayAmount(ord.saldoPendiente);
    }
  };

  // Cálculo del 8% de IVA en frontera para tarjeta o transferencia
  const appliesIva8 = payMethod === 'tarjeta' || payMethod === 'transferencia';
  const ivaCalculado = appliesIva8 ? Math.round(payAmount * 0.08) : 0;
  const totalConIva = payAmount + ivaCalculado;

  // Registrar Gasto Menor
  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expenseDesc.trim() || expenseAmount <= 0) return;

    const updated = StorageService.addExpense({
      fecha: new Date().toISOString().replace('T', ' ').substring(0, 16),
      descripcion: expenseDesc.trim(),
      monto: Number(expenseAmount),
      categoria: expenseCategory,
      autorizadoPor: expenseAuthorized.trim() || 'Carlos Amaya',
    });

    setShift(updated);
    setIsAddingExpense(false);
    setExpenseDesc('');
    setExpenseAmount(150);
  };

  // Abrir modal de edición de gasto
  const handleStartEditExpense = (gasto: CashExpense) => {
    setEditingExpenseId(gasto.id);
    setEditExpenseDesc(gasto.descripcion);
    setEditExpenseAmount(gasto.monto);
    setEditExpenseCategory(gasto.categoria);
    setEditExpenseAuthorized(gasto.autorizadoPor);
  };

  // Guardar edición de gasto
  const handleSaveEditExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingExpenseId || !editExpenseDesc.trim() || editExpenseAmount <= 0) return;

    const updated = StorageService.updateExpense(editingExpenseId, {
      descripcion: editExpenseDesc.trim(),
      monto: Number(editExpenseAmount),
      categoria: editExpenseCategory,
      autorizadoPor: editExpenseAuthorized.trim() || 'Carlos Amaya',
    });

    setShift(updated);
    setEditingExpenseId(null);
  };

  // Confirmar eliminación con PIN de Reyna (2036)
  const handleConfirmDeleteExpense = () => {
    if (!expenseToAuthorizeDelete) return;
    const updated = StorageService.deleteExpense(expenseToAuthorizeDelete.id);
    setShift(updated);
    setExpenseToAuthorizeDelete(null);
  };

  // Confirmar desbloqueo de edición con PIN de Reyna (2036)
  const handleConfirmUnlockEdit = () => {
    if (!expenseToAuthorizeEdit) return;
    handleStartEditExpense(expenseToAuthorizeEdit);
    setExpenseToAuthorizeEdit(null);
  };

  // Procesar Cobro de Orden de Servicio
  const handleProcessPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOrder || payAmount <= 0) return;

    // Actualizar orden de trabajo
    selectedOrder.totalPagado += payAmount;
    selectedOrder.saldoPendiente = Math.max(0, selectedOrder.subtotalGeneral - selectedOrder.totalPagado);
    selectedOrder.metodoPago = payMethod;
    if (selectedOrder.saldoPendiente === 0) {
      selectedOrder.estado = 'entregado';
    }

    StorageService.saveWorkOrder(selectedOrder);

    // Sumar a la caja según el método de pago
    const currentShift = StorageService.getCashShift();
    if (payMethod === 'efectivo') {
      currentShift.ingresosEfectivo += payAmount;
      currentShift.efectivoEsperado += payAmount;
    } else if (payMethod === 'tarjeta') {
      currentShift.ingresosTarjeta += totalConIva;
    } else if (payMethod === 'transferencia') {
      currentShift.ingresosTransferencia += totalConIva;
    }

    StorageService.saveCashShift(currentShift);
    setShift(currentShift);

    alert(`¡Pago de $${totalConIva} MXN registrado correctamente! Folio #${selectedOrder.folio}`);
    setIsPayingOrder(false);
    if (onOrderPaid) onOrderPaid();
  };

  // Cerrar Turno / Corte de Caja
  const handleCloseShift = (e: React.FormEvent) => {
    e.preventDefault();
    const diff = countedCash - shift.efectivoEsperado;

    const closedShift: CashRegisterShift = {
      ...shift,
      fechaCierre: new Date().toISOString().replace('T', ' ').substring(0, 16),
      efectivoRealContado: Number(countedCash),
      diferencia: diff,
      estado: 'cerrada',
      observaciones: arqueoNotes.trim(),
    };

    StorageService.saveCashShift(closedShift);
    setShift(closedShift);
    setIsDoingArqueo(false);
    alert(
      `Corte de caja completado.\nEfectivo esperado: $${shift.efectivoEsperado}\nContado: $${countedCash}\nDiferencia: $${diff}`
    );
  };

  // Abrir nuevo turno con fondo inicial ($500 - $1,000 MXN)
  const handleOpenNewShift = (fondo: number) => {
    const newShift: CashRegisterShift = {
      id: `caja-${Date.now()}`,
      fechaApertura: new Date().toISOString().replace('T', ' ').substring(0, 16),
      fondoInicial: fondo,
      ingresosEfectivo: 0,
      ingresosTarjeta: 0,
      ingresosTransferencia: 0,
      gastosMenores: [],
      totalGastosMenores: 0,
      efectivoEsperado: fondo,
      estado: 'abierta',
      cajero: 'Reyna Amaya (Administración)',
    };
    StorageService.saveCashShift(newShift);
    setShift(newShift);
    alert(`Nuevo turno de caja abierto con fondo inicial de $${fondo} MXN.`);
  };

  return (
    <div className="space-y-6">
      {/* Banner Principal de Caja */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-rose-600 text-xs font-bold uppercase tracking-wider mb-1">
            <DollarSign className="w-4 h-4" />
            <span>Control de Caja, Salidas y Arqueo Diario</span>
          </div>
          <h2 className="text-2xl font-black text-slate-800">
            Caja Registradora & Cortes de Turno
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Fondo inicial configurado: <strong>${shift.fondoInicial} MXN</strong> | Se aplica <strong>8% de IVA</strong> en tarjeta y transferencia.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {shift.estado === 'abierta' ? (
            <>
              <button
                onClick={() => setIsAddingExpense(true)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs border border-slate-200 transition-colors"
              >
                <TrendingDown className="w-4 h-4 text-rose-600" />
                <span>Salida de Caja (Gasto)</span>
              </button>

              <button
                onClick={() => {
                  const firstPending = workOrders.find((o) => o.saldoPendiente > 0);
                  if (firstPending) {
                    handleSelectOrderForPay(firstPending.id);
                  }
                  setIsPayingOrder(true);
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-all active:scale-95"
              >
                <Plus className="w-4 h-4" />
                <span>Cobrar Orden</span>
              </button>

              <button
                onClick={() => {
                  setCountedCash(shift.efectivoEsperado);
                  setIsDoingArqueo(true);
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs shadow-sm transition-all"
              >
                <Lock className="w-4 h-4" />
                <span>Realizar Corte Diario</span>
              </button>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <span className="text-xs text-rose-600 font-bold">Caja Cerrada</span>
              <button
                onClick={() => handleOpenNewShift(1000)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md"
              >
                <Unlock className="w-4 h-4" />
                <span>Abrir Caja ($1,000 Fondo)</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Tarjetas de Saldos de Caja */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Efectivo Esperado en Cajón */}
        <div className="bg-white border border-emerald-300 rounded-2xl p-5 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
            <span>Efectivo Físico Esperado</span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
          </div>
          <div className="font-mono text-2xl font-black text-emerald-600 mt-1">
            ${shift.efectivoEsperado.toLocaleString()} MXN
          </div>
          <div className="text-[11px] text-slate-500 mt-2 space-y-0.5 border-t border-slate-100 pt-2">
            <div>Fondo Inicial: <strong>${shift.fondoInicial}</strong></div>
            <div>Entradas Efectivo: <strong>+${shift.ingresosEfectivo}</strong></div>
            <div>Gastos Taller: <strong className="text-rose-600">-${shift.totalGastosMenores}</strong></div>
          </div>
        </div>

        {/* Tarjetas Bancarias */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
            <span>Cobros con Tarjeta (+8% IVA)</span>
            <CreditCard className="w-4 h-4 text-sky-600" />
          </div>
          <div className="font-mono text-2xl font-black text-sky-600 mt-1">
            ${shift.ingresosTarjeta.toLocaleString()} MXN
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Vouchers procesados por terminal bancaria
          </p>
        </div>

        {/* Transferencias Bancarias BBVA */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
            <span>Transferencias BBVA (+8% IVA)</span>
            <Building2 className="w-4 h-4 text-rose-600" />
          </div>
          <div className="font-mono text-2xl font-black text-slate-800 mt-1">
            ${shift.ingresosTransferencia.toLocaleString()} MXN
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            CLABE: 012028004778816301
          </p>
        </div>

        {/* Total Salidas / Gastos Menores */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
            <span>Salidas / Gastos del Día</span>
            <TrendingDown className="w-4 h-4 text-rose-600" />
          </div>
          <div className="font-mono text-2xl font-black text-rose-600 mt-1">
            ${shift.totalGastosMenores.toLocaleString()} MXN
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Solventes, tornillería urgente y víveres
          </p>
        </div>
      </div>

      {/* Historial de Gastos Menores del Turno */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wide flex items-center gap-2">
            <Receipt className="w-4 h-4 text-rose-600" />
            <span>Salidas de Caja Registradas ({shift.gastosMenores.length})</span>
          </h3>
          <span className="text-xs text-slate-400">
            Se descuentan automáticamente del efectivo en el corte de caja
          </span>
        </div>

        {shift.gastosMenores.length === 0 ? (
          <p className="text-xs text-slate-500 italic bg-slate-50 p-4 rounded-xl border border-slate-100">
            No se han registrado salidas de caja menores en este turno.
          </p>
        ) : (
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold bg-slate-50">
                  <th className="py-2.5 px-3">Hora / Fecha</th>
                  <th className="py-2.5 px-3">Categoría</th>
                  <th className="py-2.5 px-3">Descripción</th>
                  <th className="py-2.5 px-3">Autorizado Por</th>
                  <th className="py-2.5 px-3 text-right">Monto</th>
                  <th className="py-2.5 px-3 text-center w-20">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {shift.gastosMenores.map((gasto) => (
                  <tr key={gasto.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-2.5 px-3 text-slate-500 font-mono">{gasto.fecha}</td>
                    <td className="py-2.5 px-3">
                      <span className="capitalize px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium border border-slate-200">
                        {gasto.categoria}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-medium text-slate-800">{gasto.descripcion}</td>
                    <td className="py-2.5 px-3 text-slate-500">{gasto.autorizadoPor}</td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-600">
                      -${gasto.monto.toLocaleString()} MXN
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => setExpenseToAuthorizeEdit(gasto)}
                          className="p-1 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 transition-colors"
                          title="Modificar salida de caja (Requiere PIN de Reyna: 2036)"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setExpenseToAuthorizeDelete(gasto)}
                          className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                          title="Eliminar salida de caja (Requiere PIN de Reyna: 2036)"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* MODAL PARA REGISTRAR GASTO MENOR */}
      {isAddingExpense && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full p-6 shadow-2xl text-slate-800">
            <h3 className="text-lg font-bold text-slate-800 mb-1">Registrar Salida de Caja Menor</h3>
            <p className="text-xs text-slate-500 mb-4">
              Gastos imprevistos de taller que se descuentan del efectivo al cierre
            </p>

            <form onSubmit={handleAddExpense} className="space-y-4">
              <div>
                <label className="text-xs text-slate-600 block mb-1 font-medium">Categoría:</label>
                <select
                  value={expenseCategory}
                  onChange={(e) =>
                    setExpenseCategory(
                      e.target.value as 'solventes' | 'tornilleria' | 'alimentos' | 'herramienta' | 'otro'
                    )
                  }
                  className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none capitalize"
                >
                  <option value="solventes">Solventes / Químicos / Estopa</option>
                  <option value="tornilleria">Tornillería / Ferretería urgente</option>
                  <option value="alimentos">Comida / Garrafón de agua / Taller</option>
                  <option value="herramienta">Herramienta menor</option>
                  <option value="otro">Otro gasto menor</option>
                </select>
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1 font-medium">
                  Descripción del Gasto *:
                </label>
                <input
                  type="text"
                  value={expenseDesc}
                  onChange={(e) => setExpenseDesc(e.target.value)}
                  placeholder="Ej. Thinner estándar y estopa para bahía 2..."
                  required
                  className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-rose-600 block mb-1 font-bold">
                  Monto a Descontar ($ MXN) *:
                </label>
                <input
                  type="number"
                  value={expenseAmount}
                  onChange={(e) => setExpenseAmount(Number(e.target.value))}
                  required
                  className="w-full bg-rose-50/40 border border-rose-300 text-rose-700 font-mono font-bold rounded-lg px-3 py-2 text-sm focus:outline-none text-right"
                />
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1 font-medium">
                  Autorizado Por:
                </label>
                <input
                  type="text"
                  value={expenseAuthorized}
                  onChange={(e) => setExpenseAuthorized(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddingExpense(false)}
                  className="flex-1 py-2 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-all active:scale-95"
                >
                  Confirmar Salida
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL PARA MODIFICAR / EDITAR GASTO MENOR EXISTENTE */}
      {editingExpenseId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full p-6 shadow-2xl text-slate-800">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <Edit2 className="w-5 h-5 text-amber-600" />
                <span>Modificar Salida de Caja</span>
              </h3>
              <button
                type="button"
                onClick={() => setEditingExpenseId(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Ajusta la cantidad, descripción o categoría de este gasto menor. Los totales de caja se recalcularán automáticamente.
            </p>

            <form onSubmit={handleSaveEditExpense} className="space-y-4">
              <div>
                <label className="text-xs text-slate-600 block mb-1 font-medium">Categoría:</label>
                <select
                  value={editExpenseCategory}
                  onChange={(e) =>
                    setEditExpenseCategory(
                      e.target.value as 'solventes' | 'tornilleria' | 'alimentos' | 'herramienta' | 'otro'
                    )
                  }
                  className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none capitalize"
                >
                  <option value="solventes">Solventes / Químicos / Estopa</option>
                  <option value="tornilleria">Tornillería / Ferretería urgente</option>
                  <option value="alimentos">Comida / Garrafón de agua / Taller</option>
                  <option value="herramienta">Herramienta menor</option>
                  <option value="otro">Otro gasto menor</option>
                </select>
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1 font-medium">
                  Descripción del Gasto *:
                </label>
                <input
                  type="text"
                  value={editExpenseDesc}
                  onChange={(e) => setEditExpenseDesc(e.target.value)}
                  placeholder="Ej. Tornillos para cárter..."
                  required
                  className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-rose-600 block mb-1 font-bold">
                  Cantidad a Descontar ($ MXN) *:
                </label>
                <input
                  type="number"
                  value={editExpenseAmount}
                  onChange={(e) => setEditExpenseAmount(Number(e.target.value))}
                  required
                  className="w-full bg-rose-50/40 border border-rose-300 text-rose-700 font-mono font-bold rounded-lg px-3 py-2 text-sm focus:outline-none text-right"
                />
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1 font-medium">
                  Autorizado Por:
                </label>
                <input
                  type="text"
                  value={editExpenseAuthorized}
                  onChange={(e) => setEditExpenseAuthorized(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingExpenseId(null)}
                  className="flex-1 py-2 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-md transition-all active:scale-95 flex items-center justify-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Guardar Cambios</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal de Seguridad de Reyna para Eliminar Gasto */}
      <ReinaSecurityModal
        isOpen={!!expenseToAuthorizeDelete}
        onClose={() => setExpenseToAuthorizeDelete(null)}
        onSuccess={handleConfirmDeleteExpense}
        title="Eliminar Salida de Caja"
        description={`Para eliminar el gasto de "${expenseToAuthorizeDelete?.descripcion}" (-$${expenseToAuthorizeDelete?.monto} MXN), ingresa el PIN de Reyna Amaya.`}
        actionLabel="Eliminar Gasto"
        actionType="delete"
      />

      {/* Modal de Seguridad de Reyna para Modificar Gasto */}
      <ReinaSecurityModal
        isOpen={!!expenseToAuthorizeEdit}
        onClose={() => setExpenseToAuthorizeEdit(null)}
        onSuccess={handleConfirmUnlockEdit}
        title="Modificar Salida de Caja"
        description={`Para editar el gasto de "${expenseToAuthorizeEdit?.descripcion}" (-$${expenseToAuthorizeEdit?.monto} MXN), ingresa el PIN de Reyna Amaya.`}
        actionLabel="Desbloquear Edición"
        actionType="edit"
      />

      {/* MODAL PARA COBRAR ORDEN DE SERVICIO CON 8% IVA FRONTERA */}
      {isPayingOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full p-6 shadow-2xl text-slate-800">
            <h3 className="text-lg font-bold text-slate-800 mb-1">Registrar Cobro en Caja</h3>
            <p className="text-xs text-slate-500 mb-4">
              Pagos con tarjeta o transferencia aplican 8% de IVA (Zona Fronteriza Tijuana)
            </p>

            <form onSubmit={handleProcessPayment} className="space-y-4">
              <div>
                <label className="text-xs text-slate-600 block mb-1 font-medium">
                  Seleccionar Orden con Saldo Pendiente:
                </label>
                <select
                  value={selectedOrderId}
                  onChange={(e) => handleSelectOrderForPay(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none font-mono"
                >
                  {workOrders.map((o) => (
                    <option key={o.id} value={o.id}>
                      Folio #{o.folio} - Saldo: ${o.saldoPendiente} MXN ({o.fallaReportada.substring(0, 30)}...)
                    </option>
                  ))}
                </select>
              </div>

              {selectedOrder && (
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs flex justify-between">
                  <div>
                    <span className="text-slate-500 block">Total de la Orden:</span>
                    <strong className="text-slate-800 font-mono text-sm">
                      ${selectedOrder.subtotalGeneral} MXN
                    </strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Ya Pagado:</span>
                    <strong className="text-emerald-600 font-mono text-sm">
                      ${selectedOrder.totalPagado} MXN
                    </strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Saldo Pendiente:</span>
                    <strong className="text-rose-600 font-mono text-sm">
                      ${selectedOrder.saldoPendiente} MXN
                    </strong>
                  </div>
                </div>
              )}

              {/* Selector de Método de Pago */}
              <div>
                <label className="text-xs text-slate-600 block mb-1 font-medium">
                  Método de Pago:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['efectivo', 'tarjeta', 'transferencia'] as PaymentMethod[]).map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setPayMethod(m)}
                      className={`py-2 px-2 text-center rounded-lg border text-xs font-bold capitalize transition-all ${
                        payMethod === m
                          ? 'bg-rose-600 text-white border-rose-600 shadow-sm'
                          : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      {m === 'efectivo' ? '💵 Efectivo' : m === 'tarjeta' ? '💳 Tarjeta (+8%)' : '🏦 Transfer (+8%)'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-600 block mb-1 font-medium">
                    Monto Base a Abonar:
                  </label>
                  <input
                    type="number"
                    value={payAmount}
                    onChange={(e) => setPayAmount(Number(e.target.value))}
                    required
                    className="w-full bg-slate-50 border border-slate-300 text-slate-800 font-mono font-bold rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none text-right"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-600 block mb-1 font-medium">
                    Referencia / Folio Banco:
                  </label>
                  <input
                    type="text"
                    value={payRef}
                    onChange={(e) => setPayRef(e.target.value)}
                    placeholder="Ej. BBVA-88120"
                    className="w-full bg-slate-50 border border-slate-300 text-slate-800 font-mono rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Desglose de 8% IVA Frontera */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs space-y-1.5">
                <div className="flex justify-between text-slate-500">
                  <span>Subtotal del Cobro:</span>
                  <span className="font-mono text-slate-800">${payAmount.toLocaleString()} MXN</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>
                    IVA 8% Zona Fronteriza:
                    {appliesIva8 ? (
                      <span className="text-rose-600 text-[10px] ml-1 font-semibold">
                        (Aplica a {payMethod})
                      </span>
                    ) : (
                      <span className="text-slate-400 text-[10px] ml-1">(Exento en efectivo)</span>
                    )}
                  </span>
                  <span className="font-mono text-amber-600 font-bold">
                    +${ivaCalculado.toLocaleString()} MXN
                  </span>
                </div>
                <div className="flex justify-between text-sm font-bold text-slate-800 pt-2 border-t border-slate-200">
                  <span>Total Final a Cobrar:</span>
                  <span className="font-mono text-emerald-600 text-base font-black">
                    ${totalConIva.toLocaleString()} MXN
                  </span>
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsPayingOrder(false)}
                  className="flex-1 py-2 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-all active:scale-95"
                >
                  Confirmar Cobro
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL DE ARQUEO Y CORTE DE CAJA */}
      {isDoingArqueo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full p-6 shadow-2xl text-slate-800">
            <h3 className="text-lg font-bold text-slate-800 mb-1">
              Arqueo y Corte de Caja Diario / Semanal
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Comprobación física de efectivo contado en cajón vs cálculo del sistema
            </p>

            <form onSubmit={handleCloseShift} className="space-y-4">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs">
                <div className="flex justify-between text-slate-500">
                  <span>Fondo Inicial de Apertura:</span>
                  <span className="font-mono text-slate-800">${shift.fondoInicial} MXN</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>(+) Ingresos en Efectivo:</span>
                  <span className="font-mono text-emerald-600 font-semibold">+${shift.ingresosEfectivo} MXN</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>(-) Gastos Menores Taller:</span>
                  <span className="font-mono text-rose-600 font-semibold">-${shift.totalGastosMenores} MXN</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-slate-800 pt-2 border-t border-slate-200">
                  <span>Efectivo Esperado en Caja:</span>
                  <span className="font-mono text-emerald-600 text-base">
                    ${shift.efectivoEsperado} MXN
                  </span>
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-700 block mb-1 font-bold">
                  Efectivo Físico Contado en Cajón ($ MXN) *:
                </label>
                <input
                  type="number"
                  value={countedCash}
                  onChange={(e) => setCountedCash(Number(e.target.value))}
                  required
                  className="w-full bg-slate-50 border-2 border-slate-300 text-slate-900 font-mono font-black rounded-lg px-4 py-2.5 text-lg text-right focus:border-rose-500 focus:outline-none"
                />
              </div>

              {/* Cálculo de diferencia */}
              <div className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs">
                <span className="text-slate-500">Diferencia de Arqueo:</span>
                {countedCash - shift.efectivoEsperado === 0 ? (
                  <span className="font-mono font-bold text-emerald-600">✓ Arqueo Cuadrado ($0)</span>
                ) : countedCash - shift.efectivoEsperado > 0 ? (
                  <span className="font-mono font-bold text-amber-600">
                    Sobrante: +${countedCash - shift.efectivoEsperado} MXN
                  </span>
                ) : (
                  <span className="font-mono font-bold text-rose-600">
                    Faltante: -${Math.abs(countedCash - shift.efectivoEsperado)} MXN
                  </span>
                )}
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1 font-medium">
                  Observaciones de Cierre:
                </label>
                <textarea
                  value={arqueoNotes}
                  onChange={(e) => setArqueoNotes(e.target.value)}
                  placeholder="Notas adicionales sobre el corte del día o pendientes..."
                  rows={2}
                  className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg p-2.5 text-xs focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsDoingArqueo(false)}
                  className="flex-1 py-2 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-all active:scale-95"
                >
                  Finalizar Corte de Caja
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
