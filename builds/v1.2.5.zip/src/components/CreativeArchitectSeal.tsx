'use client';

import React from 'react';

interface CreativeArchitectSealProps {
  className?: string;
  theme?: 'light' | 'dark';
}

export const CreativeArchitectSeal: React.FC<CreativeArchitectSealProps> = ({
  className = '',
  theme = 'light',
}) => {
  const isLight = theme === 'light';

  return (
    <div
      className={`creator-hallmark inline-flex items-center gap-2 px-3 py-1.5 rounded-full transition-all duration-300 select-none cursor-default group ${
        isLight
          ? 'bg-white/80 hover:bg-white text-slate-900 border border-slate-300/80 hover:border-slate-800/80 shadow-xs backdrop-blur-xs'
          : 'bg-slate-900/40 hover:bg-slate-900/70 text-slate-100 border border-slate-700/60 hover:border-[#7ED957]/50 shadow-xs backdrop-blur-xs'
      } ${className}`}
      title="Firma de Autor: Designed & Engineered by Creative Architect"
    >
      {/* Monograma eb. en negro o blanco según el tema */}
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={isLight ? '/eb-monogram-black.png' : '/eb-monogram-white.png'}
        alt="Creative Architect"
        className="h-4 w-auto object-contain shrink-0 opacity-90 group-hover:opacity-100 transition-opacity"
      />

      {/* Tipografía sutil tipo firma */}
      <div className="flex flex-col text-left leading-tight">
        <span
          className={`text-[8.5px] uppercase tracking-widest font-medium ${
            isLight ? 'text-slate-400 group-hover:text-slate-500' : 'text-slate-400'
          }`}
        >
          Designed &amp; Engineered by
        </span>
        <span
          className={`text-[10.5px] font-bold tracking-wider uppercase flex items-center ${
            isLight ? 'text-slate-900' : 'text-white'
          }`}
        >
          Creative Architect
          {/* Punto de acento verde lima */}
          <span
            className="inline-block w-1.5 h-1.5 rounded-full bg-[#7ED957] ml-1 shadow-[0_0_6px_rgba(126,217,87,0.7)]"
            title="Creative Architect Accent Dot"
          />
        </span>
      </div>
    </div>
  );
};
