'use client';

import React, { useState } from 'react';
import { StorageService } from '@/lib/storage';
import {
  BarChart3,
  TrendingUp,
  DollarSign,
  Wrench,
  Car,
  Users,
  Calendar,
  Percent,
  Download,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';

export const DashboardReports: React.FC = () => {
  const [period, setPeriod] = useState<'semanal' | 'mensual'>('semanal');

  const workOrders = StorageService.getWorkOrders();
  const mechanics = StorageService.getMechanics();
  const companies = StorageService.getCompanies();
  const vehicles = StorageService.getVehicles();
  const shift = StorageService.getCashShift();

  // Cálculos consolidados
  const totalFacturado = workOrders.reduce((acc, o) => acc + o.subtotalGeneral, 0);
  const totalManoObra = workOrders.reduce((acc, o) => acc + o.subtotalManoObra, 0);
  const totalRefacciones = workOrders.reduce((acc, o) => acc + o.subtotalRefacciones, 0);
  const totalComisiones = workOrders.reduce((acc, o) => acc + o.totalComisionesMecanicos, 0);
  const totalPagado = workOrders.reduce((acc, o) => acc + o.totalPagado, 0);
  const totalPendiente = workOrders.reduce((acc, o) => acc + o.saldoPendiente, 0);

  // Utilidad neta estimada de mano de obra para el taller
  const utilidadTallerManoObra = totalManoObra - totalComisiones;

  return (
    <div className="space-y-6">
      {/* Banner Principal */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-rose-600 text-xs font-bold uppercase tracking-wider mb-1">
            <BarChart3 className="w-4 h-4" />
            <span>Dashboard Ejecutivo & Reportes Financieros</span>
          </div>
          <h2 className="text-2xl font-black text-slate-800">
            Rendimiento del Taller Amaya
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Métricas de ingresos, comisiones de mecánicos, cobranza y flujo de caja en Tijuana B.C.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-50 p-1 rounded-xl border border-slate-200 text-xs">
          <button
            onClick={() => setPeriod('semanal')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
              period === 'semanal'
                ? 'bg-rose-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Vista Semanal
          </button>
          <button
            onClick={() => setPeriod('mensual')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
              period === 'mensual'
                ? 'bg-rose-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Vista Mensual
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
          <span className="text-xs text-slate-500 block font-semibold">Total Facturado</span>
          <div className="font-mono text-2xl font-black text-slate-800 mt-1">
            ${totalFacturado.toLocaleString()} MXN
          </div>
          <div className="text-[11px] text-slate-400 mt-2 flex justify-between">
            <span>MO: ${totalManoObra.toLocaleString()}</span>
            <span>Refac: ${totalRefacciones.toLocaleString()}</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
          <span className="text-xs text-slate-500 block font-semibold">Comisiones a Mecánicos</span>
          <div className="font-mono text-2xl font-black text-amber-600 mt-1">
            ${totalComisiones.toLocaleString()} MXN
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            10% al 45% sobre mano de obra (refacciones 0%)
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
          <span className="text-xs text-slate-500 block font-semibold">Margen Taller (Mano de Obra)</span>
          <div className="font-mono text-2xl font-black text-emerald-600 mt-1">
            ${utilidadTallerManoObra.toLocaleString()} MXN
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Utilidad retenida post-comisiones
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
          <span className="text-xs text-slate-500 block font-semibold">Cuentas por Cobrar</span>
          <div className="font-mono text-2xl font-black text-rose-600 mt-1">
            ${totalPendiente.toLocaleString()} MXN
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Flotillas con crédito y pagos pendientes
          </p>
        </div>
      </div>

      {/* Desglose Gráfico: Rendimiento de los 4 Mecánicos */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
        <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
          <Wrench className="w-5 h-5 text-rose-600" />
          <span>Productividad y Comisiones por Técnico</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {mechanics.map((mec) => {
            let comisionMec = 0;
            let countTrabajos = 0;

            workOrders.forEach((o) => {
              o.servicios.forEach((s) => {
                if (s.mecanicoId === mec.id) {
                  comisionMec += s.comisionManoObra;
                  countTrabajos++;
                }
              });
            });

            return (
              <div key={mec.id} className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 text-sm">{mec.nombre}</span>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200">
                    {mec.comisionDefault}%
                  </span>
                </div>
                <p className="text-xs text-slate-500">{mec.especialidad}</p>
                <div className="pt-2 border-t border-slate-200 flex justify-between items-baseline text-xs">
                  <span className="text-slate-400">{countTrabajos} trabajos</span>
                  <span className="font-mono font-black text-emerald-600 text-sm">
                    ${comisionMec.toLocaleString()} MXN
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Resumen de Flujo de Efectivo en Caja */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-emerald-600" />
            <span>Desglose de Ingresos por Método de Pago & 8% IVA</span>
          </h3>

          <span className="text-xs text-slate-500 font-mono">
            Fondo Inicial en Turno: ${shift.fondoInicial} MXN
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
            <span className="text-slate-500 block font-semibold">1. Efectivo Físico</span>
            <span className="font-mono text-xl font-bold text-slate-800 block mt-1">
              ${shift.ingresosEfectivo.toLocaleString()} MXN
            </span>
            <span className="text-[11px] text-slate-400 mt-1 block">
              Menos gastos menores del taller (-${shift.totalGastosMenores})
            </span>
          </div>

          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
            <span className="text-slate-500 block font-semibold">2. Tarjeta Bancaria (+8% IVA)</span>
            <span className="font-mono text-xl font-bold text-sky-600 block mt-1">
              ${shift.ingresosTarjeta.toLocaleString()} MXN
            </span>
            <span className="text-[11px] text-slate-400 mt-1 block">
              Cobrado en terminal bancaria
            </span>
          </div>

          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
            <span className="text-slate-500 block font-semibold">3. Transferencias BBVA (+8% IVA)</span>
            <span className="font-mono text-xl font-bold text-rose-600 block mt-1">
              ${shift.ingresosTransferencia.toLocaleString()} MXN
            </span>
            <span className="text-[11px] text-slate-400 mt-1 block">
              CLABE 012028004778816301
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
