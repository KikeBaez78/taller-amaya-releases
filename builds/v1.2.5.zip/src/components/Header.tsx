'use client';

import React, { useState } from 'react';
import { TallerConfig } from '@/types';
import {
  Wrench,
  Phone,
  MessageCircle,
  MapPin,
  Building2,
  CreditCard,
  X,
  Search,
  PlusCircle,
  ClipboardList,
  Users,
  DollarSign,
  BarChart3,
  RotateCcw,
} from 'lucide-react';
import { StorageService } from '@/lib/storage';

interface HeaderProps {
  config: TallerConfig;
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onNewOrder: () => void;
  openBankModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  config,
  currentTab,
  setCurrentTab,
  onNewOrder,
  openBankModal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'bitacora', label: 'Bitácora & Búsqueda', icon: Search, badge: 'Placas/Historial' },
    { id: 'ordenes', label: 'Órdenes de Trabajo', icon: ClipboardList },
    { id: 'crm', label: 'Flotillas & CRM', icon: Users },
    { id: 'mecanicos', label: 'Taller & Comisiones', icon: Wrench, badge: '4 Mecánicos' },
    { id: 'caja', label: 'Caja & Cortes', icon: DollarSign, badge: '8% IVA' },
    { id: 'reportes', label: 'Dashboard', icon: BarChart3 },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-40 shadow-xl">
      {/* Top Banner de Identidad del Taller */}
      <div className="bg-slate-950 border-b border-slate-800/80 px-4 py-2 text-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-slate-400">
            <span className="font-semibold text-sky-400 uppercase tracking-wide">Razón Social:</span>
            <span>{config.razonSocial}</span>
            <span className="text-slate-600">|</span>
            <span className="font-semibold text-slate-300">RFC: {config.rfc}</span>
          </div>

          <div className="flex items-center gap-4 text-slate-300">
            <div className="hidden md:flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-rose-400" />
              <span>{config.direccion}</span>
            </div>
            <a
              href={`tel:${config.telefonoLocal}`}
              className="flex items-center gap-1 hover:text-sky-400 transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-sky-400" />
              <span>Tel: {config.telefonoLocal}</span>
            </a>
            <a
              href={`https://wa.me/52${config.whatsapp}`}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 transition-colors font-medium"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WA: {config.whatsapp}</span>
            </a>
            <button
              onClick={openBankModal}
              className="flex items-center gap-1 text-amber-400 hover:text-amber-300 transition-colors px-2 py-0.5 rounded bg-amber-950/40 border border-amber-800/50"
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>Datos Bancarios BBVA</span>
            </button>
            <button
              onClick={() => {
                if (confirm('¿Restablecer datos de demostración a valores de fábrica?')) {
                  StorageService.resetToInitial();
                }
              }}
              title="Restablecer datos demo"
              className="text-slate-500 hover:text-slate-300 p-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Nav Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between gap-4">
          {/* Logo y Nombre */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-500 to-blue-700 flex items-center justify-center shadow-lg shadow-sky-500/20 ring-2 ring-sky-400/30">
              <Wrench className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-black tracking-wider text-white">TALLER AMAYA</span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-sky-950 text-sky-400 border border-sky-800">
                  Tijuana, B.C.
                </span>
              </div>
              <p className="text-xs text-slate-400">Control de Vehículos, CRM Flotillas & Comisiones</p>
            </div>
          </div>

          {/* Botón Acción Rápida: Nueva Entrada */}
          <div className="hidden sm:flex items-center gap-3">
            <button
              onClick={onNewOrder}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-bold text-sm shadow-lg shadow-sky-500/25 transition-all transform hover:-translate-y-0.5 active:translate-y-0"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Registrar Entrada (Check-in)</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <nav className="flex items-center gap-1 mt-4 overflow-x-auto pb-1 scrollbar-none border-t border-slate-800/60 pt-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-semibold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-sky-500 text-white shadow-md shadow-sky-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
                {item.badge && (
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                      isActive ? 'bg-sky-700 text-sky-100' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
