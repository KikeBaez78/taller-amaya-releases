'use client';

import React, { useState } from 'react';
import { StorageService } from '@/lib/storage';
import { openRemisionPrintWindow } from '@/lib/remisionGenerator';
import { PresupuestoItemParte, PresupuestoManoObra, Vehicle, WorkOrder } from '@/types';
import {
  Zap,
  X,
  Plus,
  Trash2,
  Wrench,
  Package,
  Calculator,
  MessageCircle,
  FileCheck,
  FileText,
  Printer,
  Car,
  User,
  Phone,
  Sparkles,
  Check,
  ArrowRight,
} from 'lucide-react';

interface CotizadorRapidoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConvertToOrder?: (quoteData: {
    clienteNombre: string;
    clienteTelefono: string;
    vehiculoInfo: string;
    placas: string;
    partes: PresupuestoItemParte[];
    manoObra: PresupuestoManoObra[];
    aplicaIva: boolean;
    total: number;
    falla: string;
  }) => void;
}

const PRESET_SERVICIOS = [
  {
    titulo: 'Afinación Mayor (4 Cilindros)',
    desc: 'Bujías, filtros (aire, aceite, gas), aceite sintético y lavado de inyectores',
    manoObra: [{ id: 'mo-p1', concepto: 'Afinación mayor completa y lavado de cuerpo de aceleración', costo: 1200, comisionPorcentaje: 35 }],
    partes: [
      { id: 'p-p1', descripcion: 'Aceite sintético 5W-30 (Garrafa 5L)', cantidad: 1, precioUnitario: 850, subtotal: 850, origen: 'taller' as const },
      { id: 'p-p2', descripcion: 'Juego de bujías platino NGK (4 pzas)', cantidad: 1, precioUnitario: 650, subtotal: 650, origen: 'taller' as const },
      { id: 'p-p3', descripcion: 'Filtro de aire y filtro de aceite', cantidad: 1, precioUnitario: 380, subtotal: 380, origen: 'taller' as const },
    ],
  },
  {
    titulo: 'Frenos Delanteros y Rectificado',
    desc: 'Balatas cerámicas nuevas + rectificado de 2 discos en torno',
    manoObra: [{ id: 'mo-p2', concepto: 'Cambio de balatas y rectificado de 2 rotores delanteros', costo: 850, comisionPorcentaje: 35 }],
    partes: [
      { id: 'p-p4', descripcion: 'Juego de balatas delanteras cerámicas Wagner/Duralast', cantidad: 1, precioUnitario: 750, subtotal: 750, origen: 'taller' as const },
      { id: 'p-p5', descripcion: 'Servicio de rectificado de 2 discos en torno', cantidad: 1, precioUnitario: 450, subtotal: 450, origen: 'taller' as const },
    ],
  },
  {
    titulo: 'Cambio de Aceite Sintético y Filtro',
    desc: 'Servicio express de lubricación y revisión de 25 puntos de seguridad',
    manoObra: [{ id: 'mo-p3', concepto: 'Mano de obra cambio de aceite y filtro + revisión de niveles', costo: 400, comisionPorcentaje: 30 }],
    partes: [
      { id: 'p-p6', descripcion: 'Garrafa Aceite Sintético 5W-30 / 5W-20', cantidad: 1, precioUnitario: 820, subtotal: 820, origen: 'taller' as const },
      { id: 'p-p7', descripcion: 'Filtro de aceite alto rendimiento', cantidad: 1, precioUnitario: 180, subtotal: 180, origen: 'taller' as const },
    ],
  },
  {
    titulo: 'Diagnóstico Scanner y Borrado Check Engine',
    desc: 'Escaneo electrónico OBD2 con reporte de códigos y lectura de sensores',
    manoObra: [{ id: 'mo-p4', concepto: 'Diagnóstico electrónico por scanner y prueba de sensores', costo: 500, comisionPorcentaje: 40 }],
    partes: [],
  },
  {
    titulo: 'Suspensión Delantera (Amortiguadores)',
    desc: 'Reemplazo de par de amortiguadores y bases delanteras',
    manoObra: [{ id: 'mo-p5', concepto: 'Instalación de amortiguadores delanteros y alineación', costo: 1400, comisionPorcentaje: 30 }],
    partes: [
      { id: 'p-p8', descripcion: 'Par de amortiguadores de gas delanteros', cantidad: 1, precioUnitario: 2600, subtotal: 2600, origen: 'taller' as const },
      { id: 'p-p9', descripcion: 'Par de bases de amortiguador con balero', cantidad: 1, precioUnitario: 900, subtotal: 900, origen: 'taller' as const },
    ],
  },
];

export const CotizadorRapidoModal: React.FC<CotizadorRapidoModalProps> = ({
  isOpen,
  onClose,
  onConvertToOrder,
}) => {
  const config = StorageService.getConfig();

  // Modo de operación: Cotizador Rápido vs Remisión Oficial
  const [docMode, setDocMode] = useState<'cotizador' | 'remision'>('cotizador');
  const [folioRemision, setFolioRemision] = useState(() => `REM-${Math.floor(1000 + Math.random() * 9000)}`);

  // Datos rápidos de cliente y auto
  const [clienteNombre, setClienteNombre] = useState('');
  const [clienteTelefono, setClienteTelefono] = useState('');
  const [vehiculoInfo, setVehiculoInfo] = useState('');
  const [placas, setPlacas] = useState('');
  const [falla, setFalla] = useState('');

  // Listas de cotización
  const [manoObra, setManoObra] = useState<PresupuestoManoObra[]>([]);
  const [partes, setPartes] = useState<PresupuestoItemParte[]>([]);
  const [aplicaIva, setAplicaIva] = useState(false);

  // Inputs para añadir items manualmente
  const [nuevoConceptoMO, setNuevoConceptoMO] = useState('');
  const [nuevoCostoMO, setNuevoCostoMO] = useState<number>(0);

  const [nuevaDescParte, setNuevaDescParte] = useState('');
  const [nuevaCantParte, setNuevaCantParte] = useState<number>(1);
  const [nuevoPrecioParte, setNuevoPrecioParte] = useState<number>(0);
  const [nuevoOrigenParte, setNuevoOrigenParte] = useState<'taller' | 'cliente'>('taller');

  // Cálculos reactivos
  const subtotalManoObra = manoObra.reduce((acc, curr) => acc + (curr.costo || 0), 0);
  const subtotalPartes = partes.reduce((acc, curr) => acc + (curr.subtotal || 0), 0);
  const subtotalSinIva = subtotalManoObra + subtotalPartes;
  const ivaMonto = aplicaIva ? Math.round(subtotalSinIva * (config.ivaFronteraPorcentaje / 100)) : 0;
  const totalCotizado = subtotalSinIva + ivaMonto;

  if (!isOpen) return null;

  // Cargar preset rápido
  const handleApplyPreset = (preset: typeof PRESET_SERVICIOS[0]) => {
    setManoObra([...preset.manoObra]);
    setPartes([...preset.partes]);
    if (!falla) setFalla(preset.titulo);
  };

  // Añadir Mano de Obra
  const handleAddManoObra = () => {
    if (!nuevoConceptoMO.trim() || nuevoCostoMO <= 0) return;
    const item: PresupuestoManoObra = {
      id: `mo-${Date.now()}`,
      concepto: nuevoConceptoMO.trim(),
      costo: nuevoCostoMO,
      comisionPorcentaje: 30,
    };
    setManoObra([...manoObra, item]);
    setNuevoConceptoMO('');
    setNuevoCostoMO(0);
  };

  // Añadir Parte
  const handleAddParte = () => {
    if (!nuevaDescParte.trim() || (nuevoOrigenParte === 'taller' && nuevoPrecioParte <= 0)) return;
    const subtotal = nuevoOrigenParte === 'cliente' ? 0 : nuevaCantParte * nuevoPrecioParte;
    const item: PresupuestoItemParte = {
      id: `p-${Date.now()}`,
      descripcion: nuevaDescParte.trim(),
      cantidad: nuevaCantParte,
      precioUnitario: nuevoOrigenParte === 'cliente' ? 0 : nuevoPrecioParte,
      subtotal,
      origen: nuevoOrigenParte,
    };
    setPartes([...partes, item]);
    setNuevaDescParte('');
    setNuevaCantParte(1);
    setNuevoPrecioParte(0);
    setNuevoOrigenParte('taller');
  };

  // Generar mensaje para WhatsApp
  const handleSendWhatsApp = () => {
    const tel = clienteTelefono.replace(/\D/g, '') || config.whatsapp;
    let mensaje = `*COTIZACIÓN TALLER AMAYA* 🚗🔧\n`;
    mensaje += `Estimado(a) *${clienteNombre || 'Cliente'}*:\n\n`;
    if (vehiculoInfo) mensaje += `Vehículo: *${vehiculoInfo}* ${placas ? `(Placas: ${placas})` : ''}\n`;
    if (falla) mensaje += `Servicio / Falla: ${falla}\n\n`;

    mensaje += `*📋 MANO DE OBRA:*\n`;
    if (manoObra.length === 0) {
      mensaje += `• Sin mano de obra especificada\n`;
    } else {
      manoObra.forEach((mo) => {
        mensaje += `• ${mo.concepto}: $${mo.costo.toLocaleString()} MXN\n`;
      });
      mensaje += `*Subtotal M.O.: $${subtotalManoObra.toLocaleString()} MXN*\n\n`;
    }

    mensaje += `*📦 REFACCIONES Y PARTES:*\n`;
    if (partes.length === 0) {
      mensaje += `• Ninguna o suministradas por cliente\n`;
    } else {
      partes.forEach((p) => {
        if (p.origen === 'cliente') {
          mensaje += `• ${p.descripcion} (Traída por cliente: $0)\n`;
        } else {
          mensaje += `• ${p.cantidad}x ${p.descripcion}: $${p.subtotal.toLocaleString()} MXN\n`;
        }
      });
      mensaje += `*Subtotal Partes: $${subtotalPartes.toLocaleString()} MXN*\n\n`;
    }

    if (aplicaIva) {
      mensaje += `Subtotal: $${subtotalSinIva.toLocaleString()} MXN\n`;
      mensaje += `IVA 8% Frontera: $${ivaMonto.toLocaleString()} MXN\n`;
    }
    mensaje += `*💵 TOTAL ESTIMADO: $${totalCotizado.toLocaleString()} MXN*\n\n`;
    mensaje += `📍 *Taller Amaya:* ${config.direccion}\n`;
    mensaje += `📞 Tel: ${config.telefonoLocal} | WhatsApp: ${config.whatsapp}\n`;
    mensaje += `_¿Gusta que le reservemos espacio o agendemos su vehículo?_`;

    const encoded = encodeURIComponent(mensaje);
    window.open(`https://wa.me/52${tel}?text=${encoded}`, '_blank');
  };

  // Imprimir o Guardar en PDF la Remisión Oficial
  const handlePrintCotizacionPDF = () => {
    const partsWords = (vehiculoInfo || '').trim().split(/\s+/);
    let ano = '';
    let marca = '';
    let modelo = '';
    if (partsWords.length > 0 && /^\d{4}$/.test(partsWords[0])) {
      ano = partsWords[0];
      marca = partsWords[1] || '';
      modelo = partsWords.slice(2).join(' ');
    } else {
      marca = partsWords[0] || '';
      modelo = partsWords.slice(1).join(' ');
    }

    const folioFinal = folioRemision.trim() || `REM-${Date.now().toString().slice(-4)}`;

    openRemisionPrintWindow({
      folio: folioFinal,
      cliente: clienteNombre,
      telefono: clienteTelefono,
      vehiculo: {
        marca,
        modelo,
        ano,
        placas,
      },
      partes: partes.map((p) => ({
        cantidad: p.cantidad,
        descripcion: p.descripcion,
        costo: p.subtotal,
      })),
      manoDeObraItems: manoObra.map((m) => ({
        cantidad: 1,
        descripcion: m.concepto,
        costo: m.costo,
      })),
      subtotalPartes,
      subtotalManoObra,
      aplicaIva,
      ivaMonto,
      total: totalCotizado,
    });
  };

  // Convertir a Orden
  const handleConvert = () => {
    if (onConvertToOrder) {
      onConvertToOrder({
        clienteNombre,
        clienteTelefono,
        vehiculoInfo,
        placas,
        partes,
        manoObra,
        aplicaIva,
        total: totalCotizado,
        falla: falla || 'Cotización express aprobada',
      });
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-fadeIn">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl text-slate-800 overflow-hidden">
        {/* Cabecera con Selector de Modo */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-50 via-white to-rose-50/50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-2xl flex items-center justify-center border shadow-sm transition-colors ${
                docMode === 'remision'
                  ? 'bg-slate-900 text-white border-slate-800'
                  : 'bg-amber-100 text-amber-700 border-amber-200'
              }`}
            >
              {docMode === 'remision' ? (
                <FileText className="w-5 h-5 text-rose-400" />
              ) : (
                <Zap className="w-5 h-5 fill-amber-500 text-amber-600" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-slate-900">
                  {docMode === 'remision' ? 'Remisión Oficial de Taller' : 'Cotizador Rápido Express'}
                </h2>
                <span
                  className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                    docMode === 'remision'
                      ? 'bg-slate-900 text-rose-300 border-slate-700'
                      : 'bg-amber-100 text-amber-800 border-amber-200'
                  }`}
                >
                  {docMode === 'remision' ? 'Formato Carta / PDF' : 'Presupuesto Express'}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                {docMode === 'remision'
                  ? 'Genera e imprime remisión tamaño carta con desglose de refacciones y datos fiscales'
                  : 'Calcula presupuesto en 30 segundos, envía por WhatsApp o convierte en orden formal'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {/* SELECTOR DE MODO: COTIZADOR VS REMISIÓN */}
            <div className="flex items-center bg-slate-200/80 p-1 rounded-2xl border border-slate-300 shadow-inner">
              <button
                type="button"
                onClick={() => setDocMode('cotizador')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                  docMode === 'cotizador'
                    ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/30'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Zap className="w-3.5 h-3.5 fill-current" />
                <span>Cotizador Rápido</span>
              </button>
              <button
                type="button"
                onClick={() => setDocMode('remision')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                  docMode === 'remision'
                    ? 'bg-slate-900 text-white shadow-md shadow-slate-900/30'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <FileText className="w-3.5 h-3.5 text-rose-400" />
                <span>Remisión</span>
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Cuerpo con Scroll */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6 flex-1 bg-slate-50/50">
          {/* Paquetes / Presets Rápidos con 1 Clic */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1.5 mb-2.5">
              <Sparkles className="w-4 h-4 text-rose-500" />
              <span>1. Seleccionar Paquete Rápido (Opcional):</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {PRESET_SERVICIOS.map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleApplyPreset(preset)}
                  className="text-left p-3 rounded-2xl bg-white hover:bg-rose-50/60 border border-slate-200 hover:border-rose-300 transition-all shadow-sm hover:shadow group flex flex-col justify-between"
                >
                  <div>
                    <h4 className="text-xs font-bold text-slate-800 group-hover:text-rose-700 flex items-center justify-between">
                      <span>{preset.titulo}</span>
                      <Plus className="w-3.5 h-3.5 text-slate-400 group-hover:text-rose-600" />
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">{preset.desc}</p>
                  </div>
                  <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] font-mono">
                    <span className="text-slate-400">Est. M.O. + Partes:</span>
                    <strong className="text-rose-600 font-bold">
                      ${(
                        preset.manoObra.reduce((a, b) => a + b.costo, 0) +
                        preset.partes.reduce((a, b) => a + b.subtotal, 0)
                      ).toLocaleString()}{' '}
                      MXN
                    </strong>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Datos del Cliente y Vehículo */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2.5">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
                <Car className="w-4 h-4 text-slate-500" />
                <span>2. Datos del Cliente y Vehículo:</span>
              </h3>

              {docMode === 'remision' && (
                <div className="flex items-center gap-2 bg-slate-900 text-white px-3 py-1.5 rounded-xl border border-slate-800 shadow-sm">
                  <span className="text-[11px] font-bold uppercase text-slate-400">Folio:</span>
                  <input
                    type="text"
                    value={folioRemision}
                    onChange={(e) => setFolioRemision(e.target.value.toUpperCase())}
                    className="bg-slate-950 border border-slate-700 text-rose-300 font-mono font-black text-xs px-2 py-0.5 rounded-lg text-center focus:outline-none focus:border-rose-500 w-28 uppercase"
                    placeholder="REM-0000"
                  />
                  <button
                    type="button"
                    onClick={() => setFolioRemision(`REM-${Math.floor(1000 + Math.random() * 9000)}`)}
                    className="text-[9px] bg-slate-800 hover:bg-slate-700 text-slate-300 px-1.5 py-0.5 rounded border border-slate-700 font-bold"
                    title="Generar nuevo folio correlativo"
                  >
                    Nuevo
                  </button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="text-slate-600 font-medium block mb-1">Nombre del Cliente:</label>
                <input
                  type="text"
                  placeholder="Ej. Juan Pérez"
                  value={clienteNombre}
                  onChange={(e) => setClienteNombre(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="text-slate-600 font-medium block mb-1">WhatsApp / Celular:</label>
                <input
                  type="tel"
                  placeholder="664-123-4567"
                  value={clienteTelefono}
                  onChange={(e) => setClienteTelefono(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 font-mono focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="text-slate-600 font-medium block mb-1">Vehículo (Año/Marca/Modelo):</label>
                <input
                  type="text"
                  placeholder="Ej. 2018 Nissan Versa"
                  value={vehiculoInfo}
                  onChange={(e) => setVehiculoInfo(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="text-slate-600 font-medium block mb-1">Placas (Opcional):</label>
                <input
                  type="text"
                  placeholder="BJH-44-12"
                  value={placas}
                  onChange={(e) => setPlacas(e.target.value.toUpperCase())}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 font-mono uppercase focus:outline-none focus:border-rose-500"
                />
              </div>
            </div>

            <div>
              <label className="text-slate-600 font-medium block mb-1 text-xs">Falla o Trabajo a Cotizar:</label>
              <input
                type="text"
                placeholder="Ej. Frenos delanteros, zumbido al dar vuelta, afinación..."
                value={falla}
                onChange={(e) => setFalla(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>

          {/* Desglose Mano de Obra y Partes */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Columna Mano de Obra */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <Wrench className="w-4 h-4 text-rose-600" />
                    <span>Mano de Obra ({manoObra.length})</span>
                  </h3>
                  <span className="font-mono font-bold text-rose-600 text-xs">
                    Subtotal: ${subtotalManoObra.toLocaleString()} MXN
                  </span>
                </div>

                {/* Lista de Mano de Obra */}
                <div className="space-y-1.5 min-h-[90px] max-h-[180px] overflow-y-auto mb-3">
                  {manoObra.length === 0 ? (
                    <div className="text-center py-6 text-slate-400 text-xs">
                      No hay conceptos de mano de obra añadidos
                    </div>
                  ) : (
                    manoObra.map((mo) => (
                      <div
                        key={mo.id}
                        className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                      >
                        <span className="font-medium text-slate-800 flex-1 truncate pr-2">
                          {mo.concepto}
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-slate-900">${mo.costo.toLocaleString()}</span>
                          <button
                            type="button"
                            onClick={() => setManoObra(manoObra.filter((m) => m.id !== mo.id))}
                            className="p-1 text-slate-400 hover:text-rose-600"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Agregar Concepto Mano de Obra Rápido */}
              <div className="pt-2 border-t border-slate-100 flex gap-2">
                <input
                  type="text"
                  placeholder="Concepto de mano de obra..."
                  value={nuevoConceptoMO}
                  onChange={(e) => setNuevoConceptoMO(e.target.value)}
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-rose-500"
                />
                <input
                  type="number"
                  placeholder="$ Monto"
                  value={nuevoCostoMO || ''}
                  onChange={(e) => setNuevoCostoMO(parseFloat(e.target.value) || 0)}
                  className="w-24 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-mono text-slate-800 focus:outline-none focus:border-rose-500"
                />
                <button
                  type="button"
                  onClick={handleAddManoObra}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold"
                >
                  +
                </button>
              </div>
            </div>

            {/* Columna Refacciones y Partes */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <Package className="w-4 h-4 text-emerald-600" />
                    <span>Partes y Refacciones ({partes.length})</span>
                  </h3>
                  <span className="font-mono font-bold text-emerald-600 text-xs">
                    Subtotal: ${subtotalPartes.toLocaleString()} MXN
                  </span>
                </div>

                {/* Lista de Partes */}
                <div className="space-y-1.5 min-h-[90px] max-h-[180px] overflow-y-auto mb-3">
                  {partes.length === 0 ? (
                    <div className="text-center py-6 text-slate-400 text-xs">
                      No hay piezas agregadas o son del cliente
                    </div>
                  ) : (
                    partes.map((p) => (
                      <div
                        key={p.id}
                        className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                      >
                        <div className="flex-1 truncate pr-2">
                          <span className="font-medium text-slate-800 block truncate">
                            {p.cantidad}x {p.descripcion}
                          </span>
                          <span
                            className={`text-[10px] font-semibold ${
                              p.origen === 'cliente' ? 'text-amber-600' : 'text-slate-400'
                            }`}
                          >
                            {p.origen === 'cliente' ? '✓ Traída por cliente' : 'Surtida por taller'}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-slate-900">
                            {p.origen === 'cliente' ? '$0' : `$${p.subtotal.toLocaleString()}`}
                          </span>
                          <button
                            type="button"
                            onClick={() => setPartes(partes.filter((part) => part.id !== p.id))}
                            className="p-1 text-slate-400 hover:text-rose-600"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Agregar Parte Rápida */}
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Descripción de la pieza..."
                    value={nuevaDescParte}
                    onChange={(e) => setNuevaDescParte(e.target.value)}
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-rose-500"
                  />
                  <select
                    value={nuevoOrigenParte}
                    onChange={(e) => setNuevoOrigenParte(e.target.value as any)}
                    className="bg-slate-50 border border-slate-200 rounded-xl px-2 py-1.5 text-xs text-slate-700"
                  >
                    <option value="taller">Taller</option>
                    <option value="cliente">Cliente</option>
                  </select>
                </div>
                <div className="flex gap-2">
                  <input
                    type="number"
                    min="1"
                    placeholder="Cant"
                    value={nuevaCantParte || ''}
                    onChange={(e) => setNuevaCantParte(parseInt(e.target.value) || 1)}
                    className="w-16 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-mono text-slate-800"
                  />
                  <input
                    type="number"
                    placeholder="$ P. Unitario"
                    disabled={nuevoOrigenParte === 'cliente'}
                    value={nuevoOrigenParte === 'cliente' ? 0 : nuevoPrecioParte || ''}
                    onChange={(e) => setNuevoPrecioParte(parseFloat(e.target.value) || 0)}
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-mono text-slate-800 disabled:opacity-50"
                  />
                  <button
                    type="button"
                    onClick={handleAddParte}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold"
                  >
                    + Agregar
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Resumen Final de Cotización */}
          <div className="bg-gradient-to-br from-rose-50/60 to-slate-50 border border-rose-200/80 rounded-2xl p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-1">
              <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-slate-700 font-semibold">
                <input
                  type="checkbox"
                  checked={aplicaIva}
                  onChange={(e) => setAplicaIva(e.target.checked)}
                  className="rounded border-slate-300 text-rose-600 focus:ring-rose-500 w-4 h-4"
                />
                <span>Aplicar 8% IVA Zona Fronteriza (Tijuana - si requiere factura)</span>
              </label>
              <div className="flex items-center gap-4 text-xs font-mono text-slate-600 pt-1">
                <span>M.O.: ${subtotalManoObra.toLocaleString()}</span>
                <span>•</span>
                <span>Partes: ${subtotalPartes.toLocaleString()}</span>
                {aplicaIva && (
                  <>
                    <span>•</span>
                    <span className="text-rose-600">IVA 8%: ${ivaMonto.toLocaleString()}</span>
                  </>
                )}
              </div>
            </div>

            <div className="text-right">
              <span className="text-[11px] uppercase font-bold text-slate-500 block">Total Cotizado Estimado:</span>
              <div className="text-2xl sm:text-3xl font-black font-mono text-slate-900 tracking-tight">
                ${totalCotizado.toLocaleString()} <span className="text-sm font-bold text-rose-600">MXN</span>
              </div>
            </div>
          </div>
        </div>

        {/* Barra de Acciones */}
        <div className="p-4 sm:p-5 bg-white border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold text-xs transition-colors"
          >
            Cerrar
          </button>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Botón Imprimir / Guardar en PDF */}
            <button
              type="button"
              onClick={handlePrintCotizacionPDF}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-black text-xs transition-all cursor-pointer ${
                docMode === 'remision'
                  ? 'bg-slate-900 hover:bg-slate-800 text-white shadow-xl shadow-slate-900/30 ring-2 ring-rose-500/50 scale-102'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300'
              }`}
              title="Generar Remisión oficial e imprimir o guardar en PDF"
            >
              <Printer className={`w-4 h-4 ${docMode === 'remision' ? 'text-rose-400' : 'text-slate-600'}`} />
              <span>{docMode === 'remision' ? '🖨️ Imprimir Remisión (PDF)' : 'Remisión (PDF)'}</span>
            </button>

            {/* Botón Enviar WhatsApp */}
            <button
              type="button"
              onClick={handleSendWhatsApp}
              className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                docMode === 'cotizador'
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/30'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300'
              }`}
              title="Enviar resumen por mensaje de WhatsApp"
            >
              <MessageCircle className={`w-4 h-4 ${docMode === 'cotizador' ? 'text-white' : 'text-emerald-600'}`} />
              <span>{docMode === 'cotizador' ? 'Enviar WhatsApp' : 'WhatsApp'}</span>
            </button>

            {/* Botón Convertir en Orden */}
            <button
              type="button"
              onClick={handleConvert}
              className="flex items-center gap-1.5 px-4 sm:px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black text-xs shadow-lg shadow-rose-600/30 transition-all cursor-pointer"
            >
              <span>Crear Orden de Trabajo</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
