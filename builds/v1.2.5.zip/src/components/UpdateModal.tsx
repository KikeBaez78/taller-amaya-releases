'use client';

import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Download,
  ShieldCheck,
  CheckCircle2,
  RefreshCw,
  AlertTriangle,
  Lock,
  ArrowUpCircle,
  Database,
  FileCode,
} from 'lucide-react';
import { RemoteUpdateManifest } from '@/lib/updates';

interface UpdateModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentVersion: string;
  remoteInfo?: RemoteUpdateManifest | null;
  onUpdateSuccess: (newVersion: string) => void;
}

export const UpdateModal: React.FC<UpdateModalProps> = ({
  isOpen,
  onClose,
  currentVersion,
  remoteInfo,
  onUpdateSuccess,
}) => {
  const [pin, setPin] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [step, setStep] = useState<'info' | 'installing' | 'completed' | 'error'>('info');
  const [progressMsg, setProgressMsg] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const targetVersion = remoteInfo?.version || '1.1.0';

  const handleStartUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pin.trim()) {
      setErrorMessage('Ingresa el PIN de seguridad del dueño para autorizar.');
      return;
    }

    setIsVerifying(true);
    setErrorMessage(null);
    setStep('installing');

    try {
      setProgressMsg('1/3: Descargando archivos de actualización v' + targetVersion + '...');
      await new Promise((r) => setTimeout(r, 1200));

      setProgressMsg('2/3: Protegiendo base de datos e historial vehicular...');
      await new Promise((r) => setTimeout(r, 1200));

      const res = await fetch('/api/updates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'apply_update',
          pin: pin.trim(),
          targetVersion: targetVersion,
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        setErrorMessage(data.message || 'Error al aplicar actualización');
        setStep('info');
        setIsVerifying(false);
        return;
      }

      setProgressMsg('3/3: ¡Actualización completada! Asentando nueva versión...');
      await new Promise((r) => setTimeout(r, 1000));

      setStep('completed');
      setIsVerifying(false);
      onUpdateSuccess(targetVersion);
    } catch (err) {
      setErrorMessage('Ocurrió un error inesperado al conectar con el servidor.');
      setStep('info');
      setIsVerifying(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[9999] bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 text-slate-800 animate-in fade-in duration-200">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl space-y-6 relative overflow-hidden">
        {/* Cabecera */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-rose-50 text-rose-600 border border-rose-100 shadow-sm">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-slate-900 tracking-tight">
                  Centro de Actualizaciones Oficial
                </h2>
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                  OTA v{targetVersion}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Notificación exclusiva para el propietario de Taller Amaya
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Estado actual de versiones */}
        <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-200 text-xs">
          <div>
            <span className="text-slate-400 block text-[10px] uppercase font-bold">
              Versión Instalada:
            </span>
            <span className="font-mono font-black text-slate-700 text-sm">
              v{currentVersion}
            </span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase font-bold">
              Nueva Versión Disponible:
            </span>
            <span className="font-mono font-black text-emerald-600 text-sm flex items-center gap-1">
              v{targetVersion} <ArrowUpCircle className="w-4 h-4" />
            </span>
          </div>
        </div>

        {/* Novedades y Notas de la Versión */}
        {step === 'info' && (
          <div className="space-y-4">
            <div className="space-y-2">
              <h3 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <FileCode className="w-4 h-4 text-rose-600" />
                <span>Novedades en esta versión ({remoteInfo?.releaseDate || 'Reciente'}):</span>
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed font-medium bg-rose-50/50 p-3 rounded-xl border border-rose-100/60">
                {remoteInfo?.description ||
                  'Nuevas mejoras de rendimiento, seguridad en caja y visor de fotos.'}
              </p>

              {remoteInfo?.changelog && remoteInfo.changelog.length > 0 && (
                <ul className="space-y-1.5 pl-1 text-xs text-slate-700">
                  {remoteInfo.changelog.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-rose-500 font-bold">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {/* Garantía de datos */}
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-[11px] flex items-center gap-2.5">
              <Database className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                <strong>Garantía de Protección de Datos:</strong> Tus vehículos registrados, órdenes de servicio y clientes se conservan al 100%. No se borra nada.
              </span>
            </div>

            {/* Formulario de Autorización con PIN */}
            <form onSubmit={handleStartUpdate} className="space-y-3 pt-2 border-t border-slate-100">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1 flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-rose-600" />
                  <span>PIN de Autorización de Reyna Amaya (4 dígitos):</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="password"
                    maxLength={4}
                    required
                    value={pin}
                    onChange={(e) => setPin(e.target.value)}
                    placeholder="PIN..."
                    className="w-32 bg-slate-50 border border-slate-300 text-slate-900 rounded-xl px-3 py-2 text-center text-sm font-mono tracking-widest font-black focus:outline-none focus:border-rose-500"
                  />
                  <button
                    type="submit"
                    disabled={isVerifying}
                    className="flex-1 py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md shadow-rose-600/25 transition-all active:scale-95 flex items-center justify-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    <span>Autorizar y Actualizar a v{targetVersion}</span>
                  </button>
                </div>
              </div>

              {errorMessage && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2 font-medium">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
                  <span>{errorMessage}</span>
                </div>
              )}
            </form>
          </div>
        )}

        {/* Pantalla de Instalación en Progreso */}
        {step === 'installing' && (
          <div className="py-8 text-center space-y-4">
            <div className="inline-flex p-4 rounded-3xl bg-rose-50 text-rose-600 border border-rose-200 shadow-lg animate-spin">
              <RefreshCw className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-900 mb-1">
                Aplicando Actualización a v{targetVersion}...
              </h3>
              <p className="text-xs text-rose-600 font-mono font-bold">{progressMsg}</p>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden max-w-xs mx-auto">
              <div className="bg-rose-600 h-full rounded-full animate-pulse w-3/4" />
            </div>
          </div>
        )}

        {/* Pantalla de Completado */}
        {step === 'completed' && (
          <div className="py-6 text-center space-y-4">
            <div className="inline-flex p-4 rounded-3xl bg-emerald-50 text-emerald-600 border border-emerald-200 shadow-lg">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900">
                ¡Actualización Exitosa!
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                El sistema ahora está corriendo en la versión oficial <strong>v{targetVersion}</strong>.
              </p>
            </div>
            <button
              onClick={() => {
                onClose();
                window.location.reload();
              }}
              className="px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow transition-all active:scale-95"
            >
              Cerrar y Recargar Sistema
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
