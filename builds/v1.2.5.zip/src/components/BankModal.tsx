'use client';

import React, { useState } from 'react';
import { TallerConfig } from '@/types';
import { X, Copy, Check, Building2, CreditCard, Mail, Phone, MessageSquare } from 'lucide-react';

interface BankModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: TallerConfig;
}

export const BankModal: React.FC<BankModalProps> = ({ isOpen, onClose, config }) => {
  const [copiedField, setCopiedField] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const shareText = `*DATOS PARA TRANSFERENCIA BANCARIA - TALLER AMAYA*\n\nBanco: ${config.banco}\nBeneficiario: ${config.razonSocial}\nCuenta: ${config.cuenta}\nCLABE Interbancaria: ${config.clabe}\nRFC: ${config.rfc}\nCorreo: ${config.correo}\n\n*Nota:* Pagos por transferencia causan 8% de IVA en zona fronteriza Tijuana. Favor de enviar comprobante con su número de orden.`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative text-slate-800">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-600">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-800">Cuentas Bancarias para Transferencias</h3>
            <p className="text-xs text-slate-500">Datos oficiales para compartir con clientes y empresas</p>
          </div>
        </div>

        <div className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <span className="text-xs text-slate-500 font-medium">Banco:</span>
            <span className="font-bold text-rose-600">{config.banco}</span>
          </div>

          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <div>
              <span className="text-xs text-slate-500 block font-medium">Beneficiario:</span>
              <span className="font-semibold text-sm text-slate-800">{config.razonSocial}</span>
            </div>
            <button
              onClick={() => copyToClipboard(config.razonSocial, 'beneficiario')}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-200"
              title="Copiar beneficiario"
            >
              {copiedField === 'beneficiario' ? (
                <Check className="w-4 h-4 text-emerald-600" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </button>
          </div>

          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <div>
              <span className="text-xs text-slate-500 block font-medium">Número de Cuenta:</span>
              <span className="font-mono text-base font-bold text-slate-800 tracking-wider">
                {config.cuenta}
              </span>
            </div>
            <button
              onClick={() => copyToClipboard(config.cuenta, 'cuenta')}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-200"
              title="Copiar cuenta"
            >
              {copiedField === 'cuenta' ? (
                <Check className="w-4 h-4 text-emerald-600" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </button>
          </div>

          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <div>
              <span className="text-xs text-slate-500 block font-medium">CLABE Interbancaria:</span>
              <span className="font-mono text-base font-bold text-emerald-600 tracking-wider">
                {config.clabe}
              </span>
            </div>
            <button
              onClick={() => copyToClipboard(config.clabe, 'clabe')}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-200"
              title="Copiar CLABE"
            >
              {copiedField === 'clabe' ? (
                <Check className="w-4 h-4 text-emerald-600" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </button>
          </div>

          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <div>
              <span className="text-xs text-slate-500 block font-medium">RFC Receptor:</span>
              <span className="font-mono text-sm font-semibold text-slate-700">{config.rfc}</span>
            </div>
            <button
              onClick={() => copyToClipboard(config.rfc, 'rfc')}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-200"
              title="Copiar RFC"
            >
              {copiedField === 'rfc' ? (
                <Check className="w-4 h-4 text-emerald-600" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </button>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-500 block font-medium">Correo para Comprobantes:</span>
              <span className="text-sm font-medium text-slate-700">{config.correo}</span>
            </div>
            <button
              onClick={() => copyToClipboard(config.correo, 'correo')}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-200"
              title="Copiar correo"
            >
              {copiedField === 'correo' ? (
                <Check className="w-4 h-4 text-emerald-600" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>

        <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800">
          <strong>Regla de Cobro:</strong> Se cobra el 8% de IVA (tasa fronteriza Tijuana) en pagos realizados con transferencia bancaria y tarjeta.
        </div>

        <div className="mt-5 flex gap-3">
          <button
            onClick={() => copyToClipboard(shareText, 'todo')}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-sm transition-colors border border-slate-200"
          >
            {copiedField === 'todo' ? (
              <>
                <Check className="w-4 h-4 text-emerald-600" />
                <span>¡Texto Copiado!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copiar Todo el Texto</span>
              </>
            )}
          </button>

          <a
            href={`https://wa.me/?text=${encodeURIComponent(shareText)}`}
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm transition-colors shadow-md"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Enviar por WhatsApp</span>
          </a>
        </div>
      </div>
    </div>
  );
};
