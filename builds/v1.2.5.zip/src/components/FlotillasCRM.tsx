'use client';

import React, { useState } from 'react';
import { StorageService } from '@/lib/storage';
import { Company, Vehicle } from '@/types';
import {
  Building2,
  Phone,
  Mail,
  MapPin,
  Car,
  AlertTriangle,
  MessageCircle,
  Plus,
  ShieldCheck,
  Calendar,
  Gauge,
  User,
  ExternalLink,
} from 'lucide-react';

interface FlotillasCRMProps {
  onSelectVehicle?: (vehicle: Vehicle) => void;
  onNewOrderForVehicle?: (vehicle: Vehicle) => void;
}

export const FlotillasCRM: React.FC<FlotillasCRMProps> = ({
  onSelectVehicle,
  onNewOrderForVehicle,
}) => {
  const companies = StorageService.getCompanies();
  const vehicles = StorageService.getVehicles();

  const [selectedCompanyId, setSelectedCompanyId] = useState<string>(companies[0]?.id || '');

  // Modal para dar de alta nueva empresa
  const [isAddingCompany, setIsAddingCompany] = useState(false);
  const [razonSocial, setRazonSocial] = useState('');
  const [rfc, setRfc] = useState('');
  const [encargado, setEncargado] = useState('');
  const [direccion, setDireccion] = useState('');
  const [telefonos, setTelefonos] = useState('');
  const [correos, setCorreos] = useState('');
  const [diasCredito, setDiasCredito] = useState(15);
  const [notas, setNotas] = useState('');

  const selectedCompany = companies.find((c) => c.id === selectedCompanyId) || companies[0];

  // Vehículos de la empresa seleccionada
  const companyVehicles = vehicles.filter((v) => v.empresaId === selectedCompany?.id);

  // Vehículos en alerta preventiva general (más de 2 meses o 10,000 km)
  const allAlerts = StorageService.searchBitacora('').filter((r) => r.requiereMantenimiento);

  const handleSaveCompany = (e: React.FormEvent) => {
    e.preventDefault();
    if (!razonSocial.trim() || !encargado.trim()) {
      alert('Por favor introduce la Razón Social y el nombre del Encargado de Flotilla.');
      return;
    }

    const newCompany: Company = {
      id: `emp-${Date.now()}`,
      razonSocial: razonSocial.trim(),
      rfc: rfc.trim().toUpperCase() || 'XAXX010101000',
      encargadoFlotilla: encargado.trim(),
      direccion: direccion.trim() || 'Tijuana B.C.',
      telefonos: telefonos
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean),
      correos: correos
        .split(',')
        .map((c) => c.trim())
        .filter(Boolean),
      diasCredito: Number(diasCredito) || 15,
      notas: notas.trim(),
      creadoEn: new Date().toISOString().split('T')[0],
    };

    StorageService.saveCompany(newCompany);
    setSelectedCompanyId(newCompany.id);
    setIsAddingCompany(false);
    setRazonSocial('');
    setEncargado('');
    alert(`¡Empresa "${newCompany.razonSocial}" dada de alta exitosamente!`);
  };

  return (
    <div className="space-y-6">
      {/* Banner Principal */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-rose-600 text-xs font-bold uppercase tracking-wider mb-1">
            <Building2 className="w-4 h-4" />
            <span>Gestión de Flotillas Corporativas & Mantenimiento Preventivo</span>
          </div>
          <h2 className="text-2xl font-black text-slate-800">
            CRM de Empresas & Flotas
          </h2>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            Control de empresas con múltiples vehículos, choferes asignados, teléfonos y correos múltiples, con <strong>alertas preventivas automáticas cada 2 meses o 10,000 km</strong>.
          </p>
        </div>

        <button
          onClick={() => setIsAddingCompany(true)}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-sm shadow-md transition-all active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>Dar de Alta Empresa</span>
        </button>
      </div>

      {/* Grid Principal: Lista de Empresas a la izquierda, Detalle a la derecha */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Selector de Empresas */}
        <div className="lg:col-span-4 space-y-3">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider px-1">
            Empresas Registradas ({companies.length})
          </div>

          {companies.map((comp) => {
            const isSelected = comp.id === selectedCompanyId;
            const countVeh = vehicles.filter((v) => v.empresaId === comp.id).length;

            return (
              <div
                key={comp.id}
                onClick={() => setSelectedCompanyId(comp.id)}
                className={`bg-white border rounded-2xl p-4 cursor-pointer transition-all hover:border-rose-400 hover:shadow-md ${
                  isSelected
                    ? 'border-rose-500 ring-2 ring-rose-500/20 bg-rose-50/20 shadow-sm'
                    : 'border-slate-200'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold text-slate-800 text-sm mb-0.5">{comp.razonSocial}</h3>
                    <span className="font-mono text-xs text-rose-600 font-semibold block">
                      RFC: {comp.rfc}
                    </span>
                    <span className="text-xs text-slate-500 mt-1 block">
                      Encargado: <strong className="text-slate-700">{comp.encargadoFlotilla}</strong>
                    </span>
                  </div>

                  <span className="font-mono text-xs font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                    {countVeh} autos
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Detalle de la Empresa y sus Vehículos */}
        {selectedCompany && (
          <div className="lg:col-span-8 space-y-6">
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
              {/* Encabezado */}
              <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-slate-100">
                <div>
                  <span className="text-xs font-mono font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                    RFC: {selectedCompany.rfc}
                  </span>
                  <h3 className="text-xl font-bold text-slate-800 mt-1">
                    {selectedCompany.razonSocial}
                  </h3>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1">
                    <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                    <span>{selectedCompany.direccion}</span>
                  </div>
                </div>

                <div className="bg-slate-50 px-3.5 py-2 rounded-xl border border-slate-200 text-right text-xs">
                  <span className="text-slate-500 block font-medium">Condición de Pago:</span>
                  <span className="font-bold text-amber-600">
                    Crédito {selectedCompany.diasCredito || 15} Días
                  </span>
                </div>
              </div>

              {/* Ficha de Contactos Múltiples */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 my-4 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
                <div>
                  <span className="text-slate-500 block font-medium">Encargado de Flotilla:</span>
                  <span className="font-bold text-slate-800 text-sm">
                    {selectedCompany.encargadoFlotilla}
                  </span>
                  <div className="mt-2 space-y-1">
                    <span className="text-slate-500 block">Teléfonos de Contacto:</span>
                    {selectedCompany.telefonos.map((tel, i) => (
                      <div key={i} className="flex items-center gap-1 text-slate-700 font-mono">
                        <Phone className="w-3 h-3 text-rose-600" />
                        <span>{tel}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="text-slate-500 block font-medium">Correos Electrónicos:</span>
                  <div className="mt-1 space-y-1">
                    {selectedCompany.correos.map((correo, i) => (
                      <div key={i} className="flex items-center gap-1 text-slate-700">
                        <Mail className="w-3 h-3 text-rose-600" />
                        <span>{correo}</span>
                      </div>
                    ))}
                  </div>
                  {selectedCompany.notas && (
                    <div className="mt-3 p-2 bg-white rounded border border-slate-200 text-[11px] text-slate-600">
                      <strong>Notas:</strong> {selectedCompany.notas}
                    </div>
                  )}
                </div>
              </div>

              {/* Lista de Vehículos de la Flotilla */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
                    <Car className="w-4 h-4 text-rose-600" />
                    <span>Vehículos Registrados en esta Flota ({companyVehicles.length})</span>
                  </h4>
                </div>

                {companyVehicles.length === 0 ? (
                  <p className="text-xs text-slate-500 italic bg-slate-50 p-4 rounded-xl border border-slate-100">
                    No hay vehículos registrados para esta empresa todavía.
                  </p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {companyVehicles.map((veh) => {
                      // Comprobar alerta de 2 meses o 10,000 km
                      let hasAlert = false;
                      let alertText = '';
                      if (veh.ultimoServicioFecha) {
                        const m = (Date.now() - new Date(veh.ultimoServicioFecha).getTime()) / (1000 * 60 * 60 * 24 * 30.4);
                        if (m >= 2) {
                          hasAlert = true;
                          alertText = `Hace ${Math.floor(m)} meses`;
                        }
                      }
                      if (veh.ultimoServicioKm && veh.kilometrajeActual - veh.ultimoServicioKm >= 10000) {
                        hasAlert = true;
                        alertText += (alertText ? ' / ' : '') + `>10,000 km`;
                      }

                      return (
                        <div
                          key={veh.id}
                          className="bg-white border border-slate-200 rounded-xl p-3.5 hover:border-slate-300 transition-colors shadow-sm"
                        >
                          <div className="flex items-start justify-between">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-mono font-black text-sm bg-rose-50 text-rose-700 px-2 py-0.5 rounded border border-rose-200">
                                  {veh.placas}
                                </span>
                                <span className="font-bold text-slate-800 text-xs">
                                  {veh.marca} {veh.modelo}
                                </span>
                              </div>
                              <span className="text-[11px] text-slate-500 block mt-1">
                                Chofer: <strong className="text-slate-700">{veh.choferHabitual || 'Sin chofer'}</strong>
                                {veh.choferTelefono && ` (${veh.choferTelefono})`}
                              </span>
                              <span className="text-[11px] font-mono text-slate-500 block mt-0.5">
                                Odómetro: {veh.kilometrajeActual.toLocaleString()} km
                              </span>
                            </div>

                            {hasAlert && (
                              <span
                                className="flex items-center gap-1 text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200 shrink-0"
                                title="Alerta preventiva (2 meses / 10,000 km)"
                              >
                                <AlertTriangle className="w-3 h-3 text-amber-600" />
                                <span>{alertText}</span>
                              </span>
                            )}
                          </div>

                          <div className="flex items-center justify-between gap-2 mt-3 pt-2 border-t border-slate-100 text-xs">
                            {onSelectVehicle && (
                              <button
                                onClick={() => onSelectVehicle(veh)}
                                className="text-rose-600 hover:text-rose-700 font-semibold"
                              >
                                Ver Bitácora
                              </button>
                            )}

                            {hasAlert && (
                              <a
                                href={StorageService.generateWhatsAppReminder(
                                  veh,
                                  selectedCompany.encargadoFlotilla,
                                  selectedCompany.telefonos[0] || '6644093068',
                                  alertText
                                )}
                                target="_blank"
                                rel="noreferrer"
                                className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[10px] font-bold shadow-sm"
                              >
                                <MessageCircle className="w-3 h-3" />
                                <span>Avisar WA</span>
                              </a>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* TABLERO DE RECORDATORIOS PREVENTIVOS GENERALES */}
            <div className="bg-white border border-amber-200 rounded-2xl p-6 shadow-sm">
              <div className="flex items-center gap-2 text-amber-700 font-bold text-xs uppercase tracking-wider mb-2">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <span>Panel de Alertas de Mantenimiento Preventivo (Regla: 2 Meses o 10,000 Km)</span>
              </div>
              <h3 className="text-base font-bold text-slate-800 mb-4">
                Vehículos con Servicio Sugerido Pendiente ({allAlerts.length})
              </h3>

              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {allAlerts.map((rec) => (
                  <div
                    key={rec.vehicle.id}
                    className="flex flex-wrap items-center justify-between gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                          {rec.vehicle.placas}
                        </span>
                        <strong className="text-slate-800">
                          {rec.vehicle.marca} {rec.vehicle.modelo}
                        </strong>
                        <span className="text-slate-500">
                          ({rec.company ? rec.company.razonSocial : rec.client?.nombre})
                        </span>
                      </div>
                      <span className="text-[11px] text-amber-700 font-semibold block mt-1">
                        ⚠️ {rec.motivoAlerta}
                      </span>
                    </div>

                    <a
                      href={StorageService.generateWhatsAppReminder(
                        rec.vehicle,
                        rec.client?.nombre || rec.company?.encargadoFlotilla || 'Cliente',
                        rec.client?.telefono || rec.company?.telefonos[0] || '6644093068',
                        rec.motivoAlerta
                      )}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-sm"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>Enviar Recordatorio por WhatsApp</span>
                    </a>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* MODAL PARA DAR DE ALTA EMPRESA */}
      {isAddingCompany && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-xl w-full p-6 shadow-2xl text-slate-800">
            <h3 className="text-lg font-bold text-slate-800 mb-1">
              Dar de Alta Empresa / Flotilla
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Registra los datos fiscales, encargado y contactos múltiples para el CRM
            </p>

            <form onSubmit={handleSaveCompany} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="text-xs text-slate-600 block mb-1 font-medium">
                    Razón Social *:
                  </label>
                  <input
                    type="text"
                    value={razonSocial}
                    onChange={(e) => setRazonSocial(e.target.value)}
                    placeholder="Ej. TRANSPORTES DEL PACIFICO S.A. DE C.V."
                    required
                    className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none uppercase"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-600 block mb-1 font-medium">RFC:</label>
                  <input
                    type="text"
                    value={rfc}
                    onChange={(e) => setRfc(e.target.value.toUpperCase())}
                    placeholder="TPA190204KL8"
                    className="w-full bg-slate-50 border border-slate-300 text-slate-800 font-mono rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-600 block mb-1 font-medium">
                    Encargado de Flotilla *:
                  </label>
                  <input
                    type="text"
                    value={encargado}
                    onChange={(e) => setEncargado(e.target.value)}
                    placeholder="Ej. Lic. Fernando Orozco"
                    required
                    className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="text-xs text-slate-600 block mb-1 font-medium">
                    Dirección Física:
                  </label>
                  <input
                    type="text"
                    value={direccion}
                    onChange={(e) => setDireccion(e.target.value)}
                    placeholder="Blvd. Insurgentes #14200, Tijuana B.C."
                    className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-600 block mb-1 font-medium">
                    Teléfonos (separados por coma):
                  </label>
                  <input
                    type="text"
                    value={telefonos}
                    onChange={(e) => setTelefonos(e.target.value)}
                    placeholder="664-987-6543, 664-210-9876"
                    className="w-full bg-slate-50 border border-slate-300 text-slate-800 font-mono rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-600 block mb-1 font-medium">
                    Correos Electrónicos (separados por coma):
                  </label>
                  <input
                    type="text"
                    value={correos}
                    onChange={(e) => setCorreos(e.target.value)}
                    placeholder="flotilla@empresa.com, pagos@empresa.com"
                    className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1 font-medium">
                  Notas / Observaciones de Flotilla:
                </label>
                <textarea
                  value={notas}
                  onChange={(e) => setNotas(e.target.value)}
                  placeholder="Instrucciones especiales para choferes, facturación, etc."
                  rows={2}
                  className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg p-2.5 text-xs focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddingCompany(false)}
                  className="flex-1 py-2 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-all active:scale-95"
                >
                  Guardar Empresa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
