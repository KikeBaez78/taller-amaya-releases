'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { X, ZoomIn, ZoomOut, RotateCcw, ChevronLeft, ChevronRight, ExternalLink } from 'lucide-react';

export interface LightboxPhoto {
  url: string;
  title?: string;
}

interface ImageLightboxModalProps {
  isOpen: boolean;
  onClose: () => void;
  photos?: LightboxPhoto[];
  initialIndex?: number;
  currentPhoto?: LightboxPhoto | null;
}

export const ImageLightboxModal: React.FC<ImageLightboxModalProps> = ({
  isOpen,
  onClose,
  photos,
  initialIndex = 0,
  currentPhoto,
}) => {
  // Normalize items to an array of LightboxPhoto
  const items: LightboxPhoto[] = React.useMemo(() => {
    if (photos && photos.length > 0) return photos.filter((p) => Boolean(p && p.url));
    if (currentPhoto && currentPhoto.url) return [currentPhoto];
    return [];
  }, [photos, currentPhoto]);

  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [zoom, setZoom] = useState(1);

  // Sync index when initialIndex or items change
  useEffect(() => {
    if (initialIndex >= 0 && initialIndex < items.length) {
      setCurrentIndex(initialIndex);
    } else {
      setCurrentIndex(0);
    }
    setZoom(1);
  }, [initialIndex, items.length, isOpen]);

  // Reset zoom on index change
  useEffect(() => {
    setZoom(1);
  }, [currentIndex]);

  const hasMultiple = items.length > 1;
  const activePhoto = items[currentIndex];

  const handlePrev = useCallback(() => {
    if (!hasMultiple) return;
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : items.length - 1));
  }, [hasMultiple, items.length]);

  const handleNext = useCallback(() => {
    if (!hasMultiple) return;
    setCurrentIndex((prev) => (prev < items.length - 1 ? prev + 1 : 0));
  }, [hasMultiple, items.length]);

  // Handle keyboard navigation & body scroll
  useEffect(() => {
    if (!isOpen) return;

    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowLeft') {
        handlePrev();
      } else if (e.key === 'ArrowRight') {
        handleNext();
      } else if (e.key === '+' || e.key === '=') {
        setZoom((z) => Math.min(3, +(z + 0.25).toFixed(2)));
      } else if (e.key === '-') {
        setZoom((z) => Math.max(0.75, +(z - 0.25).toFixed(2)));
      } else if (e.key === '0') {
        setZoom(1);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.body.style.overflow = originalOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose, handlePrev, handleNext]);

  if (!isOpen || !activePhoto) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-[100] flex flex-col bg-slate-950/95 backdrop-blur-md text-white select-none animate-in fade-in duration-200"
      onClick={onClose}
    >
      {/* Barra superior de controles */}
      <div
        className="flex items-center justify-between px-4 py-3 bg-slate-900/80 border-b border-slate-800/80 z-20 shrink-0"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3">
          <span className="text-xs sm:text-sm font-black text-rose-400 uppercase tracking-wider">
            {activePhoto.title || 'Fotografía de Inspección'}
          </span>
          {hasMultiple && (
            <span className="text-xs bg-slate-800 text-slate-300 px-2.5 py-0.5 rounded-full font-bold border border-slate-700">
              {currentIndex + 1} de {items.length}
            </span>
          )}
        </div>

        {/* Botones de acción y zoom */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Zoom controls */}
          <div className="flex items-center bg-slate-800/90 rounded-xl p-1 border border-slate-700">
            <button
              type="button"
              onClick={() => setZoom((z) => Math.max(0.75, +(z - 0.25).toFixed(2)))}
              disabled={zoom <= 0.75}
              title="Alejar (-)"
              className="p-1.5 hover:bg-slate-700 rounded-lg text-slate-300 disabled:opacity-30 disabled:hover:bg-transparent transition-colors"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="text-[11px] font-mono px-2 text-slate-300 min-w-[42px] text-center">
              {Math.round(zoom * 100)}%
            </span>
            <button
              type="button"
              onClick={() => setZoom((z) => Math.min(3, +(z + 0.25).toFixed(2)))}
              disabled={zoom >= 3}
              title="Acercar (+)"
              className="p-1.5 hover:bg-slate-700 rounded-lg text-slate-300 disabled:opacity-30 disabled:hover:bg-transparent transition-colors"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            {zoom !== 1 && (
              <button
                type="button"
                onClick={() => setZoom(1)}
                title="Restablecer tamaño (0)"
                className="p-1.5 hover:bg-slate-700 rounded-lg text-rose-400 transition-colors border-l border-slate-700 ml-0.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Abrir en nueva pestaña */}
          <a
            href={activePhoto.url}
            target="_blank"
            rel="noopener noreferrer"
            title="Abrir imagen completa en nueva pestaña"
            className="p-2 hover:bg-slate-800 text-slate-300 hover:text-white rounded-xl transition-colors border border-slate-800 hidden sm:flex items-center justify-center"
          >
            <ExternalLink className="w-4 h-4" />
          </a>

          {/* Botón Cerrar */}
          <button
            type="button"
            onClick={onClose}
            title="Cerrar (Esc)"
            className="p-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold transition-transform active:scale-95 shadow-lg flex items-center gap-1.5"
          >
            <X className="w-5 h-5" />
            <span className="text-xs font-semibold hidden sm:inline">Cerrar</span>
          </button>
        </div>
      </div>

      {/* Contenedor principal de la imagen */}
      <div
        className="flex-1 relative flex items-center justify-center p-3 sm:p-6 overflow-hidden"
        onClick={onClose}
      >
        {/* Flecha Izquierda (Anterior) */}
        {hasMultiple && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handlePrev();
            }}
            title="Foto anterior (←)"
            className="absolute left-3 sm:left-6 z-30 p-3 sm:p-3.5 rounded-full bg-slate-900/80 hover:bg-rose-600 text-white border border-slate-700/60 transition-all hover:scale-110 active:scale-95 shadow-2xl backdrop-blur-sm"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}

        {/* Imagen Ampliada */}
        <div
          className="relative max-w-full max-h-full flex items-center justify-center overflow-auto cursor-default"
          onClick={(e) => e.stopPropagation()}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={activePhoto.url}
            alt={activePhoto.title || 'Foto de inspección vehicular'}
            style={{ transform: `scale(${zoom})` }}
            className="max-h-[82vh] max-w-[92vw] sm:max-w-[85vw] object-contain rounded-2xl shadow-2xl border border-slate-800/80 transition-transform duration-150"
            onClick={() => setZoom((z) => (z === 1 ? 1.75 : 1))}
            title="Haz clic para alternar zoom"
          />
        </div>

        {/* Flecha Derecha (Siguiente) */}
        {hasMultiple && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handleNext();
            }}
            title="Siguiente foto (→)"
            className="absolute right-3 sm:right-6 z-30 p-3 sm:p-3.5 rounded-full bg-slate-900/80 hover:bg-rose-600 text-white border border-slate-700/60 transition-all hover:scale-110 active:scale-95 shadow-2xl backdrop-blur-sm"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}
      </div>

      {/* Barra inferior: tira de miniaturas si hay múltiples fotos */}
      {hasMultiple && (
        <div
          className="px-4 py-2 bg-slate-900/90 border-t border-slate-800/80 z-20 shrink-0 overflow-x-auto flex items-center justify-center gap-2"
          onClick={(e) => e.stopPropagation()}
        >
          {items.map((item, idx) => {
            const isSelected = idx === currentIndex;
            return (
              <button
                key={idx}
                type="button"
                onClick={() => setCurrentIndex(idx)}
                className={`relative rounded-lg overflow-hidden border-2 transition-all w-14 h-11 shrink-0 ${
                  isSelected
                    ? 'border-rose-500 ring-2 ring-rose-500/40 scale-105'
                    : 'border-slate-700 opacity-60 hover:opacity-100'
                }`}
                title={item.title || `Foto ${idx + 1}`}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={item.url} alt="" className="w-full h-full object-cover" />
                <span className="absolute bottom-0 inset-x-0 bg-slate-950/80 text-[8px] font-bold text-center text-white truncate px-0.5">
                  {idx + 1}
                </span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};
