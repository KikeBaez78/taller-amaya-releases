'use client';

import React, { useState } from 'react';
import { StorageService } from '@/lib/storage';
import { Mechanic, WorkOrder, ServiceItem } from '@/types';
import { ReinaSecurityModal } from './ReinaSecurityModal';
import {
  Wrench,
  DollarSign,
  UserCheck,
  CheckCircle2,
  Clock,
  Plus,
  Percent,
  TrendingUp,
  ShieldAlert,
  ChevronRight,
  FileSpreadsheet,
  Edit2,
  Trash2,
  Settings,
  X,
  Phone,
  User,
} from 'lucide-react';

interface MecanicosPanelProps {
  onRefreshOrders?: () => void;
}

export const MecanicosPanel: React.FC<MecanicosPanelProps> = ({ onRefreshOrders }) => {
  const [mechanics, setMechanics] = useState<Mechanic[]>(StorageService.getMechanics());
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(StorageService.getWorkOrders());

  React.useEffect(() => {
    const handleSync = () => {
      setMechanics(StorageService.getMechanics());
      setWorkOrders(StorageService.getWorkOrders());
    };
    window.addEventListener('taller_data_synced', handleSync);
    return () => window.removeEventListener('taller_data_synced', handleSync);
  }, []);

  const [selectedMechanicId, setSelectedMechanicId] = useState<string>(mechanics[0]?.id || '');

  // Modal para ASIGNAR TRABAJO a mecánico
  const [isAssigning, setIsAssigning] = useState(false);
  const [targetOrderId, setTargetOrderId] = useState(workOrders[0]?.id || '');
  const [concepto, setConcepto] = useState('');
  const [manoObra, setManoObra] = useState<number>(1000);
  const [refaccionesMonto, setRefaccionesMonto] = useState<number>(0);
  const [comisionPorcentaje, setComisionPorcentaje] = useState<number>(30); // 10% al 45%

  // Modal para CONFIGURAR / CREAR / EDITAR MECÁNICO
  const [isManagingMechanic, setIsManagingMechanic] = useState(false);
  const [editingMechanicId, setEditingMechanicId] = useState<string | null>(null);
  const [mecNombre, setMecNombre] = useState('');
  const [mecEspecialidad, setMecEspecialidad] = useState('');
  const [mecTelefono, setMecTelefono] = useState('');
  const [mecComisionDefault, setMecComisionDefault] = useState<number>(30);

  // Estado para eliminar con autorización de Reyna Amaya (PIN 2036)
  const [mecToDelete, setMecToDelete] = useState<Mechanic | null>(null);

  const handleConfirmDeleteMechanic = () => {
    if (!mecToDelete) return;
    const updatedList = StorageService.deleteMechanic(mecToDelete.id);
    setMechanics([...updatedList]);
    if (selectedMechanicId === mecToDelete.id) {
      setSelectedMechanicId(updatedList[0]?.id || '');
    }
    setMecToDelete(null);
  };

  // Abrir modal para crear nuevo mecánico
  const handleOpenNewMechanic = () => {
    setEditingMechanicId(null);
    setMecNombre('');
    setMecEspecialidad('Mecánica General');
    setMecTelefono('');
    setMecComisionDefault(30);
    setIsManagingMechanic(true);
  };

  // Abrir modal para editar mecánico existente
  const handleOpenEditMechanic = (mec: Mechanic, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingMechanicId(mec.id);
    setMecNombre(mec.nombre);
    setMecEspecialidad(mec.especialidad);
    setMecTelefono(mec.telefono);
    setMecComisionDefault(mec.comisionDefault);
    setIsManagingMechanic(true);
  };

  // Guardar mecánico (nuevo o editado)
  const handleSaveMechanic = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mecNombre.trim()) return;

    const mechanicToSave: Mechanic = {
      id: editingMechanicId || `mec-${Date.now()}`,
      nombre: mecNombre.trim(),
      especialidad: mecEspecialidad.trim() || 'Mecánica General',
      telefono: mecTelefono.trim() || '664-000-0000',
      comisionDefault: Number(mecComisionDefault) || 30,
      activo: true,
    };

    const updatedList = StorageService.saveMechanic(mechanicToSave);
    setMechanics([...updatedList]);
    if (!selectedMechanicId || editingMechanicId === selectedMechanicId) {
      setSelectedMechanicId(mechanicToSave.id);
    }
    setIsManagingMechanic(false);
    alert(`¡Mecánico "${mechanicToSave.nombre}" guardado con ${mechanicToSave.comisionDefault}% de comisión base!`);
  };

  // Eliminar mecánico
  const handleDeleteMechanic = (mecId: string, mecName: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm(`¿Estás seguro de eliminar a "${mecName}" de la lista de mecánicos?`)) {
      return;
    }

    const updatedList = StorageService.deleteMechanic(mecId);
    setMechanics([...updatedList]);
    if (selectedMechanicId === mecId) {
      setSelectedMechanicId(updatedList[0]?.id || '');
    }
  };

  // Comisiones calculadas por mecánico
  const statsByMechanic = mechanics.map((mec) => {
    let totalComisiones = 0;
    let totalManoObraGenerada = 0;
    let totalRefaccionesGeneradas = 0;
    let tareasCompletadas = 0;
    let tareasPendientes = 0;

    const assignedServices: { order: WorkOrder; service: ServiceItem }[] = [];

    workOrders.forEach((order) => {
      order.servicios.forEach((srv) => {
        if (srv.mecanicoId === mec.id) {
          assignedServices.push({ order, service: srv });
          totalComisiones += srv.comisionManoObra;
          totalManoObraGenerada += srv.manoObra;
          totalRefaccionesGeneradas += srv.refaccionesMonto;
          if (srv.estado === 'terminado') {
            tareasCompletadas++;
          } else {
            tareasPendientes++;
          }
        }
      });
    });

    return {
      mechanic: mec,
      totalComisiones,
      totalManoObraGenerada,
      totalRefaccionesGeneradas,
      tareasCompletadas,
      tareasPendientes,
      assignedServices,
    };
  });

  const activeStats = statsByMechanic.find((s) => s.mechanic.id === selectedMechanicId);

  // Cálculo en tiempo real de la comisión para el modal
  const previewComision = Math.round(manoObra * (comisionPorcentaje / 100));

  // Asignar trabajo a mecánico
  const handleAssignTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetOrderId || !concepto.trim()) return;

    const order = workOrders.find((o) => o.id === targetOrderId);
    if (!order) return;

    const mec = mechanics.find((m) => m.id === selectedMechanicId);

    const newService: ServiceItem = {
      id: `srv-${Date.now()}`,
      concepto: concepto.trim(),
      mecanicoId: selectedMechanicId,
      mecanicoNombre: mec ? mec.nombre : 'Mecánico',
      manoObra: Number(manoObra),
      refaccionesMonto: Number(refaccionesMonto),
      comisionPorcentaje: Number(comisionPorcentaje),
      comisionManoObra: previewComision,
      estado: 'en_progreso',
    };

    order.servicios.push(newService);
    order.subtotalManoObra += newService.manoObra;
    order.subtotalRefacciones += newService.refaccionesMonto;
    order.subtotalGeneral = order.subtotalManoObra + order.subtotalRefacciones;
    order.totalComisionesMecanicos += newService.comisionManoObra;
    order.saldoPendiente = order.subtotalGeneral - order.totalPagado;

    StorageService.saveWorkOrder(order);
    setWorkOrders(StorageService.getWorkOrders());
    alert(`¡Trabajo asignado a ${mec?.nombre} con ${comisionPorcentaje}% de comisión sobre mano de obra!`);
    setIsAssigning(false);
    setConcepto('');
    if (onRefreshOrders) onRefreshOrders();
  };

  // Marcar trabajo como Terminado / En progreso
  const handleToggleServiceStatus = (orderId: string, serviceId: string) => {
    const order = workOrders.find((o) => o.id === orderId);
    if (!order) return;

    const srv = order.servicios.find((s) => s.id === serviceId);
    if (!srv) return;

    srv.estado = srv.estado === 'terminado' ? 'en_progreso' : 'terminado';
    StorageService.saveWorkOrder(order);
    setWorkOrders(StorageService.getWorkOrders());
    if (onRefreshOrders) onRefreshOrders();
  };

  return (
    <div className="space-y-6">
      {/* Banner Superior */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-rose-600 text-xs font-bold uppercase tracking-wider mb-1">
            <Percent className="w-4 h-4" />
            <span>Nómina y Comisiones por Mano de Obra (10% al 45%)</span>
          </div>
          <h2 className="text-2xl font-black text-slate-800">
            Control de Bahías & Equipo de Mecánicos
          </h2>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            Configura los técnicos del taller, asigna trabajos por orden de servicio y ajusta el porcentaje de comisión (10% al 45%) exclusivo sobre la <strong>Mano de Obra</strong>. Las refacciones están <strong>100% exentas</strong> de comisión.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleOpenNewMechanic}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs border border-slate-200 transition-colors shadow-2xs"
          >
            <Plus className="w-4 h-4 text-slate-600" />
            <span>+ Agregar Mecánico</span>
          </button>

          <button
            onClick={() => {
              if (workOrders.length === 0) {
                alert('Aún no hay órdenes de trabajo activas. Primero crea una orden en "Nueva Orden" para asignarle trabajos al mecánico.');
                return;
              }
              setIsAssigning(true);
            }}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-all active:scale-95"
          >
            <Wrench className="w-4 h-4" />
            <span>Asignar Trabajo a Mecánico</span>
          </button>
        </div>
      </div>

      {/* Grid de Mecánicos Registrados */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {mechanics.length === 0 ? (
          <div className="col-span-full bg-white border border-dashed border-slate-300 rounded-2xl p-8 text-center text-slate-500">
            <User className="w-10 h-10 mx-auto text-slate-400 mb-2" />
            <h4 className="font-bold text-slate-700">No hay mecánicos registrados</h4>
            <p className="text-xs text-slate-400 mt-1 mb-3">
              Agrega los nombres de los técnicos del taller y sus comisiones base
            </p>
            <button
              onClick={handleOpenNewMechanic}
              className="px-4 py-2 bg-rose-600 text-white rounded-xl text-xs font-bold"
            >
              + Agregar Primer Mecánico
            </button>
          </div>
        ) : (
          statsByMechanic.map(({ mechanic, totalComisiones, tareasPendientes, tareasCompletadas }) => {
            const isSelected = mechanic.id === selectedMechanicId;

            return (
              <div
                key={mechanic.id}
                onClick={() => setSelectedMechanicId(mechanic.id)}
                className={`bg-white border rounded-2xl p-5 cursor-pointer transition-all hover:border-rose-400 hover:shadow-md relative group ${
                  isSelected
                    ? 'border-rose-500 ring-2 ring-rose-500/20 bg-rose-50/20 shadow-sm'
                    : 'border-slate-200'
                }`}
              >
                {/* Botones de acción rápida: Editar / Eliminar */}
                <div className="absolute top-4 right-4 flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={(e) => handleOpenEditMechanic(mechanic, e)}
                    className="p-1 text-slate-400 hover:text-slate-800 rounded hover:bg-slate-100"
                    title="Editar nombre o comisión"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setMecToDelete(mechanic);
                    }}
                    className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-slate-100"
                    title="Eliminar mecánico (Requiere PIN de Reyna: 2036)"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex items-start justify-between mb-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center font-black ${
                      isSelected ? 'bg-rose-600 text-white' : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {mechanic.nombre.charAt(0)}
                  </div>
                </div>

                <div className="flex items-center justify-between mb-1">
                  <h3 className="font-bold text-slate-800 text-base leading-tight">
                    {mechanic.nombre}
                  </h3>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-mono">
                    Base {mechanic.comisionDefault}%
                  </span>
                </div>
                <p className="text-xs text-slate-500 mb-1">{mechanic.especialidad}</p>
                <span className="text-[10px] text-slate-400 block font-mono mb-4">
                  Tel: {mechanic.telefono}
                </span>

                <div className="pt-3 border-t border-slate-100 space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Comisión Acumulada:</span>
                    <span className="font-mono text-emerald-600 font-black text-sm">
                      ${totalComisiones.toLocaleString()} MXN
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-500 text-[11px]">
                    <span>Trabajos Activos:</span>
                    <span className="text-amber-600 font-bold">{tareasPendientes} en proceso</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-500 text-[11px]">
                    <span>Completados:</span>
                    <span className="text-slate-700 font-semibold">{tareasCompletadas} listos</span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Detalle y Desglose del Mecánico Seleccionado */}
      {activeStats && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-black text-slate-800">
                  Desglose de Trabajos: {activeStats.mechanic.nombre}
                </h3>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-rose-50 text-rose-700 border border-rose-200 font-semibold">
                  {activeStats.mechanic.especialidad}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Teléfono: {activeStats.mechanic.telefono} | Comisión base configurada: <strong>{activeStats.mechanic.comisionDefault}%</strong>
              </p>
            </div>

            <div className="bg-slate-50 px-4 py-2.5 rounded-xl border border-slate-200 text-right">
              <span className="text-[10px] text-slate-500 uppercase font-bold block">
                Total Acumulado de Comisiones:
              </span>
              <span className="font-mono text-xl font-black text-emerald-600">
                ${activeStats.totalComisiones.toLocaleString()} MXN
              </span>
            </div>
          </div>

          {/* Métricas Clave */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="text-xs text-slate-500 block font-medium">Mano de Obra Facturada:</span>
              <span className="font-mono text-lg font-bold text-sky-700">
                ${activeStats.totalManoObraGenerada.toLocaleString()} MXN
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">Base sobre la que se calcula su porcentaje</span>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="text-xs text-slate-500 block font-medium">Refacciones Utilizadas:</span>
              <span className="font-mono text-lg font-bold text-slate-700">
                ${activeStats.totalRefaccionesGeneradas.toLocaleString()} MXN
              </span>
              <span className="text-[10px] text-emerald-600 font-semibold block mt-0.5">
                ✓ 100% Exentas de Comisión (Taller Amaya)
              </span>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="text-xs text-slate-500 block font-medium">Efectividad en Bahía:</span>
              <span className="font-mono text-lg font-bold text-amber-600">
                {activeStats.tareasCompletadas} / {activeStats.tareasCompletadas + activeStats.tareasPendientes}
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">Trabajos concluidos</span>
            </div>
          </div>

          {/* Tabla de Servicios Asignados a este Mecánico */}
          <div>
            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
              Lista de Conceptos y Operaciones Asignadas
            </h4>

            {activeStats.assignedServices.length === 0 ? (
              <p className="text-xs text-slate-500 italic bg-slate-50 p-4 rounded-xl border border-slate-100 text-center">
                No hay servicios asignados a este mecánico todavía. Asigna un trabajo usando el botón arriba.
              </p>
            ) : (
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500 font-semibold bg-slate-50">
                      <th className="py-2.5 px-3">Folio OT</th>
                      <th className="py-2.5 px-3">Concepto / Trabajo</th>
                      <th className="py-2.5 px-3 text-right">Mano de Obra</th>
                      <th className="py-2.5 px-3 text-center">% Comisión</th>
                      <th className="py-2.5 px-3 text-right">Comisión Ganada</th>
                      <th className="py-2.5 px-3 text-right">Refacciones (0%)</th>
                      <th className="py-2.5 px-3 text-center">Estado</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {activeStats.assignedServices.map(({ order, service }) => (
                      <tr key={service.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-3 font-mono font-bold text-rose-600">
                          #{order.folio}
                        </td>
                        <td className="py-3 px-3">
                          <span className="font-semibold text-slate-800 block">{service.concepto}</span>
                          <span className="text-[10px] text-slate-500">
                            Falla: {order.fallaReportada.substring(0, 40)}...
                          </span>
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-semibold text-slate-700">
                          ${service.manoObra.toLocaleString()}
                        </td>
                        <td className="py-3 px-3 text-center">
                          <span className="font-mono font-bold px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200 text-[11px]">
                            {service.comisionPorcentaje}%
                          </span>
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-black text-emerald-600">
                          ${service.comisionManoObra.toLocaleString()}
                        </td>
                        <td className="py-3 px-3 text-right font-mono text-slate-400">
                          ${service.refaccionesMonto.toLocaleString()}
                        </td>
                        <td className="py-3 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => handleToggleServiceStatus(order.id, service.id)}
                            className={`text-[10px] font-bold uppercase px-2.5 py-1 rounded-full border transition-all cursor-pointer ${
                              service.estado === 'terminado'
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-emerald-100'
                                : 'bg-amber-50 text-amber-700 border-amber-300 hover:bg-amber-100'
                            }`}
                            title="Toca para cambiar estado de terminado o en proceso"
                          >
                            {service.estado === 'terminado' ? '✓ Terminado' : '⏳ En Proceso'}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL PARA CREAR / EDITAR MECÁNICO */}
      {isManagingMechanic && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white border border-slate-200 rounded-3xl max-w-md w-full p-6 shadow-2xl text-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-lg font-bold text-slate-900">
                {editingMechanicId ? 'Editar Datos del Mecánico' : 'Alta de Nuevo Mecánico'}
              </h3>
              <button
                type="button"
                onClick={() => setIsManagingMechanic(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveMechanic} className="space-y-4">
              <div>
                <label className="text-xs text-slate-600 block mb-1 font-semibold">
                  Nombre Completo *:
                </label>
                <input
                  type="text"
                  value={mecNombre}
                  onChange={(e) => setMecNombre(e.target.value)}
                  placeholder="Ej. Carlos Mendoza, Javier Ruiz..."
                  required
                  className="w-full bg-slate-50 border border-slate-200 text-slate-900 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1 font-semibold">
                  Especialidad Técnica *:
                </label>
                <input
                  type="text"
                  value={mecEspecialidad}
                  onChange={(e) => setMecEspecialidad(e.target.value)}
                  placeholder="Ej. Frenos y suspensión, Afinación y motor, Eléctrico..."
                  required
                  className="w-full bg-slate-50 border border-slate-200 text-slate-900 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1 font-semibold">
                  Teléfono Celular:
                </label>
                <input
                  type="tel"
                  value={mecTelefono}
                  onChange={(e) => setMecTelefono(e.target.value)}
                  placeholder="664-123-4567"
                  className="w-full bg-slate-50 border border-slate-200 text-slate-900 font-mono rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              {/* Selector de Comisión Base 10% al 45% */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs text-slate-700 font-bold block">
                    Porcentaje de Comisión Base (Mano de Obra):
                  </label>
                  <span className="font-mono text-base font-black text-rose-600 px-2.5 py-0.5 rounded-lg bg-rose-50 border border-rose-200">
                    {mecComisionDefault}%
                  </span>
                </div>

                {/* Botones de selección rápida del 10 al 45% */}
                <div className="grid grid-cols-8 gap-1 mb-2">
                  {[10, 15, 20, 25, 30, 35, 40, 45].map((pct) => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => setMecComisionDefault(pct)}
                      className={`py-1 text-center font-mono text-xs font-bold rounded-lg transition-colors ${
                        mecComisionDefault === pct
                          ? 'bg-rose-600 text-white font-black shadow-xs'
                          : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                      }`}
                    >
                      {pct}%
                    </button>
                  ))}
                </div>

                <input
                  type="range"
                  min="10"
                  max="45"
                  step="5"
                  value={mecComisionDefault}
                  onChange={(e) => setMecComisionDefault(Number(e.target.value))}
                  className="w-full accent-rose-600"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsManagingMechanic(false)}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-all active:scale-95"
                >
                  Guardar Mecánico
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL PARA ASIGNAR TRABAJO A MECÁNICO */}
      {isAssigning && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white border border-slate-200 rounded-3xl max-w-lg w-full p-6 shadow-2xl text-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  Asignar Trabajo & Configurar Comisión
                </h3>
                <p className="text-xs text-slate-500">
                  Selecciona la orden de trabajo y el porcentaje de comisión para el técnico
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsAssigning(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAssignTask} className="space-y-4">
              <div>
                <label className="text-xs text-slate-600 block mb-1 font-semibold">
                  Mecánico Asignado *:
                </label>
                <select
                  value={selectedMechanicId}
                  onChange={(e) => {
                    setSelectedMechanicId(e.target.value);
                    const found = mechanics.find((m) => m.id === e.target.value);
                    if (found) setComisionPorcentaje(found.comisionDefault);
                  }}
                  className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                >
                  {mechanics.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.nombre} ({m.especialidad}) - Base {m.comisionDefault}%
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1 font-semibold">
                  Orden de Trabajo / Folio *:
                </label>
                <select
                  value={targetOrderId}
                  onChange={(e) => setTargetOrderId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none font-mono"
                >
                  {workOrders.map((o) => (
                    <option key={o.id} value={o.id}>
                      Folio #{o.folio} - {o.fallaReportada.substring(0, 35)}... ({o.estado})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1 font-semibold">
                  Concepto o Trabajo Específico *:
                </label>
                <input
                  type="text"
                  value={concepto}
                  onChange={(e) => setConcepto(e.target.value)}
                  placeholder="Ej. Rectificado de discos y cambio de balatas delanteras..."
                  required
                  className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-rose-600 block mb-1 font-bold">
                    Mano de Obra ($ MXN) *:
                  </label>
                  <input
                    type="number"
                    value={manoObra}
                    onChange={(e) => setManoObra(Number(e.target.value))}
                    required
                    className="w-full bg-rose-50/40 border border-rose-300 text-rose-700 font-mono font-bold rounded-xl px-3 py-2 text-sm focus:outline-none text-right"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-600 block mb-1 font-medium">
                    Refacciones ($ MXN):
                  </label>
                  <input
                    type="number"
                    value={refaccionesMonto}
                    onChange={(e) => setRefaccionesMonto(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 font-mono rounded-xl px-3 py-2 text-sm focus:outline-none text-right"
                  />
                  <span className="text-[10px] text-emerald-600 block mt-0.5">Exentas de comisión</span>
                </div>
              </div>

              {/* Selector del 10% al 45% */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs text-slate-700 font-bold block">
                    Porcentaje de Comisión sobre Mano de Obra:
                  </label>
                  <span className="font-mono text-base font-black text-rose-600 px-2.5 py-0.5 rounded-lg bg-rose-50 border border-rose-200">
                    {comisionPorcentaje}%
                  </span>
                </div>

                {/* Botones de selección rápida del 10 al 45% */}
                <div className="grid grid-cols-8 gap-1 mb-2">
                  {[10, 15, 20, 25, 30, 35, 40, 45].map((pct) => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => setComisionPorcentaje(pct)}
                      className={`py-1 text-center font-mono text-xs font-bold rounded-lg transition-colors ${
                        comisionPorcentaje === pct
                          ? 'bg-rose-600 text-white font-black shadow-xs'
                          : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                      }`}
                    >
                      {pct}%
                    </button>
                  ))}
                </div>

                <input
                  type="range"
                  min="10"
                  max="45"
                  step="5"
                  value={comisionPorcentaje}
                  onChange={(e) => setComisionPorcentaje(Number(e.target.value))}
                  className="w-full accent-rose-600"
                />

                {/* Resumen del cálculo en vivo */}
                <div className="mt-3 pt-3 border-t border-slate-200 flex items-center justify-between text-xs">
                  <span className="text-slate-500">Cálculo de Comisión:</span>
                  <span className="font-mono font-bold text-emerald-600 text-sm">
                    ${manoObra} × {comisionPorcentaje}% = ${previewComision} MXN
                  </span>
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAssigning(false)}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-all active:scale-95"
                >
                  Guardar y Asignar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal de Seguridad de Reyna para Eliminar Mecánico */}
      <ReinaSecurityModal
        isOpen={!!mecToDelete}
        onClose={() => setMecToDelete(null)}
        onSuccess={handleConfirmDeleteMechanic}
        title="Eliminar Técnico / Mecánico"
        description={`¿Estás seguro de eliminar a "${mecToDelete?.nombre}" del equipo de mecánicos? Requiere autorización de Reyna Amaya.`}
        actionLabel="Eliminar Mecánico"
        actionType="delete"
      />
    </div>
  );
};
