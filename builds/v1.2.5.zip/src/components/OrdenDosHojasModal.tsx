'use client';

import React, { useState, useEffect, useRef } from 'react';
import { StorageService } from '@/lib/storage';
import { WorkOrder, Vehicle, Client, Company, TallerConfig, MandatoryPhotos } from '@/types';
import { DEFAULT_DISCLAIMERS, DisclaimerClause } from '@/data/defaultDisclaimers';
import {
  X,
  Printer,
  FileText,
  Edit3,
  RotateCcw,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  Share2,
  Car,
  Wrench,
  DollarSign,
  Fuel,
  Camera,
  ShieldCheck,
  PenTool,
  IdCard,
  Eraser,
  UserCheck,
  Upload,
  Eye,
  Maximize2,
} from 'lucide-react';
import { ImageLightboxModal } from './ImageLightboxModal';

interface OrdenDosHojasModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: WorkOrder;
  vehicle?: Vehicle;
  client?: Client;
  company?: Company;
  config: TallerConfig;
  onOrderUpdated?: (order: WorkOrder) => void;
}

export const OrdenDosHojasModal: React.FC<OrdenDosHojasModalProps> = ({
  isOpen,
  onClose,
  order,
  vehicle,
  client,
  company,
  config,
  onOrderUpdated,
}) => {
  const [activeTab, setActiveTab] = useState<'ambas' | 'hoja1' | 'hoja2'>('ambas');
  const [disclaimers, setDisclaimers] = useState<DisclaimerClause[]>(DEFAULT_DISCLAIMERS);
  const [showEditor, setShowEditor] = useState(false);
  const [editingClauses, setEditingClauses] = useState<DisclaimerClause[]>(DEFAULT_DISCLAIMERS);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Estados de Identificación Oficial del Cliente
  const [tipoIdentificacion, setTipoIdentificacion] = useState<'INE' | 'Licencia' | 'Pasaporte' | 'Otro'>('INE');
  const [numeroIdentificacion, setNumeroIdentificacion] = useState<string>('');
  const [nombreFirmante, setNombreFirmante] = useState<string>(
    client?.nombre || order.choferNombre || ''
  );
  const [caracterFirmante, setCaracterFirmante] = useState<'Propietario' | 'Chofer' | 'Apoderado'>('Propietario');
  const [fotoIdentificacion, setFotoIdentificacion] = useState<string | null>(null);

  // Estados de Firma Digital Interactiva
  const [digitalSignature, setDigitalSignature] = useState<string | null>(
    order.firmaCliente?.startsWith('data:image') ? order.firmaCliente : null
  );
  const [showSignPad, setShowSignPad] = useState(false);
  const [isDrawing, setIsDrawing] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Cargar disclaimers guardados en localStorage si existen
  useEffect(() => {
    try {
      const saved = localStorage.getItem('taller_disclaimers');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setDisclaimers(parsed);
          setEditingClauses(parsed);
        }
      }
    } catch (e) {
      console.warn('Error al leer disclaimers de localStorage', e);
    }
  }, []);

  // Inicializar nombre si cambia el cliente
  useEffect(() => {
    if (client?.nombre && !nombreFirmante) {
      setNombreFirmante(client.nombre);
    }
  }, [client, nombreFirmante]);

  if (!isOpen) return null;

  // Formateadores
  const formatMoney = (amount?: number) => {
    const val = Number(amount || 0);
    return `$${val.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return '—';
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('es-MX', {
        year: 'numeric',
        month: 'short',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return dateString;
    }
  };

  // Manejo de la firma digital en Canvas
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setIsDrawing(true);
    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#0f172a';
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setDigitalSignature(null);

    try {
      const updatedOrder: WorkOrder = {
        ...order,
        firmaCliente: null,
      };
      StorageService.saveWorkOrder(updatedOrder);
      if (onOrderUpdated) {
        onOrderUpdated(updatedOrder);
      }
    } catch (e) {
      console.warn('Error al borrar firma:', e);
    }
  };

  const saveSignature = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    setDigitalSignature(dataUrl);
    setShowSignPad(false);

    try {
      const updatedOrder: WorkOrder = {
        ...order,
        firmaCliente: dataUrl,
      };
      StorageService.saveWorkOrder(updatedOrder);
      if (onOrderUpdated) {
        onOrderUpdated(updatedOrder);
      }
    } catch (e) {
      console.warn('Error al persistir firma del cliente:', e);
    }
  };

  // Capturar foto de identificación INE
  const handleUploadIne = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      setFotoIdentificacion(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Fotos de entrada del vehículo
  const photoEntries: { key: keyof MandatoryPhotos; label: string; url?: string }[] = [
    { key: 'frente', label: '1. Frente', url: order.fotosEntrada?.frente },
    { key: 'trasera', label: '2. Trasera', url: order.fotosEntrada?.trasera },
    { key: 'lateralIzquierdo', label: '3. Lat. Izquierdo', url: order.fotosEntrada?.lateralIzquierdo },
    { key: 'lateralDerecho', label: '4. Lat. Derecho', url: order.fotosEntrada?.lateralDerecho },
    { key: 'motor', label: '5. Bahía Motor', url: order.fotosEntrada?.motor },
    { key: 'odometro', label: '6. Odómetro', url: order.fotosEntrada?.odometro },
    { key: 'interior', label: '7. Interior', url: order.fotosEntrada?.interior },
    { key: 'cajuela', label: '8. Cajuela', url: order.fotosEntrada?.cajuela },
  ];

  const fotosValidas = photoEntries.filter((p) => Boolean(p.url));

  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  const lightboxPhotos = [
    ...fotosValidas.map((f) => ({
      url: f.url as string,
      title: f.label,
    })),
    ...(fotoIdentificacion ? [{ url: fotoIdentificacion, title: 'Identificación Oficial INE' }] : []),
  ];

  // Manejo de guardado y edición de disclaimers
  const handleSaveDisclaimers = () => {
    setDisclaimers(editingClauses);
    try {
      localStorage.setItem('taller_disclaimers', JSON.stringify(editingClauses));
    } catch (e) {
      console.error(e);
    }
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      setShowEditor(false);
    }, 1200);
  };

  const handleResetDisclaimers = () => {
    if (confirm('¿Restablecer las cláusulas y disclaimers sugeridos por defecto?')) {
      setEditingClauses(DEFAULT_DISCLAIMERS);
      setDisclaimers(DEFAULT_DISCLAIMERS);
      localStorage.removeItem('taller_disclaimers');
    }
  };

  const handleClauseChange = (id: string, field: 'titulo' | 'contenido', value: string) => {
    setEditingClauses((prev) =>
      prev.map((c) => (c.id === id ? { ...c, [field]: value } : c))
    );
  };

  const handleAddClause = () => {
    const newClause: DisclaimerClause = {
      id: `clausula-${Date.now()}`,
      numero: editingClauses.length + 1,
      titulo: 'NUEVA CLÁUSULA ADICIONAL',
      contenido: 'Escriba aquí los términos y condiciones específicos...',
    };
    setEditingClauses([...editingClauses, newClause]);
  };

  const handleDeleteClause = (id: string) => {
    const filtered = editingClauses.filter((c) => c.id !== id);
    const renumbered = filtered.map((c, idx) => ({ ...c, numero: idx + 1 }));
    setEditingClauses(renumbered);
  };

  // Impresión en ventana aislada para hoja tamaño Carta / PDF de 2 hojas exactas
  const handlePrint = () => {
    const printWindow = window.open('', '_blank', 'width=920,height=1000');
    if (!printWindow) {
      alert('Por favor permita las ventanas emergentes (pop-ups) para imprimir o guardar en PDF.');
      return;
    }

    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    const logoUrl = `${origin}/logo-taller-amaya.png`;

    // Conceptos del presupuesto o servicios
    const partes = order.presupuesto?.partes || [];
    const manoObra = order.presupuesto?.manoObra || [];
    const hasPresupuesto = partes.length > 0 || manoObra.length > 0;

    let itemsHtml = '';
    if (hasPresupuesto) {
      manoObra.forEach((mo) => {
        itemsHtml += `
          <tr>
            <td style="padding: 4px 6px; border-bottom: 1px solid #e2e8f0; font-weight: 600;">${mo.concepto}</td>
            <td style="padding: 4px 6px; border-bottom: 1px solid #e2e8f0; text-align: center; color: #475569;">Mano de Obra</td>
            <td style="padding: 4px 6px; border-bottom: 1px solid #e2e8f0; text-align: center;">1</td>
            <td style="padding: 4px 6px; border-bottom: 1px solid #e2e8f0; text-align: right;">${formatMoney(mo.costo)}</td>
            <td style="padding: 4px 6px; border-bottom: 1px solid #e2e8f0; text-align: right; font-weight: 700;">${formatMoney(mo.costo)}</td>
          </tr>
        `;
      });
      partes.forEach((pt) => {
        itemsHtml += `
          <tr>
            <td style="padding: 4px 6px; border-bottom: 1px solid #e2e8f0;">${pt.descripcion}</td>
            <td style="padding: 4px 6px; border-bottom: 1px solid #e2e8f0; text-align: center; color: #475569;">Refacción (${pt.origen === 'cliente' ? 'Cliente' : 'Taller'})</td>
            <td style="padding: 4px 6px; border-bottom: 1px solid #e2e8f0; text-align: center;">${pt.cantidad}</td>
            <td style="padding: 4px 6px; border-bottom: 1px solid #e2e8f0; text-align: right;">${formatMoney(pt.precioUnitario)}</td>
            <td style="padding: 4px 6px; border-bottom: 1px solid #e2e8f0; text-align: right; font-weight: 700;">${formatMoney(pt.subtotal)}</td>
          </tr>
        `;
      });
    } else {
      order.servicios.forEach((srv) => {
        itemsHtml += `
          <tr>
            <td style="padding: 4px 6px; border-bottom: 1px solid #e2e8f0; font-weight: 600;">${srv.concepto}</td>
            <td style="padding: 4px 6px; border-bottom: 1px solid #e2e8f0; text-align: center; color: #475569;">Servicio</td>
            <td style="padding: 4px 6px; border-bottom: 1px solid #e2e8f0; text-align: center;">1</td>
            <td style="padding: 4px 6px; border-bottom: 1px solid #e2e8f0; text-align: right;">${formatMoney(srv.manoObra)}</td>
            <td style="padding: 4px 6px; border-bottom: 1px solid #e2e8f0; text-align: right; font-weight: 700;">${formatMoney(srv.manoObra)}</td>
          </tr>
        `;
      });
    }

    // Generar fotos en HTML
    let fotosHtml = '';
    if (fotosValidas.length > 0) {
      fotosHtml = `
        <div style="margin-top: 6px; margin-bottom: 8px;">
          <div style="font-size: 9.5px; font-weight: 800; text-transform: uppercase; color: #0f172a; margin-bottom: 4px; border-bottom: 1px solid #cbd5e1; padding-bottom: 2px;">
            📸 Inspección Fotográfica de Recepción (${fotosValidas.length} fotografías registradas)
          </div>
          <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px;">
            ${fotosValidas.slice(0, 4).map((f) => `
              <div style="border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px; text-align: center; background: #f8fafc;">
                <img src="${f.url}" style="width: 100%; height: 70px; object-fit: cover; border-radius: 2px; display: block;" />
                <div style="font-size: 8px; font-weight: 700; color: #334155; margin-top: 2px;">${f.label}</div>
              </div>
            `).join('')}
          </div>
        </div>
      `;
    } else {
      fotosHtml = `
        <div style="margin-top: 6px; margin-bottom: 6px; padding: 6px; background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 4px; font-size: 8.5px; color: #64748b; text-align: center;">
          Inspección fotográfica digital registrada en el sistema técnico de recepción de Taller Amaya.
        </div>
      `;
    }

    // Cláusulas de la Hoja 2
    const clausulasHtml = disclaimers.map((c) => {
      if (c.esSeccionEspecial) {
        return `
          <div style="margin-bottom: 6px;">
            <div style="font-size: 8.5px; font-weight: 900; color: #0f172a; margin-bottom: 1px; text-transform: uppercase;">
              ${c.numero}.- ${c.titulo || ''}.
            </div>
            <div style="font-size: 7.5px; line-height: 1.25; color: #1e293b; text-align: justify; white-space: pre-line;">
              ${c.contenido}
            </div>
          </div>
        `;
      }
      return `
        <div style="margin-bottom: 3.5px; font-size: 7.5px; line-height: 1.22; color: #1e293b; text-align: justify;">
          <strong>${c.numero}.</strong> ${c.contenido}
        </div>
      `;
    }).join('');

    const htmlContent = `
      <!DOCTYPE html>
      <html lang="es">
        <head>
          <meta charset="utf-8" />
          <title>Orden de Servicio #${order.folio} - Taller Amaya (2 Hojas)</title>
          <style>
            @page {
              size: letter portrait;
              margin: 9mm 11mm;
            }
            * {
              box-sizing: border-box;
              margin: 0;
              padding: 0;
            }
            body {
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
              color: #0f172a;
              background: #ffffff;
              font-size: 9px;
              line-height: 1.28;
              -webkit-print-color-adjust: exact !important;
              print-color-adjust: exact !important;
            }
            .page {
              width: 100%;
              min-height: 256mm;
              max-height: 260mm;
              position: relative;
              page-break-after: always;
              break-after: page;
              display: flex;
              flex-direction: column;
              justify-content: space-between;
            }
            .page:last-child {
              page-break-after: avoid;
              break-after: avoid;
            }
            .header-bar {
              display: flex;
              justify-content: space-between;
              align-items: center;
              border-bottom: 2.5px solid #e11d48;
              padding-bottom: 6px;
              margin-bottom: 6px;
            }
            .logo-wrap {
              display: flex;
              align-items: center;
              gap: 12px;
            }
            .logo-img {
              height: 52px;
              max-width: 160px;
              object-fit: contain;
              display: block;
            }
            .logo-title {
              font-size: 16px;
              font-weight: 900;
              color: #e11d48;
              letter-spacing: -0.5px;
            }
            .taller-info {
              font-size: 8px;
              color: #475569;
              line-height: 1.25;
              margin-top: 1px;
            }
            .folio-box {
              text-align: right;
            }
            .folio-num {
              font-size: 16px;
              font-weight: 900;
              color: #0f172a;
            }
            .status-badge {
              display: inline-block;
              background: #f1f5f9;
              border: 1px solid #cbd5e1;
              color: #0f172a;
              padding: 1px 6px;
              border-radius: 4px;
              font-size: 8.5px;
              font-weight: 800;
              text-transform: uppercase;
              margin-top: 1px;
            }
            .grid-2 {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 6px;
              margin-bottom: 6px;
            }
            .card-box {
              border: 1px solid #cbd5e1;
              border-radius: 4px;
              padding: 5px 7px;
              background: #f8fafc;
            }
            .card-title {
              font-size: 9px;
              font-weight: 800;
              text-transform: uppercase;
              color: #0f172a;
              border-bottom: 1px solid #e2e8f0;
              padding-bottom: 2px;
              margin-bottom: 4px;
            }
            .card-row {
              display: flex;
              justify-content: space-between;
              margin-bottom: 2px;
              font-size: 8.5px;
            }
            .card-label {
              color: #64748b;
              font-weight: 600;
            }
            .card-val {
              color: #0f172a;
              font-weight: 700;
              text-align: right;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              font-size: 8px;
              margin-top: 3px;
            }
            th {
              background: #0f172a;
              color: #ffffff;
              padding: 3px 5px;
              text-align: left;
              font-size: 7.5px;
              text-transform: uppercase;
              letter-spacing: 0.5px;
            }
            .financial-summary {
              display: flex;
              justify-content: flex-end;
              margin-top: 5px;
            }
            .summary-table {
              width: 230px;
              border: 1px solid #cbd5e1;
              border-radius: 4px;
              background: #f8fafc;
              padding: 4px 6px;
              font-size: 8.5px;
            }
            .summary-row {
              display: flex;
              justify-content: space-between;
              padding: 1.5px 0;
            }
            .total-row {
              border-top: 1px solid #cbd5e1;
              padding-top: 2px;
              margin-top: 2px;
              font-weight: 900;
              font-size: 10px;
              color: #0f172a;
            }
            .id-box-legal {
              border: 1.5px solid #0f172a;
              border-radius: 5px;
              padding: 6px 8px;
              background: #f8fafc;
              margin-top: 8px;
            }
            .id-box-legal-title {
              font-size: 9px;
              font-weight: 900;
              text-transform: uppercase;
              color: #0f172a;
              display: flex;
              justify-content: space-between;
              border-bottom: 1px solid #cbd5e1;
              padding-bottom: 3px;
              margin-bottom: 4px;
            }
            .signatures-box {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 16px;
              margin-top: 10px;
              padding-top: 8px;
              border-top: 1px dashed #cbd5e1;
            }
            .sign-card {
              border: 1px solid #cbd5e1;
              border-radius: 4px;
              padding: 6px 8px;
              background: #ffffff;
              display: flex;
              flex-direction: column;
              justify-content: space-between;
              min-height: 95px;
            }
            .sign-area {
              height: 48px;
              display: flex;
              align-items: center;
              justify-content: center;
              border-bottom: 1px solid #0f172a;
              margin-bottom: 4px;
            }
            .sign-img {
              max-height: 44px;
              max-width: 140px;
              object-fit: contain;
              display: block;
            }
            .sign-title {
              font-size: 8.5px;
              font-weight: 800;
              text-align: center;
              color: #0f172a;
            }
            .sign-details {
              font-size: 7.5px;
              color: #475569;
              text-align: center;
              margin-top: 2px;
              line-height: 1.25;
            }
            .page-footer {
              text-align: center;
              font-size: 7.5px;
              color: #64748b;
              border-top: 1px solid #e2e8f0;
              padding-top: 3px;
              margin-top: 4px;
            }
          </style>
        </head>
        <body>
          <!-- ============================================================== -->
          <!-- HOJA 1: DATOS DEL VEHÍCULO, FOTOS, IDENTIFICACIÓN Y PRESUPUESTO -->
          <!-- ============================================================== -->
          <div class="page">
            <div>
              <!-- Encabezado con Logotipo Oficial del Taller Amaya -->
              <div class="header-bar">
                <div class="logo-wrap">
                  <img src="${logoUrl}" alt="${config.nombreComercial}" class="logo-img" />
                  <div>
                    <div class="logo-title">${config.nombreComercial}</div>
                    <div class="taller-info">
                      <strong>${config.razonSocial}</strong> • RFC: <strong>${config.rfc}</strong><br />
                      ${config.direccion}<br />
                      Teléfono: <strong>${config.telefonoLocal}</strong> • WhatsApp: <strong>${config.whatsapp}</strong>
                    </div>
                  </div>
                </div>
                <div class="folio-box">
                  <div style="font-size: 9px; font-weight: 800; color: #64748b;">ORDEN DE SERVICIO Y RECEPCIÓN</div>
                  <div class="folio-num">FOLIO #${order.folio}</div>
                  <div class="status-badge">Estatus: ${order.estado.toUpperCase()}</div>
                  <div style="font-size: 8px; color: #475569; margin-top: 2px;">
                    Ingreso: <strong>${formatDate(order.fechaIngreso)}</strong>
                  </div>
                  ${order.fechaPromesa ? `<div style="font-size: 8px; color: #e11d48;">Promesa: <strong>${formatDate(order.fechaPromesa)}</strong></div>` : ''}
                </div>
              </div>

              <!-- Grid 2 Columnas: Cliente e Identificación + Ficha Técnica -->
              <div class="grid-2">
                <!-- Datos del Cliente e Identificación -->
                <div class="card-box">
                  <div class="card-title">👤 Datos del Cliente e Identificación</div>
                  <div class="card-row">
                    <span class="card-label">Nombre / Razón Social:</span>
                    <span class="card-val">${company ? company.razonSocial : (client?.nombre || 'Cliente General')}</span>
                  </div>
                  <div class="card-row">
                    <span class="card-label">Identificación Oficial:</span>
                    <span class="card-val" style="color: #0284c7;">
                      ${tipoIdentificacion}: <strong>${numeroIdentificacion || 'Presentada en físico'}</strong>
                    </span>
                  </div>
                  <div class="card-row">
                    <span class="card-label">Firmante Autorizado:</span>
                    <span class="card-val">${nombreFirmante} (${caracterFirmante})</span>
                  </div>
                  <div class="card-row">
                    <span class="card-label">Teléfono / WhatsApp:</span>
                    <span class="card-val">${client?.telefono || config.whatsapp}</span>
                  </div>
                  ${client?.correo ? `
                    <div class="card-row">
                      <span class="card-label">Correo Electrónico:</span>
                      <span class="card-val" style="font-size: 8px;">${client.correo}</span>
                    </div>
                  ` : ''}
                  ${client?.direccion ? `
                    <div class="card-row">
                      <span class="card-label">Dirección:</span>
                      <span class="card-val" style="font-size: 8px;">${client.direccion}</span>
                    </div>
                  ` : ''}
                  ${order.choferNombre ? `
                    <div class="card-row">
                      <span class="card-label">Chofer de entrega:</span>
                      <span class="card-val">${order.choferNombre} ${order.choferTelefono ? `(${order.choferTelefono})` : ''}</span>
                    </div>
                  ` : ''}
                </div>

                <!-- Vehículo -->
                <div class="card-box">
                  <div class="card-title">🚗 Ficha Técnica del Vehículo</div>
                  <div class="card-row">
                    <span class="card-label">Vehículo:</span>
                    <span class="card-val">${vehicle?.marca || '—'} ${vehicle?.modelo || '—'} (${vehicle?.ano || '—'})</span>
                  </div>
                  <div class="card-row">
                    <span class="card-label">Placas:</span>
                    <span class="card-val" style="background: #e2e8f0; padding: 1px 4px; border-radius: 2px;">${vehicle?.placas || '—'}</span>
                  </div>
                  <div class="card-row">
                    <span class="card-label">Color:</span>
                    <span class="card-val">${vehicle?.color || '—'}</span>
                  </div>
                  ${vehicle?.motor ? `
                    <div class="card-row">
                      <span class="card-label">Motor / Cilindros:</span>
                      <span class="card-val">${vehicle.motor}</span>
                    </div>
                  ` : ''}
                  ${vehicle?.vin ? `
                    <div class="card-row">
                      <span class="card-label">No. Serie / VIN:</span>
                      <span class="card-val" style="font-family: monospace;">${vehicle.vin}</span>
                    </div>
                  ` : ''}
                  <div class="card-row">
                    <span class="card-label">Kilometraje Entrada:</span>
                    <span class="card-val">${Number(order.kilometrajeEntrada || vehicle?.kilometrajeActual || 0).toLocaleString()} km</span>
                  </div>
                  <div class="card-row">
                    <span class="card-label">Nivel Gasolina:</span>
                    <span class="card-val">⛽ ${order.nivelCombustible || '1/2'}</span>
                  </div>
                </div>
              </div>

              <!-- Motivo de Ingreso y Daños Previos -->
              <div class="card-box" style="margin-bottom: 6px;">
                <div class="card-title">⚠️ Motivo de Ingreso y Diagnóstico Preliminar</div>
                <div style="font-size: 8.5px; line-height: 1.3; color: #1e293b; margin-bottom: 2px;">
                  <strong>Falla reportada:</strong> ${order.fallaReportada || 'Mantenimiento preventivo general e inspección de seguridad.'}
                </div>
                ${order.refaccionesCliente && order.refaccionesCliente.length > 0 ? `
                  <div style="font-size: 8px; color: #0284c7; margin-top: 1px;">
                    <strong>Partes aportadas por el cliente:</strong> ${order.refaccionesCliente.join(', ')}
                  </div>
                ` : ''}
                ${order.danosPrevios && order.danosPrevios.length > 0 ? `
                  <div style="font-size: 8px; color: #b45309; margin-top: 1px;">
                    <strong>Inspección de daños previos:</strong> ${order.danosPrevios.map((d) => `${d.tipo} (${d.detalle || 'registrado'})`).join(' • ')}
                  </div>
                ` : ''}
              </div>

              <!-- Galería de Fotos de Entrada -->
              ${fotosHtml}

              <!-- Tabla de Presupuesto y Servicios -->
              <div style="margin-top: 4px;">
                <div style="font-size: 9px; font-weight: 800; text-transform: uppercase; color: #1e293b; border-bottom: 1px solid #cbd5e1; padding-bottom: 2px; margin-bottom: 3px;">
                  📋 Desglose de Presupuesto y Servicios Autorizados
                </div>
                <table>
                  <thead>
                    <tr>
                      <th style="width: 48%;">Concepto / Trabajo / Refacción</th>
                      <th style="width: 20%; text-align: center;">Tipo</th>
                      <th style="width: 8%; text-align: center;">Cant.</th>
                      <th style="width: 12%; text-align: right;">P. Unit</th>
                      <th style="width: 12%; text-align: right;">Importe</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${itemsHtml}
                  </tbody>
                </table>

                <!-- Resumen Financiero -->
                <div class="financial-summary">
                  <div class="summary-table">
                    <div class="summary-row">
                      <span style="color: #64748b;">Mano de Obra:</span>
                      <strong>${formatMoney(order.subtotalManoObra)}</strong>
                    </div>
                    <div class="summary-row">
                      <span style="color: #64748b;">Refacciones / Partes:</span>
                      <strong>${formatMoney(order.subtotalRefacciones)}</strong>
                    </div>
                    ${order.presupuesto?.aplicaIva ? `
                      <div class="summary-row">
                        <span style="color: #64748b;">IVA (Frontera ${config.ivaFronteraPorcentaje}%):</span>
                        <strong>${formatMoney(order.presupuesto.ivaMonto)}</strong>
                      </div>
                    ` : ''}
                    <div class="summary-row total-row">
                      <span>TOTAL ESTIMADO:</span>
                      <span style="color: #e11d48;">${formatMoney(order.presupuesto?.totalPresupuesto || order.subtotalGeneral)}</span>
                    </div>
                    <div class="summary-row" style="color: #059669; font-weight: 700;">
                      <span>Anticipo Pagado:</span>
                      <span>${formatMoney(order.totalPagado)}</span>
                    </div>
                    <div class="summary-row" style="font-weight: 800; color: #dc2626;">
                      <span>SALDO PENDIENTE:</span>
                      <span>${formatMoney(order.saldoPendiente)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Firmas de Aceptación Hoja 1 y Footer -->
            <div>
              <div class="signatures-box">
                <!-- Firma Taller -->
                <div class="sign-card">
                  <div class="sign-title">POR TALLER MECÁNICO AMAYA</div>
                  <div class="sign-area">
                    <div style="font-size: 8px; color: #94a3b8; font-style: italic;">Sello y Firma de Recepción Técnica</div>
                  </div>
                  <div class="sign-details">
                    ${config.razonSocial}<br />
                    Recepción y Custodia de Unidad
                  </div>
                </div>

                <!-- Firma de Aceptación del Cliente -->
                <div class="sign-card" style="border: 1.5px solid #0f172a; background: #fafafa;">
                  <div class="sign-title" style="color: #0f172a;">
                    FIRMA DE ACEPTACIÓN DEL CLIENTE
                  </div>
                  <div class="sign-area">
                    ${digitalSignature ? `
                      <img src="${digitalSignature}" class="sign-img" alt="Firma Cliente" />
                    ` : `
                      <div style="font-size: 8px; color: #94a3b8; font-style: italic;">Firma autógrafa de conformidad</div>
                    `}
                  </div>
                  <div class="sign-details">
                    <strong>${nombreFirmante}</strong> (${caracterFirmante})<br />
                    Identificación: <strong>${tipoIdentificacion} ${numeroIdentificacion ? `No. ${numeroIdentificacion}` : '(En resguardo)'}</strong><br />
                    Acepto inventario, fotos de recepción y presupuesto estimado.
                  </div>
                </div>
              </div>

              <div class="page-footer">
                Página 1 de 2 • Orden #${order.folio} • Continúa en Hoja 2 con Identificación Oficial, Póliza de Garantía y Disclaimers.
              </div>
            </div>
          </div>

          <!-- ============================================================== -->
          <!-- HOJA 2: IDENTIFICACIÓN LEGAL, DISCLAIMERS Y FIRMA DE ACEPTACIÓN -->
          <!-- ============================================================== -->
          <div class="page">
            <div>
              <!-- Encabezado con Logotipo Oficial en Hoja 2 -->
              <div class="header-bar">
                <div class="logo-wrap">
                  <img src="${logoUrl}" alt="${config.nombreComercial}" class="logo-img" />
                  <div>
                    <div class="logo-title">${config.nombreComercial} — PÓLIZA Y CONDICIONES</div>
                    <div class="taller-info">
                      Términos de Prestación de Servicios, Póliza de Garantía y Deslinde de Responsabilidad (Disclaimers)
                    </div>
                  </div>
                </div>
                <div class="folio-box">
                  <div class="folio-num">HOJA 2 / 2</div>
                  <div style="font-size: 8.5px; font-weight: 700; color: #475569;">
                    Orden #${order.folio} • Placas: ${vehicle?.placas || '—'}
                  </div>
                </div>
              </div>

              <!-- Banner de Marco Legal -->
              <div style="background: #f1f5f9; border-left: 3px solid #e11d48; padding: 5px 8px; margin-bottom: 10px; font-size: 8px; color: #334155; line-height: 1.3;">
                Las presentes cláusulas regulan formalmente la relación de prestación de servicios entre <strong>${config.razonSocial} (TALLER AMAYA)</strong> y el cliente identificado con documento oficial, quien acepta el presupuesto, las políticas de garantía y las autorizaciones de desarme y prueba.
              </div>

              <!-- Lista de Cláusulas y Disclaimers -->
              <div style="margin-bottom: 10px;">
                ${clausulasHtml}
              </div>

              <!-- Recuadro Destacado de Identificación Oficial del Cliente -->
              <div class="id-box-legal">
                <div class="id-box-legal-title">
                  <span>🪪 DATOS DE IDENTIFICACIÓN OFICIAL DEL CLIENTE O TITULAR</span>
                  <span style="color: #e11d48;">COTEJADO Y REGISTRADO</span>
                </div>
                <div style="display: grid; grid-template-columns: 1.5fr 1fr 1fr; gap: 8px; font-size: 8px; margin-bottom: 4px;">
                  <div>
                    <span style="color: #64748b;">Nombre del Titular:</span><br />
                    <strong style="color: #0f172a; font-size: 9px;">${nombreFirmante}</strong>
                  </div>
                  <div>
                    <span style="color: #64748b;">Tipo de Documento:</span><br />
                    <strong>[X] ${tipoIdentificacion} &nbsp; [ ] Pasaporte &nbsp; [ ] Licencia</strong>
                  </div>
                  <div>
                    <span style="color: #64748b;">No. Identificación / Clave:</span><br />
                    <strong style="font-family: monospace; font-size: 9.5px; color: #0284c7;">
                      ${numeroIdentificacion || '_______________________________'}
                    </strong>
                  </div>
                </div>

                ${fotoIdentificacion ? `
                  <div style="margin-top: 4px; padding-top: 4px; border-top: 1px dashed #cbd5e1; display: flex; align-items: center; gap: 8px;">
                    <img src="${fotoIdentificacion}" style="height: 48px; border: 1px solid #cbd5e1; border-radius: 3px;" />
                    <span style="font-size: 7.5px; color: #64748b;">Copia digital de identificación oficial cotejada en recepción técnica.</span>
                  </div>
                ` : ''}
              </div>

              <!-- Declaración Formal de Aceptación -->
              <div style="border: 1px solid #cbd5e1; border-radius: 4px; padding: 6px 8px; background: #fafafa; margin-top: 8px;">
                <div style="font-weight: 800; font-size: 8.5px; text-transform: uppercase; color: #0f172a; margin-bottom: 2px;">
                  DECLARACIÓN Y ACEPTACIÓN EXPRESA DE CONFORMIDAD
                </div>
                <div style="font-size: 8px; line-height: 1.3; color: #334155;">
                  El suscrito manifiesta bajo protesta de decir verdad que: <strong>(1)</strong> Se identifica debidamente con el documento oficial antes registrado; <strong>(2)</strong> Es propietario o representante legítimo con autorización plena para ordenar los trabajos y pruebas de ruta; <strong>(3)</strong> Ha verificado el inventario, daños preexistentes y nivel de combustible en la Hoja 1; y <strong>(4)</strong> Ha leído, comprendido y aceptado en su totalidad las cláusulas, exclusiones de garantía, plazos de almacenaje y deslindes aquí estipulados.
                </div>
              </div>
            </div>

            <!-- Firmas Formales Hoja 2 y Footer -->
            <div>
              <div class="signatures-box" style="margin-top: 12px;">
                <!-- Firma de Aceptación del Cliente -->
                <div class="sign-card" style="border: 1.5px solid #0f172a; background: #fafafa;">
                  <div class="sign-title">
                    FIRMA DE ACEPTACIÓN DEL CLIENTE
                  </div>
                  <div class="sign-area" style="height: 52px;">
                    ${digitalSignature ? `
                      <img src="${digitalSignature}" class="sign-img" style="max-height: 48px;" alt="Firma Aceptación" />
                    ` : `
                      <div style="font-size: 8px; color: #94a3b8; font-style: italic;">Firma autógrafa de aceptación legal</div>
                    `}
                  </div>
                  <div class="sign-details">
                    <strong>${nombreFirmante}</strong><br />
                    ${tipoIdentificacion}: <strong>${numeroIdentificacion || '____________________'}</strong><br />
                    Fecha: ${formatDate(order.fechaIngreso)}
                  </div>
                </div>

                <!-- Sello y Firma Taller Amaya -->
                <div class="sign-card">
                  <div class="sign-title">POR TALLER MECÁNICO AMAYA</div>
                  <div class="sign-area" style="height: 52px;">
                    <div style="font-size: 8px; color: #94a3b8; font-style: italic;">Sello y Firma del Responsable Técnico</div>
                  </div>
                  <div class="sign-details">
                    ${config.razonSocial}<br />
                    RFC: ${config.rfc}<br />
                    Tijuana, B.C. • ${new Date().toLocaleDateString('es-MX')}
                  </div>
                </div>
              </div>

              <div class="page-footer">
                Página 2 de 2 • Taller Mecánico Amaya • C. Santo Domingo #19950, Buenos Aires Sur, Tijuana B.C. • Tel: ${config.telefonoLocal}
                <div style="font-size: 7px; font-weight: 700; color: #475569; margin-top: 2px;">
                  ESTE DOCUMENTO NO TIENE VALIDEZ FISCAL, NI SUSTITUYE AL COMPROBANTE FISCAL, ES EXCLUSIVO PARA CONTROL INTERNO Y FINES INFORMATIVOS.
                </div>
              </div>
            </div>
          </div>

          <script>
            window.addEventListener('load', () => {
              setTimeout(() => {
                window.print();
              }, 400);
            });
          </script>
        </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  // Enviar mensaje de WhatsApp al cliente
  const handleShareWhatsApp = () => {
    const publicUrl = `https://talleramaya.com/seguimiento/${order.folio}`;
    const text = encodeURIComponent(
      `Hola ${client?.nombre || 'Estimado Cliente'}, le compartimos su *Orden de Servicio #${order.folio}* en 2 hojas emitida por *TALLER AMAYA*:\n\n` +
      `🚗 *Vehículo:* ${vehicle?.marca} ${vehicle?.modelo} (${vehicle?.ano}) - Placas: *${vehicle?.placas}*\n` +
      `📋 *Estatus:* ${order.estado.toUpperCase()}\n` +
      `💰 *Total Presupuestado:* ${formatMoney(order.presupuesto?.totalPresupuesto || order.subtotalGeneral)}\n` +
      `💳 *Saldo Pendiente:* ${formatMoney(order.saldoPendiente)}\n\n` +
      `Puede consultar su orden digital con fotos, presupuesto, identificación y póliza de garantía aquí:\n${publicUrl}\n\n` +
      `📍 C. Santo Domingo #19950, Tijuana B.C. • Tel: ${config.telefonoLocal}`
    );
    const phone = client?.whatsapp || client?.telefono || '';
    const cleanPhone = phone.replace(/\D/g, '');
    const url = cleanPhone ? `https://wa.me/52${cleanPhone}?text=${text}` : `https://wa.me/?text=${text}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/70 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-100 border border-slate-300 rounded-2xl w-full max-w-5xl h-[94vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* ============================================================== */}
        {/* BARRA SUPERIOR DE ACCIONES                                      */}
        {/* ============================================================== */}
        <div className="bg-white border-b border-slate-200 px-5 py-3.5 flex flex-wrap items-center justify-between gap-3 shrink-0 shadow-sm">
          <div className="flex items-center gap-3">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/logo-taller-amaya.png"
              alt="Logo Taller Amaya"
              className="h-10 w-auto object-contain drop-shadow-sm"
            />
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-slate-900 tracking-tight">
                  Orden de Servicio en 2 Hojas (PDF)
                </h2>
                <span className="text-xs px-2 py-0.5 rounded-full font-bold bg-rose-100 text-rose-800 border border-rose-200">
                  Folio #{order.folio}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Logo Oficial • Identificación Oficial del Cliente • Firma de Aceptación Legal
              </p>
            </div>
          </div>

          {/* Selector de vistas previas */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-semibold">
            <button
              onClick={() => setActiveTab('ambas')}
              className={`px-3 py-1 rounded-lg transition-all ${
                activeTab === 'ambas'
                  ? 'bg-white text-slate-900 shadow-sm font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Ver Ambas Hojas
            </button>
            <button
              onClick={() => setActiveTab('hoja1')}
              className={`px-3 py-1 rounded-lg transition-all ${
                activeTab === 'hoja1'
                  ? 'bg-white text-slate-900 shadow-sm font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Hoja 1 (Recepción y Fotos)
            </button>
            <button
              onClick={() => setActiveTab('hoja2')}
              className={`px-3 py-1 rounded-lg transition-all ${
                activeTab === 'hoja2'
                  ? 'bg-white text-slate-900 shadow-sm font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Hoja 2 (Disclaimers y Firmas)
            </button>
          </div>

          {/* Acciones principales */}
          <div className="flex items-center gap-2">
            {/* Botón Capturar Firma Digital */}
            <button
              onClick={() => setShowSignPad(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-900 font-bold text-xs rounded-xl border border-indigo-200 transition-colors shadow-sm"
              title="Capturar o actualizar firma digital en pantalla"
            >
              <PenTool className="w-3.5 h-3.5 text-indigo-600" />
              <span>{digitalSignature ? 'Firma Lista ✓' : 'Firmar en Pantalla'}</span>
            </button>

            {/* Botón Editar Disclaimers */}
            <button
              onClick={() => setShowEditor(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 font-bold text-xs rounded-xl border border-amber-300 transition-colors shadow-sm"
              title="Personalizar o editar las cláusulas legales y disclaimers"
            >
              <Edit3 className="w-3.5 h-3.5 text-amber-700" />
              <span>Editar Disclaimers</span>
            </button>

            {/* Compartir WhatsApp */}
            <button
              onClick={handleShareWhatsApp}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-xs rounded-xl border border-emerald-300 transition-colors shadow-sm"
              title="Enviar resumen y enlace al cliente por WhatsApp"
            >
              <Share2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>WhatsApp</span>
            </button>

            {/* Imprimir / Guardar en PDF */}
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-1.5 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black text-xs rounded-xl shadow-md shadow-rose-600/25 transition-all active:scale-95 cursor-pointer"
              title="Imprimir directamente o Guardar como PDF en tamaño Carta"
            >
              <Printer className="w-4 h-4" />
              <span>Imprimir / PDF</span>
            </button>

            {/* Cerrar */}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* ============================================================== */}
        {/* PANEL RÁPIDO DE DATOS DE IDENTIFICACIÓN DEL CLIENTE            */}
        {/* ============================================================== */}
        <div className="bg-slate-50 border-b border-slate-200 px-5 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
          <div className="flex items-center gap-2">
            <IdCard className="w-4 h-4 text-rose-600" />
            <span className="font-bold text-slate-800">Identificación Oficial del Cliente:</span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={tipoIdentificacion}
              onChange={(e) => setTipoIdentificacion(e.target.value as any)}
              className="bg-white border border-slate-300 rounded-lg px-2.5 py-1 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-rose-500"
            >
              <option value="INE">INE / IFE</option>
              <option value="Licencia">Licencia de Conducir</option>
              <option value="Pasaporte">Pasaporte</option>
              <option value="Otro">Otra Identificación</option>
            </select>

            <input
              type="text"
              placeholder="No. de Identificación / Clave de Elector..."
              value={numeroIdentificacion}
              onChange={(e) => setNumeroIdentificacion(e.target.value)}
              className="bg-white border border-slate-300 rounded-lg px-3 py-1 text-xs text-slate-800 w-56 font-mono focus:outline-none focus:ring-1 focus:ring-rose-500"
            />

            <input
              type="text"
              placeholder="Nombre del Firmante..."
              value={nombreFirmante}
              onChange={(e) => setNombreFirmante(e.target.value)}
              className="bg-white border border-slate-300 rounded-lg px-3 py-1 text-xs text-slate-800 w-48 font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500"
            />

            <select
              value={caracterFirmante}
              onChange={(e) => setCaracterFirmante(e.target.value as any)}
              className="bg-white border border-slate-300 rounded-lg px-2.5 py-1 text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-rose-500"
            >
              <option value="Propietario">Propietario</option>
              <option value="Chofer">Chofer</option>
              <option value="Apoderado">Apoderado Legal</option>
            </select>

            {/* Subir foto de INE */}
            <label className="flex items-center gap-1 px-2.5 py-1 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg text-slate-700 cursor-pointer font-medium text-[11px]">
              <Upload className="w-3.5 h-3.5 text-slate-500" />
              <span>{fotoIdentificacion ? 'INE Adjunta ✓' : 'Adjuntar Foto INE'}</span>
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleUploadIne}
              />
            </label>
          </div>
        </div>

        {/* ============================================================== */}
        {/* ÁREA DE PREVISUALIZACIÓN DE HOJAS (HOJA 1 Y HOJA 2)             */}
        {/* ============================================================== */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 flex flex-col items-center gap-8 bg-slate-200/70">
          
          {/* ------------------------------------------------------------ */}
          {/* HOJA 1: VISTA PREVIA CARTA                                    */}
          {/* ------------------------------------------------------------ */}
          {(activeTab === 'ambas' || activeTab === 'hoja1') && (
            <div className="bg-white w-full max-w-[800px] min-h-[1050px] p-8 rounded-lg shadow-xl border border-slate-300 flex flex-col justify-between text-slate-900 animate-fadeIn">
              <div>
                {/* Encabezado Taller con Logotipo Oficial */}
                <div className="flex justify-between items-center border-b-2 border-rose-600 pb-4 mb-4">
                  <div className="flex items-center gap-4">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src="/logo-taller-amaya.png"
                      alt={config.nombreComercial}
                      className="h-16 w-auto object-contain drop-shadow"
                    />
                    <div>
                      <div className="text-xl font-black text-rose-600 tracking-tight">
                        {config.nombreComercial}
                      </div>
                      <div className="text-xs text-slate-500 leading-tight mt-0.5">
                        <strong className="text-slate-800">{config.razonSocial}</strong> • RFC: <strong className="text-slate-800">{config.rfc}</strong><br />
                        {config.direccion}<br />
                        Tel: <strong className="text-slate-800">{config.telefonoLocal}</strong> • WhatsApp: <strong className="text-slate-800">{config.whatsapp}</strong>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] font-black tracking-wider uppercase text-slate-400">
                      ORDEN DE SERVICIO Y RECEPCIÓN
                    </span>
                    <div className="text-2xl font-black text-slate-900">
                      FOLIO #{order.folio}
                    </div>
                    <span className="inline-block mt-0.5 px-2.5 py-0.5 rounded-full text-xs font-bold uppercase bg-slate-100 text-slate-800 border border-slate-300">
                      Estatus: {order.estado.toUpperCase()}
                    </span>
                    <div className="text-xs text-slate-600 mt-1">
                      Ingreso: <strong>{formatDate(order.fechaIngreso)}</strong>
                    </div>
                    {order.fechaPromesa && (
                      <div className="text-xs text-rose-600 font-semibold">
                        Promesa: <strong>{formatDate(order.fechaPromesa)}</strong>
                      </div>
                    )}
                  </div>
                </div>

                {/* Grid 2 Columnas: Cliente + Identificación y Vehículo */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                  {/* Cliente e Identificación */}
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
                    <div className="text-xs font-black uppercase text-slate-800 border-b border-slate-200 pb-1.5 mb-2 flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <IdCard className="w-3.5 h-3.5 text-rose-600" />
                        <span>Datos del Cliente e Identificación</span>
                      </div>
                      <span className="text-[10px] text-rose-600 font-bold">Oficial</span>
                    </div>
                    <div className="space-y-1.5 text-xs">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Nombre / Razón Social:</span>
                        <strong className="text-slate-900">
                          {company ? company.razonSocial : (client?.nombre || 'Cliente General')}
                        </strong>
                      </div>
                      <div className="flex justify-between items-center bg-white px-2 py-1 rounded border border-slate-200">
                        <span className="text-slate-500 font-medium">Identificación Oficial:</span>
                        <strong className="text-sky-700 font-mono">
                          {tipoIdentificacion}: {numeroIdentificacion || 'En cotejo físico'}
                        </strong>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Firmante Autorizado:</span>
                        <strong className="text-slate-800">{nombreFirmante} ({caracterFirmante})</strong>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Teléfono / WhatsApp:</span>
                        <strong className="text-slate-800">{client?.telefono || config.whatsapp}</strong>
                      </div>
                      {client?.correo && (
                        <div className="flex justify-between">
                          <span className="text-slate-500">Correo Electrónico:</span>
                          <span className="text-slate-800 font-medium text-[11px]">{client.correo}</span>
                        </div>
                      )}
                      {client?.direccion && (
                        <div className="flex justify-between">
                          <span className="text-slate-500">Dirección:</span>
                          <span className="text-slate-800 font-medium text-[11px] text-right truncate max-w-[200px]" title={client.direccion}>{client.direccion}</span>
                        </div>
                      )}
                      {order.choferNombre && (
                        <div className="flex justify-between">
                          <span className="text-slate-500">Chofer que entrega:</span>
                          <strong className="text-slate-800">{order.choferNombre}</strong>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Vehículo */}
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
                    <div className="text-xs font-black uppercase text-slate-800 border-b border-slate-200 pb-1.5 mb-2 flex items-center gap-1.5">
                      <Car className="w-3.5 h-3.5 text-rose-600" />
                      <span>Ficha Técnica del Vehículo</span>
                    </div>
                    <div className="space-y-1.5 text-xs">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Vehículo:</span>
                        <strong className="text-slate-900">
                          {vehicle?.marca || '—'} {vehicle?.modelo || '—'} ({vehicle?.ano || '—'})
                        </strong>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Placas:</span>
                        <span className="font-mono font-bold px-2 py-0.5 rounded bg-slate-200 text-slate-900">
                          {vehicle?.placas || '—'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Color:</span>
                        <strong className="text-slate-800">{vehicle?.color || '—'}</strong>
                      </div>
                      {vehicle?.motor && (
                        <div className="flex justify-between">
                          <span className="text-slate-500">Motor:</span>
                          <strong className="text-slate-800">{vehicle.motor}</strong>
                        </div>
                      )}
                      {vehicle?.vin && (
                        <div className="flex justify-between">
                          <span className="text-slate-500">Serie / VIN:</span>
                          <span className="font-mono text-[11px] text-slate-700">{vehicle.vin}</span>
                        </div>
                      )}
                      <div className="flex justify-between">
                        <span className="text-slate-500">Kilometraje Entrada:</span>
                        <strong className="text-slate-800">
                          {Number(order.kilometrajeEntrada || vehicle?.kilometrajeActual || 0).toLocaleString()} km
                        </strong>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-500">Nivel Combustible:</span>
                        <span className="font-bold text-amber-700 flex items-center gap-1">
                          <Fuel className="w-3.5 h-3.5" />
                          {order.nivelCombustible || '1/2'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Motivo de Ingreso y Daños */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 mb-3 text-xs">
                  <div className="font-black uppercase text-slate-800 mb-1">
                    ⚠️ Falla Reportada y Motivo de Servicio
                  </div>
                  <p className="text-slate-700 leading-relaxed mb-1.5">
                    {order.fallaReportada || 'Revisión y mantenimiento general.'}
                  </p>
                  {order.refaccionesCliente && order.refaccionesCliente.length > 0 && (
                    <div className="text-sky-700 font-medium">
                      <strong>Partes aportadas por el cliente:</strong> {order.refaccionesCliente.join(', ')}
                    </div>
                  )}
                  {order.danosPrevios && order.danosPrevios.length > 0 && (
                    <div className="text-amber-800 font-medium mt-1">
                      <strong>Daños previos observados:</strong>{' '}
                      {order.danosPrevios.map((d) => `${d.tipo} (${d.detalle || 'registrado'})`).join(' • ')}
                    </div>
                  )}
                </div>

                {/* Galería de Fotos de Entrada */}
                <div className="mb-3">
                  <div className="text-xs font-black uppercase text-slate-800 border-b border-slate-200 pb-1 mb-2 flex items-center gap-1.5">
                    <Camera className="w-3.5 h-3.5 text-rose-600" />
                    <span>Fotos de Inspección al Recibir ({fotosValidas.length} Registradas)</span>
                  </div>
                  {fotosValidas.length > 0 ? (
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {fotosValidas.map((f, idx) => (
                        <div
                          key={f.key}
                          onClick={() => {
                            setLightboxIndex(idx);
                            setLightboxOpen(true);
                          }}
                          className="border border-slate-300 hover:border-rose-500 rounded-lg p-1 bg-white shadow-sm cursor-pointer group transition-all"
                          title="Clic para ver foto en tamaño completo"
                        >
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <div className="relative overflow-hidden rounded">
                            <img
                              src={f.url}
                              alt={f.label}
                              className="w-full h-20 object-cover group-hover:scale-105 transition-transform"
                            />
                            <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                              <span className="px-1.5 py-0.5 bg-white/95 text-slate-800 rounded text-[9px] font-bold flex items-center gap-1 shadow">
                                <Eye className="w-3 h-3 text-rose-600" />
                                <span>Ver Grande</span>
                              </span>
                            </div>
                          </div>
                          <div className="text-[10px] font-bold text-slate-700 text-center mt-0.5 group-hover:text-rose-600">
                            {f.label}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-2.5 bg-slate-50 border border-dashed border-slate-300 rounded-lg text-center text-xs text-slate-500">
                      Fotografías registradas en el sistema técnico de recepción.
                    </div>
                  )}
                </div>

                {/* Desglose de Presupuesto */}
                <div>
                  <div className="text-xs font-black uppercase text-slate-800 border-b border-slate-200 pb-1 mb-2">
                    📋 Desglose de Conceptos y Presupuesto
                  </div>
                  <div className="border border-slate-200 rounded-lg overflow-hidden">
                    <table className="w-full text-xs text-left">
                      <thead className="bg-slate-900 text-white text-[11px] uppercase tracking-wider">
                        <tr>
                          <th className="p-2">Concepto / Servicio</th>
                          <th className="p-2 text-center">Tipo</th>
                          <th className="p-2 text-center">Cant.</th>
                          <th className="p-2 text-right">P. Unit</th>
                          <th className="p-2 text-right">Importe</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {order.presupuesto?.manoObra?.map((mo) => (
                          <tr key={mo.id}>
                            <td className="p-2 font-semibold text-slate-900">{mo.concepto}</td>
                            <td className="p-2 text-center text-slate-500">Mano de Obra</td>
                            <td className="p-2 text-center">1</td>
                            <td className="p-2 text-right">{formatMoney(mo.costo)}</td>
                            <td className="p-2 text-right font-bold text-slate-900">{formatMoney(mo.costo)}</td>
                          </tr>
                        ))}
                        {order.presupuesto?.partes?.map((pt) => (
                          <tr key={pt.id}>
                            <td className="p-2 text-slate-800">{pt.descripcion}</td>
                            <td className="p-2 text-center text-slate-500">
                              Refacción ({pt.origen === 'cliente' ? 'Cliente' : 'Taller'})
                            </td>
                            <td className="p-2 text-center">{pt.cantidad}</td>
                            <td className="p-2 text-right">{formatMoney(pt.precioUnitario)}</td>
                            <td className="p-2 text-right font-bold text-slate-900">{formatMoney(pt.subtotal)}</td>
                          </tr>
                        ))}
                        {(!order.presupuesto?.manoObra?.length && !order.presupuesto?.partes?.length) &&
                          order.servicios.map((srv) => (
                            <tr key={srv.id}>
                              <td className="p-2 font-semibold text-slate-900">{srv.concepto}</td>
                              <td className="p-2 text-center text-slate-500">Servicio</td>
                              <td className="p-2 text-center">1</td>
                              <td className="p-2 text-right">{formatMoney(srv.manoObra)}</td>
                              <td className="p-2 text-right font-bold text-slate-900">{formatMoney(srv.manoObra)}</td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Resumen Financiero */}
                  <div className="flex justify-end mt-2">
                    <div className="w-64 bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs space-y-1">
                      <div className="flex justify-between text-slate-600">
                        <span>Mano de Obra:</span>
                        <strong className="text-slate-800">{formatMoney(order.subtotalManoObra)}</strong>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Refacciones:</span>
                        <strong className="text-slate-800">{formatMoney(order.subtotalRefacciones)}</strong>
                      </div>
                      {order.presupuesto?.aplicaIva && (
                        <div className="flex justify-between text-slate-600">
                          <span>IVA (Frontera {config.ivaFronteraPorcentaje}%):</span>
                          <strong className="text-slate-800">{formatMoney(order.presupuesto.ivaMonto)}</strong>
                        </div>
                      )}
                      <div className="flex justify-between text-sm font-black border-t border-slate-200 pt-1 text-slate-900">
                        <span>TOTAL ESTIMADO:</span>
                        <span className="text-rose-600">{formatMoney(order.presupuesto?.totalPresupuesto || order.subtotalGeneral)}</span>
                      </div>
                      <div className="flex justify-between text-xs font-bold text-emerald-700">
                        <span>Anticipo Pagado:</span>
                        <span>{formatMoney(order.totalPagado)}</span>
                      </div>
                      <div className="flex justify-between text-xs font-black text-rose-700 border-t border-slate-200 pt-1">
                        <span>SALDO PENDIENTE:</span>
                        <span>{formatMoney(order.saldoPendiente)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Firmas de Recepción e Identificación Hoja 1 */}
              <div>
                <div className="grid grid-cols-2 gap-6 border-t border-dashed border-slate-300 pt-4 mt-4">
                  {/* Taller */}
                  <div className="border border-slate-300 rounded-xl p-3 bg-slate-50 text-center flex flex-col justify-between h-28">
                    <div className="font-bold text-xs text-slate-900">
                      POR TALLER MECÁNICO AMAYA
                    </div>
                    <div className="text-[10px] text-slate-400 italic">
                      Sello y Firma de Recepción Técnica
                    </div>
                    <div className="text-[10px] text-slate-500">
                      {config.razonSocial}<br />Recepción y Custodia
                    </div>
                  </div>

                  {/* Cliente Firma */}
                  <div className="border-2 border-slate-900 rounded-xl p-3 bg-white text-center flex flex-col justify-between h-28">
                    <div className="font-bold text-xs text-slate-900 flex items-center justify-center gap-1">
                      <UserCheck className="w-3.5 h-3.5 text-rose-600" />
                      <span>FIRMA DE ACEPTACIÓN DEL CLIENTE</span>
                    </div>

                    <div className="h-10 flex items-center justify-center border-b border-slate-800">
                      {digitalSignature ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                          src={digitalSignature}
                          alt="Firma del Cliente"
                          className="max-h-9 max-w-[150px] object-contain"
                        />
                      ) : (
                        <span className="text-[10px] text-slate-400 italic">
                          Firma autógrafa de conformidad
                        </span>
                      )}
                    </div>

                    <div className="text-[10px] text-slate-700">
                      <strong>{nombreFirmante}</strong> • {tipoIdentificacion}: {numeroIdentificacion || 'En resguardo'}
                    </div>
                  </div>
                </div>

                <div className="text-center text-[10px] text-slate-400 border-t border-slate-200 pt-2 mt-3">
                  Hoja 1 de 2 • Orden #{order.folio} • Continúa en Hoja 2 con Identificación Oficial, Garantías y Disclaimers
                </div>
              </div>
            </div>
          )}

          {/* ------------------------------------------------------------ */}
          {/* HOJA 2: VISTA PREVIA CARTA (DISCLAIMERS Y FIRMAS LEGALES)     */}
          {/* ------------------------------------------------------------ */}
          {(activeTab === 'ambas' || activeTab === 'hoja2') && (
            <div className="bg-white w-full max-w-[800px] min-h-[1050px] p-8 rounded-lg shadow-xl border border-slate-300 flex flex-col justify-between text-slate-900 animate-fadeIn">
              <div>
                {/* Encabezado Hoja 2 con Logotipo Oficial */}
                <div className="flex justify-between items-center border-b-2 border-rose-600 pb-4 mb-4">
                  <div className="flex items-center gap-4">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src="/logo-taller-amaya.png"
                      alt={config.nombreComercial}
                      className="h-14 w-auto object-contain drop-shadow"
                    />
                    <div>
                      <div className="text-lg font-black text-rose-600 tracking-tight flex items-center gap-1.5">
                        <ShieldCheck className="w-5 h-5" />
                        {config.nombreComercial} — PÓLIZA Y CONDICIONES
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5">
                        Términos de Servicio, Póliza de Garantía y Deslinde de Responsabilidad (Disclaimers)
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-base font-black text-slate-900">HOJA 2 / 2</div>
                    <div className="text-xs text-slate-500">
                      Orden #{order.folio} • Placas: {vehicle?.placas || '—'}
                    </div>
                  </div>
                </div>

                {/* Sub-banner explicativo */}
                <div className="bg-rose-50/70 border-l-4 border-rose-600 p-2.5 rounded-r-lg text-xs text-slate-700 leading-relaxed mb-3">
                  El presente contrato regula los servicios de diagnóstico, mantenimiento y reparación convenidos entre{' '}
                  <strong>{config.razonSocial} (TALLER AMAYA)</strong> y el cliente identificado oficialmente al calce.
                </div>

                {/* Lista de Cláusulas y Disclaimers Legales */}
                <div className="space-y-2 mb-4">
                  {disclaimers.map((c) => (
                    <div key={c.id} className="text-xs">
                      {c.esSeccionEspecial ? (
                        <div>
                          <div className="font-black text-slate-900 uppercase tracking-tight flex items-center gap-1.5 mb-0.5">
                            <span className="w-4 h-4 rounded-full bg-slate-900 text-white text-[10px] flex items-center justify-center font-bold shrink-0">
                              {c.numero}
                            </span>
                            <span>{c.titulo}</span>
                          </div>
                          <p className="text-slate-700 text-[10.5px] leading-relaxed text-justify pl-5 whitespace-pre-line">
                            {c.contenido}
                          </p>
                        </div>
                      ) : (
                        <div className="flex items-start gap-1.5">
                          <span className="font-bold text-slate-900 text-[11px] shrink-0">
                            {c.numero}.
                          </span>
                          <p className="text-slate-700 text-[11px] leading-relaxed text-justify">
                            {c.contenido}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Recuadro de Identificación Oficial del Cliente (Destacado) */}
                <div className="border-2 border-slate-900 rounded-xl p-3.5 bg-slate-50/70 mb-3 text-xs">
                  <div className="flex items-center justify-between border-b border-slate-300 pb-1.5 mb-2">
                    <span className="font-black text-slate-900 uppercase flex items-center gap-1.5">
                      <IdCard className="w-4 h-4 text-rose-600" />
                      DATOS DE IDENTIFICACIÓN OFICIAL DEL CLIENTE O TITULAR
                    </span>
                    <span className="text-[10px] bg-rose-100 text-rose-800 px-2 py-0.5 rounded font-bold">
                      COTEJADO OFICIALMENTE
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    <div>
                      <span className="text-slate-500 block text-[11px]">Titular / Firmante:</span>
                      <strong className="text-slate-900">{nombreFirmante}</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[11px]">Tipo de Identificación:</span>
                      <strong className="text-slate-800">[X] {tipoIdentificacion} &nbsp; [ ] Otra</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[11px]">No. de Identificación / Clave:</span>
                      <strong className="text-sky-700 font-mono text-xs">
                        {numeroIdentificacion || '_______________________________'}
                      </strong>
                    </div>
                  </div>

                  {fotoIdentificacion && (
                    <div className="mt-2 pt-2 border-t border-slate-200 flex items-center gap-3">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={fotoIdentificacion}
                        alt="Identificación Oficial INE"
                        onClick={() => {
                          setLightboxIndex(fotosValidas.length);
                          setLightboxOpen(true);
                        }}
                        className="h-12 border border-slate-300 hover:border-rose-500 rounded shadow-sm cursor-pointer hover:scale-105 transition-all"
                        title="Clic para ver identificación en tamaño grande"
                      />
                      <span className="text-[11px] text-slate-500">
                        Copia digital de identificación oficial verificada y vinculada a la orden de servicio. (Clic para ampliar)
                      </span>
                    </div>
                  )}
                </div>

                {/* Declaración de aceptación */}
                <div className="bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs text-slate-700 leading-relaxed">
                  <div className="font-black uppercase text-slate-900 mb-0.5">
                    DECLARACIÓN EXPRESA DE CONFORMIDAD Y ACEPTACIÓN
                  </div>
                  <p className="text-[11px] text-slate-600">
                    El suscrito declara bajo protesta de decir verdad que se identifica con el documento oficial asentado, cuenta con facultades legales para autorizar la reparación y pruebas de manejo, y acepta de plena conformidad los términos de servicio, póliza de garantía, deslindes legales y plazos de almacenaje.
                  </p>
                </div>
              </div>

              {/* Firmas Hoja 2 */}
              <div>
                <div className="grid grid-cols-2 gap-6 border-t border-dashed border-slate-300 pt-4 mt-4">
                  {/* Firma de Aceptación del Cliente */}
                  <div className="border-2 border-slate-900 rounded-xl p-3 bg-white text-center flex flex-col justify-between h-32">
                    <div className="font-bold text-xs text-slate-900 flex items-center justify-center gap-1">
                      <UserCheck className="w-3.5 h-3.5 text-rose-600" />
                      <span>FIRMA DE ACEPTACIÓN DEL CLIENTE</span>
                    </div>

                    <div className="h-12 flex items-center justify-center border-b border-slate-800">
                      {digitalSignature ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                          src={digitalSignature}
                          alt="Firma Aceptación Legal"
                          className="max-h-11 max-w-[160px] object-contain"
                        />
                      ) : (
                        <span className="text-[10px] text-slate-400 italic">
                          Firma autógrafa de conformidad legal
                        </span>
                      )}
                    </div>

                    <div className="text-[10px] text-slate-700 leading-tight">
                      <strong>{nombreFirmante}</strong><br />
                      {tipoIdentificacion}: <strong>{numeroIdentificacion || '____________________'}</strong> • Fecha: {formatDate(order.fechaIngreso)}
                    </div>
                  </div>

                  {/* Sello y Firma Taller */}
                  <div className="border border-slate-300 rounded-xl p-3 bg-slate-50 text-center flex flex-col justify-between h-32">
                    <div className="font-bold text-xs text-slate-900">
                      POR TALLER MECÁNICO AMAYA
                    </div>
                    <div className="text-[10px] text-slate-400 italic">
                      Sello y Firma del Responsable Técnico
                    </div>
                    <div className="text-[10px] text-slate-500 leading-tight">
                      {config.razonSocial}<br />
                      RFC: {config.rfc}<br />
                      Tijuana B.C.
                    </div>
                  </div>
                </div>

                <div className="text-center text-[10px] text-slate-400 border-t border-slate-200 pt-2 mt-3">
                  Hoja 2 de 2 • Taller Mecánico Amaya • C. Santo Domingo #19950, Tijuana B.C. • Tel: {config.telefonoLocal}
                  <div className="text-[9px] font-bold text-slate-500 mt-1">
                    ESTE DOCUMENTO NO TIENE VALIDEZ FISCAL, NI SUSTITUYE AL COMPROBANTE FISCAL, ES EXCLUSIVO PARA CONTROL INTERNO Y FINES INFORMATIVOS.
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* ============================================================== */}
        {/* MODAL / CANVAS PARA CAPTURAR FIRMA DIGITAL DEL CLIENTE         */}
        {/* ============================================================== */}
        {showSignPad && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fadeIn">
            <div className="bg-white border border-slate-300 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col">
              <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
                <div className="flex items-center gap-2">
                  <PenTool className="w-5 h-5 text-indigo-600" />
                  <h3 className="font-black text-slate-900 text-sm">
                    Captura de Firma Digital de Aceptación
                  </h3>
                </div>
                <button
                  onClick={() => setShowSignPad(false)}
                  className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-4 space-y-3">
                <p className="text-xs text-slate-500">
                  El cliente puede firmar con el dedo (en pantalla táctil/celular) o con el mouse:
                </p>

                {/* Canvas de Dibujo */}
                <div className="border-2 border-slate-300 rounded-xl overflow-hidden bg-slate-50 relative">
                  <canvas
                    ref={canvasRef}
                    width={400}
                    height={180}
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={stopDrawing}
                    onMouseLeave={stopDrawing}
                    onTouchStart={startDrawing}
                    onTouchMove={draw}
                    onTouchEnd={stopDrawing}
                    className="w-full h-44 cursor-crosshair touch-none bg-white"
                  />
                  <div className="absolute bottom-2 right-2 text-[10px] text-slate-400 pointer-events-none">
                    Firme sobre la línea
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <button
                    onClick={clearSignature}
                    className="flex items-center gap-1 text-xs text-rose-600 hover:text-rose-700 font-bold px-3 py-1.5 rounded-lg border border-rose-200 hover:bg-rose-50"
                  >
                    <Eraser className="w-3.5 h-3.5" />
                    <span>Borrar / Limpiar</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setShowSignPad(false)}
                      className="px-3 py-1.5 border border-slate-300 rounded-xl text-slate-700 hover:bg-slate-100 font-bold text-xs"
                    >
                      Cancelar
                    </button>
                    <button
                      onClick={saveSignature}
                      className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-xs shadow-md shadow-indigo-600/25 flex items-center gap-1.5"
                    >
                      <Save className="w-4 h-4" />
                      <span>Guardar Firma</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* CAJÓN LATERAL / MODAL PARA EDITAR DISCLAIMERS                  */}
        {/* ============================================================== */}
        {showEditor && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-fadeIn">
            <div className="bg-white border border-slate-300 rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
              <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
                <div className="flex items-center gap-2">
                  <Edit3 className="w-5 h-5 text-amber-600" />
                  <h3 className="font-black text-slate-900 text-sm">
                    Personalizar Cláusulas y Disclaimers Legales (Hoja 2)
                  </h3>
                </div>
                <button
                  onClick={() => setShowEditor(false)}
                  className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-4 flex-1 overflow-y-auto space-y-4 text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <p className="text-slate-500">
                    Puedes redactar, agregar o eliminar cláusulas según los requerimientos de tu taller.
                  </p>
                  <button
                    onClick={handleResetDisclaimers}
                    className="flex items-center gap-1 text-xs text-rose-600 hover:underline font-bold"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Restablecer sugeridas
                  </button>
                </div>

                {editingClauses.map((clause) => (
                  <div
                    key={clause.id}
                    className="p-3.5 border border-slate-200 rounded-xl bg-slate-50/50 space-y-2 relative group"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 flex-1">
                        <span className="font-bold text-slate-500 w-5">
                          {clause.numero}.
                        </span>
                        <input
                          type="text"
                          value={clause.titulo}
                          onChange={(e) => handleClauseChange(clause.id, 'titulo', e.target.value)}
                          className="font-bold text-slate-900 bg-white border border-slate-300 rounded-lg px-2.5 py-1 text-xs w-full focus:outline-none focus:ring-1 focus:ring-rose-500"
                          placeholder="Título de la cláusula..."
                        />
                      </div>
                      <button
                        onClick={() => handleDeleteClause(clause.id)}
                        className="text-slate-400 hover:text-rose-600 p-1 rounded hover:bg-rose-50 transition-colors"
                        title="Eliminar cláusula"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <textarea
                      rows={3}
                      value={clause.contenido}
                      onChange={(e) => handleClauseChange(clause.id, 'contenido', e.target.value)}
                      className="w-full text-slate-700 bg-white border border-slate-300 rounded-lg p-2.5 text-xs focus:outline-none focus:ring-1 focus:ring-rose-500 leading-relaxed"
                      placeholder="Contenido legal de la cláusula..."
                    />
                  </div>
                ))}

                <button
                  onClick={handleAddClause}
                  className="w-full py-2.5 border-2 border-dashed border-slate-300 hover:border-rose-400 rounded-xl text-slate-600 hover:text-rose-600 font-bold flex items-center justify-center gap-1.5 transition-colors bg-white"
                >
                  <Plus className="w-4 h-4" />
                  <span>Añadir Nueva Cláusula</span>
                </button>
              </div>

              <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
                {saveSuccess ? (
                  <span className="text-emerald-600 font-bold flex items-center gap-1 text-xs animate-fadeIn">
                    <CheckCircle2 className="w-4 h-4" /> ¡Guardado con éxito!
                  </span>
                ) : (
                  <span className="text-[11px] text-slate-500">
                    Se guardará permanentemente en este equipo para todas las órdenes.
                  </span>
                )}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowEditor(false)}
                    className="px-3 py-1.5 border border-slate-300 rounded-xl text-slate-700 hover:bg-slate-100 font-bold text-xs"
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={handleSaveDisclaimers}
                    className="px-4 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl font-bold text-xs shadow-md shadow-rose-600/25 flex items-center gap-1.5"
                  >
                    <Save className="w-4 h-4" />
                    <span>Guardar Cambios</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Modal Lightbox para ver fotografías en tamaño completo */}
        <ImageLightboxModal
          isOpen={lightboxOpen}
          onClose={() => setLightboxOpen(false)}
          photos={lightboxPhotos}
          initialIndex={lightboxIndex}
        />
      </div>
    </div>
  );
};
