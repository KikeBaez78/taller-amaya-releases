'use client';

import React, { useState, useMemo } from 'react';
import { StorageService } from '@/lib/storage';
import { Vehicle, WorkOrder, Client, Company } from '@/types';
import {
  Search,
  Car,
  Calendar,
  Gauge,
  User,
  Building2,
  AlertTriangle,
  Clock,
  Wrench,
  CheckCircle2,
  FileText,
  DollarSign,
  ChevronRight,
  Eye,
  Camera,
  MessageCircle,
  Hash,
  ShieldCheck,
  Tag,
} from 'lucide-react';
import { ImageLightboxModal, LightboxPhoto } from './ImageLightboxModal';

interface BitacoraSearchProps {
  onSelectOrder?: (order: WorkOrder) => void;
  onNewOrderForVehicle?: (vehicle: Vehicle) => void;
}

export const BitacoraSearch: React.FC<BitacoraSearchProps> = ({
  onSelectOrder,
  onNewOrderForVehicle,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedVehicleId, setSelectedVehicleId] = useState<string | null>(null);
  const [expandedPhotoVisitId, setExpandedPhotoVisitId] = useState<string | null>(null);
  const [syncCount, setSyncCount] = useState(0);

  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxPhotos, setLightboxPhotos] = useState<LightboxPhoto[]>([]);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  const handleOpenPhoto = (photosObj: Record<string, string | undefined>, currentKey: string) => {
    const labels: Record<string, string> = {
      frente: '1. Frente',
      trasera: '2. Trasera',
      lateralIzquierdo: '3. Lateral Izquierdo',
      lateralDerecho: '4. Lateral Derecho',
      motor: '5. Bahía Motor',
      odometro: '6. Tablero / Odómetro',
      interior: '7. Interior / Asientos',
      cajuela: '8. Cajuela / Maletero',
    };
    const list = Object.entries(photosObj)
      .filter(([, url]) => Boolean(url))
      .map(([k, url]) => ({
        url: url as string,
        title: labels[k] || k.charAt(0).toUpperCase() + k.slice(1),
      }));
    const idx = list.findIndex((p) => p.url === photosObj[currentKey]);
    setLightboxPhotos(list);
    setLightboxIndex(idx >= 0 ? idx : 0);
    setLightboxOpen(true);
  };

  // Escuchar sincronización en tiempo real
  React.useEffect(() => {
    const handleSync = () => setSyncCount((c) => c + 1);
    window.addEventListener('taller_data_synced', handleSync);
    return () => window.removeEventListener('taller_data_synced', handleSync);
  }, []);

  // Resultados de búsqueda reactivos
  const results = useMemo(() => {
    return StorageService.searchBitacora(searchTerm);
  }, [searchTerm, syncCount]);

  const selectedRecord = useMemo(() => {
    if (!selectedVehicleId) return null;
    return results.find((r) => r.vehicle.id === selectedVehicleId) || null;
  }, [selectedVehicleId, results]);

  return (
    <div className="space-y-6">
      {/* Buscador Principal */}
      <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-sm">
        <div className="max-w-3xl">
          <div className="flex items-center gap-2 text-rose-600 font-extrabold text-xs mb-1 uppercase tracking-widest">
            <Search className="w-4 h-4" />
            <span>Bitácora Relacional de Vehículos, Clientes y Servicios</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 mb-2 tracking-tight">
            Buscador Clínico del Taller
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mb-5">
            Escribe el <strong>número de placas</strong>, marca/modelo del <strong>vehículo</strong> o <strong>nombre del cliente / empresa</strong> para desplegar todos los vehículos relacionados y el historial completo de sus visitas y trabajos realizados.
          </p>

          <div className="relative">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Ejemplos: BJE-849-A, Urvan, Civic, Hilux, Baja, Morales, Carmen..."
              className="w-full bg-slate-50 border-2 border-slate-200 focus:border-rose-500 rounded-2xl px-5 py-3.5 pl-12 text-base sm:text-lg text-slate-900 placeholder-slate-400 focus:outline-none transition-all shadow-inner font-medium"
              autoFocus
            />
            <Search className="w-5 h-5 text-rose-600 absolute left-4 top-1/2 -translate-y-1/2" />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-semibold px-2.5 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg"
              >
                Limpiar
              </button>
            )}
          </div>
        </div>

        {/* Quick filters / tags */}
        <div className="flex flex-wrap items-center gap-2 mt-4 pt-4 border-t border-slate-100 text-xs text-slate-500">
          <span>Atajos rápidos:</span>
          {['BJE-849-A', 'ALK-192-B', 'ZAR-771-C', 'BJU-409-D', 'Baja', 'Morales'].map((tag) => (
            <button
              key={tag}
              onClick={() => setSearchTerm(tag)}
              className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-200 border border-slate-200 transition-colors font-mono font-semibold text-slate-700"
            >
              {tag}
            </button>
          ))}
        </div>
      </div>

      {/* Resultados de Vehículos Coincidentes */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Lista de Vehículos (lado izquierdo) */}
        <div className={selectedRecord ? 'lg:col-span-5 space-y-3' : 'lg:col-span-12 space-y-3'}>
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider px-1">
            <span>Vehículos Encontrados ({results.length})</span>
            {selectedVehicleId && (
              <button
                onClick={() => setSelectedVehicleId(null)}
                className="text-rose-600 hover:underline font-bold"
              >
                Cerrar expediente
              </button>
            )}
          </div>

          {results.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-3xl p-8 text-center text-slate-400 shadow-sm">
              <Car className="w-12 h-12 mx-auto text-slate-300 mb-3" />
              <p className="font-bold text-slate-700">No se encontraron vehículos</p>
              <p className="text-xs text-slate-500 mt-1">
                Verifica las placas o el nombre del cliente ingresado.
              </p>
            </div>
          ) : (
            results.map((rec) => {
              const isSelected = selectedVehicleId === rec.vehicle.id;
              const hasAlert = rec.requiereMantenimiento;

              return (
                <div
                  key={rec.vehicle.id}
                  onClick={() => setSelectedVehicleId(rec.vehicle.id)}
                  className={`bg-white border rounded-2xl p-4 cursor-pointer transition-all hover:border-rose-500 hover:shadow-md ${
                    isSelected
                      ? 'border-rose-500 ring-2 ring-rose-500/20 bg-rose-50/20 shadow-sm'
                      : 'border-slate-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      {/* Placa y Marca */}
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono font-black text-base bg-rose-50 text-rose-700 border border-rose-200 px-2.5 py-0.5 rounded-lg tracking-wider">
                          {rec.vehicle.placas}
                        </span>
                        <span className="text-sm font-bold text-slate-900">
                          {rec.vehicle.marca} {rec.vehicle.modelo} ({rec.vehicle.ano})
                        </span>
                      </div>

                      {/* Cliente / Empresa */}
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-600 mt-2">
                        {rec.company ? (
                          <div className="flex items-center gap-1 text-emerald-700 font-semibold">
                            <Building2 className="w-3.5 h-3.5" />
                            <span>{rec.company.razonSocial}</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1 text-slate-600">
                            <User className="w-3.5 h-3.5 text-slate-400" />
                            <span>{rec.client?.nombre || 'Particular'}</span>
                          </div>
                        )}

                        {rec.vehicle.choferHabitual && (
                          <div className="text-slate-500">
                            Chofer: <strong className="text-slate-700">{rec.vehicle.choferHabitual}</strong>
                          </div>
                        )}
                      </div>

                      {/* Odómetro y Visitas */}
                      <div className="flex items-center gap-4 text-xs text-slate-400 mt-2">
                        <span className="flex items-center gap-1">
                          <Gauge className="w-3.5 h-3.5 text-slate-400" />
                          <span>{rec.vehicle.kilometrajeActual.toLocaleString()} km</span>
                        </span>

                        <span className="flex items-center gap-1">
                          <FileText className="w-3.5 h-3.5 text-slate-400" />
                          <span>{rec.history.length} visita(s) en historial</span>
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-2">
                      <ChevronRight
                        className={`w-5 h-5 text-slate-400 transition-transform ${
                          isSelected ? 'rotate-90 text-rose-600' : ''
                        }`}
                      />
                      {hasAlert && (
                        <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-300 animate-pulse">
                          <AlertTriangle className="w-3 h-3 text-amber-600" />
                          <span>Alerta Servicio</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Detalle breve de alerta */}
                  {hasAlert && (
                    <div className="mt-3 p-2 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-center justify-between gap-2">
                      <span>⚠️ {rec.motivoAlerta}</span>
                      <a
                        href={StorageService.generateWhatsAppReminder(
                          rec.vehicle,
                          rec.client?.nombre || rec.vehicle.choferHabitual || 'Estimado Cliente',
                          rec.client?.telefono || rec.vehicle.choferTelefono || '6644093068',
                          rec.motivoAlerta
                        )}
                        target="_blank"
                        rel="noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[11px] font-bold shrink-0 shadow-sm"
                      >
                        <MessageCircle className="w-3 h-3" />
                        <span>Avisar WA</span>
                      </a>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Expediente Clínico Completo del Vehículo Seleccionado (lado derecho) */}
        {selectedRecord && (
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm sticky top-24">
              {/* Encabezado del Expediente */}
              <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-2xl font-black bg-rose-50 text-rose-700 border border-rose-200 px-3 py-1 rounded-xl">
                      {selectedRecord.vehicle.placas}
                    </span>
                    <div>
                      <h3 className="text-xl font-black text-slate-900">
                        {selectedRecord.vehicle.marca} {selectedRecord.vehicle.modelo} {selectedRecord.vehicle.ano}
                      </h3>
                      <p className="text-xs text-slate-500">
                        Color: {selectedRecord.vehicle.color} {selectedRecord.vehicle.vin && `| VIN: ${selectedRecord.vehicle.vin}`}
                      </p>
                    </div>
                  </div>
                </div>

                {onNewOrderForVehicle && (
                  <button
                    onClick={() => onNewOrderForVehicle(selectedRecord.vehicle)}
                    className="flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white text-xs font-bold rounded-xl shadow-md shadow-rose-600/20 transition-all"
                  >
                    <Wrench className="w-4 h-4" />
                    <span>Abrir Nueva Orden</span>
                  </button>
                )}
              </div>

              {/* Ficha Resumen */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 my-4 bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs">
                <div>
                  <span className="text-slate-400 block font-medium">Propietario / Flotilla:</span>
                  <span className="font-bold text-slate-900 text-sm">
                    {selectedRecord.company
                      ? selectedRecord.company.razonSocial
                      : selectedRecord.client?.nombre || 'Particular'}
                  </span>
                  {selectedRecord.company && (
                    <span className="text-[11px] text-emerald-600 font-semibold block mt-0.5">
                      Encargado: {selectedRecord.company.encargadoFlotilla}
                    </span>
                  )}
                </div>

                <div>
                  <span className="text-slate-400 block font-medium">Chofer Asignado:</span>
                  <span className="font-semibold text-slate-800">
                    {selectedRecord.vehicle.choferHabitual || 'No asignado'}
                  </span>
                  {selectedRecord.vehicle.choferTelefono && (
                    <span className="text-[11px] text-slate-500 block font-mono">
                      Tel: {selectedRecord.vehicle.choferTelefono}
                    </span>
                  )}
                </div>

                <div>
                  <span className="text-slate-400 block font-medium">Kilometraje Odómetro:</span>
                  <span className="font-mono text-base font-bold text-rose-600">
                    {selectedRecord.vehicle.kilometrajeActual.toLocaleString()} km
                  </span>
                </div>
              </div>

              {/* Historial Cronológico de Visitas y Trabajos */}
              <div>
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-slate-400" />
                  <span>Historial de Visitas y Trabajos Realizados ({selectedRecord.history.length})</span>
                </h4>

                {selectedRecord.history.length === 0 ? (
                  <p className="text-xs text-slate-500 italic bg-slate-50 p-4 rounded-xl">
                    Este vehículo no tiene órdenes previas registradas.
                  </p>
                ) : (
                  <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                    {selectedRecord.history.map((order) => {
                      const isPhotoExpanded = expandedPhotoVisitId === order.id;

                      return (
                        <div
                          key={order.id}
                          className="bg-slate-50 border border-slate-200 rounded-2xl p-4 hover:border-slate-300 transition-colors"
                        >
                          {/* Cabecera de la Visita */}
                          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200">
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-bold text-xs bg-white text-slate-800 px-2.5 py-1 rounded-lg border border-slate-200 shadow-sm">
                                Folio: #{order.folio}
                              </span>
                              <span className="text-xs text-slate-500 flex items-center gap-1">
                                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                                {order.fechaIngreso}
                              </span>
                            </div>

                            <div className="flex items-center gap-2">
                              <span
                                className={`text-[11px] font-bold uppercase px-2.5 py-0.5 rounded-full border ${
                                  order.estado === 'entregado'
                                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                    : order.estado === 'en_proceso'
                                    ? 'bg-amber-50 text-amber-800 border-amber-200'
                                    : 'bg-sky-50 text-sky-800 border-sky-200'
                                }`}
                              >
                                {order.estado}
                              </span>

                              {onSelectOrder && (
                                <button
                                  onClick={() => onSelectOrder(order)}
                                  className="text-xs font-semibold text-rose-600 hover:text-rose-700 px-2 py-0.5 bg-white border border-slate-200 rounded-lg shadow-sm"
                                >
                                  Ver Orden
                                </button>
                              )}
                            </div>
                          </div>

                          {/* Falla Reportada */}
                          <div className="my-2.5">
                            <span className="text-[11px] text-slate-400 font-semibold uppercase block">
                              Motivo de Ingreso / Falla Reportada:
                            </span>
                            <p className="text-xs font-medium text-slate-700 mt-0.5">
                              {order.fallaReportada}
                            </p>
                          </div>

                          {/* Refacciones traídas por el cliente */}
                          {order.refaccionesCliente && order.refaccionesCliente.length > 0 && (
                            <div className="my-2 p-2 bg-amber-50 border border-amber-200 rounded-xl text-xs">
                              <span className="text-[11px] text-amber-800 font-bold uppercase block mb-1">
                                Refacciones que trajo el cliente:
                              </span>
                              <ul className="list-disc list-inside space-y-0.5 text-amber-900">
                                {order.refaccionesCliente.map((ref, idx) => (
                                  <li key={idx}>{ref}</li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {/* Conceptos y Trabajos Realizados */}
                          <div className="my-3">
                            <span className="text-[11px] text-slate-400 font-semibold uppercase block mb-1">
                              Servicios Aplicados:
                            </span>
                            <div className="space-y-1.5">
                              {order.servicios.map((srv) => (
                                <div
                                  key={srv.id}
                                  className="flex flex-wrap items-center justify-between text-xs bg-white px-3 py-2 rounded-xl border border-slate-200 shadow-sm"
                                >
                                  <div>
                                    <span className="font-semibold text-slate-900">{srv.concepto}</span>
                                    <span className="text-[11px] text-slate-500 block">
                                      Mecánico: <strong className="text-slate-700">{srv.mecanicoNombre}</strong> (Comisión {srv.comisionPorcentaje}%)
                                    </span>
                                  </div>
                                  <div className="text-right">
                                    <span className="font-mono text-slate-900 font-bold">
                                      ${(srv.manoObra + srv.refaccionesMonto).toLocaleString()} MXN
                                    </span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Desglose de Pago & Fotos */}
                          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-200 text-xs">
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() =>
                                  setExpandedPhotoVisitId(isPhotoExpanded ? null : order.id)
                                }
                                className="flex items-center gap-1 text-slate-600 hover:text-rose-600 py-1 font-semibold"
                              >
                                <Camera className="w-3.5 h-3.5 text-slate-500" />
                                <span>{isPhotoExpanded ? 'Ocultar Fotos' : 'Ver 8 Fotos de Entrada'}</span>
                              </button>
                            </div>

                            <div className="font-mono text-xs">
                              <span className="text-slate-500">Total Orden: </span>
                              <strong className="text-slate-900">${order.subtotalGeneral.toLocaleString()} MXN</strong>
                              {order.saldoPendiente > 0 ? (
                                <span className="text-rose-600 font-bold ml-2">
                                  (Pendiente: ${order.saldoPendiente.toLocaleString()})
                                </span>
                              ) : (
                                <span className="text-emerald-600 font-bold ml-2">✓ Liquidado</span>
                              )}
                            </div>
                          </div>

                          {/* Galería de las 8 Fotos desplegable */}
                          {isPhotoExpanded && order.fotosEntrada && (
                            <div className="mt-3 pt-3 border-t border-slate-200">
                              <span className="text-[11px] font-bold text-slate-500 uppercase block mb-2">
                                Registro Fotográfico de Entrada (8 Fotos Oficiales):
                              </span>
                              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                                {Object.entries(order.fotosEntrada).map(([angulo, url]) => (
                                  <div
                                    key={angulo}
                                    onClick={() => handleOpenPhoto(order.fotosEntrada as any, angulo)}
                                    className="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-100 aspect-video group cursor-pointer shadow-sm hover:border-rose-400 transition-all"
                                    title="Clic para ver foto en tamaño grande"
                                  >
                                    <img
                                      src={url as string}
                                      alt={angulo}
                                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                                    />
                                    <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                      <span className="p-1 bg-white/95 text-slate-900 rounded text-[9px] font-bold flex items-center gap-1 shadow">
                                        <Eye className="w-3 h-3 text-rose-600" />
                                        <span>Ver Grande</span>
                                      </span>
                                    </div>
                                    <span className="absolute bottom-0 inset-x-0 bg-slate-900/75 text-[9px] text-center text-white font-semibold py-0.5 capitalize truncate">
                                      {angulo}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Lightbox para ver fotos de historial en tamaño grande */}
      <ImageLightboxModal
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        photos={lightboxPhotos}
        initialIndex={lightboxIndex}
      />
    </div>
  );
};
