import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { BackupService } from '@/lib/backupService';
import { TALLER_CONFIG } from '@/data/tallerConfig';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action');
    const file = searchParams.get('file');

    // 1. Listar respaldos existentes
    if (action === 'list') {
      const backups = BackupService.listBackups();
      return NextResponse.json({
        success: true,
        backups,
        total: backups.length,
        backupsDir: BackupService.getBackupsDir(),
      });
    }

    // 2. Descargar un archivo histórico específico
    if (action === 'download_file' && file) {
      const filePath = BackupService.getBackupFilePath(file);
      if (!filePath || !fs.existsSync(filePath)) {
        return NextResponse.json({ error: 'Archivo no encontrado' }, { status: 404 });
      }
      const fileBuffer = fs.readFileSync(filePath);
      return new Response(fileBuffer, {
        headers: {
          'Content-Type': 'application/json',
          'Content-Disposition': `attachment; filename="${path.basename(filePath)}"`,
        },
      });
    }

    // 3. Descarga directa del respaldo actual más reciente
    const currentDb = BackupService.getCurrentDb();
    if (!currentDb) {
      return NextResponse.json({ error: 'No hay base de datos disponible' }, { status: 404 });
    }

    // Asegurar que quede registrado el snapshot diario
    BackupService.performDailyAutoBackup(currentDb);

    const today = new Date().toISOString().slice(0, 10);
    const filename = `Respaldo_Taller_Amaya_${today}.json`;
    const jsonString = JSON.stringify(currentDb, null, 2);

    return new Response(jsonString, {
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Disposition': `attachment; filename="${filename}"`,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();

    // 1. Crear respaldo manual inmediato
    if (body.type === 'create_manual') {
      const filename = BackupService.createManualBackup(body.label || 'manual');
      if (!filename) {
        return NextResponse.json({ error: 'No se pudo crear el respaldo manual' }, { status: 500 });
      }
      return NextResponse.json({
        success: true,
        filename,
        message: 'Respaldo manual generado exitosamente en el equipo',
      });
    }

    // 2. Restaurar respaldo (protegido por PIN administrativo)
    if (body.type === 'restore') {
      const { filename, pin } = body;

      if (!pin || String(pin).trim() !== String(TALLER_CONFIG.adminPin).trim()) {
        return NextResponse.json(
          { error: 'PIN de seguridad incorrecto. Solo la administración puede restaurar respaldos.' },
          { status: 403 }
        );
      }

      if (!filename) {
        return NextResponse.json({ error: 'Nombre de archivo requerido' }, { status: 400 });
      }

      const res = BackupService.restoreBackup(filename);
      if (!res.success) {
        return NextResponse.json({ error: res.message }, { status: 400 });
      }

      return NextResponse.json({
        success: true,
        message: res.message,
      });
    }

    return NextResponse.json({ error: 'Acción no soportada' }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
