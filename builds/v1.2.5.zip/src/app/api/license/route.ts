import { NextResponse } from 'next/server';
import {
  checkLicenseStatus,
  getMachineHardwareId,
  verifyActivationKey,
  saveLicenseFile,
  LicenseData,
} from '@/lib/license';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const status = checkLicenseStatus();
    return NextResponse.json(status);
  } catch (error) {
    console.error('Error al verificar licencia:', error);
    return NextResponse.json(
      {
        isActivated: false,
        machineId: 'DESCONOCIDO',
        reason: 'Error al consultar identificador del sistema',
      },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { activationKey, clientName } = body;

    const currentMachineId = getMachineHardwareId();

    if (!activationKey || typeof activationKey !== 'string') {
      return NextResponse.json(
        { success: false, message: 'Debe ingresar una clave de activación válida.' },
        { status: 400 }
      );
    }

    const isValid = verifyActivationKey(currentMachineId, activationKey.trim());

    if (!isValid) {
      return NextResponse.json(
        {
          success: false,
          message: 'La clave ingresada NO es válida para el código de hardware de esta computadora.',
        },
        { status: 403 }
      );
    }

    // Guardar la licencia autorizada
    const licenseData: LicenseData = {
      machineId: currentMachineId,
      activationKey: activationKey.trim().toUpperCase(),
      clientName: clientName?.trim() || 'Taller Amaya',
      activatedAt: new Date().toISOString(),
      status: 'active',
    };

    saveLicenseFile(licenseData);

    return NextResponse.json({
      success: true,
      message: '¡Software activado y casado exitosamente con este equipo!',
      license: licenseData,
    });
  } catch (error) {
    console.error('Error al procesar activación:', error);
    return NextResponse.json(
      { success: false, message: 'Ocurrió un error al intentar activar la licencia.' },
      { status: 500 }
    );
  }
}
