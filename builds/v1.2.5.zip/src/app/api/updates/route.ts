import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import {
  getCurrentVersionInfo,
  checkRemoteForUpdates,
  recordAppliedVersion,
  RemoteUpdateManifest,
} from '@/lib/updates';
import { BackupService } from '@/lib/backupService';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const checkResult = await checkRemoteForUpdates();
    return NextResponse.json(checkResult);
  } catch (error) {
    console.error('Error en /api/updates GET:', error);
    const current = getCurrentVersionInfo();
    return NextResponse.json({
      hasUpdate: false,
      currentVersion: current.version,
      offline: true,
      error: 'No se pudo conectar al servidor de actualizaciones.',
    });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, pin, targetVersion } = body;

    const currentInfo = getCurrentVersionInfo();

    // 1. Verificación de seguridad: Solo el dueño con PIN puede aplicar actualizaciones
    const requiredPin = currentInfo.ownerPin || '2036';
    if (!pin || String(pin).trim() !== requiredPin) {
      return NextResponse.json(
        {
          success: false,
          message: 'PIN del propietario incorrecto. Solo el dueño puede autorizar la actualización.',
        },
        { status: 403 }
      );
    }

    if (action === 'apply_update') {
      const nextVer = targetVersion || '1.1.0';

      // 1. Obtener la URL de descarga del manifiesto remoto
      const remoteCheck = await checkRemoteForUpdates();
      const downloadUrl =
        remoteCheck.remoteInfo?.downloadUrl ||
        `https://raw.githubusercontent.com/kikebaez78/taller-amaya-releases/main/builds/v${nextVer}.zip`;

      // 2. Descargar e instalar los archivos por internet (OTA)
      let installSuccess = false;
      try {
        console.log(`[OTA] Descargando actualización v${nextVer} desde ${downloadUrl}...`);
        const res = await fetch(downloadUrl, { cache: 'no-store' });
        if (res.ok) {
          const buffer = Buffer.from(await res.arrayBuffer());
          const tempZipPath = path.join(process.cwd(), 'temp_ota_update.zip');
          fs.writeFileSync(tempZipPath, buffer);

          // Respaldar base de datos y licencia antes de extraer
          const dbPath = path.join(process.cwd(), 'src', 'data', 'db.json');
          const licPath = path.join(process.cwd(), 'src', 'data', 'license.json');
          const dbBackup = fs.existsSync(dbPath) ? fs.readFileSync(dbPath, 'utf8') : null;
          const licBackup = fs.existsSync(licPath) ? fs.readFileSync(licPath, 'utf8') : null;

          // Crear un respaldo histórico automático del sistema antes de actualizar
          try {
            BackupService.createManualBackup('pre_actualizacion_ota');
          } catch {}

          // Guardar buffer temporal
          fs.writeFileSync(tempZipPath, buffer);

          // Crear un respaldo histórico automático del sistema antes de actualizar
          try {
            BackupService.createManualBackup('pre_actualizacion_ota');
          } catch {}

          // Si es Windows, lanzar el actualizador desacoplado para liberar bloqueos de archivos en Node
          if (process.platform === 'win32') {
            const batPath = path.join(process.cwd(), 'scripts', 'aplicar-actualizacion-silenciosa.bat');
            if (fs.existsSync(batPath)) {
              const { spawn } = require('child_process');
              const child = spawn('cmd.exe', ['/c', batPath], {
                detached: true,
                stdio: 'ignore',
              });
              child.unref();
            }
          } else {
            // En macOS / Linux
            try {
              execSync(`unzip -o "${tempZipPath}" -d "${process.cwd()}"`, {
                timeout: 30000,
                stdio: 'ignore',
              });
              if (fs.existsSync(tempZipPath)) {
                fs.unlinkSync(tempZipPath);
              }
            } catch (unzipErr) {
              console.error('[OTA] Error al descomprimir en unix:', unzipErr);
            }
          }

          installSuccess = true;
          console.log(`[OTA] ¡Actualización v${nextVer} descargada e invocada con éxito!`);
        }
      } catch (err) {
        console.error('[OTA] Error durante descarga o instalación:', err);
      }

      // 3. Asentar nueva versión en el manifiesto local
      const updated = recordAppliedVersion(nextVer);

      return NextResponse.json({
        success: true,
        restarting: true,
        message: `¡Sistema actualizado exitosamente a la versión ${nextVer}! El servidor se reiniciará automáticamente.`,
        newVersion: updated?.version || nextVer,
        installed: installSuccess,
      });
    }

    return NextResponse.json(
      { success: false, message: 'Acción no reconocida' },
      { status: 400 }
    );
  } catch (error) {
    console.error('Error en /api/updates POST:', error);
    return NextResponse.json(
      { success: false, message: 'Ocurrió un error al procesar la actualización.' },
      { status: 500 }
    );
  }
}
