import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import {
  getCurrentVersionInfo,
  checkRemoteForUpdates,
  recordAppliedVersion,
  RemoteUpdateManifest,
} from '@/lib/updates';
import { BackupService } from '@/lib/backupService';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const checkResult = await checkRemoteForUpdates();
    return NextResponse.json(checkResult);
  } catch (error) {
    console.error('Error en /api/updates GET:', error);
    const current = getCurrentVersionInfo();
    return NextResponse.json({
      hasUpdate: false,
      currentVersion: current.version,
      offline: true,
      error: 'No se pudo conectar al servidor de actualizaciones.',
    });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, pin, targetVersion } = body;

    const currentInfo = getCurrentVersionInfo();

    // 1. Verificación de seguridad: Solo el dueño con PIN puede aplicar actualizaciones
    const requiredPin = currentInfo.ownerPin || '2036';
    if (!pin || String(pin).trim() !== requiredPin) {
      return NextResponse.json(
        {
          success: false,
          message: 'PIN del propietario incorrecto. Solo el dueño puede autorizar la actualización.',
        },
        { status: 403 }
      );
    }

    if (action === 'apply_update') {
      const nextVer = targetVersion || '1.1.0';

      // 1. Obtener la URL de descarga del manifiesto remoto
      const remoteCheck = await checkRemoteForUpdates();
      const downloadUrl =
        remoteCheck.remoteInfo?.downloadUrl ||
        `https://raw.githubusercontent.com/kikebaez78/taller-amaya-releases/main/builds/v${nextVer}.zip`;

      // 2. Descargar e instalar los archivos por internet (OTA)
      let installSuccess = false;
      try {
        console.log(`[OTA] Descargando actualización v${nextVer} desde ${downloadUrl}...`);
        const res = await fetch(downloadUrl, { cache: 'no-store' });
        if (res.ok) {
          const buffer = Buffer.from(await res.arrayBuffer());
          const tempZipPath = path.join(process.cwd(), 'temp_ota_update.zip');
          fs.writeFileSync(tempZipPath, buffer);

          // Respaldar base de datos y licencia antes de extraer
          const dbPath = path.join(process.cwd(), 'src', 'data', 'db.json');
          const licPath = path.join(process.cwd(), 'src', 'data', 'license.json');
          const dbBackup = fs.existsSync(dbPath) ? fs.readFileSync(dbPath, 'utf8') : null;
          const licBackup = fs.existsSync(licPath) ? fs.readFileSync(licPath, 'utf8') : null;

          // Crear un respaldo histórico automático del sistema antes de actualizar
          try {
            BackupService.createManualBackup('pre_actualizacion_ota');
          } catch {}

          // Extraer usando tar (nativo en Windows 10/11 y macOS) o powershell
          try {
            if (process.platform === 'win32') {
              try {
                execSync(`tar -xf "${tempZipPath}" -C "${process.cwd()}"`, {
                  timeout: 30000,
                  stdio: 'ignore',
                });
              } catch {
                execSync(
                  `powershell -NoProfile -Command "Expand-Archive -Path '${tempZipPath}' -DestinationPath '${process.cwd()}' -Force"`,
                  { timeout: 45000, stdio: 'ignore' }
                );
              }
            } else {
              execSync(`unzip -o "${tempZipPath}" -d "${process.cwd()}"`, {
                timeout: 30000,
                stdio: 'ignore',
              });
            }
          } catch (unzipErr) {
            console.error('[OTA] Error al descomprimir actualización:', unzipErr);
          }

          // Restaurar base de datos intacta (conserva clientes, vehículos, órdenes y caja)
          if (dbBackup) {
            fs.writeFileSync(dbPath, dbBackup, 'utf8');
          }

          // Restaurar licencia intacta (garantía de matrimonio de hardware)
          if (licBackup) {
            fs.writeFileSync(licPath, licBackup, 'utf8');
          }

          // Eliminar archivo temporal
          if (fs.existsSync(tempZipPath)) {
            fs.unlinkSync(tempZipPath);
          }

          installSuccess = true;
          console.log(`[OTA] ¡Actualización v${nextVer} descargada e instalada con éxito!`);
        }
      } catch (err) {
        console.error('[OTA] Error durante descarga o instalación:', err);
      }

      // 3. Asentar nueva versión en el manifiesto local
      const updated = recordAppliedVersion(nextVer);

      return NextResponse.json({
        success: true,
        message: `¡Sistema actualizado exitosamente a la versión ${nextVer}! Todos tus vehículos, clientes y fotos siguen 100% seguros.`,
        newVersion: updated?.version || nextVer,
        installed: installSuccess,
      });
    }

    return NextResponse.json(
      { success: false, message: 'Acción no reconocida' },
      { status: 400 }
    );
  } catch (error) {
    console.error('Error en /api/updates POST:', error);
    return NextResponse.json(
      { success: false, message: 'Ocurrió un error al procesar la actualización.' },
      { status: 500 }
    );
  }
}
