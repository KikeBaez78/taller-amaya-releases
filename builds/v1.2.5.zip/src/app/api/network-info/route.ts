import { NextResponse } from 'next/server';
import os from 'os';

export const dynamic = 'force-dynamic';

function getLanInfo(): { lanIp: string; allIps: string[] } {
  const interfaces = os.networkInterfaces();
  const candidates: string[] = [];

  for (const name of Object.keys(interfaces)) {
    const lowerName = name.toLowerCase();
    // Omitir adaptadores virtuales comunes (VirtualBox, WSL, VMware, Docker)
    if (
      lowerName.includes('virtual') ||
      lowerName.includes('vethernet') ||
      lowerName.includes('vmnet') ||
      lowerName.includes('docker') ||
      lowerName.includes('loopback')
    ) {
      continue;
    }

    const ifaceList = interfaces[name];
    if (!ifaceList) continue;

    for (const iface of ifaceList) {
      if (iface.family === 'IPv4' && !iface.internal) {
        if (!candidates.includes(iface.address)) {
          candidates.push(iface.address);
        }
      }
    }
  }

  // Priorizar rango típico de routers Wi-Fi de taller (192.168.X.X o 10.X.X.X)
  const wifiIp = candidates.find(
    (ip) => ip.startsWith('192.168.') || ip.startsWith('10.')
  );

  return {
    lanIp: wifiIp || candidates[0] || '192.168.1.194',
    allIps: candidates.length > 0 ? candidates : ['192.168.1.194'],
  };
}

export async function GET(request: Request) {
  const { lanIp, allIps } = getLanInfo();
  const hostHeader = request.headers.get('host') || '';
  const port = hostHeader.includes(':') ? hostHeader.split(':')[1] : '3000';

  return NextResponse.json({
    lanIp,
    allIps,
    port,
    lanOrigin: `http://${lanIp}:${port}`,
  });
}
