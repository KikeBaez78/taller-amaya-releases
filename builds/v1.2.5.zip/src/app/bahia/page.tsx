'use client';

import React from 'react';
import { BahiaDisplay } from '@/components/BahiaDisplay';

export default function BahiaDisplayPage() {
  return <BahiaDisplay isStandalone={true} />;
}
