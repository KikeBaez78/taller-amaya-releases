import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Taller Amaya — Sistema de Gestión Automotriz, Flotillas & CRM',
  description:
    'Control de vehículos, check-in con fotos obligatorias, bitácora clínica por placas, comisiones de mecánicos, cortes de caja y enlace WhatsApp en Tijuana, B.C.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body className="bg-slate-100 text-slate-800 antialiased min-h-screen selection:bg-rose-600 selection:text-white">
        {children}
      </body>
    </html>
  );
}
