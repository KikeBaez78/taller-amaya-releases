'use client';

import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { StorageService } from '@/lib/storage';
import { WorkOrder, Vehicle, Client, Company } from '@/types';
import {
  Wrench,
  Car,
  Clock,
  CheckCircle2,
  Camera,
  MapPin,
  Phone,
  MessageCircle,
  CreditCard,
  AlertTriangle,
  Building2,
  Calendar,
  Gauge,
  Copy,
  Check,
  Loader2,
  FileSpreadsheet,
  Package,
  Eye,
} from 'lucide-react';
import { ImageLightboxModal } from '@/components/ImageLightboxModal';
import { CreativeArchitectSeal } from '@/components/CreativeArchitectSeal';

export default function SeguimientoPage() {
  const params = useParams();
  const rawFolio = params?.folio as string;
  const cleanFolio = rawFolio ? rawFolio.replace(/^ot-/, '') : '';

  const config = StorageService.getConfig();

  const [order, setOrder] = useState<WorkOrder | null>(null);
  const [vehicle, setVehicle] = useState<Vehicle | null>(null);
  const [client, setClient] = useState<Client | null>(null);
  const [company, setCompany] = useState<Company | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [copiedClabe, setCopiedClabe] = useState(false);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  const fotosEntradaList = React.useMemo(() => {
    if (!order?.fotosEntrada) return [];
    const labels: Record<string, string> = {
      frente: '1. Frente',
      trasera: '2. Trasera',
      lateralIzquierdo: '3. Lateral Izquierdo',
      lateralDerecho: '4. Lateral Derecho',
      motor: '5. Bahía Motor',
      odometro: '6. Tablero / Odómetro',
      interior: '7. Interior / Asientos',
      cajuela: '8. Cajuela / Maletero',
    };
    return Object.entries(order.fotosEntrada)
      .filter(([, url]) => Boolean(url))
      .map(([key, url]) => ({
        url: url as string,
        title: labels[key] || key.charAt(0).toUpperCase() + key.slice(1),
      }));
  }, [order?.fotosEntrada]);

  useEffect(() => {
    if (!cleanFolio) {
      setIsLoading(false);
      return;
    }

    // 1. Intentar cargar de StorageService local si existe
    const localOrders = StorageService.getWorkOrders();
    const foundOrder = localOrders.find(
      (o) => o.folio === cleanFolio || o.id === `ot-${cleanFolio}` || o.id === cleanFolio
    );
    if (foundOrder) {
      setOrder(foundOrder);
      setVehicle(StorageService.getVehicles().find((v) => v.id === foundOrder.vehiculoId) || null);
      setClient(StorageService.getClients().find((c) => c.id === foundOrder.clienteId) || null);
      if (foundOrder.empresaId) {
        setCompany(StorageService.getCompanies().find((co) => co.id === foundOrder.empresaId) || null);
      }
      setIsLoading(false);
    }

    // 2. Consultar siempre la API central para tener los datos más recientes
    fetch(`/api/sync?folio=${cleanFolio}`)
      .then((res) => {
        if (!res.ok) throw new Error('Not found');
        return res.json();
      })
      .then((data) => {
        if (data?.order) {
          setOrder(data.order);
          setVehicle(data.vehicle || null);
          setClient(data.client || null);
          setCompany(data.company || null);
        }
      })
      .catch((err) => {
        console.log('API sync fallback to local/mock', err);
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, [cleanFolio]);

  const handleCopyClabe = () => {
    navigator.clipboard.writeText(config.clabe);
    setCopiedClabe(true);
    setTimeout(() => setCopiedClabe(false), 2000);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col items-center justify-center p-6 text-center">
        <Loader2 className="w-10 h-10 text-rose-600 animate-spin mb-4" />
        <h2 className="text-base font-bold text-slate-900">Cargando expediente de Taller Amaya...</h2>
        <span className="text-xs text-slate-500 mt-1">Folio #{cleanFolio}</span>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col items-center justify-center p-6 text-center">
        <div className="w-20 h-20 rounded-3xl bg-white p-2 border border-slate-200 mb-4 shadow-md flex items-center justify-center">
          <img src="/logo-taller-amaya.png" alt="Taller Amaya" className="w-full h-full object-contain" />
        </div>
        <h1 className="text-xl font-black mb-2 text-slate-900">Orden no encontrada</h1>
        <p className="text-sm text-slate-500 max-w-sm mb-6">
          No localizamos una orden activa con el folio <strong>#{cleanFolio}</strong>. Por favor verifica el número o comunícate con recepción.
        </p>
        <a
          href={`https://wa.me/52${config.whatsapp}?text=Hola%2C%20tengo%20duda%20con%20el%20folio%20%23${cleanFolio}`}
          className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 font-bold text-sm text-white flex items-center gap-2 shadow-md"
        >
          <MessageCircle className="w-4 h-4" />
          <span>Consultar por WhatsApp ({config.whatsapp})</span>
        </a>
      </div>
    );
  }

  const steps = [
    { key: 'recepcion', label: '1. Recepción', done: true },
    { key: 'diagnostico', label: '2. Diagnóstico & Presupuesto', done: order.estado !== 'recepcion' },
    { key: 'en_proceso', label: '3. En Bahía (Reparación)', done: order.estado === 'en_proceso' || order.estado === 'listo' || order.estado === 'entregado' },
    { key: 'listo', label: '4. Listo para Entrega', done: order.estado === 'listo' || order.estado === 'entregado' },
    { key: 'entregado', label: '5. Entregado al Cliente', done: order.estado === 'entregado' },
  ];

  const pEstado = order.presupuesto?.estado || 'pendiente';

  const whatsAppAuthorizeText = encodeURIComponent(
    `Hola Taller Amaya, soy el cliente de la orden *#${order.folio}* (Vehículo: *${vehicle?.marca} ${vehicle?.modelo}* - Placas: *${vehicle?.placas}*) y *AUTORIZO* el presupuesto de *$${order.subtotalGeneral.toLocaleString()} MXN* para proceder con los trabajos.`
  );

  const whatsAppDoubtText = encodeURIComponent(
    `Hola Taller Amaya, tengo una duda sobre el estatus de mi vehículo en la orden *#${order.folio}* (Placas: *${vehicle?.placas}*).`
  );

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 font-sans selection:bg-rose-600 selection:text-white pb-12">
      {/* Cabecera Móvil Oficial */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm">
        <div className="max-w-xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white p-1 shadow-sm border border-slate-200 flex items-center justify-center">
              <img
                src="/logo-taller-amaya.png"
                alt="Taller Amaya"
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <h1 className="font-black text-sm tracking-wide text-slate-900 leading-tight">
                TALLER AMAYA
              </h1>
              <span className="text-[10px] text-rose-600 font-extrabold uppercase tracking-widest block">
                SEGUIMIENTO EN LÍNEA
              </span>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-slate-400 block uppercase font-bold">Folio:</span>
            <span className="font-mono font-black text-sm text-slate-900 bg-rose-50 border border-rose-200 px-2.5 py-0.5 rounded-lg">
              #{order.folio}
            </span>
          </div>
        </div>
      </header>

      {/* Contenido Central */}
      <main className="max-w-xl mx-auto px-4 pt-5 space-y-4">
        {/* Tarjeta del Vehículo */}
        <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <span className="font-mono font-black text-sm bg-slate-100 text-slate-800 px-2.5 py-1 rounded-xl border border-slate-200">
                {vehicle?.placas || 'SIN PLACAS'}
              </span>
              <h2 className="text-base font-black text-slate-900">
                {vehicle?.marca} {vehicle?.modelo} ({vehicle?.ano})
              </h2>
            </div>
            <span className="text-xs text-slate-500 font-mono">
              Color: {vehicle?.color || 'N/A'}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Odómetro al entrar:</span>
              <strong className="text-slate-800 text-sm font-mono">
                {order.kilometrajeEntrada.toLocaleString()} km
              </strong>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Nivel Combustible:</span>
              <strong className="text-slate-800 text-sm">
                Tanque a {order.nivelCombustible}
              </strong>
            </div>
            <div className="col-span-2 pt-1 border-t border-slate-100">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Propietario / Flotilla:</span>
              <strong className="text-slate-900 text-sm">
                {company ? company.razonSocial : client?.nombre || 'Particular'}
              </strong>
              {order.choferNombre && (
                <span className="text-[11px] text-slate-500 block">
                  Chofer que entregó: {order.choferNombre}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Estatus en Línea de Tiempo */}
        <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm space-y-3">
          <h2 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-rose-600" />
            <span>Progreso del Vehículo en Bahía:</span>
          </h2>

          <div className="space-y-3 pt-1">
            {steps.map((st, idx) => (
              <div key={st.key} className="flex items-center gap-3">
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs shrink-0 ${
                    st.done
                      ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                      : 'bg-slate-100 text-slate-400 border border-slate-200'
                  }`}
                >
                  {st.done ? '✓' : idx + 1}
                </div>
                <div className="flex-1">
                  <span
                    className={`text-xs block font-bold ${
                      st.done ? 'text-slate-900' : 'text-slate-400'
                    }`}
                  >
                    {st.label}
                  </span>
                  {order.estado === st.key && (
                    <span className="text-[10px] text-rose-600 font-extrabold uppercase animate-pulse">
                      ● Estado actual
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Falla Reportada */}
        <div className="bg-white border border-slate-200 rounded-3xl p-5 text-xs shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Motivo de Ingreso / Diagnóstico Reportado:
          </span>
          <p className="text-slate-700 font-medium whitespace-pre-wrap">
            {order.fallaReportada}
          </p>
        </div>

        {/* Refacciones traídas por el cliente */}
        {order.refaccionesCliente && order.refaccionesCliente.length > 0 && (
          <div className="bg-amber-50 border border-amber-200 p-4 rounded-3xl text-xs shadow-sm">
            <strong className="text-amber-800 uppercase text-[10px] font-bold block mb-1">
              ✓ Refacciones registradas al ingresar:
            </strong>
            <ul className="list-disc list-inside text-amber-900 space-y-0.5 font-medium">
              {order.refaccionesCliente.map((ref, i) => (
                <li key={i}>{ref}</li>
              ))}
            </ul>
          </div>
        )}

        {/* ============================================================== */}
        {/* SECCIÓN DE PRESUPUESTO & AUTORIZACIÓN (PARTES + MANO DE OBRA) */}
        {/* ============================================================== */}
        <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-rose-600" />
              <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Presupuesto Detallado
              </h2>
            </div>

            <span
              className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase border ${
                pEstado === 'autorizado'
                  ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                  : pEstado === 'rechazado'
                  ? 'bg-rose-100 text-rose-800 border-rose-300'
                  : 'bg-amber-100 text-amber-800 border-amber-300 animate-pulse'
              }`}
            >
              {pEstado === 'autorizado'
                ? '✓ Presupuesto Autorizado'
                : pEstado === 'rechazado'
                ? '✕ Presupuesto Rechazado'
                : '⏳ Pendiente de tu Autorización'}
            </span>
          </div>

          {/* Mano de Obra */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
              <Wrench className="w-3.5 h-3.5 text-rose-600" />
              <span>Mano de Obra y Servicios:</span>
            </span>

            {order.servicios.map((srv) => (
              <div
                key={srv.id}
                className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
              >
                <span className="font-medium text-slate-800">{srv.concepto}</span>
                <span className="font-mono font-bold text-slate-900">
                  ${srv.manoObra.toLocaleString()} MXN
                </span>
              </div>
            ))}
          </div>

          {/* Partes y Refacciones si existen en el presupuesto */}
          {order.presupuesto?.partes && order.presupuesto.partes.length > 0 && (
            <div className="space-y-1.5 pt-2 border-t border-slate-100">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                <Package className="w-3.5 h-3.5 text-emerald-600" />
                <span>Refacciones y Partes:</span>
              </span>

              {order.presupuesto.partes.map((p) => (
                <div
                  key={p.id}
                  className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                >
                  <div>
                    <span className="font-medium text-slate-800 block">
                      {p.cantidad}x {p.descripcion}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {p.origen === 'cliente' ? 'Suministrada por cliente ($0)' : 'Surtida por Taller Amaya'}
                    </span>
                  </div>
                  <span className="font-mono font-bold text-slate-900">
                    {p.origen === 'cliente' ? '$0' : `$${p.subtotal.toLocaleString()} MXN`}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* Desglose de Totales */}
          <div className="pt-3 border-t border-slate-100 space-y-1 text-xs font-mono">
            <div className="flex justify-between text-slate-500">
              <span>Mano de Obra:</span>
              <span>${order.subtotalManoObra.toLocaleString()} MXN</span>
            </div>
            <div className="flex justify-between text-slate-500">
              <span>Refacciones y Partes:</span>
              <span>${order.subtotalRefacciones.toLocaleString()} MXN</span>
            </div>
            {order.presupuesto?.aplicaIva && (
              <div className="flex justify-between text-slate-500">
                <span>IVA 8% Frontera:</span>
                <span>${order.presupuesto.ivaMonto.toLocaleString()} MXN</span>
              </div>
            )}
            <div className="flex justify-between text-slate-800 font-bold pt-1 border-t border-slate-100">
              <span>Total Estimado:</span>
              <span>${order.subtotalGeneral.toLocaleString()} MXN</span>
            </div>
            <div className="flex justify-between text-emerald-600 font-semibold">
              <span>Anticipos Abonados:</span>
              <span>${order.totalPagado.toLocaleString()} MXN</span>
            </div>
            <div className="flex justify-between text-base font-black text-slate-900 pt-2 border-t border-slate-200">
              <span>Saldo Pendiente:</span>
              <span className={order.saldoPendiente > 0 ? 'text-rose-600' : 'text-emerald-600'}>
                ${order.saldoPendiente.toLocaleString()} MXN
              </span>
            </div>
          </div>

          {/* Botón de Autorización del Cliente por WhatsApp */}
          {pEstado === 'pendiente' && (
            <div className="pt-2">
              <a
                href={`https://wa.me/52${config.whatsapp}?text=${whatsAppAuthorizeText}`}
                className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 transition-all text-center"
              >
                <Check className="w-4 h-4" />
                <span>Autorizar este Presupuesto por WhatsApp</span>
              </a>
              <span className="text-[10px] text-slate-400 text-center block mt-1">
                Al hacer clic se enviará un mensaje confirmando tu autorización a Taller Amaya
              </span>
            </div>
          )}
        </div>

        {/* Galería Oficial de las 8 Fotos de Inspección */}
        {fotosEntradaList.length > 0 && (
          <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-rose-600" />
                <span>Fotos de Inspección ({fotosEntradaList.length} Ángulos):</span>
              </h2>
              <span className="text-[10px] text-rose-600 font-bold bg-rose-50 px-2 py-0.5 rounded-full border border-rose-100">
                Toca para ampliar
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {fotosEntradaList.map((photo, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    setLightboxIndex(idx);
                    setLightboxOpen(true);
                  }}
                  className="rounded-2xl overflow-hidden border border-slate-200 bg-slate-100 aspect-video relative group cursor-pointer shadow-sm active:scale-95 transition-all"
                  title="Toca para ver en pantalla completa"
                >
                  <img
                    src={photo.url}
                    alt={photo.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                  <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <span className="p-1 bg-white/95 text-slate-900 rounded-lg text-[10px] font-bold flex items-center gap-1 shadow">
                      <Eye className="w-3.5 h-3.5 text-rose-600" />
                      <span>Ver Grande</span>
                    </span>
                  </div>
                  <span className="absolute bottom-0 inset-x-0 bg-slate-900/80 text-[10px] text-center text-white font-semibold py-0.5 truncate px-1">
                    {photo.title}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Cuentas BBVA para pagar por transferencia */}
        <div className="bg-white border border-slate-200 rounded-3xl p-5 space-y-2 text-xs shadow-sm">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-800 flex items-center gap-1.5">
              <CreditCard className="w-4 h-4 text-blue-600" />
              <span>Datos Bancarios BBVA para Transferencia:</span>
            </span>
          </div>

          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-1 font-mono text-[11px] text-slate-700">
            <div>Banco: <strong>{config.banco}</strong></div>
            <div>Beneficiario: <strong>{config.razonSocial}</strong></div>
            <div>Cuenta: <strong>{config.cuenta}</strong></div>
            <div className="flex items-center justify-between pt-1">
              <div>CLABE: <strong className="text-blue-700">{config.clabe}</strong></div>
              <button
                onClick={handleCopyClabe}
                className="px-2 py-0.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-100 text-[10px] text-slate-700 flex items-center gap-1 shadow-sm font-semibold"
              >
                {copiedClabe ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                <span>{copiedClabe ? 'Copiado' : 'Copiar'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Contacto Directo por WhatsApp */}
        <div className="text-center pt-2">
          <a
            href={`https://wa.me/52${config.whatsapp}?text=${whatsAppDoubtText}`}
            className="inline-flex items-center gap-2 text-xs font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-50 border border-emerald-200 px-4 py-2.5 rounded-2xl shadow-sm"
          >
            <MessageCircle className="w-4 h-4" />
            <span>¿Tienes alguna duda? Escríbenos por WhatsApp</span>
          </a>
        </div>
      </main>

      {/* Footer */}
      <footer className="max-w-xl mx-auto px-4 mt-8 pt-4 pb-12 border-t border-slate-200 text-center text-[10px] text-slate-400 space-y-3 flex flex-col items-center">
        <div>
          <div>{config.nombreComercial} — {config.razonSocial}</div>
          <div>{config.direccion} | Tijuana, B.C.</div>
        </div>
        <div className="self-end pt-1">
          <CreativeArchitectSeal />
        </div>
      </footer>

      {/* Modal Lightbox para ver fotos en grande en el celular */}
      <ImageLightboxModal
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        photos={fotosEntradaList}
        initialIndex={lightboxIndex}
      />
    </div>
  );
}
