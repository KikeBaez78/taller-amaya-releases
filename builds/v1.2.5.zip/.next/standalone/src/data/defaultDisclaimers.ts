export interface DisclaimerClause {
  id: string;
  numero: number;
  titulo?: string;
  contenido: string;
  esSeccionEspecial?: boolean;
}

export const DEFAULT_DISCLAIMERS: DisclaimerClause[] = [
  {
    id: 'clausula-1',
    numero: 1,
    contenido: 'Taller Amaya no se hace responsable de objetos personales olvidados en el vehículo.',
  },
  {
    id: 'clausula-2',
    numero: 2,
    contenido:
      'Taller Amaya no se hace responsable por vehículos que el cliente decida dejar fuera del taller, incluyendo daños por vidrios quebrados, violación de chapas, rayones, robo parcial o total del vehículo o cualquier otro.',
  },
  {
    id: 'clausula-3',
    numero: 3,
    contenido:
      'Para poder ingresar un automóvil a servicio, se requiere obligatoriamente la entrega de un anticipo fijado por Taller Amaya.',
  },
  {
    id: 'clausula-4',
    numero: 4,
    contenido:
      'El cliente expresa ser dueño del vehículo o tener autorización para solicitar la reparación o mantenimiento del vehículo, por lo que acepta las condiciones del servicio.',
  },
  {
    id: 'clausula-5',
    numero: 5,
    contenido:
      'El precio total del servicio realizado en su vehículo deberá ser cubierto en las instalaciones de Taller Amaya antes de retirar el automóvil del lugar, incluyendo el costo total por cualquier refacción que pudiera aplicar.',
  },
  {
    id: 'clausula-6',
    numero: 6,
    contenido:
      'La garantía del servicio queda pactada dependiendo del tipo de reparación o mantenimiento realizada y será estipulada por Taller Amaya.',
  },
  {
    id: 'clausula-7',
    numero: 7,
    contenido:
      'Durante el tiempo de almacenamiento del automóvil, Taller Amaya no se hace responsable de objetos olvidados, rayones, chapas forzadas, vidrios quebrados, ni del robo parcial o total del vehículo.',
  },
  {
    id: 'clausula-8',
    numero: 8,
    contenido:
      'Al firmar el cliente la hoja de servicio está autorizando a Taller Amaya a probar los vehículos en vía pública antes de entregarse y/o para detección de fallas, por lo que Taller Amaya no se hace responsable ante el contenido del vehículo y/o alguna situación legal (fiscal) que involucre el remolque o retención de la unidad, ejercida por alguna autoridad fiscal (Retenes del SAT, policía federal, estatal, municipal, tránsito, etc.).',
  },
  {
    id: 'clausula-9',
    numero: 9,
    contenido:
      'Otros puntos importantes en beneficio de Taller Amaya para la elaboración en la hoja de servicio.',
  },
  {
    id: 'clausula-10',
    numero: 10,
    contenido:
      'Vehículos fuera del taller (en la calle) solo podrán durar 2 días máximo o de lo contrario serán remolcadas por la autoridad.',
  },
  {
    id: 'clausula-11',
    numero: 11,
    contenido:
      'No nos hacemos responsables de tapicerías tostadas, quebradas y dañadas en el proceso de trabajo.',
  },
  {
    id: 'clausula-12',
    numero: 12,
    contenido:
      'Los vehículos que estén acumulados después de dos meses sin respuesta por parte del cliente serán sacados a la calle y remolcados por la grúa al corralón municipal.',
  },
  {
    id: 'clausula-13',
    numero: 13,
    contenido:
      'No nos hacemos responsables por problemas ocasionados electrónicamente por baterías en mal estado.',
  },
  {
    id: 'clausula-14',
    numero: 14,
    contenido:
      'El taller no se hace responsable por accesorios de carrocería que sea necesario desmontar para la reparación del vehículo (mal estado).',
  },
  {
    id: 'clausula-15',
    numero: 15,
    titulo: 'GARANTÍA PRENDARIA',
    esSeccionEspecial: true,
    contenido:
      'El CLIENTE constituye expresamente a favor de TALLER AMAYA, como garantía del pago de los trabajos de reparación, mantenimiento, refacciones, materiales, servicios adicionales autorizados, así como los gastos de conservación, custodia y resguardo que en su caso se generen, garantía prendaria sobre el vehículo descrito en la presente Orden de Servicio, manifestando bajo protesta de decir verdad que es legítimo propietario del mismo o que cuenta con facultades suficientes para constituir dicha garantía.\nEl CLIENTE reconoce que la presente garantía se constituye por escrito y acepta que el vehículo permanecerá bajo resguardo del TALLER mientras exista saldo pendiente derivado de los servicios contratados, en los términos permitidos por la legislación aplicable. El Código Civil de Baja California exige que el contrato de prenda conste por escrito y establece obligaciones específicas para el acreedor respecto de la conservación e identificación del bien.',
  },
  {
    id: 'clausula-16',
    numero: 16,
    titulo: 'VEHÍCULO TERMINADO Y PLAZO PARA RECOGERLO',
    esSeccionEspecial: true,
    contenido:
      'Una vez terminados los trabajos, TALLER AMAYA notificará al CLIENTE mediante llamada telefónica, mensaje de texto, WhatsApp o cualquier otro medio de contacto proporcionado en esta Orden de Servicio.\nA partir de la fecha y hora en que se efectúe dicha notificación, el CLIENTE contará con un plazo máximo de 24 (veinticuatro) horas para recoger el vehículo y liquidar la totalidad del saldo pendiente.\nTranscurridas las 24 horas sin que el CLIENTE haya recogido el vehículo y liquidado el saldo, comenzará a generarse un cargo por concepto de resguardo, almacenamiento y custodia por día o fracción. Dicho cargo se acumulará al saldo pendiente hasta que el vehículo sea retirado o se celebre un convenio por escrito entre las partes.',
  },
  {
    id: 'clausula-17',
    numero: 17,
    titulo: 'INCUMPLIMIENTO Y EJECUCIÓN DE LA GARANTÍA',
    esSeccionEspecial: true,
    contenido:
      'Si el CLIENTE incumple con el pago de la deuda en el plazo acordado, y después de haber sido requerido para realizar el pago, TALLER AMAYA podrá hacer valer la garantía prendaria y ejercer las acciones legales correspondientes para obtener el pago de la deuda.\nLas partes acuerdan expresamente que, cuando legalmente resulte procedente, podrá realizarse la venta extrajudicial de la prenda, conforme al convenio celebrado y a las disposiciones aplicables del Código Civil para el Estado de Baja California. El artículo 2751 contempla expresamente la posibilidad de pactar la venta extrajudicial de la prenda.',
  },
  {
    id: 'clausula-18',
    numero: 18,
    titulo: 'DISPOSICIÓN DEL VEHÍCULO Y APLICACIÓN DEL PRODUCTO DE LA VENTA',
    esSeccionEspecial: true,
    contenido:
      'En caso de llevarse a cabo legalmente la venta del vehículo dado en garantía, el importe obtenido será aplicado al pago de:\na. El saldo pendiente de la reparación y servicios autorizados;\nb. Refacciones y materiales;\nc. Gastos de conservación, custodia y resguardo debidamente generados; y\nd. Los demás gastos legalmente procedentes relacionados con la ejecución de la garantía.\nSi el importe obtenido de la venta excede el monto total de la deuda y gastos legalmente procedentes, el excedente corresponderá al CLIENTE, conforme a la legislación aplicable. El Código Civil de Baja California establece expresamente que, si el producto de la venta excede la deuda, el excedente debe entregarse al deudor.',
  },
  {
    id: 'clausula-19',
    numero: 19,
    titulo: 'NO TRANSMISIÓN AUTOMÁTICA DE PROPIEDAD',
    esSeccionEspecial: true,
    contenido:
      'El CLIENTE reconoce y acepta que el transcurso de las 24 horas señaladas en esta Orden de Servicio, así como la permanencia del vehículo dentro de las instalaciones de TALLER AMAYA, no constituye por sí misma una transmisión automática de la propiedad del vehículo.\nLa presente cláusula constituye una garantía respecto de las obligaciones de pago contraídas por el CLIENTE. Cualquier adjudicación, venta o disposición del vehículo deberá realizarse conforme al procedimiento y requisitos establecidos por la legislación aplicable.\nAsimismo, el CLIENTE reconoce que el TALLER deberá conservar el vehículo con la diligencia correspondiente mientras éste se encuentre bajo su resguardo. El Código Civil de Baja California establece obligaciones específicas del acreedor prendario de conservar la cosa empeñada y restituirla una vez pagadas íntegramente las cantidades correspondientes.',
  },
];
