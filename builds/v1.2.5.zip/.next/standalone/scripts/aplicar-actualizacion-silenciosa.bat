@echo off
title ACTUALIZADOR SILENCIOSO TALLER AMAYA
cd /d "%~dp0\.."

:: Esperar 2 segundos para permitir que la respuesta HTTP termine de enviarse al navegador
timeout /t 2 /nobreak >nul 2>&1

:: Cerrar procesos previos de Node para liberar el bloqueo de archivos en Windows
taskkill /F /IM node.exe >nul 2>&1
timeout /t 1 /nobreak >nul 2>&1

:: Respaldar datos y licencia si existen
if not exist "src\data\backups" mkdir "src\data\backups"
if exist "src\data\db.json" (
    copy /y "src\data\db.json" "src\data\backups\respaldo_pre_ota.json" >nul 2>&1
)

:: Extraer el paquete de actualización descargado (temp_ota_update.zip)
if exist "temp_ota_update.zip" (
    tar -xf "temp_ota_update.zip" -C "%~dp0\.." >nul 2>&1
    if errorlevel 1 (
        powershell -NoProfile -Command "Expand-Archive -Path '%~dp0\..\temp_ota_update.zip' -DestinationPath '%~dp0\..' -Force" >nul 2>&1
    )
    del /f /q "temp_ota_update.zip" >nul 2>&1
)

:: Limpiar cache de Next.js
if exist ".next\cache" rd /s /q ".next\cache" >nul 2>&1

:: Re-iniciar el sistema automáticamente en segundo plano
start wscript "%~dp0\iniciar-taller-silencioso.vbs"

exit
