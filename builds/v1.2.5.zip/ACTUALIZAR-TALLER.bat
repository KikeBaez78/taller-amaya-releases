@echo off
title ACTUALIZAR TALLER AMAYA
color 0A

cd /d "%~dp0"

echo ========================================================
echo       APLICANDO ACTUALIZACION v1.2.5 - TALLER AMAYA
echo ========================================================
echo.

echo [1/5] Cerrando procesos previos de Taller Amaya...
taskkill /F /IM node.exe >nul 2>&1
timeout /t 1 >nul

echo [2/5] Buscando archivo de actualizacion descargado...
set "ZIP_FOUND="
if exist "temp_ota_update.zip" set "ZIP_FOUND=temp_ota_update.zip"
if exist "actualizacion-v1.2.5.zip" set "ZIP_FOUND=actualizacion-v1.2.5.zip"
if exist "..\actualizacion-v1.2.5.zip" set "ZIP_FOUND=..\actualizacion-v1.2.5.zip"
if exist "%USERPROFILE%\Desktop\actualizacion-v1.2.5.zip" set "ZIP_FOUND=%USERPROFILE%\Desktop\actualizacion-v1.2.5.zip"
if exist "%USERPROFILE%\Downloads\actualizacion-v1.2.5.zip" set "ZIP_FOUND=%USERPROFILE%\Downloads\actualizacion-v1.2.5.zip"
if exist "%USERPROFILE%\Downloads\v1.2.5.zip" set "ZIP_FOUND=%USERPROFILE%\Downloads\v1.2.5.zip"

if defined ZIP_FOUND (
    echo [INFO] Encontrado paquete: %ZIP_FOUND%
    echo [INFO] Extrayendo actualizacion limpia sin tocar clientes ni licencias...
    tar -xf "%ZIP_FOUND%" -C "%~dp0" >nul 2>&1
    if errorlevel 1 (
        powershell -NoProfile -Command "Expand-Archive -Path '%ZIP_FOUND%' -DestinationPath '%~dp0' -Force"
    )
    echo [OK] Archivos extraidos con exito.
    if exist "temp_ota_update.zip" del /f /q "temp_ota_update.zip" >nul 2>&1
) else (
    echo [INFO] No se encontro zip externo, aplicando archivos locales...
)

echo.
echo [3/5] Limpiando cache del servidor...
if exist ".next\cache" rd /s /q ".next\cache" >nul 2>&1

echo.
echo [4/5] Verificando proteccion de base de datos...
if not exist "src\data\backups" mkdir "src\data\backups"
if exist "src\data\db.json" (
    copy /y "src\data\db.json" "src\data\backups\respaldo_previo_actualizacion.json" >nul 2>&1
    echo [OK] Base de datos de clientes, vehiculos y ordenes: RESPALDADA E INTACTA.
)
if exist "src\data\license.json" (
    echo [OK] Licencia oficial casada con este equipo: INTACTA.
)

:: Habilitar puerto 3000 en Windows Firewall para Tablet y Celular
netsh advfirewall firewall add rule name="Taller Amaya Puerto 3000" dir=in action=allow protocol=TCP localport=3000 >nul 2>&1

echo.
echo [5/5] Iniciando Taller Amaya v1.2.5 con motor renovado...
start wscript scripts\iniciar-taller-silencioso.vbs

echo.
echo ========================================================
echo  [EXITO] Sistema actualizado y reiniciado en v1.2.5.
echo  - PIN Administrativo de Reyna Amaya: 2036
echo  - Pantalla de Bahia: Sin comisiones a la vista y con candado PIN
echo  - Cotizador Rapido: Selector Cotizador vs Remision Oficial lista
echo  - Conexion Bahia: Respuestas ultra-rapidas desde memoria RAM
echo ========================================================
timeout /t 4 >nul
exit
