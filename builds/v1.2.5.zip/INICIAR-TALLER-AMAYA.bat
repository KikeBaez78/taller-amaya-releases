@echo off
title TALLER AMAYA - SISTEMA AUTOMOTRIZ
color 0A

cd /d "%~dp0"

echo ========================================================
echo          INICIANDO TALLER AMAYA (MODO OFICIAL)
echo ========================================================
echo.

if exist "runtime\node.exe" (
    echo [OK] Motor autonomo listo (Cero dependencias).
    start wscript scripts\iniciar-taller-silencioso.vbs
    timeout /t 2 >nul
    exit
)

if exist ".next\standalone\server.js" (
    echo [OK] Servidor compilado listo.
    start wscript scripts\iniciar-taller-silencioso.vbs
    timeout /t 2 >nul
    exit
)

echo [ERROR] No se encontraron los archivos del motor autonomo en esta carpeta.
echo Por favor asegurate de haber descomprimido el archivo taller-amaya.zip completo.
echo.
pause
exit
