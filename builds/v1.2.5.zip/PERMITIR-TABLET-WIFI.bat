@echo off
title PERMITIR TABLET Y CELULAR POR WI-FI - TALLER AMAYA
color 0B
cd /d "%~dp0"

echo ========================================================
echo   CONFIGURANDO FIREWALL DE WINDOWS PARA TABLET / WI-FI
echo ========================================================
echo.

echo Habilitando comunicacion entrante en el puerto 3000...
netsh advfirewall firewall delete rule name="Taller Amaya Puerto 3000" >nul 2>&1
netsh advfirewall firewall add rule name="Taller Amaya Puerto 3000" dir=in action=allow protocol=TCP localport=3000 >nul 2>&1

echo.
echo ========================================================
echo  [EXITO] Puerto 3000 autorizado en la red local.
echo  La Tablet y Celulares ahora pueden abrir la Bahia
echo  y la Recepcion sin bloqueos del Firewall de Windows.
echo ========================================================
echo.
pause
exit
