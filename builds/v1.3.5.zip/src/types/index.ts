export type ContactType = 'persona' | 'empresa';

export interface Company {
  id: string;
  razonSocial: string;
  rfc: string;
  encargadoFlotilla: string;
  direccion: string;
  telefonos: string[];
  correos: string[];
  diasCredito?: number;
  notas?: string;
  creadoEn: string;
  updatedAt?: string;
}

export interface Client {
  id: string;
  tipo: ContactType;
  nombre: string;
  telefono: string;
  whatsapp?: string;
  correo?: string;
  direccion?: string; // Dirección simple del cliente
  empresaId?: string; // Si pertenece a una empresa de flotilla
  creadoEn: string;
  updatedAt?: string;
}

export interface Vehicle {
  id: string;
  clienteId: string;
  empresaId?: string;
  numeroEconomico?: string; // No. Económico o de Unidad en flotillas (ej. Eco-04)
  placas: string;
  marca: string;
  modelo: string;
  ano: number;
  color: string;
  motor?: string; // Tipo o número de motor (ej. 2.5L, 4 Cil, etc.)
  vin?: string;   // Número de serie / VIN
  choferHabitual?: string;
  choferTelefono?: string;
  kilometrajeActual: number;
  ultimoServicioFecha?: string;
  ultimoServicioKm?: number;
  proximoServicioFecha?: string; // Regla de 2 meses
  proximoServicioKm?: number;   // Regla de 10,000 km
  notas?: string;
  updatedAt?: string;
}

export type FuelLevel = 'Vacio' | '1/4' | '1/2' | '3/4' | 'Lleno';

export interface DamagePoint {
  id: string;
  x: number; // Porcentaje en ancho de carrocería (0-100)
  y: number; // Porcentaje en alto (0-100)
  tipo: 'golpe' | 'rayon' | 'abolladura' | 'quebrado';
  detalle: string;
}

export interface ServiceItem {
  id: string;
  concepto: string;
  mecanicoId: string;
  mecanicoNombre: string;
  manoObra: number;
  refaccionesMonto: number;
  comisionPorcentaje: number; // Entre 10% y 45%
  comisionManoObra: number; // manoObra * (comisionPorcentaje / 100)
  estado: 'pendiente' | 'en_progreso' | 'terminado';
}

export type PresupuestoStatus = 'pendiente' | 'autorizado' | 'rechazado';

export interface PresupuestoItemParte {
  id: string;
  descripcion: string;
  cantidad: number;
  precioUnitario: number;
  subtotal: number;
  origen: 'taller' | 'cliente';
}

export interface PresupuestoManoObra {
  id: string;
  concepto: string;
  mecanicoId?: string;
  mecanicoNombre?: string;
  costo: number;
  comisionPorcentaje: number;
}

export interface Presupuesto {
  partes: PresupuestoItemParte[];
  manoObra: PresupuestoManoObra[];
  subtotalPartes: number;
  subtotalManoObra: number;
  aplicaIva: boolean;
  ivaMonto: number;
  totalPresupuesto: number;
  estado: PresupuestoStatus;
  fechaAutorizacion?: string;
  medioAutorizacion?: 'verbal' | 'whatsapp' | 'firma';
  notasAutorizacion?: string;
}

export type PaymentMethod = 'efectivo' | 'tarjeta' | 'transferencia';

export interface PaymentRecord {
  id: string;
  fecha: string;
  metodo: PaymentMethod;
  monto: number;
  aplicaIva8: boolean;
  montoIva: number;
  montoTotalConIva: number;
  referencia?: string;
}

export type OrderStatus =
  | 'recepcion'
  | 'diagnostico'
  | 'aprobada'
  | 'en_proceso'
  | 'listo'
  | 'entregado'
  | 'cancelado';

export interface MandatoryPhotos {
  frente?: string;
  trasera?: string;
  lateralIzquierdo?: string;
  lateralDerecho?: string;
  motor?: string;
  odometro?: string;
  interior?: string;
  cajuela?: string;
}

export interface SolicitudBahia {
  id: string;
  fecha: string;
  mecanicoId: string;
  mecanicoNombre: string;
  descripcion: string;
  tipo: 'refaccion' | 'mano_obra_extra' | 'ambos';
  estado: 'pendiente_admin' | 'autorizado_cliente' | 'rechazado_cliente';
  costoManoObraExtra?: number;
  notasAdmin?: string;
}

export interface WorkOrder {
  id: string;
  folio: string; // Modificable, iniciado en 0900
  esModificable: boolean;
  vehiculoId: string;
  clienteId: string;
  empresaId?: string;
  
  // Datos del Chofer que entrega (si es flotilla o tercero)
  choferNombre?: string;
  choferTelefono?: string;

  fechaIngreso: string;
  fechaPromesa?: string;
  fechaSalida?: string;
  estado: OrderStatus;
  fallaReportada: string;

  // Inspección y Check-in
  nivelCombustible: FuelLevel;
  kilometrajeEntrada: number;
  refaccionesCliente: string[]; // Refacciones que trae consigo el cliente
  fotosEntrada: MandatoryPhotos;
  videoEntrada?: string | null;
  danosPrevios: DamagePoint[];

  // Servicios, Refacciones y Comisiones
  servicios: ServiceItem[];
  subtotalManoObra: number;
  subtotalRefacciones: number;
  subtotalGeneral: number;
  totalComisionesMecanicos: number;

  // Solicitudes enviadas por el mecánico a Administración
  solicitudesBahia?: SolicitudBahia[];

  // Presupuesto detallado (Partes + Mano de Obra para autorización)
  presupuesto?: Presupuesto;

  // Pagos y Facturación (8% IVA en frontera para tarjeta/transferencia)
  metodoPago?: PaymentMethod;
  pagos: PaymentRecord[];
  totalPagado: number;
  saldoPendiente: number;

  // Salida y Check-out
  fotosSalida?: string[];
  firmaCliente?: string | null;
  notasSalida?: string;
  entregadoPor?: string;

  // Registro de Auditoría de Modificaciones
  historialModificaciones?: HistorialModificacion[];
  updatedAt?: string;
}

export interface HistorialModificacion {
  id: string;
  fecha: string;
  usuario: string;
  motivo?: string;
  cambios: string[];
}

export interface Mechanic {
  id: string;
  nombre: string;
  especialidad: string;
  telefono: string;
  comisionDefault: number; // Porcentaje default (ej. 30%)
  activo: boolean;
  updatedAt?: string;
}

export interface CashExpense {
  id: string;
  fecha: string;
  descripcion: string;
  monto: number;
  categoria: 'solventes' | 'tornilleria' | 'alimentos' | 'herramienta' | 'otro';
  autorizadoPor: string;
}

export interface CashRegisterShift {
  id: string;
  fechaApertura: string;
  fechaCierre?: string;
  fondoInicial: number; // $500 - $1,000 MXN
  ingresosEfectivo: number;
  ingresosTarjeta: number;
  ingresosTransferencia: number;
  gastosMenores: CashExpense[];
  totalGastosMenores: number;
  efectivoEsperado: number; // fondoInicial + ingresosEfectivo - totalGastosMenores
  efectivoRealContado?: number;
  diferencia?: number;
  estado: 'abierta' | 'cerrada';
  cajero: string;
  observaciones?: string;
}

export interface TallerConfig {
  razonSocial: string;
  nombreComercial: string;
  rfc: string;
  direccion: string;
  telefonoLocal: string;
  whatsapp: string;
  correo: string;
  banco: string;
  cuenta: string;
  clabe: string;
  ivaFronteraPorcentaje: number; // 8%
  folioInicial: number; // 0900
  adminPin?: string; // PIN maestro de Reyna Amaya para editar y eliminar
}
