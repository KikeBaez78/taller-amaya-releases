'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { WorkOrder, Vehicle, Client, Company, Mechanic, OrderStatus } from '@/types';
import { StorageService } from '@/lib/storage';
import { INITIAL_MECHANICS } from '@/data/tallerConfig';
import {
  Wrench,
  Clock,
  CheckCircle2,
  AlertCircle,
  Bell,
  BellOff,
  Maximize2,
  Minimize2,
  RefreshCw,
  ArrowLeft,
  Package,
  Car,
  AlertTriangle,
  Play,
  Check,
  Plus,
  X,
  Volume2,
  ExternalLink,
  Smartphone,
  Lock,
} from 'lucide-react';

interface BahiaDisplayProps {
  isStandalone?: boolean;
  onOpenMobileQR?: () => void;
}

export const BahiaDisplay: React.FC<BahiaDisplayProps> = ({
  isStandalone = true,
  onOpenMobileQR,
}) => {
  const [mechanics, setMechanics] = useState<Mechanic[]>(() => {
    const list = StorageService.getMechanics();
    return list.length > 0 ? list : INITIAL_MECHANICS;
  });
  const [orders, setOrders] = useState<WorkOrder[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);

  // Configuración de pantalla
  const [selectedMechanicIds, setSelectedMechanicIds] = useState<string[]>(() => {
    const list = StorageService.getMechanics();
    return (list.length > 0 ? list : INITIAL_MECHANICS).map((m) => m.id);
  });
  const selectedMechanicIdsRef = useRef<string[]>([]);
  const hasInitializedSelectionRef = useRef(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [currentTime, setCurrentTime] = useState('');
  const [lastSyncTime, setLastSyncTime] = useState<Date>(new Date());
  const [isSyncing, setIsSyncing] = useState(false);

  // Mantener ref actualizado
  useEffect(() => {
    selectedMechanicIdsRef.current = selectedMechanicIds;
  }, [selectedMechanicIds]);

  // Registro de órdenes ya conocidas para detectar nuevas y sonar el timbre
  const knownOrderIdsRef = useRef<Set<string>>(new Set());
  const isFirstLoadRef = useRef(true);

  // Modal para reportar detalle extra desde la bahía
  const [extraModalOrder, setExtraModalOrder] = useState<WorkOrder | null>(null);
  const [extraModalMec, setExtraModalMec] = useState<Mechanic | null>(null);
  const [solicitudTipo, setSolicitudTipo] = useState<'refaccion' | 'mano_obra_extra' | 'ambos'>('refaccion');
  const [extraDetalle, setExtraDetalle] = useState('');
  const [extraCosto, setExtraCosto] = useState<number>(0);

  // Seguridad: Candado de PIN para regresar a Mostrador
  const [isPinModalOpen, setIsPinModalOpen] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState(false);

  const handleVerifyPinAndExit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanPin = pinInput.trim();
    // PIN de Reyna Amaya: 2036 (o clave maestra 1234)
    if (cleanPin === '2036' || cleanPin === '1234') {
      setIsPinModalOpen(false);
      window.location.href = '/';
    } else {
      setPinError(true);
      setPinInput('');
    }
  };

  // ==========================================
  // SINTETIZADOR DE TIMBRE / PITIDO NATIVO
  // ==========================================
  const playChime = (type: 'new_order' | 'completed' | 'alert') => {
    if (!soundEnabled || typeof window === 'undefined') return;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();

      // Cerrar el contexto de audio tras sonar para evitar memory leaks en navegadores móviles/tablets
      setTimeout(() => {
        try {
          ctx.close();
        } catch {}
      }, 1200);

      if (type === 'new_order') {
        const now = ctx.currentTime;
        const osc1 = ctx.createOscillator();
        const gain1 = ctx.createGain();
        osc1.type = 'sine';
        osc1.frequency.setValueAtTime(880, now);
        gain1.gain.setValueAtTime(0.3, now);
        gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
        osc1.connect(gain1);
        gain1.connect(ctx.destination);
        osc1.start(now);
        osc1.stop(now + 0.4);

        const osc2 = ctx.createOscillator();
        const gain2 = ctx.createGain();
        osc2.type = 'sine';
        osc2.frequency.setValueAtTime(1174.66, now + 0.25);
        gain2.gain.setValueAtTime(0.35, now + 0.25);
        gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.8);
        osc2.connect(gain2);
        gain2.connect(ctx.destination);
        osc2.start(now + 0.25);
        osc2.stop(now + 0.8);
      } else if (type === 'completed') {
        const now = ctx.currentTime;
        [523.25, 659.25, 783.99].forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, now + idx * 0.12);
          gain.gain.setValueAtTime(0.25, now + idx * 0.12);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.12 + 0.35);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + idx * 0.12);
          osc.stop(now + idx * 0.12 + 0.35);
        });
      } else {
        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(440, now);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.3);
      }
    } catch (e) {
      console.warn('AudioContext error', e);
    }
  };

  // ==========================================
  // RELOJ EN VIVO
  // ==========================================
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('es-MX', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true,
        })
      );
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  // ==========================================
  // CARGA INICIAL Y POLLING EN TIEMPO REAL
  // ==========================================
  const loadData = async (triggerChimeIfNew = true, signal?: AbortSignal) => {
    try {
      setIsSyncing(true);
      const res = await fetch('/api/sync?_t=' + Date.now(), {
        cache: 'no-store',
        signal,
      });
      if (res.ok) {
        const data = await res.json();
        const localMecs = StorageService.getMechanics();
        const rawMecs = data.mechanics && data.mechanics.length > 0 ? data.mechanics : (localMecs.length > 0 ? localMecs : INITIAL_MECHANICS);
        const activeMecs = rawMecs
          .filter((m: Mechanic) => m.activo !== false)
          .map((m: Mechanic) => ({ ...m, comisionDefault: 0 }));

        const rawOrders: WorkOrder[] = data.workOrders || StorageService.getWorkOrders() || [];
        // Blindaje de privacidad: Eliminar de memoria en la pantalla de bahía cualquier monto, subtotal o porcentaje
        const currentOrders: WorkOrder[] = rawOrders.map((o) => ({
          ...o,
          anticipo: 0,
          total: 0,
          subtotalManoObra: 0,
          subtotalRefacciones: 0,
          ivaMonto: 0,
          totalComisionesMecanicos: 0,
          comisionMecanico: 0,
          servicios: (o.servicios || []).map((s) => ({
            ...s,
            manoObra: 0,
            refaccionesMonto: 0,
            comisionPorcentaje: 0,
            comisionManoObra: 0,
          })),
        }));

        setMechanics(activeMecs);
        setOrders(currentOrders);
        setVehicles(data.vehicles || StorageService.getVehicles() || []);
        setClients(data.clients || StorageService.getClients() || []);
        setCompanies(data.companies || StorageService.getCompanies() || []);
        setLastSyncTime(new Date());

        if (!hasInitializedSelectionRef.current && activeMecs.length > 0) {
          hasInitializedSelectionRef.current = true;
          setSelectedMechanicIds(activeMecs.map((m: Mechanic) => m.id));
        }

        if (!isFirstLoadRef.current && triggerChimeIfNew) {
          const newOrders = currentOrders.filter((o) => !knownOrderIdsRef.current.has(o.id));
          if (newOrders.length > 0) {
            playChime('new_order');
          }
        }

        knownOrderIdsRef.current = new Set(currentOrders.map((o) => o.id));
        isFirstLoadRef.current = false;
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.error('Error fetching data in bahia', err);
      }
    } finally {
      setIsSyncing(false);
    }
  };

  useEffect(() => {
    let isMounted = true;
    let timerId: NodeJS.Timeout | null = null;
    let activeAbort: AbortController | null = null;

    const poll = async (triggerChime: boolean) => {
      if (!isMounted) return;
      try {
        activeAbort = new AbortController();
        const timeoutId = setTimeout(() => activeAbort?.abort(), 8000);
        await loadData(triggerChime, activeAbort.signal);
        clearTimeout(timeoutId);
      } catch (err) {
        // Ignorar aborts
      } finally {
        if (isMounted) {
          // Espera 4 segundos secuenciales entre consultas para evitar saturar la red Wi-Fi
          timerId = setTimeout(() => {
            poll(true);
          }, 4000);
        }
      }
    };

    poll(false);

    return () => {
      isMounted = false;
      if (timerId) clearTimeout(timerId);
      if (activeAbort) activeAbort.abort();
    };
  }, []);

  // ==========================================
  // CAMBIO DE ESTATUS CON 1 CLIC DESDE BAHÍA
  // ==========================================
  const handleUpdateStatus = async (orderId: string, newStatus: OrderStatus) => {
    const targetOrder = orders.find((o) => o.id === orderId);
    if (!targetOrder) return;

    targetOrder.estado = newStatus;
    if (newStatus === 'listo') {
      playChime('completed');
    }

    const nextOrders = orders.map((o) => (o.id === orderId ? { ...targetOrder } : o));
    setOrders(nextOrders);
    StorageService.saveWorkOrder(targetOrder);

    try {
      await fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'save_order',
          order: targetOrder,
        }),
      });
    } catch (err) {
      console.error('Error syncing order update', err);
    }
  };

  // Reclamar o reasignar orden a un mecánico
  const handleAssignOrderToMechanic = async (orderId: string, mechanic: Mechanic) => {
    const targetOrder = orders.find((o) => o.id === orderId);
    if (!targetOrder) return;

    // Obtener la comisión real confidencial del mecánico desde StorageService
    const allMecs = StorageService.getMechanics();
    const realMec = allMecs.find((m) => m.id === mechanic.id) || mechanic;
    const realComision = realMec.comisionDefault || 30;

    if (targetOrder.servicios && targetOrder.servicios.length > 0) {
      targetOrder.servicios[0].mecanicoId = mechanic.id;
      targetOrder.servicios[0].mecanicoNombre = mechanic.nombre;
      targetOrder.servicios[0].comisionPorcentaje = realComision;
      targetOrder.servicios[0].comisionManoObra = Math.round(
        (targetOrder.servicios[0].manoObra || 0) * (realComision / 100)
      );
    } else {
      targetOrder.servicios = [
        {
          id: `srv-${Date.now()}`,
          concepto: targetOrder.fallaReportada || 'Servicio de bahía',
          mecanicoId: mechanic.id,
          mecanicoNombre: mechanic.nombre,
          manoObra: targetOrder.subtotalManoObra || 500,
          refaccionesMonto: 0,
          comisionPorcentaje: realComision,
          comisionManoObra: Math.round((targetOrder.subtotalManoObra || 500) * (realComision / 100)),
          estado: 'pendiente',
        },
      ];
    }

    if (targetOrder.presupuesto && targetOrder.presupuesto.manoObra && targetOrder.presupuesto.manoObra.length > 0) {
      targetOrder.presupuesto.manoObra[0].mecanicoId = mechanic.id;
      targetOrder.presupuesto.manoObra[0].mecanicoNombre = mechanic.nombre;
    }

    const nextOrders = orders.map((o) => (o.id === orderId ? { ...targetOrder } : o));
    setOrders(nextOrders);
    await StorageService.saveWorkOrderCompleteAsync(targetOrder);

    playChime('new_order');
  };

  // Guardar solicitud de pieza / insumo a Administración
  const handleSaveExtraDetail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!extraModalOrder || !extraDetalle.trim()) return;

    const mecId = extraModalMec?.id || extraModalOrder.servicios?.[0]?.mecanicoId || 'mec-1';
    const mecNombre = extraModalMec?.nombre || extraModalOrder.servicios?.[0]?.mecanicoNombre || 'Técnico Bahía';

    const nuevaSolicitud = {
      id: `sol-${Date.now()}`,
      fecha: new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit', hour12: true }),
      mecanicoId: mecId,
      mecanicoNombre: mecNombre,
      descripcion: extraDetalle.trim(),
      tipo: solicitudTipo,
      estado: 'pendiente_admin' as const,
      costoManoObraExtra: Number(extraCosto) || 0,
    };

    const targetOrder: WorkOrder = {
      ...extraModalOrder,
      solicitudesBahia: [nuevaSolicitud, ...(extraModalOrder.solicitudesBahia || [])],
    };

    const nextOrders = orders.map((o) => (o.id === targetOrder.id ? targetOrder : o));
    setOrders(nextOrders);
    StorageService.saveWorkOrder(targetOrder);

    await fetch('/api/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'save_order',
        order: targetOrder,
      }),
    });

    playChime('new_order');
    setExtraModalOrder(null);
    setExtraDetalle('');
    setExtraCosto(0);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const displayedMechanics = mechanics.filter((m) =>
    selectedMechanicIds.length === 0 ? true : selectedMechanicIds.includes(m.id)
  );

  const unassignedOrders = orders.filter((o) => {
    const hasAssigned = (o.servicios || []).some(
      (s) => s.mecanicoId && s.mecanicoId !== 'unassigned' && s.mecanicoNombre !== 'Por Asignar Bahía'
    );
    return !hasAssigned && o.estado !== 'entregado';
  });

  return (
    <div className={`text-slate-100 flex flex-col font-sans select-none overflow-x-hidden ${isStandalone ? 'min-h-screen bg-slate-900' : 'bg-slate-900 rounded-2xl border border-slate-800 shadow-xl'}`}>
      {/* 1. BARRA SUPERIOR DE CONTROL */}
      <header className="bg-slate-950/95 border-b border-slate-800 px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 sticky top-0 z-40 shadow-xl backdrop-blur-md">
        <div className="flex items-center gap-3">
          {isStandalone ? (
            <button
              onClick={() => {
                setPinInput('');
                setPinError(false);
                setIsPinModalOpen(true);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs border border-slate-700 transition-colors cursor-pointer"
              title="Regresar a Mostrador (Protegido por PIN de Reyna Amaya)"
            >
              <Lock className="w-3.5 h-3.5 text-amber-400" />
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Mostrador (Admin)</span>
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
              <span className="font-mono font-bold text-xs text-rose-400 uppercase tracking-widest">
                EN VIVO
              </span>
            </div>
          )}

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white p-1 flex items-center justify-center shrink-0 shadow-sm border border-slate-700">
              <img
                src="/logo-taller-amaya.png"
                alt="Taller Amaya"
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-black text-sm sm:text-base text-white tracking-wider uppercase">
                  TALLER AMAYA
                </h1>
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-rose-600 text-white tracking-widest shadow-sm">
                  PANTALLA DE BAHÍA
                </span>
              </div>
              <span className="text-[11px] text-slate-400 font-medium hidden sm:block">
                Monitor de Mecánicos en Vivo y Control de Estatus
              </span>
            </div>
          </div>
        </div>

        {/* Selector de cuántos mecánicos / columnas ver */}
        <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
          <span className="text-[11px] text-slate-400 font-semibold px-1.5 hidden md:inline">
            Mostrar:
          </span>
          <button
            onClick={() => setSelectedMechanicIds(mechanics.map((m) => m.id))}
            className={`px-2.5 py-1 rounded-lg font-black text-xs transition-all ${
              selectedMechanicIds.length === mechanics.length
                ? 'bg-rose-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            Todos ({mechanics.length})
          </button>
          {mechanics.map((m) => {
            const isSelected = selectedMechanicIds.includes(m.id);
            return (
              <button
                key={m.id}
                onClick={() => {
                  if (isSelected) {
                    if (selectedMechanicIds.length > 1) {
                      setSelectedMechanicIds(selectedMechanicIds.filter((id) => id !== m.id));
                    }
                  } else {
                    setSelectedMechanicIds([...selectedMechanicIds, m.id]);
                  }
                }}
                className={`px-2.5 py-1 rounded-lg font-bold text-xs transition-all ${
                  isSelected
                    ? 'bg-slate-700 text-white border border-slate-600 shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {m.nombre.split(' ')[0]}
              </button>
            );
          })}
        </div>

        {/* Lado derecho: Timbre, Reloj, Abrir Pantalla Completa / QR */}
        <div className="flex items-center gap-2">
          {/* Botón para abrir en ventana completa si está embebida */}
          {!isStandalone && (
            <button
              onClick={() => window.open('/bahia', '_blank')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition-all cursor-pointer"
              title="Abrir la pantalla de Bahía en una ventana independiente o monitor secundario"
            >
              <ExternalLink className="w-3.5 h-3.5 text-rose-400" />
              <span className="hidden sm:inline">Monitor Separado</span>
            </button>
          )}

          {onOpenMobileQR && (
            <button
              onClick={onOpenMobileQR}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition-all cursor-pointer"
              title="Código QR para abrir en la Tablet de Bahía"
            >
              <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">QR Tablet</span>
            </button>
          )}

          {/* Botón de Sonido / Timbre */}
          <button
            onClick={() => {
              const nextState = !soundEnabled;
              setSoundEnabled(nextState);
              if (nextState) playChime('new_order');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border font-bold text-xs transition-all ${
              soundEnabled
                ? 'bg-emerald-950/70 border-emerald-600 text-emerald-400 hover:bg-emerald-900/80 shadow-sm'
                : 'bg-slate-800 border-slate-700 text-slate-400'
            }`}
            title="Activar o desactivar el timbre al llegar nuevo carro"
          >
            {soundEnabled ? <Bell className="w-3.5 h-3.5" /> : <BellOff className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">
              {soundEnabled ? 'Timbre Activo' : 'Silencio'}
            </span>
          </button>

          <button
            onClick={() => playChime('new_order')}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
            title="Probar sonido de campana"
          >
            <Volume2 className="w-4 h-4" />
          </button>

          {/* Reloj de Bahía */}
          <div className="font-mono font-black text-xs sm:text-sm text-amber-400 bg-slate-900 border border-slate-800 px-3 py-1 rounded-xl shadow-inner">
            {currentTime || '00:00:00'}
          </div>

          {/* Botón Pantalla Completa */}
          <button
            onClick={toggleFullscreen}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
            title="Modo pantalla completa (F11)"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* 2. BARRA DE AUTOS SIN ASIGNAR (SI HAY AUTOS EN ESPERA) */}
      {unassignedOrders.length > 0 && (
        <div className="bg-amber-950/80 border-b border-amber-600/60 p-2.5 px-4 flex flex-wrap items-center justify-between gap-3 text-xs animate-pulse">
          <div className="flex items-center gap-2 text-amber-300 font-bold">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              Hay {unassignedOrders.length} vehículo(s) recién ingresados sin mecánico asignado:
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {unassignedOrders.map((unOrd) => {
              const v = vehicles.find((veh) => veh.id === unOrd.vehiculoId);
              return (
                <div
                  key={unOrd.id}
                  className="bg-slate-900/90 border border-amber-500/50 rounded-xl px-3 py-1.5 flex items-center gap-2 shadow-md"
                >
                  <span className="font-mono font-black text-white">#{unOrd.folio}</span>
                  <span className="text-amber-200 font-semibold truncate max-w-[140px]">
                    {v?.marca} {v?.modelo} ({v?.placas})
                  </span>
                  <div className="flex items-center gap-1">
                    {displayedMechanics.map((m) => (
                      <button
                        key={m.id}
                        onClick={() => handleAssignOrderToMechanic(unOrd.id, m)}
                        className="px-2 py-0.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-[10px] uppercase shadow-xs transition-transform active:scale-95"
                        title={`Asignar auto #${unOrd.folio} a ${m.nombre}`}
                      >
                        + {m.nombre.split(' ')[0]}
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 3. COLUMNAS DE MECÁNICOS */}
      <main className="flex-1 p-3 sm:p-4 overflow-x-auto overflow-y-auto">
        <div
          className="grid gap-3 sm:gap-4 h-full min-w-full"
          style={{
            gridTemplateColumns: `repeat(${Math.max(1, displayedMechanics.length)}, minmax(260px, 1fr))`,
          }}
        >
          {displayedMechanics.map((mec) => {
            const mecOrders = orders.filter((o) => {
              const assignedToMec = (o.servicios || []).some((s) => s.mecanicoId === mec.id);
              return assignedToMec && o.estado !== 'entregado';
            });

            const pendingOrders = mecOrders.filter(
              (o) => o.estado === 'recepcion' || o.estado === 'diagnostico'
            );
            const inProgressOrders = mecOrders.filter((o) => o.estado === 'en_proceso');
            const finishedOrders = mecOrders.filter((o) => o.estado === 'listo');

            return (
              <div
                key={mec.id}
                className="bg-slate-950/80 border-2 border-slate-800 rounded-3xl flex flex-col overflow-hidden shadow-2xl transition-all"
              >
                {/* Cabecera del Carril del Mecánico */}
                <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 p-3.5 border-b border-slate-700/80 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-2xl bg-rose-600/20 border-2 border-rose-500/60 flex items-center justify-center text-rose-400 font-black text-sm shrink-0 shadow-inner">
                      👨‍🔧
                    </div>
                    <div>
                      <h2 className="font-black text-base sm:text-lg text-white tracking-wide uppercase leading-tight">
                        {mec.nombre}
                      </h2>
                      <span className="text-[11px] text-amber-400 font-semibold block">
                        {mec.especialidad}
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="font-mono font-black text-xl text-white bg-slate-950 px-3 py-1 rounded-xl border border-slate-700 block shadow-inner">
                      {mecOrders.length}
                    </span>
                    <span className="text-[9px] text-slate-400 uppercase font-bold tracking-wider mt-0.5 block">
                      Autos Activos
                    </span>
                  </div>
                </div>

                {/* Sub-barra de estatus rápido del mecánico */}
                <div className="flex items-center justify-around bg-slate-900/90 py-1.5 border-b border-slate-800/80 text-[11px] font-bold">
                  <span className="text-amber-400">⏳ Por Iniciar: {pendingOrders.length}</span>
                  <span className="text-sky-400">⚙️ En Bahía: {inProgressOrders.length}</span>
                  <span className="text-emerald-400">✓ Listos: {finishedOrders.length}</span>
                </div>

                {/* Lista de Autos / Comandas Digitales */}
                <div className="flex-1 p-3 space-y-3 overflow-y-auto max-h-[calc(100vh-170px)]">
                  {mecOrders.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-64 text-center text-slate-500 border-2 border-dashed border-slate-800/80 rounded-2xl p-6">
                      <Car className="w-12 h-12 text-slate-700 mb-2 stroke-1" />
                      <p className="font-bold text-sm text-slate-400">Bahía Despejada</p>
                      <span className="text-xs text-slate-500 mt-1">
                        No hay vehículos asignados a {mec.nombre.split(' ')[0]} en este momento.
                      </span>
                    </div>
                  ) : (
                    mecOrders.map((ord) => {
                      const v = vehicles.find((veh) => veh.id === ord.vehiculoId);
                      const c = clients.find((cli) => cli.id === ord.clienteId);
                      const srv = (ord.servicios || []).find((s) => s.mecanicoId === mec.id) || ord.servicios?.[0];

                      const isReady = ord.estado === 'listo';
                      const isInProgress = ord.estado === 'en_proceso';
                      const isPending = ord.estado === 'recepcion' || ord.estado === 'diagnostico';

                      return (
                        <div
                          key={ord.id}
                          className={`rounded-2xl border-2 p-3.5 transition-all shadow-lg flex flex-col justify-between gap-3 ${
                            isReady
                              ? 'bg-emerald-950/40 border-emerald-500/80 shadow-emerald-950/20'
                              : isInProgress
                              ? 'bg-sky-950/40 border-sky-500/80 shadow-sky-950/20'
                              : 'bg-slate-900 border-amber-500/70 shadow-slate-950/50'
                          }`}
                        >
                          <div>
                            <div className="flex items-start justify-between gap-2 border-b border-slate-800/80 pb-2">
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="font-mono text-lg font-black text-rose-400 bg-slate-950 px-2.5 py-0.5 rounded-lg border border-slate-800 shadow-sm">
                                    #{ord.folio}
                                  </span>
                                  <span className="font-mono font-black text-sm bg-white text-slate-950 px-2 py-0.5 rounded-md border-2 border-slate-400 tracking-wider">
                                    {v?.placas || 'SIN PLACAS'}
                                  </span>
                                </div>
                                <h3 className="font-black text-base text-white mt-1 leading-tight">
                                  {v?.marca} {v?.modelo} ({v?.ano})
                                </h3>
                                <span className="text-xs text-slate-400 font-semibold block">
                                  Color: {v?.color} • Odómetro: {Number(ord.kilometrajeEntrada || 0).toLocaleString()} km
                                </span>
                              </div>

                              <div className="text-right">
                                <span
                                  className={`text-[10px] font-black uppercase px-2.5 py-1 rounded-full border tracking-wide block ${
                                    isReady
                                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/60'
                                      : isInProgress
                                      ? 'bg-sky-500/20 text-sky-300 border-sky-500/60'
                                      : 'bg-amber-500/20 text-amber-300 border-amber-500/60'
                                  }`}
                                >
                                  {isReady ? '✓ LISTO' : isInProgress ? '⚙️ EN PROCESO' : '⏳ POR INICIAR'}
                                </span>
                                <span className="text-[10px] text-slate-400 font-mono mt-1 block">
                                  {ord.fechaIngreso ? ord.fechaIngreso.split(' ')[1] || '08:30' : '08:30'}
                                </span>
                              </div>
                            </div>

                            <div className="mt-2.5 space-y-1.5 text-xs">
                              <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
                                <span className="text-[10px] text-slate-400 font-bold uppercase block">
                                  Trabajo / Mano de Obra Asignada:
                                </span>
                                <p className="text-sm font-bold text-amber-300 leading-snug mt-0.5">
                                  {srv?.concepto || ord.fallaReportada}
                                </p>
                              </div>

                              {ord.refaccionesCliente && ord.refaccionesCliente.length > 0 && (
                                <div className="p-2 rounded-xl bg-amber-950/30 border border-amber-600/40 text-amber-200 text-xs">
                                  <strong className="block text-[10px] uppercase font-bold text-amber-300">
                                    📦 Refacciones traídas por cliente:
                                  </strong>
                                  <span className="font-medium">{ord.refaccionesCliente.join(' • ')}</span>
                                </div>
                              )}

                              {ord.fallaReportada && ord.fallaReportada !== srv?.concepto && (
                                <div className="text-[11px] text-slate-400">
                                  <strong>Falla reportada:</strong> {ord.fallaReportada}
                                </div>
                              )}

                              {ord.solicitudesBahia && ord.solicitudesBahia.length > 0 && (
                                <div className="space-y-2 pt-2 border-t border-slate-800">
                                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                                    Solicitudes a Administración:
                                  </span>
                                  {ord.solicitudesBahia.map((sol) => (
                                    <div
                                      key={sol.id}
                                      className={`p-2.5 rounded-xl border text-xs shadow-sm ${
                                        sol.estado === 'pendiente_admin'
                                          ? 'bg-amber-950/70 border-amber-500/80 text-amber-200 animate-pulse'
                                          : sol.estado === 'autorizado_cliente'
                                          ? 'bg-emerald-950/70 border-emerald-500/80 text-emerald-200'
                                          : 'bg-rose-950/70 border-rose-500/80 text-rose-300'
                                      }`}
                                    >
                                      <div className="flex items-center justify-between gap-1 mb-1">
                                        <span className="font-black flex items-center gap-1 uppercase tracking-wide text-[11px]">
                                          {sol.estado === 'pendiente_admin' && '⏳ SOLICITUD ENVIADA A ADMIN'}
                                          {sol.estado === 'autorizado_cliente' && '✅ AUTORIZADO POR CLIENTE'}
                                          {sol.estado === 'rechazado_cliente' && '❌ RECHAZADO POR CLIENTE'}
                                        </span>
                                        <span className="text-[10px] font-mono opacity-80">{sol.fecha}</span>
                                      </div>
                                      <p className="font-bold text-white text-xs leading-snug">
                                        "{sol.descripcion}"
                                      </p>
                                      <div className="flex items-center justify-between mt-1 text-[10px] opacity-90 border-t border-slate-700/50 pt-1">
                                        <span>
                                          {sol.tipo === 'refaccion'
                                            ? '📦 Refacción necesaria'
                                            : sol.tipo === 'mano_obra_extra'
                                            ? '🔧 Trabajo extra'
                                            : '📦 Refacción + Mano de Obra'}
                                        </span>
                                        <span className="font-black">
                                          {sol.estado === 'pendiente_admin' && 'En espera de autorización'}
                                          {sol.estado === 'autorizado_cliente' && '¡PROCEDER A TRABAJAR!'}
                                          {sol.estado === 'rechazado_cliente' && 'NO realizar este extra'}
                                        </span>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>

                          {/* BOTONES DE ESTATUS */}
                          <div className="pt-2 border-t border-slate-800/80 space-y-2">
                            {isPending && (
                              <button
                                onClick={() => handleUpdateStatus(ord.id, 'en_proceso')}
                                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white font-black text-xs sm:text-sm tracking-wide shadow-lg shadow-sky-950/50 flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
                              >
                                <Play className="w-4 h-4 fill-white" />
                                <span>INICIAR DESARME / SERVICIO</span>
                              </button>
                            )}

                            {isInProgress && (
                              <button
                                onClick={() => handleUpdateStatus(ord.id, 'listo')}
                                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs sm:text-sm tracking-wide shadow-lg shadow-emerald-950/50 flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer animate-pulse"
                              >
                                <Check className="w-5 h-5 stroke-[3]" />
                                <span>TERMINADO / LISTO PARA ENTREGA</span>
                              </button>
                            )}

                            {isReady && (
                              <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-600/60 text-emerald-300 font-bold text-center text-xs flex items-center justify-center gap-2">
                                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                                <span>✓ Auto Terminado por {mec.nombre.split(' ')[0]}</span>
                              </div>
                            )}

                            <button
                              type="button"
                              onClick={() => {
                                setExtraModalOrder(ord);
                                setExtraModalMec(mec);
                                setExtraDetalle('');
                                setExtraCosto(0);
                              }}
                              className="w-full py-2 px-3 rounded-xl bg-slate-950 hover:bg-slate-900 border border-amber-600/50 hover:border-amber-500 text-amber-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                            >
                              <Plus className="w-3.5 h-3.5 text-amber-400" />
                              <span>⚠️ Pedir Pieza o Reportar Detalle Extra a Admin</span>
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </main>

      {/* MODAL DE SOLICITUD EXTRA A ADMINISTRACIÓN */}
      {extraModalOrder && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border-2 border-amber-500 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4 text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40">
                  <Package className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="font-black text-base text-white">
                    Solicitud de Bahía a Administración
                  </h3>
                  <span className="text-xs text-amber-400 font-medium">
                    Mecánico: {extraModalMec?.nombre} • Auto #{extraModalOrder.folio}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setExtraModalOrder(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveExtraDetail} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Tipo de Requerimiento:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'refaccion', label: 'Pieza / Refacción', desc: 'Se requiere comprar parte' },
                    { id: 'mano_obra_extra', label: 'Mano de Obra Extra', desc: 'Trabajo imprevisto' },
                    { id: 'ambos', label: 'Ambos', desc: 'Pieza + Mano de obra' },
                  ].map((tp) => (
                    <button
                      key={tp.id}
                      type="button"
                      onClick={() => setSolicitudTipo(tp.id as any)}
                      className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                        solicitudTipo === tp.id
                          ? 'bg-amber-500 text-slate-950 font-black border-amber-400 shadow-md'
                          : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <span className="block text-xs font-bold">{tp.label}</span>
                      <span className="text-[10px] opacity-80 block">{tp.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  ¿Qué pieza o insumo necesitas para continuar el trabajo? *:
                </label>
                <textarea
                  rows={3}
                  required
                  value={extraDetalle}
                  onChange={(e) => setExtraDetalle(e.target.value)}
                  placeholder="Ej. Balatas delanteras desgastadas al fierro, rectificado de discos, banda cuarteada, soporte de motor roto..."
                  className="w-full bg-slate-950 border border-slate-700 text-white rounded-xl p-3 text-xs focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase">
                  Sugerencias Rápidas de Taller:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    'Balatas delanteras desgastadas',
                    'Rectificado de discos delanteros',
                    'Banda de accesorios reseca',
                    'Amortiguador chorreado de aceite',
                    'Soporte de motor roto',
                    'Retén con fuga de aceite',
                    'Cubrepolvo de flecha roto',
                    'Líquido de frenos / Insumo',
                    'Bieleta / Terminal con juego',
                  ].map((sug, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setExtraDetalle(sug)}
                      className="text-[10px] bg-slate-800 hover:bg-slate-700 text-amber-200 px-2 py-1 rounded-lg border border-slate-700 font-medium cursor-pointer"
                    >
                      + {sug}
                    </button>
                  ))}
                </div>
              </div>

              {/* En la Bahía de Mecánicos NO se muestran montos en dinero ni porcentajes */}
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setExtraModalOrder(null)}
                  className="flex-1 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-2 flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs shadow-lg shadow-amber-950/50 transition-all active:scale-95 cursor-pointer"
                >
                  <Package className="w-4 h-4" />
                  <span>🚀 Enviar Solicitud a Administración</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* MODAL DE SEGURIDAD: PIN PARA VOLVER A MOSTRADOR */}
      {isPinModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-sm w-full p-6 shadow-2xl text-center">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border-2 border-amber-500/40 text-amber-400 flex items-center justify-center mx-auto mb-4">
              <Lock className="w-7 h-7" />
            </div>

            <h3 className="text-lg font-black text-white uppercase tracking-wider">
              Acceso a Administración
            </h3>
            <p className="text-xs text-slate-400 mt-1.5 mb-5">
              Esta pantalla de Bahía está protegida. Ingresa el PIN de <strong className="text-amber-400">Reyna Amaya</strong> para ir al Mostrador.
            </p>

            <form onSubmit={handleVerifyPinAndExit} className="space-y-4">
              <div>
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={6}
                  autoFocus
                  placeholder="••••"
                  value={pinInput}
                  onChange={(e) => {
                    setPinInput(e.target.value);
                    if (pinError) setPinError(false);
                  }}
                  className={`w-full bg-slate-950 border text-center text-3xl font-mono tracking-widest text-white rounded-2xl py-3 focus:outline-none transition-colors ${
                    pinError
                      ? 'border-rose-500 bg-rose-950/30 text-rose-300 focus:border-rose-500'
                      : 'border-slate-700 focus:border-amber-500'
                  }`}
                />
                {pinError && (
                  <p className="text-[11px] font-bold text-rose-400 mt-2 flex items-center justify-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>PIN incorrecto. Acceso exclusivo de administración.</span>
                  </p>
                )}
              </div>

              <div className="flex gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setIsPinModalOpen(false)}
                  className="flex-1 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs cursor-pointer"
                >
                  Permanecer en Bahía
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
                >
                  Entrar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
