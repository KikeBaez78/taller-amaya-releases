@echo off
title CREAR ACCESOS DIRECTOS - TALLER AMAYA
color 0A

cd /d "%~dp0"

echo =========================================================================
echo          CREADOR OFICIAL DE ACCESOS DIRECTOS - TALLER AMAYA
echo =========================================================================
echo.

cscript //nologo scripts\crear-acceso-directo.vbs
if errorlevel 1 (
    wscript scripts\crear-acceso-directo.vbs
)

echo.
echo =========================================================================
echo  [EXITO] Accesos directos creados correctamente en tu Escritorio:
echo  1. "Taller Amaya"
echo  2. "Pantalla Bahia - Taller Amaya"
echo =========================================================================
echo.
pause
