' =========================================================================
' CREADOR DE ACCESO DIRECTO NATIVO DE WINDOWS - TALLER AMAYA
' =========================================================================
On Error Resume Next

Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' Obtener la ruta base del proyecto
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
projectDir = fso.GetParentFolderName(scriptDir)

desktopPath = WshShell.SpecialFolders("Desktop")
shortcutPath = desktopPath & "\Taller Amaya.lnk"
vbsTarget = scriptDir & "\iniciar-taller-silencioso.vbs"
iconTarget = projectDir & "\public\logo.ico"

Set oShortcut = WshShell.CreateShortcut(shortcutPath)
oShortcut.TargetPath = "wscript.exe"
oShortcut.Arguments = """" & vbsTarget & """"
oShortcut.WorkingDirectory = projectDir
If fso.FileExists(iconTarget) Then
    oShortcut.IconLocation = iconTarget & ",0"
End If
oShortcut.Description = "Taller Amaya - Sistema Oficial de Control Automotriz"
oShortcut.Save

' Acceso directo a Pantalla de Bahia (Monitor Mecanicos)
shortcutBahiaPath = desktopPath & "\Pantalla Bahia - Taller Amaya.lnk"
vbsBahiaTarget = scriptDir & "\abrir-bahia.vbs"

Set oShortcutBahia = WshShell.CreateShortcut(shortcutBahiaPath)
oShortcutBahia.TargetPath = "wscript.exe"
oShortcutBahia.Arguments = """" & vbsBahiaTarget & """"
oShortcutBahia.WorkingDirectory = projectDir
If fso.FileExists(iconTarget) Then
    oShortcutBahia.IconLocation = iconTarget & ",0"
End If
oShortcutBahia.Description = "Pantalla de Bahia en Vivo - Taller Amaya"
oShortcutBahia.Save

If fso.FileExists(shortcutPath) Then
    WScript.Echo "[EXITO] Accesos directos 'Taller Amaya' y 'Pantalla Bahia' creados correctamente en tu Escritorio."
Else
    WScript.Echo "[ERROR] No se pudo crear el acceso directo en el Escritorio."
End If
