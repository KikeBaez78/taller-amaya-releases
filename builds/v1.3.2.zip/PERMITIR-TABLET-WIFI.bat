@echo off
title PERMITIR TABLET Y CELULAR POR WI-FI - TALLER AMAYA
color 0B
cd /d "%~dp0"

:: 1. Verificar y solicitar elevacion a Administrador (UAC)
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] Solicitando permisos de Administrador de Windows...
    powershell -NoProfile -Command "Start-Process cmd.exe -ArgumentList '/c \"\"%~f0\"\"' -Verb RunAs"
    exit /b
)

echo =========================================================================
echo       CONFIGURACION OFICIAL DE RED Y FIREWALL - TALLER AMAYA
echo =========================================================================
echo.

echo [1/2] Abriendo puerto 3000 en Windows Defender Firewall...
netsh advfirewall firewall delete rule name="Taller Amaya Puerto 3000" >nul 2>&1
netsh advfirewall firewall add rule name="Taller Amaya Puerto 3000" dir=in action=allow protocol=TCP localport=3000 profile=any >nul 2>&1

echo [OK] Puerto 3000 autorizado para toda la red Wi-Fi.
echo.
echo [2/2] Obteniendo direccion IP local para las Tablets...
echo.

for /f "tokens=4" %%a in ('route print ^| findstr 0.0.0.0 ^| findstr /v "0.0.0.0.*0.0.0.0.*0.0.0.0"') do (
    set "LOCAL_IP=%%a"
)

echo =========================================================================
echo   DIRECCIONES PARA CONECTAR TABLETS Y CELULARES:
echo.
echo   1. PANTALLA DE BAHIA (Para Mecanicos en Bahias):
echo      http://%LOCAL_IP%:3000/bahia
echo.
echo   2. RECEPCION MOVIL (Check-in con fotos en el auto):
echo      http://%LOCAL_IP%:3000
echo =========================================================================
echo.
pause
exit
