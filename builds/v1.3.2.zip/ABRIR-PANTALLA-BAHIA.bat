@echo off
title PANTALLA DE BAHIA - TALLER AMAYA
color 0C
cd /d "%~dp0"

echo ========================================================
echo       ABRIENDO PANTALLA DE BAHIA (EN VIVO)
echo ========================================================
echo.

start msedge --app=http://localhost:3000/bahia >nul 2>&1 || start http://localhost:3000/bahia

timeout /t 1 >nul
exit
