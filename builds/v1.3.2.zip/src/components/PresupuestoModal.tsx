'use client';

import React, { useState } from 'react';
import { StorageService } from '@/lib/storage';
import { WorkOrder, Presupuesto, PresupuestoItemParte, PresupuestoManoObra, PresupuestoStatus, Vehicle, Client, Company } from '@/types';
import {
  FileSpreadsheet,
  X,
  Plus,
  Trash2,
  CheckCircle2,
  Clock,
  AlertCircle,
  MessageCircle,
  Share2,
  Wrench,
  Package,
  DollarSign,
  Save,
  Check,
  Pencil,
} from 'lucide-react';

interface PresupuestoModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: WorkOrder;
  vehicle?: Vehicle;
  client?: Client;
  company?: Company;
  onOrderUpdated: (updatedOrder: WorkOrder) => void;
}

export const PresupuestoModal: React.FC<PresupuestoModalProps> = ({
  isOpen,
  onClose,
  order,
  vehicle,
  client,
  company,
  onOrderUpdated,
}) => {
  const config = StorageService.getConfig();
  const mechanics = StorageService.getMechanics();

  // Inicializar estado del presupuesto existente o crear uno desde los servicios actuales
  const initialPresupuesto: Presupuesto = order.presupuesto || {
    partes: order.refaccionesCliente?.map((ref, idx) => ({
      id: `p-init-${idx}`,
      descripcion: ref,
      cantidad: 1,
      precioUnitario: 0,
      subtotal: 0,
      origen: 'cliente',
    })) || [],
    manoObra: order.servicios?.map((s) => ({
      id: s.id,
      concepto: s.concepto,
      mecanicoId: s.mecanicoId,
      mecanicoNombre: s.mecanicoNombre,
      costo: s.manoObra,
      comisionPorcentaje: s.comisionPorcentaje,
    })) || [],
    subtotalPartes: order.subtotalRefacciones || 0,
    subtotalManoObra: order.subtotalManoObra || 0,
    aplicaIva: false,
    ivaMonto: 0,
    totalPresupuesto: order.subtotalGeneral || 0,
    estado: 'pendiente',
  };

  const [partes, setPartes] = useState<PresupuestoItemParte[]>(initialPresupuesto.partes);
  const [manoObra, setManoObra] = useState<PresupuestoManoObra[]>(initialPresupuesto.manoObra);
  const [aplicaIva, setAplicaIva] = useState<boolean>(initialPresupuesto.aplicaIva || false);
  const [estado, setEstado] = useState<PresupuestoStatus>(initialPresupuesto.estado || 'pendiente');
  const [medioAutorizacion, setMedioAutorizacion] = useState<'verbal' | 'whatsapp' | 'firma'>(
    initialPresupuesto.medioAutorizacion || 'whatsapp'
  );
  const [notasAutorizacion, setNotasAutorizacion] = useState<string>(
    initialPresupuesto.notasAutorizacion || ''
  );

  // Inputs para agregar nuevos conceptos
  const [nuevoConceptoMO, setNuevoConceptoMO] = useState('');
  const [nuevoCostoMO, setNuevoCostoMO] = useState<number>(0);
  const [nuevaComisionMO, setNuevaComisionMO] = useState<number>(mechanics[0]?.comisionDefault || 30);
  const [nuevoMecanicoId, setNuevoMecanicoId] = useState<string>(mechanics[0]?.id || '');

  const [nuevaDescParte, setNuevaDescParte] = useState('');
  const [nuevaCantParte, setNuevaCantParte] = useState<number>(1);
  const [nuevoPrecioParte, setNuevoPrecioParte] = useState<number>(0);
  const [nuevoOrigenParte, setNuevoOrigenParte] = useState<'taller' | 'cliente'>('taller');

  // Estados para edición inline de conceptos existentes
  const [editingMoId, setEditingMoId] = useState<string | null>(null);
  const [editingParteId, setEditingParteId] = useState<string | null>(null);

  if (!isOpen) return null;

  // Totales dinámicos
  const subtotalManoObra = manoObra.reduce((acc, curr) => acc + (curr.costo || 0), 0);
  const subtotalPartes = partes.reduce((acc, curr) => acc + (curr.subtotal || 0), 0);
  const subtotalSinIva = subtotalManoObra + subtotalPartes;
  const ivaMonto = aplicaIva ? Math.round(subtotalSinIva * (config.ivaFronteraPorcentaje / 100)) : 0;
  const totalPresupuesto = subtotalSinIva + ivaMonto;

  const handleAddMO = () => {
    if (!nuevoConceptoMO.trim() || nuevoCostoMO <= 0) return;
    const mec = mechanics.find((m) => m.id === nuevoMecanicoId);
    const item: PresupuestoManoObra = {
      id: `mo-${Date.now()}`,
      concepto: nuevoConceptoMO.trim(),
      costo: nuevoCostoMO,
      comisionPorcentaje: nuevaComisionMO,
      mecanicoId: mec?.id || 'unassigned',
      mecanicoNombre: mec ? mec.nombre : 'Por Asignar Bahía',
    };
    setManoObra([...manoObra, item]);
    setNuevoConceptoMO('');
    setNuevoCostoMO(0);
  };

  const handleAddParte = () => {
    if (!nuevaDescParte.trim() || (nuevoOrigenParte === 'taller' && nuevoPrecioParte <= 0)) return;
    const subtotal = nuevoOrigenParte === 'cliente' ? 0 : nuevaCantParte * nuevoPrecioParte;
    const item: PresupuestoItemParte = {
      id: `p-${Date.now()}`,
      descripcion: nuevaDescParte.trim(),
      cantidad: nuevaCantParte,
      precioUnitario: nuevoOrigenParte === 'cliente' ? 0 : nuevoPrecioParte,
      subtotal,
      origen: nuevoOrigenParte,
    };
    setPartes([...partes, item]);
    setNuevaDescParte('');
    setNuevaCantParte(1);
    setNuevoPrecioParte(0);
    setNuevoOrigenParte('taller');
  };

  const handleSave = () => {
    const updatedPresupuesto: Presupuesto = {
      partes,
      manoObra,
      subtotalPartes,
      subtotalManoObra,
      aplicaIva,
      ivaMonto,
      totalPresupuesto,
      estado,
      medioAutorizacion: estado === 'autorizado' ? medioAutorizacion : undefined,
      fechaAutorizacion: estado === 'autorizado' ? new Date().toLocaleString() : undefined,
      notasAutorizacion: notasAutorizacion.trim() || undefined,
    };

    // Actualizar también los servicios de la orden para consistencia con comisiones
    const updatedServicios = manoObra.map((mo) => {
      const comisionManoObra = mo.costo * (mo.comisionPorcentaje / 100);
      return {
        id: mo.id,
        concepto: mo.concepto,
        mecanicoId: mo.mecanicoId || 'mec-1',
        mecanicoNombre: mo.mecanicoNombre || 'Técnico Asignado',
        manoObra: mo.costo,
        refaccionesMonto: 0,
        comisionPorcentaje: mo.comisionPorcentaje,
        comisionManoObra,
        estado: (estado === 'autorizado' ? 'en_progreso' : 'pendiente') as any,
      };
    });

    const totalComisiones = updatedServicios.reduce((acc, s) => acc + s.comisionManoObra, 0);
    const saldoPendiente = Math.max(0, totalPresupuesto - order.totalPagado);

    const updatedOrder: WorkOrder = {
      ...order,
      presupuesto: updatedPresupuesto,
      servicios: updatedServicios,
      subtotalManoObra,
      subtotalRefacciones: subtotalPartes,
      subtotalGeneral: totalPresupuesto,
      totalComisionesMecanicos: totalComisiones,
      saldoPendiente,
    };

    StorageService.saveWorkOrder(updatedOrder);
    onOrderUpdated(updatedOrder);
    onClose();
  };

  const handleShareWhatsApp = () => {
    const tel = order.choferTelefono || client?.telefono || config.whatsapp;
    let mensaje = `*PRESUPUESTO DE SERVICIO - TALLER AMAYA* 🚗🔧\n`;
    mensaje += `Folio de Orden: *#${order.folio}*\n`;
    if (vehicle) mensaje += `Vehículo: *${vehicle.marca} ${vehicle.modelo} (${vehicle.ano})* - Placas: *${vehicle.placas}*\n`;
    mensaje += `Falla: ${order.fallaReportada}\n\n`;

    mensaje += `*📋 MANO DE OBRA REQUERIDA:*\n`;
    if (manoObra.length === 0) {
      mensaje += `• Pendiente de diagnóstico\n`;
    } else {
      manoObra.forEach((m) => {
        mensaje += `• ${m.concepto}: $${m.costo.toLocaleString()} MXN\n`;
      });
      mensaje += `*Subtotal M.O.: $${subtotalManoObra.toLocaleString()} MXN*\n\n`;
    }

    mensaje += `*📦 REFACCIONES Y PARTES:*\n`;
    if (partes.length === 0) {
      mensaje += `• Ninguna o suministradas por cliente\n`;
    } else {
      partes.forEach((p) => {
        if (p.origen === 'cliente') {
          mensaje += `• ${p.descripcion} (Suministrada por cliente: $0)\n`;
        } else {
          mensaje += `• ${p.cantidad}x ${p.descripcion}: $${p.subtotal.toLocaleString()} MXN\n`;
        }
      });
      mensaje += `*Subtotal Partes: $${subtotalPartes.toLocaleString()} MXN*\n\n`;
    }

    if (aplicaIva) {
      mensaje += `Subtotal: $${subtotalSinIva.toLocaleString()} MXN\n`;
      mensaje += `IVA 8% Frontera: $${ivaMonto.toLocaleString()} MXN\n`;
    }
    mensaje += `*💵 TOTAL PRESUPUESTO: $${totalPresupuesto.toLocaleString()} MXN*\n`;
    mensaje += `*Estatus: ${estado.toUpperCase()}*\n\n`;
    mensaje += `📍 *Taller Amaya:* ${config.direccion}\n`;
    mensaje += `Favor de responder este mensaje con *"AUTORIZO"* para proceder con la reparación.`;

    const encoded = encodeURIComponent(mensaje);
    window.open(`https://wa.me/52${tel.replace(/\D/g, '')}?text=${encoded}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-fadeIn">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl text-slate-800 overflow-hidden">
        {/* Cabecera */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-50 via-white to-rose-50/40 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center border border-rose-200 shadow-sm">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-slate-900">
                  Presupuesto & Cotización — Folio #{order.folio}
                </h2>
                <span
                  className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${
                    estado === 'autorizado'
                      ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                      : estado === 'rechazado'
                      ? 'bg-rose-100 text-rose-800 border-rose-300'
                      : 'bg-amber-100 text-amber-800 border-amber-300'
                  }`}
                >
                  {estado === 'autorizado'
                    ? '✓ Autorizado'
                    : estado === 'rechazado'
                    ? '✕ Rechazado'
                    : '⏳ Pendiente de Autorización'}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                {vehicle?.marca} {vehicle?.modelo} ({vehicle?.ano}) • Placas: {vehicle?.placas || 'N/A'} • Cliente:{' '}
                {company ? company.razonSocial : client?.nombre || 'Particular'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Cuerpo */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6 flex-1 bg-slate-50/50">
          {/* Estatus de Autorización */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Estatus de Autorización del Cliente:
              </label>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setEstado('pendiente')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                    estado === 'pendiente'
                      ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  ⏳ Pendiente
                </button>
                <button
                  type="button"
                  onClick={() => setEstado('autorizado')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                    estado === 'autorizado'
                      ? 'bg-emerald-600 text-white border-emerald-700 shadow-sm'
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  ✓ Autorizado por Cliente
                </button>
                <button
                  type="button"
                  onClick={() => setEstado('rechazado')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                    estado === 'rechazado'
                      ? 'bg-rose-600 text-white border-rose-700 shadow-sm'
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  ✕ Rechazado
                </button>
              </div>
            </div>

            {estado === 'autorizado' && (
              <div className="pt-2 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs animate-fadeIn">
                <div>
                  <span className="text-slate-500 block mb-1">Medio de Autorización:</span>
                  <select
                    value={medioAutorizacion}
                    onChange={(e) => setMedioAutorizacion(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800"
                  >
                    <option value="whatsapp">Mensaje de WhatsApp</option>
                    <option value="verbal">Llamada telefónica / Verbal</option>
                    <option value="firma">Firma física en taller</option>
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <span className="text-slate-500 block mb-1">Notas de Autorización / Quién autorizó:</span>
                  <input
                    type="text"
                    value={notasAutorizacion}
                    onChange={(e) => setNotasAutorizacion(e.target.value)}
                    placeholder="Ej. Autorizado por el dueño vía WhatsApp a las 11:30 AM..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-800"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Columnas Mano de Obra y Partes */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Columna Mano de Obra */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <Wrench className="w-4 h-4 text-rose-600" />
                    <span>Mano de Obra ({manoObra.length})</span>
                  </h3>
                  <span className="font-mono font-bold text-rose-600 text-xs">
                    Subtotal: ${subtotalManoObra.toLocaleString()} MXN
                  </span>
                </div>

                <div className="space-y-1.5 min-h-[100px] max-h-[220px] overflow-y-auto mb-3">
                  {manoObra.length === 0 ? (
                    <div className="text-center py-8 text-slate-400 text-xs">
                      Sin conceptos de mano de obra
                    </div>
                  ) : (
                    manoObra.map((mo) => {
                      if (editingMoId === mo.id) {
                        return (
                          <div
                            key={mo.id}
                            className="p-2.5 rounded-xl bg-rose-50/80 border-2 border-rose-300 space-y-2 text-xs animate-fadeIn"
                          >
                            <input
                              type="text"
                              value={mo.concepto}
                              onChange={(e) => {
                                const val = e.target.value;
                                setManoObra(manoObra.map((m) => (m.id === mo.id ? { ...m, concepto: val } : m)));
                              }}
                              placeholder="Concepto..."
                              className="w-full bg-white border border-slate-300 rounded-lg px-2 py-1 text-xs text-slate-800 font-medium"
                            />
                            <div className="flex items-center gap-2">
                              <input
                                type="number"
                                value={mo.costo || ''}
                                onChange={(e) => {
                                  const val = Number(e.target.value) || 0;
                                  setManoObra(manoObra.map((m) => (m.id === mo.id ? { ...m, costo: val } : m)));
                                }}
                                placeholder="$ Costo"
                                className="w-24 bg-white border border-slate-300 rounded-lg px-2 py-1 text-xs font-mono font-bold text-slate-800 text-right"
                              />
                              <select
                                value={mo.mecanicoId}
                                onChange={(e) => {
                                  const mId = e.target.value;
                                  const found = mechanics.find((m) => m.id === mId);
                                  setManoObra(
                                    manoObra.map((m) =>
                                      m.id === mo.id
                                        ? {
                                            ...m,
                                            mecanicoId: mId,
                                            mecanicoNombre: found ? found.nombre : 'Por Asignar',
                                            comisionPorcentaje: found ? found.comisionDefault : m.comisionPorcentaje,
                                          }
                                        : m
                                    )
                                  );
                                }}
                                className="flex-1 bg-white border border-slate-300 rounded-lg px-2 py-1 text-xs text-slate-800"
                              >
                                <option value="unassigned">Por Asignar</option>
                                {mechanics.map((m) => (
                                  <option key={m.id} value={m.id}>
                                    👨‍🔧 {m.nombre}
                                  </option>
                                ))}
                              </select>
                              <button
                                type="button"
                                onClick={() => setEditingMoId(null)}
                                className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs"
                              >
                                Listo
                              </button>
                            </div>
                          </div>
                        );
                      }

                      return (
                        <div
                          key={mo.id}
                          className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                        >
                          <div className="flex-1 truncate pr-2">
                            <span className="font-medium text-slate-800 block truncate">{mo.concepto}</span>
                            <span className="text-[10px] text-slate-500 font-medium">
                              👨‍🔧 {mo.mecanicoNombre || 'Por Asignar'} • Comisión: {mo.comisionPorcentaje}% (${Math.round(mo.costo * (mo.comisionPorcentaje / 100))})
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono font-bold text-slate-900 mr-1">${mo.costo.toLocaleString()}</span>
                            <button
                              type="button"
                              onClick={() => setEditingMoId(mo.id)}
                              className="p-1 text-slate-400 hover:text-rose-600 rounded"
                              title="Editar este concepto"
                            >
                              <Pencil className="w-3.5 h-3.5 text-rose-600" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setManoObra(manoObra.filter((m) => m.id !== mo.id))}
                              className="p-1 text-slate-400 hover:text-rose-600 rounded"
                              title="Eliminar este concepto"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Agregar Mano de Obra */}
              <div className="pt-2 border-t border-slate-100 flex flex-wrap gap-2">
                <input
                  type="text"
                  placeholder="Concepto de Mano de Obra..."
                  value={nuevoConceptoMO}
                  onChange={(e) => setNuevoConceptoMO(e.target.value)}
                  className="flex-1 min-w-[140px] bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800"
                />
                <input
                  type="number"
                  placeholder="$ Monto"
                  value={nuevoCostoMO || ''}
                  onChange={(e) => setNuevoCostoMO(parseFloat(e.target.value) || 0)}
                  className="w-20 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-mono text-slate-800"
                />
                <select
                  value={nuevoMecanicoId}
                  onChange={(e) => {
                    setNuevoMecanicoId(e.target.value);
                    const found = mechanics.find((m) => m.id === e.target.value);
                    if (found) setNuevaComisionMO(found.comisionDefault);
                  }}
                  className="bg-amber-50 border border-amber-300 rounded-xl px-2 py-1.5 text-xs text-amber-900 font-bold"
                  title="Mecánico asignado"
                >
                  <option value="">-- Mecánico --</option>
                  {mechanics.map((m) => (
                    <option key={m.id} value={m.id}>
                      👨‍🔧 {m.nombre} ({m.comisionDefault}%)
                    </option>
                  ))}
                </select>
                <select
                  value={nuevaComisionMO}
                  onChange={(e) => setNuevaComisionMO(parseInt(e.target.value) || 30)}
                  className="bg-slate-50 border border-slate-200 rounded-xl px-2 py-1.5 text-xs text-slate-700 font-mono"
                  title="Comisión del mecánico"
                >
                  <option value="20">20%</option>
                  <option value="25">25%</option>
                  <option value="30">30%</option>
                  <option value="35">35%</option>
                  <option value="40">40%</option>
                  <option value="45">45%</option>
                </select>
                <button
                  type="button"
                  onClick={handleAddMO}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold"
                >
                  +
                </button>
              </div>
            </div>

            {/* Columna Partes y Refacciones */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <Package className="w-4 h-4 text-emerald-600" />
                    <span>Partes y Refacciones ({partes.length})</span>
                  </h3>
                  <span className="font-mono font-bold text-emerald-600 text-xs">
                    Subtotal: ${subtotalPartes.toLocaleString()} MXN
                  </span>
                </div>

                <div className="space-y-1.5 min-h-[100px] max-h-[220px] overflow-y-auto mb-3">
                  {partes.length === 0 ? (
                    <div className="text-center py-8 text-slate-400 text-xs">
                      Sin partes ni refacciones agregadas
                    </div>
                  ) : (
                    partes.map((p) => {
                      if (editingParteId === p.id) {
                        return (
                          <div
                            key={p.id}
                            className="p-2.5 rounded-xl bg-emerald-50/80 border-2 border-emerald-300 space-y-2 text-xs animate-fadeIn"
                          >
                            <input
                              type="text"
                              value={p.descripcion}
                              onChange={(e) => {
                                const val = e.target.value;
                                setPartes(partes.map((item) => (item.id === p.id ? { ...item, descripcion: val } : item)));
                              }}
                              placeholder="Descripción de la pieza..."
                              className="w-full bg-white border border-slate-300 rounded-lg px-2 py-1 text-xs text-slate-800 font-medium"
                            />
                            <div className="flex items-center gap-2">
                              <input
                                type="number"
                                min={1}
                                value={p.cantidad || ''}
                                onChange={(e) => {
                                  const cant = Math.max(1, Number(e.target.value) || 1);
                                  setPartes(
                                    partes.map((item) =>
                                      item.id === p.id
                                        ? {
                                            ...item,
                                            cantidad: cant,
                                            subtotal: item.origen === 'cliente' ? 0 : cant * item.precioUnitario,
                                          }
                                        : item
                                    )
                                  );
                                }}
                                className="w-16 bg-white border border-slate-300 rounded-lg px-2 py-1 text-xs text-center font-bold"
                                placeholder="Cant"
                              />
                              <input
                                type="number"
                                value={p.precioUnitario || ''}
                                onChange={(e) => {
                                  const precio = Number(e.target.value) || 0;
                                  setPartes(
                                    partes.map((item) =>
                                      item.id === p.id
                                        ? {
                                            ...item,
                                            precioUnitario: precio,
                                            subtotal: item.origen === 'cliente' ? 0 : item.cantidad * precio,
                                          }
                                        : item
                                    )
                                  );
                                }}
                                className="flex-1 bg-white border border-slate-300 rounded-lg px-2 py-1 text-xs font-mono font-bold text-slate-800 text-right"
                                placeholder="$ Unitario"
                              />
                              <button
                                type="button"
                                onClick={() => setEditingParteId(null)}
                                className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs"
                              >
                                Listo
                              </button>
                            </div>
                          </div>
                        );
                      }

                      return (
                        <div
                          key={p.id}
                          className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                        >
                          <div className="flex-1 truncate pr-2">
                            <span className="font-medium text-slate-800 block truncate">
                              {p.cantidad}x {p.descripcion}
                            </span>
                            <span
                              className={`text-[10px] font-semibold ${
                                p.origen === 'cliente' ? 'text-amber-600' : 'text-slate-400'
                              }`}
                            >
                              {p.origen === 'cliente' ? '✓ Traída por cliente ($0 comision)' : 'Surtida por taller'}
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono font-bold text-slate-900 mr-1">
                              {p.origen === 'cliente' ? '$0' : `$${p.subtotal.toLocaleString()}`}
                            </span>
                            <button
                              type="button"
                              onClick={() => setEditingParteId(p.id)}
                              className="p-1 text-slate-400 hover:text-rose-600 rounded"
                              title="Editar esta refacción"
                            >
                              <Pencil className="w-3.5 h-3.5 text-rose-600" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setPartes(partes.filter((part) => part.id !== p.id))}
                              className="p-1 text-slate-400 hover:text-rose-600 rounded"
                              title="Eliminar esta refacción"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Agregar Parte */}
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Descripción pieza..."
                    value={nuevaDescParte}
                    onChange={(e) => setNuevaDescParte(e.target.value)}
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800"
                  />
                  <select
                    value={nuevoOrigenParte}
                    onChange={(e) => setNuevoOrigenParte(e.target.value as any)}
                    className="bg-slate-50 border border-slate-200 rounded-xl px-2 py-1.5 text-xs text-slate-700"
                  >
                    <option value="taller">Taller</option>
                    <option value="cliente">Cliente</option>
                  </select>
                </div>
                <div className="flex gap-2">
                  <input
                    type="number"
                    min="1"
                    placeholder="Cant"
                    value={nuevaCantParte || ''}
                    onChange={(e) => setNuevaCantParte(parseInt(e.target.value) || 1)}
                    className="w-16 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-mono text-slate-800"
                  />
                  <input
                    type="number"
                    placeholder="$ P. Unitario"
                    disabled={nuevoOrigenParte === 'cliente'}
                    value={nuevoOrigenParte === 'cliente' ? 0 : nuevoPrecioParte || ''}
                    onChange={(e) => setNuevoPrecioParte(parseFloat(e.target.value) || 0)}
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-mono text-slate-800 disabled:opacity-50"
                  />
                  <button
                    type="button"
                    onClick={handleAddParte}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold"
                  >
                    + Agregar
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Totales y Facturación */}
          <div className="bg-gradient-to-br from-rose-50/60 to-slate-50 border border-rose-200/80 rounded-2xl p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-1">
              <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-slate-700 font-semibold">
                <input
                  type="checkbox"
                  checked={aplicaIva}
                  onChange={(e) => setAplicaIva(e.target.checked)}
                  className="rounded border-slate-300 text-rose-600 focus:ring-rose-500 w-4 h-4"
                />
                <span>Aplicar 8% IVA Zona Fronteriza (Tijuana - Factura Fiscal)</span>
              </label>
              <div className="flex items-center gap-4 text-xs font-mono text-slate-600 pt-1">
                <span>Mano de Obra: ${subtotalManoObra.toLocaleString()}</span>
                <span>•</span>
                <span>Partes: ${subtotalPartes.toLocaleString()}</span>
                {aplicaIva && (
                  <>
                    <span>•</span>
                    <span className="text-rose-600">IVA 8%: ${ivaMonto.toLocaleString()}</span>
                  </>
                )}
              </div>
            </div>

            <div className="text-right">
              <span className="text-[11px] uppercase font-bold text-slate-500 block">Total Presupuestado:</span>
              <div className="text-2xl sm:text-3xl font-black font-mono text-slate-900 tracking-tight">
                ${totalPresupuesto.toLocaleString()} <span className="text-sm font-bold text-rose-600">MXN</span>
              </div>
            </div>
          </div>
        </div>

        {/* Barra de Acciones */}
        <div className="p-4 sm:p-5 bg-white border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold text-xs transition-colors"
          >
            Cerrar
          </button>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={handleShareWhatsApp}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-all"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Enviar Presupuesto por WhatsApp</span>
            </button>

            <button
              type="button"
              onClick={handleSave}
              className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold text-xs shadow-lg shadow-rose-600/30 transition-all"
            >
              <Save className="w-4 h-4" />
              <span>Guardar Presupuesto en la Orden</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
