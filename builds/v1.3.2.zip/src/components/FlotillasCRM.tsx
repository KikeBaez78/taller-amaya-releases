'use client';

import React, { useState } from 'react';
import { StorageService } from '@/lib/storage';
import { Company, Vehicle } from '@/types';
import {
  Building2,
  Phone,
  Mail,
  MapPin,
  Car,
  AlertTriangle,
  MessageCircle,
  Plus,
  ShieldCheck,
  Calendar,
  Gauge,
  User,
  ExternalLink,
  Edit2,
  Trash2,
  X,
  CheckCircle2,
} from 'lucide-react';

interface FlotillasCRMProps {
  onSelectVehicle?: (vehicle: Vehicle) => void;
  onNewOrderForVehicle?: (vehicle: Vehicle) => void;
}

export const FlotillasCRM: React.FC<FlotillasCRMProps> = ({
  onSelectVehicle,
  onNewOrderForVehicle,
}) => {
  const [companiesList, setCompaniesList] = useState<Company[]>(() => StorageService.getCompanies());
  const [vehiclesList, setVehiclesList] = useState<Vehicle[]>(() => StorageService.getVehicles());

  const companies = companiesList;
  const vehicles = vehiclesList;

  const [selectedCompanyId, setSelectedCompanyId] = useState<string>(companies[0]?.id || '');

  // Modal para dar de alta nueva empresa
  const [isAddingCompany, setIsAddingCompany] = useState(false);
  const [razonSocial, setRazonSocial] = useState('');
  const [rfc, setRfc] = useState('');
  const [encargado, setEncargado] = useState('');
  const [direccion, setDireccion] = useState('');
  const [telefonos, setTelefonos] = useState('');
  const [correos, setCorreos] = useState('');
  const [diasCredito, setDiasCredito] = useState(15);
  const [notas, setNotas] = useState('');

  // Modal para registrar o editar vehículo en la flotilla
  const [isAddingVehicle, setIsAddingVehicle] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);
  const [vPlacas, setVPlacas] = useState('');
  const [vNumeroEconomico, setVNumeroEconomico] = useState('');
  const [vMarca, setVMarca] = useState('');
  const [vModelo, setVModelo] = useState('');
  const [vAno, setVAno] = useState<number>(new Date().getFullYear());
  const [vColor, setVColor] = useState('Blanco');
  const [vChofer, setVChofer] = useState('');
  const [vChoferTel, setVChoferTel] = useState('');
  const [vKm, setVKm] = useState<number>(0);
  const [vVin, setVVin] = useState('');

  const resetVehicleForm = () => {
    setVPlacas('');
    setVNumeroEconomico('');
    setVMarca('');
    setVModelo('');
    setVAno(new Date().getFullYear());
    setVColor('Blanco');
    setVChofer('');
    setVChoferTel('');
    setVKm(0);
    setVVin('');
  };

  const handleOpenEditVehicle = (veh: Vehicle) => {
    setEditingVehicle(veh);
    setVPlacas(veh.placas);
    setVNumeroEconomico(veh.numeroEconomico || '');
    setVMarca(veh.marca);
    setVModelo(veh.modelo);
    setVAno(veh.ano || new Date().getFullYear());
    setVColor(veh.color || 'Blanco');
    setVChofer(veh.choferHabitual || '');
    setVChoferTel(veh.choferTelefono || '');
    setVKm(veh.kilometrajeActual || 0);
    setVVin(veh.vin || '');
    setIsAddingVehicle(true);
  };

  const selectedCompany = companies.find((c) => c.id === selectedCompanyId) || companies[0];

  // Vehículos de la empresa seleccionada
  const companyVehicles = vehicles.filter((v) => v.empresaId === selectedCompany?.id);

  // Vehículos en alerta preventiva general (más de 2 meses o 10,000 km)
  const allAlerts = StorageService.searchBitacora('').filter((r) => r.requiereMantenimiento);

  const handleSaveVehicle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!vPlacas.trim() || !selectedCompany) {
      alert('Por favor introduce las placas del vehículo.');
      return;
    }

    const cleanPlacas = vPlacas.trim().toUpperCase();

    // Buscar si ya existe un vehículo con estas placas
    const existing = vehiclesList.find(
      (v) => v.placas.toUpperCase() === cleanPlacas && v.id !== editingVehicle?.id
    );

    const vehicleId = editingVehicle?.id || existing?.id || `veh-${Date.now()}`;
    const targetClientId = editingVehicle?.clienteId || existing?.clienteId || selectedCompany.id;

    const newVehicle: Vehicle = {
      id: vehicleId,
      clienteId: targetClientId,
      empresaId: selectedCompany.id,
      placas: cleanPlacas,
      numeroEconomico: vNumeroEconomico.trim() || undefined,
      marca: vMarca.trim() || 'Genérica',
      modelo: vModelo.trim() || 'Sedán',
      ano: Number(vAno) || new Date().getFullYear(),
      color: vColor.trim() || 'Blanco',
      choferHabitual: vChofer.trim() || undefined,
      choferTelefono: vChoferTel.trim() || undefined,
      kilometrajeActual: Number(vKm) || 0,
      vin: vVin.trim() || undefined,
      ultimoServicioFecha: editingVehicle?.ultimoServicioFecha || existing?.ultimoServicioFecha,
      ultimoServicioKm: editingVehicle?.ultimoServicioKm || existing?.ultimoServicioKm,
    };

    StorageService.saveVehicle(newVehicle);

    // Sincronizar en segundo plano
    try {
      fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'save_vehicle', vehicle: newVehicle }),
      });
    } catch (err) {}

    const updated = StorageService.getVehicles();
    setVehiclesList(updated);
    setIsAddingVehicle(false);
    setEditingVehicle(null);
    resetVehicleForm();
  };

  const handleSaveCompany = (e: React.FormEvent) => {
    e.preventDefault();
    if (!razonSocial.trim() || !encargado.trim()) {
      alert('Por favor introduce la Razón Social y el nombre del Encargado de Flotilla.');
      return;
    }

    const newCompany: Company = {
      id: `emp-${Date.now()}`,
      razonSocial: razonSocial.trim(),
      rfc: rfc.trim().toUpperCase() || 'XAXX010101000',
      encargadoFlotilla: encargado.trim(),
      direccion: direccion.trim() || 'Tijuana B.C.',
      telefonos: telefonos
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean),
      correos: correos
        .split(',')
        .map((c) => c.trim())
        .filter(Boolean),
      diasCredito: Number(diasCredito) || 15,
      notas: notas.trim(),
      creadoEn: new Date().toISOString().split('T')[0],
    };

    StorageService.saveCompany(newCompany);
    setCompaniesList(StorageService.getCompanies());
    setSelectedCompanyId(newCompany.id);
    setIsAddingCompany(false);
    setRazonSocial('');
    setEncargado('');
    alert(`¡Empresa "${newCompany.razonSocial}" dada de alta exitosamente!`);
  };

  return (
    <div className="space-y-6">
      {/* Banner Principal */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-rose-600 text-xs font-bold uppercase tracking-wider mb-1">
            <Building2 className="w-4 h-4" />
            <span>Gestión de Flotillas Corporativas & Mantenimiento Preventivo</span>
          </div>
          <h2 className="text-2xl font-black text-slate-800">
            CRM de Empresas & Flotas
          </h2>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            Control de empresas con múltiples vehículos, choferes asignados, teléfonos y correos múltiples, con <strong>alertas preventivas automáticas cada 2 meses o 10,000 km</strong>.
          </p>
        </div>

        <button
          onClick={() => setIsAddingCompany(true)}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-sm shadow-md transition-all active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>Dar de Alta Empresa</span>
        </button>
      </div>

      {/* Grid Principal: Lista de Empresas a la izquierda, Detalle a la derecha */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Selector de Empresas */}
        <div className="lg:col-span-4 space-y-3">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider px-1">
            Empresas Registradas ({companies.length})
          </div>

          {companies.map((comp) => {
            const isSelected = comp.id === selectedCompanyId;
            const countVeh = vehicles.filter((v) => v.empresaId === comp.id).length;

            return (
              <div
                key={comp.id}
                onClick={() => setSelectedCompanyId(comp.id)}
                className={`bg-white border rounded-2xl p-4 cursor-pointer transition-all hover:border-rose-400 hover:shadow-md ${
                  isSelected
                    ? 'border-rose-500 ring-2 ring-rose-500/20 bg-rose-50/20 shadow-sm'
                    : 'border-slate-200'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold text-slate-800 text-sm mb-0.5">{comp.razonSocial}</h3>
                    <span className="font-mono text-xs text-rose-600 font-semibold block">
                      RFC: {comp.rfc}
                    </span>
                    <span className="text-xs text-slate-500 mt-1 block">
                      Encargado: <strong className="text-slate-700">{comp.encargadoFlotilla}</strong>
                    </span>
                  </div>

                  <span className="font-mono text-xs font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                    {countVeh} autos
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Detalle de la Empresa y sus Vehículos */}
        {selectedCompany && (
          <div className="lg:col-span-8 space-y-6">
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
              {/* Encabezado */}
              <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-slate-100">
                <div>
                  <span className="text-xs font-mono font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                    RFC: {selectedCompany.rfc}
                  </span>
                  <h3 className="text-xl font-bold text-slate-800 mt-1">
                    {selectedCompany.razonSocial}
                  </h3>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1">
                    <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                    <span>{selectedCompany.direccion}</span>
                  </div>
                </div>

                <div className="bg-slate-50 px-3.5 py-2 rounded-xl border border-slate-200 text-right text-xs">
                  <span className="text-slate-500 block font-medium">Condición de Pago:</span>
                  <span className="font-bold text-amber-600">
                    Crédito {selectedCompany.diasCredito || 15} Días
                  </span>
                </div>
              </div>

              {/* Ficha de Contactos Múltiples */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 my-4 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
                <div>
                  <span className="text-slate-500 block font-medium">Encargado de Flotilla:</span>
                  <span className="font-bold text-slate-800 text-sm">
                    {selectedCompany.encargadoFlotilla}
                  </span>
                  <div className="mt-2 space-y-1">
                    <span className="text-slate-500 block">Teléfonos de Contacto:</span>
                    {selectedCompany.telefonos.map((tel, i) => (
                      <div key={i} className="flex items-center gap-1 text-slate-700 font-mono">
                        <Phone className="w-3 h-3 text-rose-600" />
                        <span>{tel}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="text-slate-500 block font-medium">Correos Electrónicos:</span>
                  <div className="mt-1 space-y-1">
                    {selectedCompany.correos.map((correo, i) => (
                      <div key={i} className="flex items-center gap-1 text-slate-700">
                        <Mail className="w-3 h-3 text-rose-600" />
                        <span>{correo}</span>
                      </div>
                    ))}
                  </div>
                  {selectedCompany.notas && (
                    <div className="mt-3 p-2 bg-white rounded border border-slate-200 text-[11px] text-slate-600">
                      <strong>Notas:</strong> {selectedCompany.notas}
                    </div>
                  )}
                </div>
              </div>

              {/* Lista de Vehículos de la Flotilla */}
              <div>
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                  <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
                    <Car className="w-4 h-4 text-rose-600" />
                    <span>Vehículos Registrados en esta Flota ({companyVehicles.length})</span>
                  </h4>

                  <button
                    type="button"
                    onClick={() => {
                      setEditingVehicle(null);
                      resetVehicleForm();
                      setIsAddingVehicle(true);
                    }}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-sm transition-all cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5 text-rose-400" />
                    <span>+ Registrar Unidad a esta Flotilla</span>
                  </button>
                </div>

                {companyVehicles.length === 0 ? (
                  <div className="bg-slate-50 p-6 rounded-2xl border border-dashed border-slate-300 text-center space-y-2">
                    <Car className="w-8 h-8 text-slate-400 mx-auto" />
                    <p className="text-xs text-slate-600 font-semibold">
                      No hay vehículos registrados para esta empresa todavía.
                    </p>
                    <p className="text-[11px] text-slate-400 max-w-sm mx-auto">
                      Da de alta las unidades con anticipación para que cuando lleguen a recepción solo tengas que preseleccionarlas con un clic.
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        setEditingVehicle(null);
                        resetVehicleForm();
                        setIsAddingVehicle(true);
                      }}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-sm mt-2 cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Dar de Alta Primer Vehículo</span>
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {companyVehicles.map((veh) => {
                      // Comprobar alerta de 2 meses o 10,000 km
                      let hasAlert = false;
                      let alertText = '';
                      if (veh.ultimoServicioFecha) {
                        const m = (Date.now() - new Date(veh.ultimoServicioFecha).getTime()) / (1000 * 60 * 60 * 24 * 30.4);
                        if (m >= 2) {
                          hasAlert = true;
                          alertText = `Hace ${Math.floor(m)} meses`;
                        }
                      }
                      if (veh.ultimoServicioKm && veh.kilometrajeActual - veh.ultimoServicioKm >= 10000) {
                        hasAlert = true;
                        alertText += (alertText ? ' / ' : '') + `>10,000 km`;
                      }

                      return (
                        <div
                          key={veh.id}
                          className="bg-white border border-slate-200 rounded-xl p-3.5 hover:border-rose-300 transition-colors shadow-sm flex flex-col justify-between"
                        >
                          <div>
                            <div className="flex items-start justify-between gap-2">
                              <div>
                                <div className="flex flex-wrap items-center gap-1.5">
                                  <span className="font-mono font-black text-sm bg-rose-50 text-rose-700 px-2 py-0.5 rounded border border-rose-200">
                                    {veh.placas}
                                  </span>
                                  {veh.numeroEconomico && (
                                    <span className="font-mono text-xs font-black bg-slate-900 text-amber-300 px-2 py-0.5 rounded-md border border-slate-800 shadow-xs">
                                      {veh.numeroEconomico}
                                    </span>
                                  )}
                                  <span className="font-bold text-slate-800 text-xs">
                                    {veh.marca} {veh.modelo} {veh.ano ? `(${veh.ano})` : ''}
                                  </span>
                                </div>

                                <span className="text-[11px] text-slate-500 block mt-1.5">
                                  Chofer: <strong className="text-slate-700">{veh.choferHabitual || 'Sin chofer habitual'}</strong>
                                  {veh.choferTelefono && ` • ${veh.choferTelefono}`}
                                </span>
                                <span className="text-[11px] font-mono text-slate-500 block mt-0.5">
                                  Odómetro: {veh.kilometrajeActual.toLocaleString()} km
                                  {veh.color && ` • Color: ${veh.color}`}
                                </span>
                              </div>

                              <div className="flex flex-col items-end gap-1 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => handleOpenEditVehicle(veh)}
                                  className="p-1.5 text-slate-400 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                                  title="Editar información de esta unidad"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>

                                {hasAlert && (
                                  <span
                                    className="flex items-center gap-1 text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200"
                                    title="Alerta preventiva (2 meses / 10,000 km)"
                                  >
                                    <AlertTriangle className="w-3 h-3 text-amber-600" />
                                    <span>{alertText}</span>
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="flex flex-wrap items-center justify-between gap-2 mt-3 pt-2.5 border-t border-slate-100 text-xs">
                            <div className="flex items-center gap-2">
                              {onSelectVehicle && (
                                <button
                                  type="button"
                                  onClick={() => onSelectVehicle(veh)}
                                  className="text-slate-600 hover:text-rose-600 font-semibold text-[11px]"
                                >
                                  Ver Bitácora
                                </button>
                              )}

                              {hasAlert && (
                                <a
                                  href={StorageService.generateWhatsAppReminder(
                                    veh,
                                    selectedCompany.encargadoFlotilla,
                                    selectedCompany.telefonos[0] || '6644093068',
                                    alertText
                                  )}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[10px] font-bold shadow-xs"
                                >
                                  <MessageCircle className="w-3 h-3" />
                                  <span>Avisar WA</span>
                                </a>
                              )}
                            </div>

                            {onNewOrderForVehicle && (
                              <button
                                type="button"
                                onClick={() => onNewOrderForVehicle(veh)}
                                className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-black shadow-sm transition-transform active:scale-95 cursor-pointer"
                                title="Crear Orden de Servicio en Check-in con este vehículo"
                              >
                                <Car className="w-3.5 h-3.5" />
                                <span>Recibir a Servicio</span>
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* TABLERO DE RECORDATORIOS PREVENTIVOS GENERALES */}
            <div className="bg-white border border-amber-200 rounded-2xl p-6 shadow-sm">
              <div className="flex items-center gap-2 text-amber-700 font-bold text-xs uppercase tracking-wider mb-2">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <span>Panel de Alertas de Mantenimiento Preventivo (Regla: 2 Meses o 10,000 Km)</span>
              </div>
              <h3 className="text-base font-bold text-slate-800 mb-4">
                Vehículos con Servicio Sugerido Pendiente ({allAlerts.length})
              </h3>

              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {allAlerts.map((rec) => (
                  <div
                    key={rec.vehicle.id}
                    className="flex flex-wrap items-center justify-between gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                          {rec.vehicle.placas}
                        </span>
                        <strong className="text-slate-800">
                          {rec.vehicle.marca} {rec.vehicle.modelo}
                        </strong>
                        <span className="text-slate-500">
                          ({rec.company ? rec.company.razonSocial : rec.client?.nombre})
                        </span>
                      </div>
                      <span className="text-[11px] text-amber-700 font-semibold block mt-1">
                        ⚠️ {rec.motivoAlerta}
                      </span>
                    </div>

                    <a
                      href={StorageService.generateWhatsAppReminder(
                        rec.vehicle,
                        rec.client?.nombre || rec.company?.encargadoFlotilla || 'Cliente',
                        rec.client?.telefono || rec.company?.telefonos[0] || '6644093068',
                        rec.motivoAlerta
                      )}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-sm"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>Enviar Recordatorio por WhatsApp</span>
                    </a>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* MODAL PARA DAR DE ALTA EMPRESA */}
      {isAddingCompany && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-xl w-full p-6 shadow-2xl text-slate-800">
            <h3 className="text-lg font-bold text-slate-800 mb-1">
              Dar de Alta Empresa / Flotilla
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Registra los datos fiscales, encargado y contactos múltiples para el CRM
            </p>

            <form onSubmit={handleSaveCompany} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="text-xs text-slate-600 block mb-1 font-medium">
                    Razón Social *:
                  </label>
                  <input
                    type="text"
                    value={razonSocial}
                    onChange={(e) => setRazonSocial(e.target.value)}
                    placeholder="Ej. TRANSPORTES DEL PACIFICO S.A. DE C.V."
                    required
                    className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none uppercase"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-600 block mb-1 font-medium">RFC:</label>
                  <input
                    type="text"
                    value={rfc}
                    onChange={(e) => setRfc(e.target.value.toUpperCase())}
                    placeholder="TPA190204KL8"
                    className="w-full bg-slate-50 border border-slate-300 text-slate-800 font-mono rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-600 block mb-1 font-medium">
                    Encargado de Flotilla *:
                  </label>
                  <input
                    type="text"
                    value={encargado}
                    onChange={(e) => setEncargado(e.target.value)}
                    placeholder="Ej. Lic. Fernando Orozco"
                    required
                    className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="text-xs text-slate-600 block mb-1 font-medium">
                    Dirección Física:
                  </label>
                  <input
                    type="text"
                    value={direccion}
                    onChange={(e) => setDireccion(e.target.value)}
                    placeholder="Blvd. Insurgentes #14200, Tijuana B.C."
                    className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-600 block mb-1 font-medium">
                    Teléfonos (separados por coma):
                  </label>
                  <input
                    type="text"
                    value={telefonos}
                    onChange={(e) => setTelefonos(e.target.value)}
                    placeholder="664-987-6543, 664-210-9876"
                    className="w-full bg-slate-50 border border-slate-300 text-slate-800 font-mono rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-600 block mb-1 font-medium">
                    Correos Electrónicos (separados por coma):
                  </label>
                  <input
                    type="text"
                    value={correos}
                    onChange={(e) => setCorreos(e.target.value)}
                    placeholder="flotilla@empresa.com, pagos@empresa.com"
                    className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg px-3 py-2 text-sm focus:border-rose-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1 font-medium">
                  Notas / Observaciones de Flotilla:
                </label>
                <textarea
                  value={notas}
                  onChange={(e) => setNotas(e.target.value)}
                  placeholder="Instrucciones especiales para choferes, facturación, etc."
                  rows={2}
                  className="w-full bg-slate-50 border border-slate-300 text-slate-800 rounded-lg p-2.5 text-xs focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddingCompany(false)}
                  className="flex-1 py-2 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-all active:scale-95"
                >
                  Guardar Empresa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* MODAL PARA DAR DE ALTA / EDITAR VEHÍCULO DE FLOTILLA */}
      {isAddingVehicle && selectedCompany && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white border border-slate-200 rounded-3xl max-w-lg w-full p-6 shadow-2xl text-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center shadow-xs">
                  <Car className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    {editingVehicle ? 'Editar Unidad de Flotilla' : 'Registrar Unidad en Flotilla'}
                  </h3>
                  <span className="text-xs text-rose-600 font-bold block">
                    Empresa: {selectedCompany.razonSocial}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsAddingVehicle(false);
                  setEditingVehicle(null);
                }}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveVehicle} className="space-y-3.5 mt-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">
                    Placas del Vehículo *:
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="BJE-849-A"
                    value={vPlacas}
                    onChange={(e) => setVPlacas(e.target.value.toUpperCase())}
                    className="w-full bg-slate-50 border border-slate-300 font-mono font-black text-slate-900 text-sm rounded-xl px-3 py-2 uppercase tracking-wider focus:outline-none focus:border-rose-500"
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">
                    No. Económico / Unidad:
                  </label>
                  <input
                    type="text"
                    placeholder="Ej. Eco-04, Unidad 12"
                    value={vNumeroEconomico}
                    onChange={(e) => setVNumeroEconomico(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 font-bold text-slate-900 rounded-xl px-3 py-2 focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2.5">
                <div>
                  <label className="text-slate-600 font-medium block mb-1">Marca:</label>
                  <input
                    type="text"
                    placeholder="Nissan / Toyota"
                    value={vMarca}
                    onChange={(e) => setVMarca(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 focus:outline-none focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="text-slate-600 font-medium block mb-1">Modelo:</label>
                  <input
                    type="text"
                    placeholder="Urvan / Versa / Hilux"
                    value={vModelo}
                    onChange={(e) => setVModelo(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 focus:outline-none focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="text-slate-600 font-medium block mb-1">Año:</label>
                  <input
                    type="number"
                    value={vAno || ''}
                    onChange={(e) => setVAno(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 font-mono focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-600 font-medium block mb-1">Color:</label>
                  <input
                    type="text"
                    placeholder="Blanco, Gris, etc."
                    value={vColor}
                    onChange={(e) => setVColor(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 focus:outline-none focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="text-slate-600 font-medium block mb-1">Kilometraje Inicial / Odómetro:</label>
                  <input
                    type="number"
                    value={vKm || ''}
                    onChange={(e) => setVKm(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 font-mono focus:outline-none focus:border-rose-500"
                    placeholder="0"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1 border-t border-slate-100">
                <div>
                  <label className="text-slate-600 font-medium block mb-1">Chofer Habitual (Opcional):</label>
                  <input
                    type="text"
                    placeholder="Nombre del chofer"
                    value={vChofer}
                    onChange={(e) => setVChofer(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 focus:outline-none focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="text-slate-600 font-medium block mb-1">Celular del Chofer:</label>
                  <input
                    type="tel"
                    placeholder="664-000-0000"
                    value={vChoferTel}
                    onChange={(e) => setVChoferTel(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 font-mono focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-600 font-medium block mb-1">VIN / Número de Serie (Opcional):</label>
                <input
                  type="text"
                  placeholder="3N1AB7AP8KY123456"
                  value={vVin}
                  onChange={(e) => setVVin(e.target.value.toUpperCase())}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 font-mono uppercase focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="flex gap-2.5 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddingVehicle(false);
                    setEditingVehicle(null);
                  }}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-black shadow-md shadow-rose-600/30 transition-all cursor-pointer"
                >
                  {editingVehicle ? 'Guardar Cambios' : 'Registrar en Flotilla'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
