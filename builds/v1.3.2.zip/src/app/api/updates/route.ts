import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import {
  getCurrentVersionInfo,
  checkRemoteForUpdates,
  recordAppliedVersion,
  RemoteUpdateManifest,
} from '@/lib/updates';
import { BackupService } from '@/lib/backupService';

export const dynamic = 'force-dynamic';

function getAppRootDir(): string {
  const cwd = process.cwd();
  if (fs.existsSync(path.join(cwd, 'ACTUALIZAR-TALLER.bat')) || fs.existsSync(path.join(cwd, 'package.json'))) {
    return cwd;
  }
  const twoUp = path.resolve(cwd, '..', '..');
  if (fs.existsSync(path.join(twoUp, 'ACTUALIZAR-TALLER.bat')) || fs.existsSync(path.join(twoUp, 'package.json'))) {
    return twoUp;
  }
  const oneUp = path.resolve(cwd, '..');
  if (fs.existsSync(path.join(oneUp, 'ACTUALIZAR-TALLER.bat')) || fs.existsSync(path.join(oneUp, 'package.json'))) {
    return oneUp;
  }
  return cwd;
}

export async function GET(request: Request) {
  try {
    const checkResult = await checkRemoteForUpdates();
    return NextResponse.json(checkResult);
  } catch (error) {
    console.error('Error en /api/updates GET:', error);
    const current = getCurrentVersionInfo();
    return NextResponse.json({
      hasUpdate: false,
      currentVersion: current.version,
      offline: true,
      error: 'No se pudo conectar al servidor de actualizaciones.',
    });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, pin, targetVersion } = body;

    const currentInfo = getCurrentVersionInfo();

    // 1. Verificación de seguridad: Solo el dueño con PIN puede aplicar actualizaciones
    const requiredPin = currentInfo.ownerPin || '2036';
    if (!pin || String(pin).trim() !== requiredPin) {
      return NextResponse.json(
        {
          success: false,
          message: 'PIN del propietario incorrecto. Solo el dueño puede autorizar la actualización.',
        },
        { status: 403 }
      );
    }

    if (action === 'apply_update') {
      const nextVer = targetVersion || '1.1.0';

      // 1. Obtener la URL de descarga del manifiesto remoto
      const remoteCheck = await checkRemoteForUpdates();
      const downloadUrl =
        remoteCheck.remoteInfo?.downloadUrl ||
        `https://raw.githubusercontent.com/kikebaez78/taller-amaya-releases/main/builds/v${nextVer}.zip`;

      // 2. Descargar e instalar los archivos por internet (OTA)
      let installSuccess = false;
      try {
        console.log(`[OTA] Descargando actualización v${nextVer} desde ${downloadUrl}...`);
        const res = await fetch(downloadUrl, { cache: 'no-store' });
        if (res.ok) {
          const buffer = Buffer.from(await res.arrayBuffer());
          const rootDir = getAppRootDir();
          const targetPaths = [
            path.join(rootDir, 'temp_ota_update.zip'),
            path.join(process.cwd(), 'temp_ota_update.zip'),
          ];

          for (const tPath of Array.from(new Set(targetPaths))) {
            try {
              fs.writeFileSync(tPath, buffer);
            } catch (wErr) {}
          }

          // Respaldar base de datos y licencia antes de extraer
          try {
            BackupService.createManualBackup('pre_actualizacion_ota');
          } catch {}

          // Si es Windows, lanzar el actualizador desacoplado para liberar bloqueos de archivos en Node
          if (process.platform === 'win32') {
            const possibleBatPaths = [
              path.join(rootDir, 'scripts', 'aplicar-actualizacion-silenciosa.bat'),
              path.join(process.cwd(), 'scripts', 'aplicar-actualizacion-silenciosa.bat'),
            ];
            const batPath = possibleBatPaths.find(p => fs.existsSync(p));
            if (batPath) {
              const { spawn } = require('child_process');
              const child = spawn('cmd.exe', ['/c', batPath], {
                detached: true,
                stdio: 'ignore',
                windowsHide: true,
                cwd: rootDir,
              });
              child.unref();
            }
          } else {
            // En macOS / Linux
            try {
              const zipToExtract = path.join(rootDir, 'temp_ota_update.zip');
              if (fs.existsSync(zipToExtract)) {
                execSync(`unzip -o "${zipToExtract}" -d "${rootDir}"`, {
                  timeout: 30000,
                  stdio: 'ignore',
                });
                fs.unlinkSync(zipToExtract);
              }
            } catch (unzipErr) {
              console.error('[OTA] Error al descomprimir en unix:', unzipErr);
            }
          }

          installSuccess = true;
          console.log(`[OTA] ¡Actualización v${nextVer} descargada e invocada con éxito!`);
        }
      } catch (err) {
        console.error('[OTA] Error durante descarga o instalación:', err);
      }

      // 3. Asentar nueva versión en el manifiesto local
      const updated = recordAppliedVersion(nextVer);

      return NextResponse.json({
        success: true,
        restarting: true,
        message: `¡Sistema actualizado exitosamente a la versión ${nextVer}! El servidor se reiniciará automáticamente.`,
        newVersion: updated?.version || nextVer,
        installed: installSuccess,
      });
    }

    return NextResponse.json(
      { success: false, message: 'Acción no reconocida' },
      { status: 400 }
    );
  } catch (error) {
    console.error('Error en /api/updates POST:', error);
    return NextResponse.json(
      { success: false, message: 'Ocurrió un error al procesar la actualización.' },
      { status: 500 }
    );
  }
}
