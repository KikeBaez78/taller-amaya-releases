import fs from 'fs';
import path from 'path';

/**
 * Localiza de forma canónica y determinista la raíz del proyecto Taller Amaya
 * tanto en desarrollo local como en producción standalone dentro de .next/standalone
 */
export function getAppRootDir(): string {
  const cwd = process.cwd();

  // 1. Si cwd incluye .next/standalone o estamos dentro
  if (cwd.includes('.next') && cwd.includes('standalone')) {
    const candidate = path.resolve(cwd, '..', '..');
    if (
      fs.existsSync(path.join(candidate, 'INICIAR-TALLER-AMAYA.bat')) ||
      fs.existsSync(path.join(candidate, 'ACTUALIZAR-TALLER.bat')) ||
      fs.existsSync(path.join(candidate, 'src', 'data')) ||
      fs.existsSync(path.join(candidate, 'package.json'))
    ) {
      return candidate;
    }
  }

  // 2. Si cwd tiene los marcadores clave de la raíz
  if (
    fs.existsSync(path.join(cwd, 'INICIAR-TALLER-AMAYA.bat')) ||
    fs.existsSync(path.join(cwd, 'ACTUALIZAR-TALLER.bat')) ||
    (fs.existsSync(path.join(cwd, 'src')) && fs.existsSync(path.join(cwd, 'public')))
  ) {
    return cwd;
  }

  // 3. Fallback subiendo 1 o 2 niveles
  const upOne = path.resolve(cwd, '..');
  if (
    fs.existsSync(path.join(upOne, 'INICIAR-TALLER-AMAYA.bat')) ||
    fs.existsSync(path.join(upOne, 'src', 'data'))
  ) {
    return upOne;
  }

  const upTwo = path.resolve(cwd, '..', '..');
  if (
    fs.existsSync(path.join(upTwo, 'INICIAR-TALLER-AMAYA.bat')) ||
    fs.existsSync(path.join(upTwo, 'src', 'data'))
  ) {
    return upTwo;
  }

  return cwd;
}

export function getDbFilePath(): string {
  const rootDir = getAppRootDir();
  const canonicalPath = path.join(rootDir, 'src', 'data', 'db.json');
  if (fs.existsSync(canonicalPath)) {
    return canonicalPath;
  }
  // Buscar si existiera en cwd
  const cwdPath = path.join(process.cwd(), 'src', 'data', 'db.json');
  if (fs.existsSync(cwdPath)) {
    return cwdPath;
  }
  return canonicalPath;
}

export function getLicenseFilePath(): string {
  const rootDir = getAppRootDir();
  const canonicalPath = path.join(rootDir, 'src', 'data', 'license.json');
  if (fs.existsSync(canonicalPath)) {
    return canonicalPath;
  }
  const cwdPath = path.join(process.cwd(), 'src', 'data', 'license.json');
  if (fs.existsSync(cwdPath)) {
    return cwdPath;
  }
  return canonicalPath;
}

export function getBackupsDir(): string {
  const rootDir = getAppRootDir();
  const backupsPath = path.join(rootDir, 'src', 'data', 'backups');
  if (!fs.existsSync(backupsPath)) {
    try {
      fs.mkdirSync(backupsPath, { recursive: true });
    } catch {}
  }
  return backupsPath;
}

/**
 * Escritura atómica a prueba de fallos y de concurrencia en Windows
 */
export function atomicWriteJson(filePath: string, data: any): void {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    try {
      fs.mkdirSync(dir, { recursive: true });
    } catch {}
  }

  const content = JSON.stringify(data, null, 2);
  const tempPath = `${filePath}.tmp.${Date.now()}.${Math.random().toString(36).slice(2, 6)}`;

  try {
    fs.writeFileSync(tempPath, content, 'utf-8');
    fs.renameSync(tempPath, filePath);
  } catch (err) {
    try {
      fs.copyFileSync(tempPath, filePath);
      if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
    } catch {
      // Fallback directo
      fs.writeFileSync(filePath, content, 'utf-8');
    }
  }
}
