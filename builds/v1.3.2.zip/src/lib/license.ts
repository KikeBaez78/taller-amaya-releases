import os from 'os';
import { execSync } from 'child_process';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { getLicenseFilePath } from './dbConfig';

// Clave secreta maestra para firmar criptográficamente las licencias
// Solo tú (desarrollador) conoces esta clave para generar claves válidas
const MASTER_SECRET = 'AMAYA_SECURE_HMAC_MASTER_LICENSE_KEY_2026_TIJUANA_BC';

export interface LicenseData {
  machineId: string;
  activationKey: string;
  clientName?: string;
  activatedAt?: string;
  status: 'active' | 'inactive';
}

/**
 * Obtiene el identificador único del hardware físico de la máquina
 * (Motherboard UUID, CPU ID, etc.) garantizando que no pueda clonarse.
 */
export function getMachineHardwareId(): string {
  let raw = '';

  try {
    if (process.platform === 'win32') {
      // 1. Intentar por PowerShell CIM (Windows 10, 11 y Server)
      try {
        raw = execSync('powershell -NoProfile -Command "(Get-CimInstance Win32_ComputerSystemProduct).UUID"', {
          timeout: 4000,
          stdio: ['ignore', 'pipe', 'ignore'],
        }).toString().trim();
      } catch {
        // Fallback clásico WMI
        try {
          raw = execSync('wmic csproduct get uuid', {
            timeout: 4000,
            stdio: ['ignore', 'pipe', 'ignore'],
          }).toString().replace(/UUID/gi, '').trim();
        } catch {
          // Fallback a número de serie de volumen
          raw = execSync('vol C:', { timeout: 3000, stdio: ['ignore', 'pipe', 'ignore'] }).toString().trim();
        }
      }
    } else if (process.platform === 'darwin') {
      // macOS: IOPlatformUUID físico
      try {
        const out = execSync('ioreg -rd1 -c IOPlatformExpertDevice', { timeout: 4000 }).toString();
        const match = out.match(/"IOPlatformUUID"\s*=\s*"([^"]+)"/i);
        if (match && match[1]) {
          raw = match[1].trim();
        }
      } catch {
        raw = execSync('system_profiler SPHardwareDataType | grep "Hardware UUID"', { timeout: 4000 }).toString().trim();
      }
    } else {
      // Linux
      try {
        raw = fs.readFileSync('/etc/machine-id', 'utf8').trim();
      } catch {
        raw = fs.readFileSync('/var/lib/dbus/machine-id', 'utf8').trim();
      }
    }
  } catch (err) {
    console.warn('Fallback para detección de hardware:', err);
  }

  // Si por alguna razón el sistema operativo no devolvió nada, combinar características físicas
  if (!raw || raw.length < 5) {
    const cpus = os.cpus();
    raw = `${os.hostname()}_${cpus[0]?.model || 'cpu'}_${cpus.length}_${os.totalmem()}_${os.arch()}`;
  }

  // Hash SHA-256 formateado como AMAYA-XXXX-XXXX-XXXX-XXXX
  const hash = crypto
    .createHash('sha256')
    .update(`TALLER_AMAYA_HARDWARE_SALT_2026:${raw.trim().toUpperCase()}`)
    .digest('hex')
    .toUpperCase();

  return `AMAYA-${hash.substring(0, 4)}-${hash.substring(4, 8)}-${hash.substring(8, 12)}-${hash.substring(12, 16)}`;
}

/**
 * Calcula la clave criptográfica válida para un Machine ID dado
 */
export function generateKeyForMachine(machineId: string): string {
  const cleanId = machineId.trim().toUpperCase();
  const signature = crypto
    .createHmac('sha256', MASTER_SECRET)
    .update(cleanId)
    .digest('hex')
    .toUpperCase();

  return `KEY-AMAYA-${signature.substring(0, 4)}-${signature.substring(4, 8)}-${signature.substring(8, 12)}-${signature.substring(12, 16)}`;
}

/**
 * Verifica si una clave ingresada es matemáticamente válida para este equipo
 */
export function verifyActivationKey(machineId: string, enteredKey: string): boolean {
  if (!enteredKey) return false;
  const expectedKey = generateKeyForMachine(machineId);
  const cleanEntered = enteredKey.trim().toUpperCase();

  return cleanEntered === expectedKey;
}

/**
 * Lee el archivo de licencia local guardado
 */
export function readLicenseFile(): LicenseData | null {
  try {
    const licPath = getLicenseFilePath();
    if (!fs.existsSync(licPath)) {
      return null;
    }
    const raw = fs.readFileSync(licPath, 'utf8');
    return JSON.parse(raw) as LicenseData;
  } catch (e) {
    return null;
  }
}

/**
 * Guarda una licencia verificada en el disco
 */
export function saveLicenseFile(license: LicenseData) {
  try {
    const licPath = getLicenseFilePath();
    const dir = path.dirname(licPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(licPath, JSON.stringify(license, null, 2), 'utf8');
  } catch (e) {
    console.error('Error al guardar archivo de licencia:', e);
  }
}

/**
 * Estado general de la licencia en este momento exacto
 */
export function checkLicenseStatus(): {
  isActivated: boolean;
  machineId: string;
  clientName?: string;
  activatedAt?: string;
  reason?: string;
} {
  const currentMachineId = getMachineHardwareId();
  const savedLicense = readLicenseFile();

  if (!savedLicense) {
    return {
      isActivated: false,
      machineId: currentMachineId,
      reason: 'No hay licencia instalada en este equipo.',
    };
  }

  // 1. Candado anti-clonación: ¿El Hardware ID coincide exactamente con la máquina actual?
  if (savedLicense.machineId !== currentMachineId) {
    return {
      isActivated: false,
      machineId: currentMachineId,
      reason: 'El software ha sido copiado o clonado a un equipo diferente no autorizado.',
    };
  }

  // 2. Validación matemática criptográfica
  if (!verifyActivationKey(currentMachineId, savedLicense.activationKey)) {
    return {
      isActivated: false,
      machineId: currentMachineId,
      reason: 'La clave de activación registrada no es válida para este equipo.',
    };
  }

  return {
    isActivated: true,
    machineId: currentMachineId,
    clientName: savedLicense.clientName || 'Taller Amaya Oficial',
    activatedAt: savedLicense.activatedAt,
  };
}
