import fs from 'fs';
import path from 'path';
import { getDbFilePath, getBackupsDir, atomicWriteJson } from './dbConfig';

const MAX_BACKUP_DAYS = 30;

export interface BackupFileInfo {
  filename: string;
  sizeBytes: number;
  sizeFormatted: string;
  createdAt: string;
  isToday: boolean;
  type: 'diario' | 'manual' | 'seguridad';
}

function ensureBackupsDir(): string {
  return getBackupsDir();
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function getTodayString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export const BackupService = {
  getBackupsDir(): string {
    return ensureBackupsDir();
  },

  /**
   * Genera el respaldo diario automático y rota snapshots viejos (> 30 días)
   */
  performDailyAutoBackup(dbData?: any): string | null {
    try {
      const backupsDir = ensureBackupsDir();
      const today = getTodayString();
      const backupPath = path.join(backupsDir, `db_backup_${today}.json`);
      const dbPath = getDbFilePath();

      let dataToSave: string;
      if (dbData) {
        dataToSave = JSON.stringify(dbData, null, 2);
      } else if (fs.existsSync(dbPath)) {
        dataToSave = fs.readFileSync(dbPath, 'utf-8');
      } else {
        return null;
      }

      atomicWriteJson(backupPath, JSON.parse(dataToSave));

      // Rotación: eliminar respaldos con más de MAX_BACKUP_DAYS días
      this.cleanupOldBackups();

      return `db_backup_${today}.json`;
    } catch (err) {
      console.error('Error during performDailyAutoBackup:', err);
      return null;
    }
  },

  /**
   * Crea un respaldo manual inmediato (a petición del usuario o antes de cambios críticos)
   */
  createManualBackup(label = 'manual', dbData?: any): string | null {
    try {
      const backupsDir = ensureBackupsDir();
      const d = new Date();
      const timestamp = `${getTodayString()}_${String(d.getHours()).padStart(2, '0')}${String(
        d.getMinutes()
      ).padStart(2, '0')}${String(d.getSeconds()).padStart(2, '0')}`;
      const filename = `db_backup_${timestamp}_${label}.json`;
      const backupPath = path.join(backupsDir, filename);
      const dbPath = getDbFilePath();

      let dataToSave: any;
      if (dbData) {
        dataToSave = dbData;
      } else if (fs.existsSync(dbPath)) {
        dataToSave = JSON.parse(fs.readFileSync(dbPath, 'utf-8'));
      } else {
        return null;
      }

      atomicWriteJson(backupPath, dataToSave);
      return filename;
    } catch (err) {
      console.error('Error creating manual backup:', err);
      return null;
    }
  },

  /**
   * Lista todos los respaldos existentes en disco ordenados del más nuevo al más antiguo
   */
  listBackups(): BackupFileInfo[] {
    try {
      const backupsDir = ensureBackupsDir();
      const files = fs.readdirSync(backupsDir);
      const today = getTodayString();

      const backups: BackupFileInfo[] = files
        .filter((f) => f.startsWith('db_backup_') && f.endsWith('.json'))
        .map((filename) => {
          const fullPath = path.join(backupsDir, filename);
          const stats = fs.statSync(fullPath);
          const isToday = filename.includes(today);

          let type: 'diario' | 'manual' | 'seguridad' = 'diario';
          if (filename.includes('manual')) type = 'manual';
          else if (filename.includes('pre_reset') || filename.includes('seguridad')) type = 'seguridad';

          return {
            filename,
            sizeBytes: stats.size,
            sizeFormatted: formatBytes(stats.size),
            createdAt: stats.mtime.toISOString(),
            isToday,
            type,
          };
        });

      return backups.sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    } catch (err) {
      console.error('Error listing backups:', err);
      return [];
    }
  },

  /**
   * Obtiene la ruta de un archivo de respaldo específico
   */
  getBackupFilePath(filename: string): string | null {
    const backupsDir = ensureBackupsDir();
    const safeFilename = path.basename(filename);
    const fullPath = path.join(backupsDir, safeFilename);
    if (fs.existsSync(fullPath)) {
      return fullPath;
    }
    return null;
  },

  /**
   * Lee la base de datos actual para descarga directa
   */
  getCurrentDb(): any {
    const dbPath = getDbFilePath();
    if (!fs.existsSync(dbPath)) return null;
    try {
      const raw = fs.readFileSync(dbPath, 'utf-8');
      return JSON.parse(raw);
    } catch {
      return null;
    }
  },

  /**
   * Restaura la base de datos desde un archivo de respaldo
   */
  restoreBackup(filename: string): { success: boolean; message: string } {
    try {
      const fullPath = this.getBackupFilePath(filename);
      if (!fullPath) {
        return { success: false, message: 'Archivo de respaldo no encontrado en disco.' };
      }

      // Crear un respaldo de seguridad del estado actual antes de sobreescribir
      this.createManualBackup('pre_restore');

      const content = fs.readFileSync(fullPath, 'utf-8');
      const parsed = JSON.parse(content);

      if (!parsed || typeof parsed !== 'object') {
        return { success: false, message: 'El archivo de respaldo está corrupto o es inválido.' };
      }

      const dbPath = getDbFilePath();
      atomicWriteJson(dbPath, parsed);
      return { success: true, message: `Base de datos restaurada correctamente desde ${filename}` };
    } catch (err: any) {
      return { success: false, message: `Error al restaurar: ${err.message}` };
    }
  },

  /**
   * Limpia respaldos antiguos conservando los últimos 30 días
   */
  cleanupOldBackups(): void {
    try {
      const backupsDir = ensureBackupsDir();
      const files = fs.readdirSync(backupsDir);
      const now = Date.now();
      const maxAgeMs = MAX_BACKUP_DAYS * 24 * 60 * 60 * 1000;

      files.forEach((file) => {
        if (file.startsWith('db_backup_') && file.endsWith('.json')) {
          const filePath = path.join(backupsDir, file);
          const stats = fs.statSync(filePath);
          if (now - stats.mtimeMs > maxAgeMs) {
            fs.unlinkSync(filePath);
          }
        }
      });
    } catch (err) {
      console.error('Error during cleanupOldBackups:', err);
    }
  },
};
