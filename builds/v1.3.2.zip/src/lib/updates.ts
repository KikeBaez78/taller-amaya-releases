import fs from 'fs';
import path from 'path';

export interface AppVersionInfo {
  version: string;
  buildDate: string;
  channel: string;
  ownerPin: string;
  updateManifestUrl?: string;
}

export interface RemoteUpdateManifest {
  version: string;
  releaseDate: string;
  title: string;
  description: string;
  changelog: string[];
  downloadUrl?: string;
  mandatory?: boolean;
}

function getVersionFilePaths(): string[] {
  const cwd = process.cwd();
  const paths = [
    path.join(cwd, 'src', 'data', 'version.json'),
    path.join(cwd, '.next', 'standalone', 'src', 'data', 'version.json'),
    path.resolve(cwd, '..', '..', 'src', 'data', 'version.json'),
    path.resolve(cwd, '..', '..', '.next', 'standalone', 'src', 'data', 'version.json'),
    path.resolve(cwd, '..', 'src', 'data', 'version.json'),
  ];
  return Array.from(new Set(paths));
}

/**
 * Obtiene la versión local instalada actualmente
 */
export function getCurrentVersionInfo(): AppVersionInfo {
  try {
    const candidatePaths = getVersionFilePaths();
    for (const vPath of candidatePaths) {
      if (fs.existsSync(vPath)) {
        const raw = fs.readFileSync(vPath, 'utf8');
        const parsed = JSON.parse(raw) as AppVersionInfo;
        if (parsed && parsed.version) {
          return parsed;
        }
      }
    }
  } catch (e) {
    console.error('Error al leer version.json:', e);
  }

  return {
    version: '1.2.8',
    buildDate: '2026-11-20',
    channel: 'production',
    ownerPin: '2036',
    updateManifestUrl: 'https://raw.githubusercontent.com/kikebaez78/taller-amaya-releases/main/version.json',
  };
}

/**
 * Compara dos versiones SemVer (ej: 1.1.0 > 1.0.0)
 * Retorna true si remote > current
 */
export function isNewerVersion(remoteVer: string, currentVer: string): boolean {
  if (!remoteVer || !currentVer) return false;

  const clean = (v: string) => v.replace(/^v/i, '').trim();
  const rParts = clean(remoteVer).split('.').map((n) => parseInt(n, 10) || 0);
  const cParts = clean(currentVer).split('.').map((n) => parseInt(n, 10) || 0);

  const maxLen = Math.max(rParts.length, cParts.length);
  for (let i = 0; i < maxLen; i++) {
    const r = rParts[i] || 0;
    const c = cParts[i] || 0;
    if (r > c) return true;
    if (r < c) return false;
  }
  return false;
}

/**
 * Consulta la nube para ver si hay una versión más reciente
 */
export async function checkRemoteForUpdates(): Promise<{
  hasUpdate: boolean;
  currentVersion: string;
  remoteInfo?: RemoteUpdateManifest;
  offline?: boolean;
  error?: string;
}> {
  const currentInfo = getCurrentVersionInfo();
  const manifestUrl = currentInfo.updateManifestUrl;

  if (!manifestUrl) {
    return {
      hasUpdate: false,
      currentVersion: currentInfo.version,
      error: 'No hay URL de actualizaciones configurada',
    };
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 6000); // 6s timeout

    const res = await fetch(manifestUrl, {
      signal: controller.signal,
      headers: { 'Cache-Control': 'no-cache' },
    });
    clearTimeout(timeout);

    if (!res.ok) {
      throw new Error(`Servidor remoto respondió con estatus: ${res.status}`);
    }

    const remoteData = (await res.json()) as RemoteUpdateManifest;
    const hasUpdate = isNewerVersion(remoteData.version, currentInfo.version);

    return {
      hasUpdate,
      currentVersion: currentInfo.version,
      remoteInfo: remoteData,
    };
  } catch (err: any) {
    // Si no hay internet o está offline, no romper nada, retornar offline: true
    return {
      hasUpdate: false,
      currentVersion: currentInfo.version,
      offline: true,
      error: 'Sin conexión para verificar actualizaciones (el sistema sigue operando normalmente).',
    };
  }
}

/**
 * Guarda una nueva versión aplicada localmente
 */
export function recordAppliedVersion(newVersion: string, buildDate?: string) {
  try {
    const current = getCurrentVersionInfo();
    const updated: AppVersionInfo = {
      ...current,
      version: newVersion,
      buildDate: buildDate || new Date().toISOString().split('T')[0],
    };
    const content = JSON.stringify(updated, null, 2);
    const candidatePaths = getVersionFilePaths();
    for (const vPath of candidatePaths) {
      try {
        const dir = path.dirname(vPath);
        if (fs.existsSync(dir)) {
          fs.writeFileSync(vPath, content, 'utf8');
        }
      } catch (writeErr) {
        // Ignorar rutas secundarias inaccesibles
      }
    }
    return updated;
  } catch (e) {
    console.error('Error al actualizar version.json:', e);
    return null;
  }
}
