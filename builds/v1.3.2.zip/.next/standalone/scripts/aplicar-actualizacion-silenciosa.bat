@echo off
title ACTUALIZADOR SILENCIOSO TALLER AMAYA

:: 1. Esperar 2 segundos para permitir que la respuesta HTTP termine de enviarse al navegador
ping 127.0.0.1 -n 3 >nul 2>&1

:: 2. Cerrar procesos previos de Node para liberar el bloqueo de archivos en Windows
taskkill /F /IM node.exe >nul 2>&1
ping 127.0.0.1 -n 2 >nul 2>&1

:: 3. Detectar la verdadera carpeta raiz del proyecto Taller Amaya
set "ROOT="
if exist "%~dp0..\INICIAR-TALLER-AMAYA.bat" set "ROOT=%~dp0.."
if not defined ROOT if exist "%~dp0..\..\..\INICIAR-TALLER-AMAYA.bat" set "ROOT=%~dp0..\..\.."
if not defined ROOT if exist "%~dp0..\..\INICIAR-TALLER-AMAYA.bat" set "ROOT=%~dp0..\.."
if not defined ROOT if exist "%USERPROFILE%\Desktop\taller-amaya\INICIAR-TALLER-AMAYA.bat" set "ROOT=%USERPROFILE%\Desktop\taller-amaya"
if not defined ROOT if exist "C:\Users\TALLER\Desktop\taller-amaya\INICIAR-TALLER-AMAYA.bat" set "ROOT=C:\Users\TALLER\Desktop\taller-amaya"
if not defined ROOT if exist "C:\taller-amaya\INICIAR-TALLER-AMAYA.bat" set "ROOT=C:\taller-amaya"
if not defined ROOT set "ROOT=%~dp0.."

cd /d "%ROOT%"

:: 4. Respaldar datos y licencia si existen
if not exist "%ROOT%\src\data\backups" mkdir "%ROOT%\src\data\backups" >nul 2>&1
if exist "%ROOT%\src\data\db.json" (
    copy /y "%ROOT%\src\data\db.json" "%ROOT%\src\data\backups\respaldo_pre_ota.json" >nul 2>&1
)
if exist "%ROOT%\src\data\license.json" (
    copy /y "%ROOT%\src\data\license.json" "%ROOT%\src\data\backups\respaldo_pre_ota_license.json" >nul 2>&1
)

:: 5. Buscar el archivo zip de actualizacion
set "ZIP_FOUND="
if exist "%ROOT%\temp_ota_update.zip" set "ZIP_FOUND=%ROOT%\temp_ota_update.zip"
if exist "%ROOT%\.next\standalone\temp_ota_update.zip" set "ZIP_FOUND=%ROOT%\.next\standalone\temp_ota_update.zip"

:: 6. Extraer actualización limpia en la raíz del proyecto
if defined ZIP_FOUND (
    tar -xf "%ZIP_FOUND%" -C "%ROOT%" >nul 2>&1
    if errorlevel 1 (
        powershell -NoProfile -Command "Expand-Archive -Path '%ZIP_FOUND%' -DestinationPath '%ROOT%' -Force" >nul 2>&1
    )
    if exist "%ROOT%\temp_ota_update.zip" del /f /q "%ROOT%\temp_ota_update.zip" >nul 2>&1
    if exist "%ROOT%\.next\standalone\temp_ota_update.zip" del /f /q "%ROOT%\.next\standalone\temp_ota_update.zip"
)

:: 7. Asegurar que los assets estáticos queden disponibles para standalone
if exist "%ROOT%\.next\static" (
    xcopy /E /I /Y /Q "%ROOT%\.next\static" "%ROOT%\.next\standalone\.next\static" >nul 2>&1
)
if exist "%ROOT%\public" (
    xcopy /E /I /Y /Q "%ROOT%\public" "%ROOT%\.next\standalone\public" >nul 2>&1
)

:: 8. Limpiar cache de Next.js
if exist "%ROOT%\.next\cache" rd /s /q "%ROOT%\.next\cache" >nul 2>&1

:: 9. Re-iniciar el sistema automáticamente en segundo plano con motor nativo 1.2.1
if exist "%ROOT%\scripts\iniciar-taller-silencioso.vbs" (
    start wscript "%ROOT%\scripts\iniciar-taller-silencioso.vbs"
) else (
    start wscript "%~dp0\iniciar-taller-silencioso.vbs"
)

exit
