@echo off
title TALLER AMAYA - SISTEMA AUTOMOTRIZ
color 0A

cd /d "%~dp0"

echo ========================================================
echo          INICIANDO TALLER AMAYA (MODO OFICIAL)
echo ========================================================
echo.

start wscript scripts\iniciar-taller-silencioso.vbs
timeout /t 2 >nul
exit
